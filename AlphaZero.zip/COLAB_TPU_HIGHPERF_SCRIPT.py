"""
AlphaZero Chess - HIGH PERFORMANCE TPU Training Script
Runtime: TPU v5e-1 (or v4-8)
Workers: 16 parallel workers
MCTS Quality: 1800 simulations (tournament-grade)
Duration: 1 Hour

🎯 KEY FEATURES:
- Automatic Drive checkpoint saving (every 10 min)
- GitHub clone (no ZIP upload needed)
- 16 workers for maximum throughput
- 1800 MCTS simulations for high-quality training

Instructions:
1. Open https://colab.research.google.com/notebooks/tpu.ipynb#
2. Change Runtime → Runtime type → TPU
3. Copy this entire script into a code cell
4. Run the cell (Shift+Enter)
5. Checkpoints auto-save to Drive - NO MANUAL ACTION NEEDED

Author: AlphaZero Chess Team
GitHub: https://github.com/AlphaZero-Chess/X
"""

# ============================================================================
# SECTION 1: ENVIRONMENT SETUP
# ============================================================================

print("="*80)
print("🚀 AlphaZero Chess - HIGH PERFORMANCE TPU Training")
print("   Workers: 16 | MCTS: 1800 | Quality: Tournament-Grade")
print("="*80)

# Mount Google Drive for checkpoint persistence
print("\n📁 Mounting Google Drive...")
from google.colab import drive
drive.mount('/content/drive', force_remount=True)
print("✅ Google Drive mounted at /content/drive")

# Create checkpoint directories
import os
from pathlib import Path

# Local checkpoint directory (fast I/O)
LOCAL_CHECKPOINT_DIR = Path("/content/alphazero/checkpoints")
LOCAL_CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

# Drive checkpoint directory (persistent storage - AUTOMATIC SAVING)
DRIVE_CHECKPOINT_DIR = Path("/content/drive/MyDrive/AlphaZero_Training_HighPerf")
DRIVE_CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

print(f"✅ Local checkpoints: {LOCAL_CHECKPOINT_DIR}")
print(f"✅ Drive checkpoints: {DRIVE_CHECKPOINT_DIR}")
print(f"   ⚠️  Checkpoints will AUTO-SAVE to Drive every 10 minutes")

# ============================================================================
# SECTION 2: TPU RUNTIME DETECTION & INITIALIZATION
# ============================================================================

print("\n🔍 Detecting TPU runtime...")

try:
    import torch
    import torch_xla
    import torch_xla.core.xla_model as xm
    
    device = xm.xla_device()
    tpu_cores = xm.xrt_world_size()
    print(f"✅ TPU detected: {device}")
    print(f"   TPU cores available: {tpu_cores}")
    
    if tpu_cores >= 8:
        print(f"   ✅ Sufficient cores for 16 workers (8+ cores available)")
    else:
        print(f"   ⚠️  Only {tpu_cores} cores - will use {tpu_cores * 2} workers")
    
    TPU_AVAILABLE = True
except ImportError:
    print("⚠️  torch_xla not found. Installing TPU dependencies...")
    
    # Install torch-xla for TPU support
    import subprocess
    import sys
    
    commands = [
        # Install torch-xla matching PyTorch version
        "pip install torch-xla -f https://storage.googleapis.com/libtpu-releases/index.html",
        # Install cloud TPU client
        "pip install cloud-tpu-client",
        # Install JAX with TPU support (for jax backend)
        'pip install "jax[tpu]" -f https://storage.googleapis.com/jax-releases/libtpu_releases.html'
    ]
    
    for cmd in commands:
        print(f"   Running: {cmd}")
        subprocess.check_call(cmd.split())
    
    # Re-import after installation
    import torch_xla
    import torch_xla.core.xla_model as xm
    device = xm.xla_device()
    tpu_cores = xm.xrt_world_size()
    print(f"✅ TPU initialized: {device}")
    print(f"   TPU cores: {tpu_cores}")
    TPU_AVAILABLE = True

# ============================================================================
# SECTION 3: ALPHAZERO REPOSITORY SETUP (GITHUB CLONE)
# ============================================================================

print("\n📦 Setting up AlphaZero Chess from GitHub...")

GITHUB_REPO = "https://github.com/AlphaZero-Chess/X.git"
PROJECT_DIR = Path("/content/AlphaZero")

# Check if already cloned
if not PROJECT_DIR.exists():
    print(f"   Cloning from: {GITHUB_REPO}")
    import subprocess
    subprocess.check_call([
        "git", "clone", GITHUB_REPO, str(PROJECT_DIR)
    ])
    print("✅ AlphaZero cloned from GitHub")
else:
    print("✅ AlphaZero repository already present")
    # Pull latest changes
    print("   Pulling latest changes...")
    subprocess.check_call([
        "git", "-C", str(PROJECT_DIR), "pull"
    ])
    print("✅ Repository updated")

# Navigate to backend directory
os.chdir(PROJECT_DIR / "backend")
print(f"📂 Working directory: {os.getcwd()}")

# ============================================================================
# SECTION 4: DEPENDENCIES INSTALLATION
# ============================================================================

print("\n📥 Installing AlphaZero dependencies...")

# Install from requirements.txt (skip TPU packages already installed)
import subprocess

# Read requirements.txt
with open("requirements.txt", "r") as f:
    requirements = [
        line.strip() 
        for line in f 
        if line.strip() 
        and not line.startswith("#")
        and "torch-xla" not in line 
        and "cloud-tpu-client" not in line
        and "jax[tpu]" not in line
    ]

# Install in batches to avoid timeout
print(f"   Installing {len(requirements)} packages...")
batch_size = 50

for i in range(0, len(requirements), batch_size):
    batch = requirements[i:i+batch_size]
    print(f"   Batch {i//batch_size + 1}: Installing {len(batch)} packages...")
    try:
        subprocess.check_call([
            "pip", "install", "-q"
        ] + batch)
    except subprocess.CalledProcessError:
        print(f"   ⚠️  Some packages in batch {i//batch_size + 1} failed, continuing...")

print("✅ All dependencies installed")

# ============================================================================
# SECTION 5: HIGH-PERFORMANCE TRAINING CONFIGURATION
# ============================================================================

print("\n⚙️  Configuring HIGH-PERFORMANCE training parameters...")

# Calculate optimal workers based on TPU cores
try:
    tpu_cores = xm.xrt_world_size()
    NUM_WORKERS = 16  # User requested 16 workers
    
    # Verify we can handle 16 workers
    if tpu_cores >= 8:
        print(f"✅ Using 16 workers (8 TPU cores × 2 workers/core)")
    else:
        NUM_WORKERS = max(8, tpu_cores * 2)
        print(f"⚠️  Adjusted to {NUM_WORKERS} workers (limited by {tpu_cores} cores)")
except:
    NUM_WORKERS = 16
    print(f"✅ Using {NUM_WORKERS} workers (default)")

TRAINING_CONFIG = {
    # Training duration
    "max_training_time_seconds": 3600,  # 1 hour = 3600 seconds
    
    # HIGH PERFORMANCE SETTINGS
    "num_workers": NUM_WORKERS,  # 16 parallel workers
    "mcts_simulations": 1800,    # Tournament-grade quality (1800 MCTS)
    
    # Distributed trainer settings (for 16 workers)
    "replay_buffer_size": 200000,  # Large buffer for quality
    "batch_size": 256,             # Larger batch for distributed
    "learning_rate": 0.001,        # Higher LR for faster convergence
    
    # Training frequency
    "retrain_frequency": 50,       # Retrain every 50 games (more data)
    "elo_gain_threshold": 5.0,     # Higher threshold for quality
    "num_epochs": 5,               # More epochs for better training
    "evaluation_games": 10,        # More eval games for accuracy
    
    # Checkpoint settings (AUTOMATIC DRIVE SAVING)
    "checkpoint_interval": 600,  # Save every 10 minutes AUTOMATICALLY
    "local_checkpoint_dir": str(LOCAL_CHECKPOINT_DIR),
    "drive_checkpoint_dir": str(DRIVE_CHECKPOINT_DIR)
}

print("✅ HIGH-PERFORMANCE Configuration:")
print(f"   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
print(f"   🚀 Workers: {TRAINING_CONFIG['num_workers']}")
print(f"   🎯 MCTS Simulations: {TRAINING_CONFIG['mcts_simulations']}")
print(f"   📊 Batch Size: {TRAINING_CONFIG['batch_size']}")
print(f"   🎓 Learning Rate: {TRAINING_CONFIG['learning_rate']}")
print(f"   🔄 Replay Buffer: {TRAINING_CONFIG['replay_buffer_size']:,}")
print(f"   💾 Auto-save to Drive: Every {TRAINING_CONFIG['checkpoint_interval']//60} minutes")
print(f"   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

# ============================================================================
# SECTION 6: HIGH-PERFORMANCE TRAINING EXECUTION (1 HOUR)
# ============================================================================

print("\n" + "="*80)
print("🏋️  STARTING 1-HOUR HIGH-PERFORMANCE TPU TRAINING")
print("   16 Workers | 1800 MCTS | Tournament Quality")
print("="*80)

import time
import logging
from datetime import datetime, timedelta

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOCAL_CHECKPOINT_DIR / "training.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Import AlphaZero modules
try:
    # Use DistributedTPUTrainer for 16 workers
    from distributed_tpu_trainer import DistributedTPUTrainer
    from neural_network import AlphaZeroNetwork, ModelManager
    from config_loader import load_config
    
    # Initialize distributed trainer with high-performance settings
    trainer = DistributedTPUTrainer(
        num_workers=TRAINING_CONFIG["num_workers"],
        replay_buffer_size=TRAINING_CONFIG["replay_buffer_size"],
        batch_size=TRAINING_CONFIG["batch_size"],
        learning_rate=TRAINING_CONFIG["learning_rate"],
        num_simulations=TRAINING_CONFIG["mcts_simulations"]
    )
    
    logger.info(f"✅ Distributed TPU Trainer initialized")
    logger.info(f"   Workers: {TRAINING_CONFIG['num_workers']}")
    logger.info(f"   MCTS Simulations: {TRAINING_CONFIG['mcts_simulations']}")
    logger.info(f"   Batch Size: {TRAINING_CONFIG['batch_size']}")
    logger.info(f"   TPU Backend: torch_xla")
    
    # Training timer
    start_time = time.time()
    end_time = start_time + TRAINING_CONFIG["max_training_time_seconds"]
    next_checkpoint_time = start_time + TRAINING_CONFIG["checkpoint_interval"]
    
    training_cycles_completed = 0
    
    print(f"\n⏱️  Training will run until: {datetime.fromtimestamp(end_time).strftime('%H:%M:%S')}")
    print(f"   Duration: {TRAINING_CONFIG['max_training_time_seconds'] / 60:.0f} minutes")
    print(f"   💾 Checkpoints AUTO-SAVE to: {DRIVE_CHECKPOINT_DIR}")
    print()
    
    # Load baseline model
    config = load_config()
    active_model_name = config.get('active_model', 'ActiveModel_Offline.pth')
    model_path = trainer.model_manager.get_model_path(Path(active_model_name).stem)
    
    if not model_path.exists():
        logger.warning(f"Active model not found, creating baseline...")
        baseline_network = AlphaZeroNetwork()
        trainer.model_manager.save_model(baseline_network, name="Baseline_HighPerf", metadata={
            'mcts_simulations': TRAINING_CONFIG['mcts_simulations'],
            'workers': TRAINING_CONFIG['num_workers']
        })
        model_path = trainer.model_manager.get_model_path("Baseline_HighPerf")
    
    # Main training loop
    while time.time() < end_time:
        try:
            cycle_start = time.time()
            remaining_time = end_time - cycle_start
            
            # Check if we have enough time for another cycle (minimum 10 minutes for high-quality)
            if remaining_time < 600:
                logger.info("⏰ Less than 10 minutes remaining - stopping gracefully")
                break
            
            logger.info(f"\n{'='*80}")
            logger.info(f"TRAINING CYCLE {training_cycles_completed + 1}")
            logger.info(f"Time remaining: {remaining_time / 60:.1f} minutes")
            logger.info(f"Workers: {TRAINING_CONFIG['num_workers']} | MCTS: {TRAINING_CONFIG['mcts_simulations']}")
            logger.info(f"{'='*80}\n")
            
            # Phase 1: Distributed Self-Play
            logger.info(f"Phase 1: Parallel self-play ({TRAINING_CONFIG['num_workers']} workers)...")
            
            training_data, game_results = trainer.launch_parallel_selfplay(
                num_games_total=TRAINING_CONFIG['retrain_frequency'],
                model_path=str(model_path)
            )
            
            logger.info(f"✅ Generated {len(training_data)} training positions from {len(game_results)} games")
            
            # Phase 2: Training
            logger.info("Phase 2: Distributed training on TPU...")
            
            network, metadata = trainer.model_manager.load_model(Path(active_model_name).stem)
            
            training_metrics = trainer.run_distributed_training_cycle(
                network=network,
                num_epochs=TRAINING_CONFIG['num_epochs']
            )
            
            training_loss = training_metrics.get('loss', 1.0)
            logger.info(f"✅ Training complete - Loss: {training_loss:.4f}")
            
            # Phase 3: Evaluation
            logger.info(f"Phase 3: Evaluating with {TRAINING_CONFIG['evaluation_games']} games...")
            
            baseline_network, _ = trainer.model_manager.load_model(Path(active_model_name).stem)
            
            eval_results, should_promote = trainer.evaluate_and_promote(
                new_network=network,
                baseline_network=baseline_network,
                num_eval_games=TRAINING_CONFIG['evaluation_games']
            )
            
            win_rate = eval_results.get('challenger_win_rate', 0.5)
            elo_delta = (win_rate - 0.5) * 400
            
            if should_promote:
                logger.info(f"✅ Model improved! Win rate: {win_rate:.1%}, ELO: {elo_delta:+.1f}")
                
                # Save improved model
                model_name = f"HighPerfModel_v{training_cycles_completed + 1}_{int(time.time())}"
                model_path = trainer.model_manager.save_model(network, name=model_name, metadata={
                    'win_rate': win_rate,
                    'elo_delta': elo_delta,
                    'training_loss': training_loss,
                    'workers': TRAINING_CONFIG['num_workers'],
                    'mcts_simulations': TRAINING_CONFIG['mcts_simulations'],
                    'games_trained': len(game_results)
                })
                
                logger.info(f"💾 Model saved: {model_name}")
            else:
                logger.warning(f"⚠️  Model did not improve (win rate: {win_rate:.1%}), keeping baseline")
            
            training_cycles_completed += 1
            cycle_duration = time.time() - cycle_start
            
            logger.info(f"✅ Cycle {training_cycles_completed} complete in {cycle_duration / 60:.1f} minutes")
            
            # AUTOMATIC CHECKPOINT TO DRIVE (every 10 minutes)
            if time.time() >= next_checkpoint_time:
                logger.info("💾 AUTOMATIC CHECKPOINT - Syncing to Google Drive...")
                
                # Copy checkpoints from local to Drive
                import shutil
                files_synced = 0
                
                for checkpoint_file in LOCAL_CHECKPOINT_DIR.glob("*.pth"):
                    drive_path = DRIVE_CHECKPOINT_DIR / checkpoint_file.name
                    shutil.copy2(checkpoint_file, drive_path)
                    logger.info(f"   ✅ Synced: {checkpoint_file.name}")
                    files_synced += 1
                
                # Also save training state and logs
                for state_file in LOCAL_CHECKPOINT_DIR.glob("*.json"):
                    shutil.copy2(state_file, DRIVE_CHECKPOINT_DIR / state_file.name)
                    files_synced += 1
                
                # Copy log file
                log_file = LOCAL_CHECKPOINT_DIR / "training.log"
                if log_file.exists():
                    shutil.copy2(log_file, DRIVE_CHECKPOINT_DIR / "training.log")
                    files_synced += 1
                
                next_checkpoint_time = time.time() + TRAINING_CONFIG["checkpoint_interval"]
                logger.info(f"✅ {files_synced} files automatically saved to Google Drive")
                logger.info(f"   Location: {DRIVE_CHECKPOINT_DIR}")
        
        except KeyboardInterrupt:
            logger.info("⚠️  Training interrupted by user")
            break
        
        except Exception as e:
            logger.error(f"❌ Error in training cycle: {e}")
            import traceback
            traceback.print_exc()
            # Continue to next cycle
            time.sleep(5)
    
    # FINAL AUTOMATIC CHECKPOINT TO DRIVE
    logger.info("\n" + "="*80)
    logger.info("💾 FINAL CHECKPOINT - Saving all progress to Google Drive")
    logger.info("="*80)
    
    import shutil
    
    # Copy all checkpoints
    final_files = 0
    for checkpoint_file in LOCAL_CHECKPOINT_DIR.glob("*"):
        if checkpoint_file.is_file():
            drive_path = DRIVE_CHECKPOINT_DIR / checkpoint_file.name
            shutil.copy2(checkpoint_file, drive_path)
            logger.info(f"   ✅ {checkpoint_file.name}")
            final_files += 1
    
    # Training summary
    total_time = time.time() - start_time
    
    print("\n" + "="*80)
    print("🎉 HIGH-PERFORMANCE TRAINING SESSION COMPLETE")
    print("="*80)
    print(f"✅ Total duration: {total_time / 60:.1f} minutes")
    print(f"✅ Training cycles completed: {training_cycles_completed}")
    print(f"✅ Files saved to Drive: {final_files}")
    print(f"\n📊 Training Configuration:")
    print(f"   - Workers: {TRAINING_CONFIG['num_workers']}")
    print(f"   - MCTS Simulations: {TRAINING_CONFIG['mcts_simulations']}")
    print(f"   - Batch Size: {TRAINING_CONFIG['batch_size']}")
    print(f"   - Learning Rate: {TRAINING_CONFIG['learning_rate']}")
    print(f"\n📁 ALL CHECKPOINTS AUTOMATICALLY SAVED TO:")
    print(f"   {DRIVE_CHECKPOINT_DIR}")
    print(f"\n✅ You can now download checkpoints from Google Drive!")
    print(f"   No manual saving needed - everything is automatic! 🚀")

except ImportError as e:
    logger.error(f"❌ Failed to import AlphaZero modules: {e}")
    logger.error("   Make sure the project structure is correct")
    import traceback
    traceback.print_exc()
    raise

except Exception as e:
    logger.error(f"❌ Training error: {e}")
    import traceback
    traceback.print_exc()
    raise

# ============================================================================
# SECTION 7: TRAINING REPORT GENERATION
# ============================================================================

print("\n" + "="*80)
print("📈 GENERATING HIGH-PERFORMANCE TRAINING REPORT")
print("="*80)

try:
    # Generate comprehensive report
    report_data = {
        'session_summary': {
            'configuration': 'HIGH-PERFORMANCE',
            'workers': TRAINING_CONFIG['num_workers'],
            'mcts_simulations': TRAINING_CONFIG['mcts_simulations'],
            'duration_minutes': total_time / 60,
            'cycles_completed': training_cycles_completed,
            'tpu_cores_used': tpu_cores,
            'quality_level': 'Tournament-Grade'
        },
        'performance_metrics': {
            'average_cycle_time_minutes': (total_time / 60) / max(training_cycles_completed, 1),
            'games_per_hour': (training_cycles_completed * TRAINING_CONFIG['retrain_frequency']) / (total_time / 3600),
        },
        'checkpoint_info': {
            'total_checkpoints': final_files,
            'location': str(DRIVE_CHECKPOINT_DIR),
            'automatic_saves': training_cycles_completed * (total_time // TRAINING_CONFIG['checkpoint_interval'])
        }
    }
    
    # Save report to Drive
    import json
    report_file = DRIVE_CHECKPOINT_DIR / "training_report_highperf.json"
    with open(report_file, 'w') as f:
        json.dump(report_data, f, indent=2)
    
    print(f"\n✅ Full report automatically saved to Drive:")
    print(f"   {report_file}")
    
    print(f"\n📊 Quick Stats:")
    print(f"   Average cycle time: {report_data['performance_metrics']['average_cycle_time_minutes']:.1f} min")
    print(f"   Games per hour: {report_data['performance_metrics']['games_per_hour']:.0f}")
    print(f"   Total checkpoints: {report_data['checkpoint_info']['total_checkpoints']}")

except Exception as e:
    logger.warning(f"Could not generate report: {e}")

print("\n" + "="*80)
print("✅ ALL DONE! Check your Google Drive for checkpoints.")
print("   Location: MyDrive/AlphaZero_Training_HighPerf/")
print("="*80)
print("\n🚀 Checkpoints were AUTOMATICALLY SAVED - no manual action needed!")
print("   Every 10 minutes + final save at completion")
