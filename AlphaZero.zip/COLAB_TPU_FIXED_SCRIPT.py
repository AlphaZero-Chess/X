"""
AlphaZero Chess TPU Training - COLAB-COMPATIBLE VERSION
Fixes dependency conflicts with Google Colab

IMPORTANT: Copy this ENTIRE script and paste directly into a Colab cell.
DO NOT save as .py file and run with !python

Runtime: TPU v5e-1
Workers: 16
MCTS: 1800
Duration: 1 hour
"""

# ============================================================================
# SECTION 0: COLAB ENVIRONMENT CHECK
# ============================================================================

print("="*80)
print("🚀 AlphaZero Chess - TPU Training (Colab-Compatible)")
print("="*80)

# Check if running in Colab
try:
    from google.colab import drive
    IN_COLAB = True
    print("✅ Running in Google Colab")
except ImportError:
    IN_COLAB = False
    print("❌ Not in Colab - this script requires Google Colab!")
    raise RuntimeError("This script must be run in Google Colab")

# ============================================================================
# SECTION 1: FIX DEPENDENCY CONFLICTS
# ============================================================================

print("\n🔧 Fixing dependency conflicts...")

import subprocess
import sys

# Uninstall conflicting packages first
conflicting_packages = [
    'google-auth',
    'pandas', 
    'requests',
    'fsspec',
    'rich',
    'torch',
    'fastapi',
    'pillow',
    'pydantic',
    'starlette',
    'numpy'
]

print("   Removing conflicting packages...")
for pkg in conflicting_packages:
    try:
        subprocess.run([sys.executable, '-m', 'pip', 'uninstall', '-y', pkg], 
                      stdout=subprocess.DEVNULL, 
                      stderr=subprocess.DEVNULL)
    except:
        pass

# Install compatible versions for Colab
print("   Installing compatible versions...")

compatible_versions = {
    'google-auth': '2.38.0',  # Colab required version
    'pandas': '2.2.2',         # Colab required version
    'requests': '2.32.4',      # Colab required version
    'numpy': '1.26.4',         # Compatible with numba
    'torch': '2.5.1',          # Compatible with fastai
    'fastapi': '0.115.2',      # Compatible with gradio
    'pillow': '11.0.0',        # Compatible with gradio
    'pydantic': '2.10.0',      # Compatible with gradio
    'starlette': '0.40.0',     # Compatible with gradio
    'rich': '13.9.4',          # Compatible with bigframes
    'fsspec': '2024.12.0'      # Compatible with datasets
}

install_cmd = ['pip', 'install', '-q']
for pkg, version in compatible_versions.items():
    install_cmd.append(f"{pkg}=={version}")

subprocess.check_call(install_cmd)

print("✅ Dependencies fixed")

# ============================================================================
# SECTION 2: RESTART WARNING
# ============================================================================

print("\n⚠️  IMPORTANT: Runtime restart may be needed")
print("   If you see numpy/pandas warnings, click:")
print("   Runtime → Restart runtime")
print("   Then re-run this cell")
print("")

# Check if restart needed
try:
    import numpy as np
    import pandas as pd
    print("✅ Core packages loaded successfully")
except Exception as e:
    print(f"❌ Package import failed: {e}")
    print("   Please restart runtime and re-run")
    raise

# ============================================================================
# SECTION 3: MOUNT GOOGLE DRIVE
# ============================================================================

print("\n📁 Mounting Google Drive...")

try:
    drive.mount('/content/drive', force_remount=False)
    print("✅ Google Drive mounted")
except Exception as e:
    print(f"❌ Drive mount failed: {e}")
    print("   Trying alternative mount method...")
    try:
        drive.mount('/content/drive')
        print("✅ Google Drive mounted (alternative method)")
    except:
        print("❌ Could not mount Drive. Please authorize manually.")
        raise

# ============================================================================
# SECTION 4: SETUP DIRECTORIES
# ============================================================================

import os
from pathlib import Path

LOCAL_CHECKPOINT_DIR = Path("/content/alphazero/checkpoints")
LOCAL_CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

DRIVE_CHECKPOINT_DIR = Path("/content/drive/MyDrive/AlphaZero_Training_HighPerf")
DRIVE_CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

print(f"✅ Local checkpoints: {LOCAL_CHECKPOINT_DIR}")
print(f"✅ Drive checkpoints: {DRIVE_CHECKPOINT_DIR}")

# ============================================================================
# SECTION 5: INSTALL TPU DEPENDENCIES
# ============================================================================

print("\n🔧 Installing TPU dependencies...")

# Install torch-xla (compatible with torch 2.5.1)
subprocess.check_call([
    'pip', 'install', '-q',
    'torch-xla==2.5.1',
    '-f', 'https://storage.googleapis.com/libtpu-releases/index.html'
])

# Install cloud TPU client
subprocess.check_call(['pip', 'install', '-q', 'cloud-tpu-client'])

# Install JAX with TPU support
subprocess.check_call([
    'pip', 'install', '-q',
    'jax[tpu]',
    '-f', 'https://storage.googleapis.com/jax-releases/libtpu_releases.html'
])

print("✅ TPU dependencies installed")

# ============================================================================
# SECTION 6: VERIFY TPU
# ============================================================================

print("\n🔍 Detecting TPU runtime...")

try:
    import torch
    import torch_xla
    import torch_xla.core.xla_model as xm
    
    device = xm.xla_device()
    tpu_cores = xm.xrt_world_size()
    print(f"✅ TPU detected: {device}")
    print(f"   TPU cores available: {tpu_cores}")
    
    if tpu_cores >= 8:
        print(f"   ✅ Sufficient cores for 16 workers")
    else:
        print(f"   ⚠️  Only {tpu_cores} cores available")
        print(f"   Will use {tpu_cores * 2} workers instead of 16")
    
    TPU_AVAILABLE = True
except Exception as e:
    print(f"❌ TPU detection failed: {e}")
    print("   Make sure Runtime Type is set to TPU")
    print("   Runtime → Change runtime type → TPU → Save")
    raise

# ============================================================================
# SECTION 7: CLONE ALPHAZERO REPOSITORY
# ============================================================================

print("\n📦 Setting up AlphaZero Chess from GitHub...")

GITHUB_REPO = "https://github.com/AlphaZero-Chess/X.git"
PROJECT_DIR = Path("/content/AlphaZero")

if not PROJECT_DIR.exists():
    print(f"   Cloning from: {GITHUB_REPO}")
    subprocess.check_call([
        'git', 'clone', '--quiet', GITHUB_REPO, str(PROJECT_DIR)
    ])
    print("✅ AlphaZero cloned from GitHub")
else:
    print("✅ AlphaZero repository already present")
    # Pull latest changes
    print("   Pulling latest changes...")
    subprocess.check_call([
        'git', '-C', str(PROJECT_DIR), 'pull', '--quiet'
    ])
    print("✅ Repository updated")

# Navigate to backend
os.chdir(PROJECT_DIR / "backend")
print(f"📂 Working directory: {os.getcwd()}")

# ============================================================================
# SECTION 8: INSTALL ALPHAZERO DEPENDENCIES
# ============================================================================

print("\n📥 Installing AlphaZero dependencies...")

# Read requirements but skip conflicting packages
with open("requirements.txt", "r") as f:
    requirements = []
    skip_packages = ['google-auth', 'pandas', 'requests', 'torch', 'numpy', 
                     'fastapi', 'pillow', 'pydantic', 'starlette', 'rich',
                     'torch-xla', 'cloud-tpu-client', 'fsspec']
    
    for line in f:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        
        # Extract package name
        pkg_name = line.split('==')[0].split('>=')[0].split('<=')[0]
        
        # Skip if in conflict list
        if pkg_name.lower() in [p.lower() for p in skip_packages]:
            continue
        
        requirements.append(line)

# Install in batches
batch_size = 30
for i in range(0, len(requirements), batch_size):
    batch = requirements[i:i+batch_size]
    print(f"   Batch {i//batch_size + 1}: {len(batch)} packages...")
    try:
        subprocess.check_call(['pip', 'install', '-q'] + batch)
    except subprocess.CalledProcessError as e:
        print(f"   ⚠️  Some packages failed, continuing... ({e})")

print("✅ Dependencies installed")

# ============================================================================
# SECTION 9: TRAINING CONFIGURATION
# ============================================================================

print("\n⚙️  Configuring HIGH-PERFORMANCE training...")

NUM_WORKERS = min(16, tpu_cores * 2)  # Adjust based on available cores

TRAINING_CONFIG = {
    "max_training_time_seconds": 3600,  # 1 hour
    "num_workers": NUM_WORKERS,
    "mcts_simulations": 1800,
    "replay_buffer_size": 200000,
    "batch_size": 256,
    "learning_rate": 0.001,
    "retrain_frequency": 50,
    "elo_gain_threshold": 5.0,
    "num_epochs": 5,
    "evaluation_games": 10,
    "checkpoint_interval": 600,  # 10 minutes
    "local_checkpoint_dir": str(LOCAL_CHECKPOINT_DIR),
    "drive_checkpoint_dir": str(DRIVE_CHECKPOINT_DIR)
}

print("✅ Configuration:")
print(f"   Workers: {TRAINING_CONFIG['num_workers']}")
print(f"   MCTS: {TRAINING_CONFIG['mcts_simulations']}")
print(f"   Batch size: {TRAINING_CONFIG['batch_size']}")
print(f"   Duration: {TRAINING_CONFIG['max_training_time_seconds']//60} minutes")

# ============================================================================
# SECTION 10: TRAINING EXECUTION
# ============================================================================

print("\n" + "="*80)
print("🏋️  STARTING 1-HOUR HIGH-PERFORMANCE TPU TRAINING")
print(f"   {NUM_WORKERS} Workers | 1800 MCTS | Tournament Quality")
print("="*80)

import time
import logging
from datetime import datetime

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

try:
    # Import training modules
    from distributed_tpu_trainer import DistributedTPUTrainer
    from neural_network import AlphaZeroNetwork, ModelManager
    from config_loader import load_config
    
    # Initialize trainer
    trainer = DistributedTPUTrainer(
        num_workers=TRAINING_CONFIG["num_workers"],
        replay_buffer_size=TRAINING_CONFIG["replay_buffer_size"],
        batch_size=TRAINING_CONFIG["batch_size"],
        learning_rate=TRAINING_CONFIG["learning_rate"],
        num_simulations=TRAINING_CONFIG["mcts_simulations"]
    )
    
    logger.info("✅ Distributed TPU Trainer initialized")
    
    # Load or create baseline model
    model_manager = ModelManager()
    config = load_config()
    active_model_name = config.get('active_model', 'ActiveModel_Offline.pth')
    model_path = model_manager.get_model_path(Path(active_model_name).stem)
    
    if not model_path.exists():
        logger.info("Creating baseline model...")
        baseline_network = AlphaZeroNetwork()
        model_manager.save_model(baseline_network, name="Baseline_HighPerf", metadata={
            'mcts_simulations': TRAINING_CONFIG['mcts_simulations'],
            'workers': TRAINING_CONFIG['num_workers']
        })
        model_path = model_manager.get_model_path("Baseline_HighPerf")
    
    # Training timer
    start_time = time.time()
    end_time = start_time + TRAINING_CONFIG["max_training_time_seconds"]
    next_checkpoint_time = start_time + TRAINING_CONFIG["checkpoint_interval"]
    
    training_cycles = 0
    
    print(f"\n⏱️  Training until: {datetime.fromtimestamp(end_time).strftime('%H:%M:%S')}")
    print(f"   Duration: {TRAINING_CONFIG['max_training_time_seconds']//60} minutes")
    print(f"   💾 Auto-save every {TRAINING_CONFIG['checkpoint_interval']//60} minutes")
    print()
    
    # Main training loop
    while time.time() < end_time:
        try:
            cycle_start = time.time()
            remaining_time = end_time - cycle_start
            
            if remaining_time < 600:  # Less than 10 minutes
                logger.info("⏰ Less than 10 minutes remaining - stopping")
                break
            
            logger.info(f"\n{'='*60}")
            logger.info(f"TRAINING CYCLE {training_cycles + 1}")
            logger.info(f"Time remaining: {remaining_time/60:.1f} minutes")
            logger.info(f"{'='*60}")
            
            # Phase 1: Self-play
            logger.info(f"Phase 1: Self-play ({TRAINING_CONFIG['num_workers']} workers)...")
            training_data, game_results = trainer.launch_parallel_selfplay(
                num_games_total=TRAINING_CONFIG['retrain_frequency'],
                model_path=str(model_path)
            )
            logger.info(f"✅ {len(training_data)} positions from {len(game_results)} games")
            
            # Phase 2: Training
            logger.info("Phase 2: Training on TPU...")
            network, _ = model_manager.load_model(Path(active_model_name).stem)
            training_metrics = trainer.run_distributed_training_cycle(
                network=network,
                num_epochs=TRAINING_CONFIG['num_epochs']
            )
            logger.info(f"✅ Loss: {training_metrics['loss']:.4f}")
            
            # Phase 3: Evaluation  
            logger.info("Phase 3: Evaluation...")
            baseline_network, _ = model_manager.load_model(Path(active_model_name).stem)
            eval_results, should_promote = trainer.evaluate_and_promote(
                new_network=network,
                baseline_network=baseline_network,
                num_eval_games=TRAINING_CONFIG['evaluation_games']
            )
            
            win_rate = eval_results.get('challenger_win_rate', 0.5)
            elo_delta = (win_rate - 0.5) * 400
            
            if should_promote:
                model_name = f"HighPerfModel_v{training_cycles + 1}_{int(time.time())}"
                model_manager.save_model(network, name=model_name, metadata={
                    'win_rate': win_rate,
                    'elo_delta': elo_delta,
                    'training_loss': training_metrics['loss'],
                    'workers': TRAINING_CONFIG['num_workers'],
                    'mcts': TRAINING_CONFIG['mcts_simulations']
                })
                logger.info(f"✅ Model improved! Win rate: {win_rate:.1%}, ELO: {elo_delta:+.1f}")
                logger.info(f"💾 Saved: {model_name}")
            else:
                logger.info(f"⚠️  No improvement (win rate: {win_rate:.1%})")
            
            training_cycles += 1
            cycle_time = time.time() - cycle_start
            logger.info(f"✅ Cycle {training_cycles} complete in {cycle_time/60:.1f} min")
            
            # Checkpoint to Drive
            if time.time() >= next_checkpoint_time:
                logger.info("💾 Checkpoint - Syncing to Drive...")
                import shutil
                synced = 0
                
                for f in LOCAL_CHECKPOINT_DIR.glob("*.pth"):
                    shutil.copy2(f, DRIVE_CHECKPOINT_DIR / f.name)
                    synced += 1
                
                for f in LOCAL_CHECKPOINT_DIR.glob("*.json"):
                    shutil.copy2(f, DRIVE_CHECKPOINT_DIR / f.name)
                    synced += 1
                
                next_checkpoint_time = time.time() + TRAINING_CONFIG["checkpoint_interval"]
                logger.info(f"✅ {synced} files synced to Drive")
        
        except KeyboardInterrupt:
            logger.info("⚠️  Interrupted by user")
            break
        except Exception as e:
            logger.error(f"❌ Cycle failed: {e}")
            import traceback
            traceback.print_exc()
            break
    
    # Final checkpoint
    logger.info("\n💾 FINAL CHECKPOINT - Saving to Drive...")
    import shutil
    final_files = 0
    
    for f in LOCAL_CHECKPOINT_DIR.glob("*"):
        if f.is_file():
            shutil.copy2(f, DRIVE_CHECKPOINT_DIR / f.name)
            final_files += 1
    
    total_time = time.time() - start_time
    
    print("\n" + "="*80)
    print("🎉 TRAINING SESSION COMPLETE")
    print("="*80)
    print(f"✅ Duration: {total_time/60:.1f} minutes")
    print(f"✅ Cycles completed: {training_cycles}")
    print(f"✅ Files saved: {final_files}")
    print(f"\n📁 All checkpoints in: {DRIVE_CHECKPOINT_DIR}")
    print("="*80)
    
except Exception as e:
    logger.error(f"❌ Training failed: {e}")
    import traceback
    traceback.print_exc()
    print("\n💡 TIP: Make sure:")
    print("   1. Runtime is set to TPU")
    print("   2. You restarted runtime after installing packages")
    print("   3. GitHub repo is accessible")

print("\n✅ Script complete!")
