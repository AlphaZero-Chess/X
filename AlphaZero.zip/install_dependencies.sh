#!/bin/bash

# AlphaZero Chess - Dependency Installation Script
# This script installs all required dependencies for TPU training
# Compatible with: Local machine, Google Colab, Cloud TPU VMs

set -e  # Exit on error

echo "============================================================================"
echo "🚀 AlphaZero Chess - Installing Dependencies"
echo "============================================================================"

# Detect environment
if [ -f "/usr/local/lib/python3.*/dist-packages/google/colab/_ipython.py" ]; then
    ENVIRONMENT="colab"
    echo "📍 Environment: Google Colab"
elif [ -d "/usr/share/tpu" ]; then
    ENVIRONMENT="tpu_vm"
    echo "📍 Environment: Cloud TPU VM"
else
    ENVIRONMENT="local"
    echo "📍 Environment: Local machine"
fi

# Step 1: Update pip
echo ""
echo "📦 Step 1/4: Updating pip..."
python3 -m pip install --upgrade pip setuptools wheel -q

# Step 2: Install core dependencies from requirements.txt
echo ""
echo "📦 Step 2/4: Installing core dependencies..."
echo "   (This may take 5-10 minutes)"

if [ -f "requirements.txt" ]; then
    # Filter out TPU-specific packages (install separately)
    grep -v "torch-xla\|cloud-tpu-client\|jax\[tpu\]" requirements.txt > temp_requirements.txt
    
    # Install in batches to avoid timeout
    pip install -r temp_requirements.txt --no-cache-dir -q
    
    rm temp_requirements.txt
    echo "   ✅ Core dependencies installed"
else
    echo "   ⚠️  requirements.txt not found, skipping core dependencies"
fi

# Step 3: Install TPU-specific packages (environment-dependent)
echo ""
echo "📦 Step 3/4: Installing TPU-specific packages..."

if [ "$ENVIRONMENT" = "colab" ] || [ "$ENVIRONMENT" = "tpu_vm" ]; then
    echo "   Installing torch-xla..."
    pip install torch-xla -f https://storage.googleapis.com/libtpu-releases/index.html -q
    
    echo "   Installing cloud-tpu-client..."
    pip install cloud-tpu-client -q
    
    echo "   Installing jax[tpu]..."
    pip install "jax[tpu]" -f https://storage.googleapis.com/jax-releases/libtpu_releases.html -q
    
    echo "   ✅ TPU packages installed"
else
    echo "   ⚠️  Skipping TPU packages (not in TPU environment)"
    echo "   To install manually:"
    echo "   pip install torch-xla -f https://storage.googleapis.com/libtpu-releases/index.html"
    echo "   pip install cloud-tpu-client"
    echo "   pip install 'jax[tpu]' -f https://storage.googleapis.com/jax-releases/libtpu_releases.html"
fi

# Step 4: Verify critical packages
echo ""
echo "📦 Step 4/4: Verifying installation..."

CRITICAL_PACKAGES=(
    "torch"
    "numpy"
    "chess"
    "optuna"
    "fastapi"
    "emergentintegrations"
    "scikit-learn"
    "pandas"
)

ALL_OK=true

for package in "${CRITICAL_PACKAGES[@]}"; do
    if python3 -c "import $package" 2>/dev/null; then
        echo "   ✅ $package"
    else
        echo "   ❌ $package - MISSING"
        ALL_OK=false
    fi
done

# Verify TPU packages (if in TPU environment)
if [ "$ENVIRONMENT" = "colab" ] || [ "$ENVIRONMENT" = "tpu_vm" ]; then
    if python3 -c "import torch_xla" 2>/dev/null; then
        echo "   ✅ torch_xla (TPU support)"
    else
        echo "   ❌ torch_xla - MISSING"
        ALL_OK=false
    fi
fi

echo ""
echo "============================================================================"

if [ "$ALL_OK" = true ]; then
    echo "✅ ALL DEPENDENCIES INSTALLED SUCCESSFULLY"
    echo ""
    echo "📊 Installed packages:"
    pip list | grep -E "torch|numpy|chess|optuna|fastapi|jax|xla"
    echo ""
    echo "🚀 Ready to train! Run:"
    echo "   python3 adaptive_trainer_tpu.py"
    echo "   or use the Colab training script"
else
    echo "⚠️  SOME DEPENDENCIES ARE MISSING"
    echo "   Please review errors above and install manually"
    exit 1
fi

echo "============================================================================"
