# AlphaZero Chess - TPU Training Guide for Google Colab

## 🎯 Objective
Run AlphaZero Chess adaptive training on Google Colab TPU v5e-1 for 1 hour, with automatic checkpoint saving to Google Drive.

---

## 📋 Prerequisites

**Required:**
1. Google account with Google Drive access
2. AlphaZero Chess project (ZIP file)
3. Google Colab account (free tier supports TPU)

**Recommended:**
- At least 5GB free space in Google Drive
- Stable internet connection

---

## 🚀 Step-by-Step Setup Instructions

### Step 1: Prepare Your Project

1. **Upload AlphaZero to Drive:**
   - Go to https://drive.google.com
   - Upload `AlphaZero.zip` to your Drive root (MyDrive)
   - Confirm the file is uploaded successfully

### Step 2: Open Google Colab with TPU Runtime

1. **Navigate to Colab TPU Notebook:**
   ```
   https://colab.research.google.com/notebooks/tpu.ipynb#
   ```

2. **Change Runtime to TPU:**
   - Click: `Runtime` → `Change runtime type`
   - Hardware accelerator: Select **TPU**
   - TPU type: **v5e-1** (or v4-8 if v5e-1 unavailable)
   - Click **Save**

3. **Verify TPU Connection:**
   - Runtime will reconnect automatically
   - Look for "Connected" status in top-right
   - You should see "TPU v5e-1" or similar in runtime details

### Step 3: Run Training Script

1. **Create New Code Cell:**
   - Click `+ Code` button to add a new cell
   - Or use existing cell

2. **Copy Training Script:**
   - Open `COLAB_TPU_TRAINING_SCRIPT.py` (provided separately)
   - Copy the **entire script**
   - Paste into the Colab code cell

3. **Execute Training:**
   - Press `Shift + Enter` or click the ▶️ Play button
   - Wait for execution to begin

---

## 📊 What Happens During Training

### Automatic Steps (No User Action Required)

**Phase 1: Environment Setup (2-3 minutes)**
- ✅ Mount Google Drive
- ✅ Create checkpoint directories
- ✅ Detect and initialize TPU

**Phase 2: Project Setup (3-5 minutes)**
- ✅ Extract AlphaZero from Drive
- ✅ Install dependencies (~140 packages)
- ✅ Configure training parameters

**Phase 3: Training Loop (55 minutes)**
- ✅ Run adaptive training cycles
- ✅ Auto-save checkpoints every 10 minutes
- ✅ Monitor ELO improvements
- ✅ Log progress to Drive

**Phase 4: Finalization (1 minute)**
- ✅ Save final checkpoints
- ✅ Generate training report
- ✅ Display summary statistics

---

## 📁 Output Files (Saved to Google Drive)

After training completes, find these files in:  
**`MyDrive/AlphaZero_Training/`**

| File | Description |
|------|-------------|
| `adaptive_training_state.json` | Training state and metadata |
| `AdaptiveModel_v*_*.pth` | Improved model checkpoints |
| `training.log` | Detailed training logs |
| `training_report.json` | Performance summary and statistics |

---

## 🛠️ Monitoring Training Progress

### Real-Time Logs

Watch the Colab output for:
- **Training Cycles:** Shows cycle number and ELO changes
- **Checkpoint Saves:** Confirms Drive sync every 10 minutes
- **Time Remaining:** Updates after each cycle

**Example Output:**
```
================================================================================
TRAINING CYCLE 3
Time remaining: 42.5 minutes
================================================================================

Collecting recent games...
Preparing training data...
Training on TPU (torch_xla)...
Epoch 1/3 complete in 3.2s - Loss: 0.1234

Evaluating model improvement...
Evaluation complete: Win rate 55.0%, ELO delta: +10

✅ Model improved by +10 ELO!
💾 Checkpoint saved: AdaptiveModel_v3_1729123456
```

### Check Drive for Checkpoints

While training runs, periodically check:
```
MyDrive/AlphaZero_Training/
```
You should see new `.pth` files appearing every ~10-15 minutes.

---

## ⚠️ Common Issues & Solutions

### Issue 1: "TPU not detected"

**Symptoms:**
- Warning: "torch_xla not found"
- Falls back to CPU/GPU

**Solution:**
1. Verify Runtime type is set to **TPU** (not CPU/GPU)
2. Runtime → Change runtime type → TPU → Save
3. Runtime will reconnect - wait 30 seconds
4. Re-run the script

---

### Issue 2: "AlphaZero.zip not found"

**Symptoms:**
- Error: "AlphaZero.zip not found in Drive root"

**Solution:**
1. Check Drive root (MyDrive) for `AlphaZero.zip`
2. If missing, upload the ZIP file to Drive root
3. Refresh Drive and re-run script

**Alternative:**
Modify script line 83-90 to point to custom location:
```python
if Path("/content/drive/MyDrive/Projects/AlphaZero.zip").exists():
    shutil.unpack_archive(
        "/content/drive/MyDrive/Projects/AlphaZero.zip",
        "/content/AlphaZero"
    )
```

---

### Issue 3: "Dependency installation timeout"

**Symptoms:**
- Pip install hangs or fails
- Timeout errors

**Solution:**
1. **Split installation** - Script already handles this in batches
2. **Retry** - Re-run the cell (pip will skip installed packages)
3. **Manual install** - Run in separate cell before main script:
   ```python
   !pip install -q torch torchvision optuna python-chess scikit-learn
   ```

---

### Issue 4: Training stops early

**Symptoms:**
- Training completes before 1 hour
- "Less than 5 minutes remaining" message

**Solution:**
- This is **expected behavior** if:
  - Training cycles take longer than estimated
  - Script has <5 min left (graceful shutdown)
- To extend training:
  ```python
  TRAINING_CONFIG["max_training_time_seconds"] = 7200  # 2 hours
  ```

---

### Issue 5: Drive checkpoint sync fails

**Symptoms:**
- "Permission denied" errors
- Checkpoints not appearing in Drive

**Solution:**
1. **Re-mount Drive:** Run in new cell:
   ```python
   from google.colab import drive
   drive.mount('/content/drive', force_remount=True)
   ```
2. **Check permissions:** Ensure Colab has Drive access
3. **Verify path:** Confirm `MyDrive/AlphaZero_Training/` exists

---

## 🧠 Understanding Training Metrics

### ELO Rating
- **Starting ELO:** 1500 (baseline)
- **ELO Delta:** Change after each training cycle
  - `+5` to `+20`: Good improvement
  - `0` to `+5`: Marginal gain
  - Negative: Performance degraded (model rollback triggered)

### Win Rate
- Percentage of games new model wins vs. baseline
- **Target:** >50% (indicates improvement)
- **Excellent:** >55% (strong improvement)

### Training Loss
- Measures prediction accuracy
- **Lower is better**
- Typical range: 0.1 - 0.5

### Retrains
- Number of successful model updates
- Each retrain produces new checkpoint
- Auto-triggered every 25 games (configurable)

---

## 🎛️ Customizing Training Parameters

Edit `TRAINING_CONFIG` dictionary in script (around line 139):

```python
TRAINING_CONFIG = {
    # Extend training time to 2 hours
    "max_training_time_seconds": 7200,  # 2 hours
    
    # Train more frequently (every 15 games instead of 25)
    "retrain_frequency": 15,
    
    # Require higher ELO gain to accept new model
    "elo_gain_threshold": 5.0,  # Was 3.0
    
    # Use more self-play data (80% instead of 70%)
    "data_mix_ratio": (0.8, 0.2),  # (self-play, human)
    
    # Increase learning rate for faster adaptation
    "learning_rate": 0.001,  # Was 0.0005
    
    # More training epochs per cycle
    "num_epochs": 5,  # Was 3
    
    # Larger batch size (if TPU memory allows)
    "batch_size": 128,  # Was 64
    
    # More evaluation games for better accuracy
    "evaluation_games": 10,  # Was 5
    
    # Save checkpoints more frequently
    "checkpoint_interval": 300,  # Every 5 minutes (was 10)
}
```

**⚠️ Warning:** Increasing parameters may slow training or exceed TPU memory.

---

## 📈 After Training: Next Steps

### 1. Download Checkpoints

**Option A: Manual Download**
- Open Google Drive
- Navigate to `MyDrive/AlphaZero_Training/`
- Right-click → Download

**Option B: Programmatic Download (in Colab)**
```python
from google.colab import files

# Download best model
files.download('/content/drive/MyDrive/AlphaZero_Training/AdaptiveModel_v5_1729123456.pth')

# Download training report
files.download('/content/drive/MyDrive/AlphaZero_Training/training_report.json')
```

### 2. Resume Training

To continue training from checkpoint:
1. Re-run the script (checkpoints auto-loaded)
2. Trainer will resume from last state
3. Total retrains will increment from previous value

### 3. Evaluate Model Performance

Use the best checkpoint in evaluation mode:
```python
# In new Colab cell
from neural_network import ModelManager
from evaluator import ModelEvaluator

# Load best model
model_manager = ModelManager()
network, metadata = model_manager.load_model("AdaptiveModel_v5_1729123456")

# Evaluate against baseline
evaluator = ModelEvaluator(num_evaluation_games=50)
results = evaluator.evaluate_models(network, baseline_network, "best", "baseline")

print(f"Win Rate: {results['challenger_win_rate']:.1%}")
print(f"ELO Estimate: {results['elo_estimate']:.0f}")
```

### 4. Deploy Model

Export for production:
```python
from model_export import ModelExporter

exporter = ModelExporter()
exporter.export_to_onnx(
    network,
    output_path="/content/drive/MyDrive/AlphaZero_Production/model.onnx"
)
```

---

## 🔧 Advanced Configuration

### Use Distributed TPU Training (Multi-Core)

For larger models or faster training:
```python
# Replace adaptive_trainer_tpu with distributed_tpu_trainer
from distributed_tpu_trainer import DistributedTPUTrainer

trainer = DistributedTPUTrainer(
    num_workers=8,  # Use all 8 TPU cores
    replay_buffer_size=100000,
    batch_size=256,  # Larger batch for distributed
    learning_rate=0.001
)
```

### Enable Hyperparameter Optimization

Run HPO before adaptive training:
```python
from hyperparam_optimizer import HyperparameterOptimizer

hpo = HyperparameterOptimizer(
    max_trials=10,
    evaluation_games=5
)

hpo.start_optimization()
# Wait for completion (~2 hours)

best_params = hpo.get_best_parameters()
# Use best_params in adaptive trainer
```

### Enable LLM-Powered Reflection

Add self-reflection for strategic insights:
```python
from reflection_engine import ReflectionEngine

reflection_engine = ReflectionEngine(use_llm=True)

# After each training cycle
reflection = await reflection_engine.reflect_on_session({
    'session_id': 'tpu_training_001',
    'games_played': 25,
    'win_rate': 0.55,
    'average_moves': 40
})

print(f"Weakness: {reflection['weakness_detected']}")
print(f"Focus: {reflection['training_focus']}")
```

---

## 📞 Support & Resources

### Official Documentation
- **AlphaZero Guide:** `/app/backend/ALPHAZERO_TRAINING_GUIDE.md`
- **TPU Documentation:** `/app/backend/TPU_RUNBOOK.md`
- **Quickstart:** `/app/backend/QUICK_START.md`

### Common Commands

**Check TPU status:**
```python
import torch_xla.core.xla_model as xm
print(f"TPU cores: {xm.xrt_world_size()}")
print(f"TPU device: {xm.xla_device()}")
```

**Monitor GPU/TPU memory:**
```python
import torch_xla.debug.metrics as met
print(met.metrics_report())
```

**View training logs in real-time:**
```python
!tail -f /content/alphazero/checkpoints/training.log
```

### Troubleshooting Checklist

- [ ] Runtime is set to TPU (not CPU/GPU)
- [ ] Google Drive is mounted successfully
- [ ] AlphaZero.zip is in Drive root
- [ ] All dependencies installed without errors
- [ ] TPU device detected (check logs for "TPU detected")
- [ ] Checkpoint directories created
- [ ] Training cycles are completing (check progress logs)
- [ ] Checkpoints appearing in Drive every 10 minutes

---

## 🎉 Success Indicators

Your training is successful if you see:

✅ **"TPU detected: xla:0"**  
✅ **"Adaptive TPU Trainer initialized"**  
✅ **"Training cycle X complete"** (repeating)  
✅ **"Model improved by +X ELO"**  
✅ **Checkpoint files in Drive** (`.pth` files)  
✅ **"TRAINING SESSION COMPLETE"** (after 1 hour)

---

## 💡 Pro Tips

1. **Longer sessions:** For serious training, use 6-12 hour sessions
2. **Batch training:** Run multiple 1-hour sessions back-to-back
3. **Parallel experiments:** Use different Colab notebooks for different configs
4. **Monitor Drive space:** Each checkpoint is ~50-200MB
5. **Download periodically:** Don't rely solely on Drive - download best models
6. **Use TPU v5e-1:** Faster than v4-8 for this workload
7. **Avoid interruptions:** Keep Colab tab active (prevents timeout)

---

**Ready to train? Copy the script and let's go! 🚀**

For questions or issues, consult the documentation in `/app/backend/` or open an issue on GitHub.
