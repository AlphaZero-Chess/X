"""
AlphaZero Chess TPU Training Script for Google Colab
Runtime: TPU v5e-1 (or v4-8)
Duration: 1 Hour Adaptive Training

Instructions:
1. Open https://colab.research.google.com/notebooks/tpu.ipynb#
2. Change Runtime → Runtime type → TPU
3. Copy this entire script into a code cell
4. Run the cell
5. Training will run for 1 hour and save checkpoints automatically

Author: AlphaZero Chess Team
"""

# ============================================================================
# SECTION 1: ENVIRONMENT SETUP
# ============================================================================

print("="*80)
print("🚀 AlphaZero Chess - TPU Training Setup")
print("="*80)

# Mount Google Drive for checkpoint persistence
print("\n📁 Mounting Google Drive...")
from google.colab import drive
drive.mount('/content/drive', force_remount=True)
print("✅ Google Drive mounted at /content/drive")

# Create checkpoint directories
import os
from pathlib import Path

# Local checkpoint directory (fast I/O)
LOCAL_CHECKPOINT_DIR = Path("/content/alphazero/checkpoints")
LOCAL_CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

# Drive checkpoint directory (persistent storage)
DRIVE_CHECKPOINT_DIR = Path("/content/drive/MyDrive/AlphaZero_Training")
DRIVE_CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

print(f"✅ Local checkpoints: {LOCAL_CHECKPOINT_DIR}")
print(f"✅ Drive checkpoints: {DRIVE_CHECKPOINT_DIR}")

# ============================================================================
# SECTION 2: TPU RUNTIME DETECTION & INITIALIZATION
# ============================================================================

print("\n🔍 Detecting TPU runtime...")

try:
    import torch
    import torch_xla
    import torch_xla.core.xla_model as xm
    
    device = xm.xla_device()
    print(f"✅ TPU detected: {device}")
    print(f"   TPU cores available: {xm.xrt_world_size()}")
    TPU_AVAILABLE = True
except ImportError:
    print("⚠️  torch_xla not found. Installing TPU dependencies...")
    
    # Install torch-xla for TPU support
    import subprocess
    import sys
    
    commands = [
        # Install torch-xla matching PyTorch version
        "pip install torch-xla -f https://storage.googleapis.com/libtpu-releases/index.html",
        # Install cloud TPU client
        "pip install cloud-tpu-client",
        # Install JAX with TPU support (for jax backend)
        'pip install "jax[tpu]" -f https://storage.googleapis.com/jax-releases/libtpu_releases.html'
    ]
    
    for cmd in commands:
        print(f"   Running: {cmd}")
        subprocess.check_call(cmd.split())
    
    # Re-import after installation
    import torch_xla
    import torch_xla.core.xla_model as xm
    device = xm.xla_device()
    print(f"✅ TPU initialized: {device}")
    TPU_AVAILABLE = True

# ============================================================================
# SECTION 3: ALPHAZERO REPOSITORY SETUP
# ============================================================================

print("\n📦 Setting up AlphaZero Chess repository...")

# Check if already cloned
if not Path("/content/AlphaZero").exists():
    # Option A: Clone from GitHub (if you have a repo)
    # !git clone https://github.com/YOUR_USERNAME/AlphaZero_Chess.git /content/AlphaZero
    
    # Option B: Upload from Drive (assuming you've uploaded the project)
    import shutil
    if Path("/content/drive/MyDrive/AlphaZero.zip").exists():
        print("   Extracting from Drive...")
        shutil.unpack_archive(
            "/content/drive/MyDrive/AlphaZero.zip",
            "/content/AlphaZero"
        )
        print("✅ AlphaZero extracted from Drive")
    else:
        # Option C: Download from provided URL (if available)
        print("   ⚠️  AlphaZero.zip not found in Drive root")
        print("   Please upload AlphaZero.zip to Google Drive root first")
        raise FileNotFoundError("AlphaZero.zip not found")
else:
    print("✅ AlphaZero repository already present")

# Navigate to backend directory
os.chdir("/content/AlphaZero/backend")
print(f"📂 Working directory: {os.getcwd()}")

# ============================================================================
# SECTION 4: DEPENDENCIES INSTALLATION
# ============================================================================

print("\n📥 Installing AlphaZero dependencies...")

# Install from requirements.txt (skip TPU packages already installed)
import subprocess

# Filter out TPU packages from requirements.txt
with open("requirements.txt", "r") as f:
    requirements = [
        line.strip() 
        for line in f 
        if line.strip() 
        and not line.startswith("#")
        and "torch-xla" not in line 
        and "cloud-tpu-client" not in line
        and "jax[tpu]" not in line
    ]

# Install in batches to avoid timeout
print(f"   Installing {len(requirements)} packages...")
subprocess.check_call([
    "pip", "install", "--no-deps", "-q"
] + requirements[:50])  # First 50 packages

subprocess.check_call([
    "pip", "install", "--no-deps", "-q"
] + requirements[50:100])  # Next 50

subprocess.check_call([
    "pip", "install", "-q"
] + requirements[100:])  # Remaining (with deps)

print("✅ All dependencies installed")

# ============================================================================
# SECTION 5: TRAINING CONFIGURATION
# ============================================================================

print("\n⚙️  Configuring training parameters...")

TRAINING_CONFIG = {
    # Training duration
    "max_training_time_seconds": 3600,  # 1 hour = 3600 seconds
    
    # Adaptive trainer settings
    "retrain_frequency": 25,  # Retrain every 25 games
    "elo_gain_threshold": 3.0,  # Minimum ELO gain to keep model
    "data_mix_ratio": (0.7, 0.3),  # 70% self-play, 30% human games
    "learning_rate": 0.0005,
    "num_epochs": 3,
    "batch_size": 64,
    "evaluation_games": 5,
    
    # Checkpoint settings
    "checkpoint_interval": 600,  # Save every 10 minutes
    "local_checkpoint_dir": str(LOCAL_CHECKPOINT_DIR),
    "drive_checkpoint_dir": str(DRIVE_CHECKPOINT_DIR)
}

print("✅ Configuration:")
for key, value in TRAINING_CONFIG.items():
    print(f"   {key}: {value}")

# ============================================================================
# SECTION 6: TRAINING EXECUTION (1 HOUR)
# ============================================================================

print("\n" + "="*80)
print("🏋️  STARTING 1-HOUR TPU TRAINING SESSION")
print("="*80)

import time
import logging
from datetime import datetime, timedelta

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOCAL_CHECKPOINT_DIR / "training.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Import AlphaZero modules
try:
    from adaptive_trainer_tpu import AdaptiveTPUTrainer
    from neural_network import AlphaZeroNetwork, ModelManager
    from config_loader import load_config
    
    # Initialize adaptive trainer
    trainer = AdaptiveTPUTrainer(
        mode="auto",
        retrain_frequency=TRAINING_CONFIG["retrain_frequency"],
        elo_gain_threshold=TRAINING_CONFIG["elo_gain_threshold"],
        data_mix_ratio=TRAINING_CONFIG["data_mix_ratio"],
        learning_rate=TRAINING_CONFIG["learning_rate"],
        num_epochs=TRAINING_CONFIG["num_epochs"],
        batch_size=TRAINING_CONFIG["batch_size"],
        evaluation_games=TRAINING_CONFIG["evaluation_games"],
        checkpoint_dir=TRAINING_CONFIG["local_checkpoint_dir"]
    )
    
    logger.info(f"✅ Adaptive TPU Trainer initialized")
    logger.info(f"   Backend: {trainer.backend_type}")
    logger.info(f"   TPU Device: {trainer.backend.device if hasattr(trainer.backend, 'device') else 'Simulated'}")
    
    # Training timer
    start_time = time.time()
    end_time = start_time + TRAINING_CONFIG["max_training_time_seconds"]
    next_checkpoint_time = start_time + TRAINING_CONFIG["checkpoint_interval"]
    
    training_cycles_completed = 0
    
    print(f"\n⏱️  Training will run until: {datetime.fromtimestamp(end_time).strftime('%H:%M:%S')}")
    print(f"   Duration: {TRAINING_CONFIG['max_training_time_seconds'] / 60:.0f} minutes\n")
    
    # Main training loop
    while time.time() < end_time:
        try:
            cycle_start = time.time()
            remaining_time = end_time - cycle_start
            
            # Check if we have enough time for another cycle (minimum 5 minutes)
            if remaining_time < 300:
                logger.info("⏰ Less than 5 minutes remaining - stopping gracefully")
                break
            
            logger.info(f"\n{'='*80}")
            logger.info(f"TRAINING CYCLE {training_cycles_completed + 1}")
            logger.info(f"Time remaining: {remaining_time / 60:.1f} minutes")
            logger.info(f"{'='*80}\n")
            
            # Run one training cycle
            trainer.run_training_cycle()
            
            training_cycles_completed += 1
            cycle_duration = time.time() - cycle_start
            
            logger.info(f"✅ Cycle {training_cycles_completed} complete in {cycle_duration / 60:.1f} minutes")
            
            # Checkpoint if interval reached
            if time.time() >= next_checkpoint_time:
                logger.info("💾 Checkpoint interval reached - saving progress...")
                
                # Copy checkpoints from local to Drive
                import shutil
                for checkpoint_file in LOCAL_CHECKPOINT_DIR.glob("*.pth"):
                    drive_path = DRIVE_CHECKPOINT_DIR / checkpoint_file.name
                    shutil.copy2(checkpoint_file, drive_path)
                    logger.info(f"   ✅ Synced: {checkpoint_file.name}")
                
                # Also save training state
                trainer.save_state()
                state_file = LOCAL_CHECKPOINT_DIR / "adaptive_training_state.json"
                if state_file.exists():
                    shutil.copy2(state_file, DRIVE_CHECKPOINT_DIR / "adaptive_training_state.json")
                
                next_checkpoint_time = time.time() + TRAINING_CONFIG["checkpoint_interval"]
                logger.info("✅ Checkpoint saved to Drive")
        
        except KeyboardInterrupt:
            logger.info("⚠️  Training interrupted by user")
            break
        
        except Exception as e:
            logger.error(f"❌ Error in training cycle: {e}")
            import traceback
            traceback.print_exc()
            # Continue to next cycle
            time.sleep(5)
    
    # Final checkpoint
    logger.info("\n" + "="*80)
    logger.info("💾 FINAL CHECKPOINT - Saving all progress to Drive")
    logger.info("="*80)
    
    import shutil
    
    # Copy all checkpoints
    for checkpoint_file in LOCAL_CHECKPOINT_DIR.glob("*"):
        if checkpoint_file.is_file():
            drive_path = DRIVE_CHECKPOINT_DIR / checkpoint_file.name
            shutil.copy2(checkpoint_file, drive_path)
            logger.info(f"   ✅ {checkpoint_file.name}")
    
    # Training summary
    total_time = time.time() - start_time
    
    print("\n" + "="*80)
    print("🎉 TRAINING SESSION COMPLETE")
    print("="*80)
    print(f"✅ Total duration: {total_time / 60:.1f} minutes")
    print(f"✅ Training cycles completed: {training_cycles_completed}")
    print(f"✅ Checkpoints saved to: {DRIVE_CHECKPOINT_DIR}")
    print(f"\n📊 Training Status:")
    
    status = trainer.get_status()
    print(f"   - Total retrains: {status['total_retrains']}")
    print(f"   - Current ELO: {status['current_elo']:.0f}")
    print(f"   - Best model: {status['current_model']}")
    print(f"   - Backend: {status['backend_type']}")
    
    print(f"\n📁 All files saved to Google Drive:")
    print(f"   {DRIVE_CHECKPOINT_DIR}")
    print("\n✅ You can now download checkpoints or continue training later!")

except ImportError as e:
    logger.error(f"❌ Failed to import AlphaZero modules: {e}")
    logger.error("   Make sure the project structure is correct")
    raise

except Exception as e:
    logger.error(f"❌ Training error: {e}")
    import traceback
    traceback.print_exc()
    raise

# ============================================================================
# SECTION 7: POST-TRAINING ANALYSIS (OPTIONAL)
# ============================================================================

print("\n" + "="*80)
print("📈 GENERATING TRAINING REPORT")
print("="*80)

try:
    # Get training history
    history = trainer.get_training_history(limit=50)
    
    if history:
        print(f"\n🏆 Training Cycles Summary (Last {len(history)}):")
        print("\n| Cycle | Model Name | Win Rate | ELO Δ | Loss | Games |")
        print("|-------|------------|----------|-------|------|-------|")
        
        for cycle in history[-10:]:  # Last 10 cycles
            print(f"| {cycle['cycle']:5d} | "
                  f"{cycle['model_name'][:20]:20s} | "
                  f"{cycle['win_rate']:8.1%} | "
                  f"{cycle['elo_delta']:+5.0f} | "
                  f"{cycle['training_loss']:6.4f} | "
                  f"{cycle['games_trained']:5d} |")
        
        # Save report to Drive
        import json
        report_file = DRIVE_CHECKPOINT_DIR / "training_report.json"
        with open(report_file, 'w') as f:
            json.dump({
                'session_summary': {
                    'duration_minutes': total_time / 60,
                    'cycles_completed': training_cycles_completed,
                    'final_elo': status['current_elo'],
                    'total_retrains': status['total_retrains']
                },
                'training_history': history,
                'final_status': status
            }, f, indent=2)
        
        print(f"\n✅ Full report saved: {report_file}")
    
    else:
        print("   No training cycles completed")

except Exception as e:
    logger.warning(f"Could not generate report: {e}")

print("\n" + "="*80)
print("✅ ALL DONE! Check your Google Drive for checkpoints.")
print("="*80)
