"""
Test script for PGN export functionality
Runs a few self-play games and verifies PGN files are created
"""
import sys
from pathlib import Path

# Add backend to path
backend_dir = Path(__file__).parent
sys.path.insert(0, str(backend_dir))

import logging
from self_play import SelfPlayManager
from neural_network import AlphaZeroNetwork

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def test_pgn_export():
    """Test PGN export with self-play games"""
    logger.info("=" * 60)
    logger.info("Starting PGN Export Test")
    logger.info("=" * 60)
    
    # Initialize neural network
    logger.info("Initializing neural network...")
    network = AlphaZeroNetwork()
    
    # Initialize self-play manager with fewer simulations for faster testing
    logger.info("Initializing self-play manager (50 simulations per move)...")
    self_play_manager = SelfPlayManager(network, num_simulations=50)
    
    # Generate a single test game
    logger.info("\n" + "=" * 60)
    logger.info("Generating test game 1...")
    logger.info("=" * 60)
    training_data, game_result = self_play_manager.generate_single_game(export_pgn=True)
    
    logger.info(f"\nGame 1 Result:")
    logger.info(f"  Result: {game_result['result']}")
    logger.info(f"  Moves: {game_result['num_moves']}")
    logger.info(f"  Positions: {game_result['num_positions']}")
    logger.info(f"  PGN Path: {game_result.get('pgn_path', 'Not saved')}")
    
    # Generate 2 more games in batch
    logger.info("\n" + "=" * 60)
    logger.info("Generating 2 more games in batch...")
    logger.info("=" * 60)
    all_training_data, game_results = self_play_manager.generate_games(num_games=2, export_pgn=True)
    
    logger.info(f"\nBatch Results:")
    for result in game_results:
        logger.info(f"  Game {result['game_num']}: {result['result']} "
                   f"({result['num_moves']} moves) - PGN: {result.get('pgn_path', 'N/A')}")
    
    # Check PGN directory
    pgn_dir = Path("/app/data/selfplay_pgns")
    if pgn_dir.exists():
        pgn_files = sorted(pgn_dir.glob("*.pgn"))
        logger.info(f"\n" + "=" * 60)
        logger.info(f"PGN Files Created: {len(pgn_files)}")
        logger.info("=" * 60)
        for pgn_file in pgn_files:
            size = pgn_file.stat().st_size
            logger.info(f"  {pgn_file.name} ({size} bytes)")
            
        # Show content of first PGN file
        if pgn_files:
            logger.info(f"\n" + "=" * 60)
            logger.info(f"Sample PGN Content ({pgn_files[0].name}):")
            logger.info("=" * 60)
            with open(pgn_files[0], 'r') as f:
                content = f.read()
                logger.info(content)
    else:
        logger.error("PGN directory not found!")
    
    logger.info("\n" + "=" * 60)
    logger.info("PGN Export Test Complete!")
    logger.info("=" * 60)

if __name__ == "__main__":
    try:
        test_pgn_export()
    except Exception as e:
        logger.error(f"Test failed: {e}", exc_info=True)
        sys.exit(1)
