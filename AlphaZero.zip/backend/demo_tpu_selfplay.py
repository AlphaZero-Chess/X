"""
Demo: 10 Self-Play Chess Games using TPU Backend

This demo runs 10 complete chess games using the TPU backend abstraction.
Works with simulated, JAX, or PyTorch XLA TPU backends.
"""

import sys
import os
import time
import json
from datetime import datetime
import argparse

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tpu_backend import get_tpu_backend, TPUConfig
from tpu_backend.utils import print_hardware_info, detect_hardware

try:
    import torch
    import torch.nn as nn
    import chess
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    print("Warning: PyTorch or python-chess not available. Some features may be limited.")


class SimplifiedChessNet(nn.Module):
    """Simplified chess neural network for demo."""
    
    def __init__(self):
        super().__init__()
        # Input: 12 channels (6 piece types x 2 colors), 8x8 board
        self.conv1 = nn.Conv2d(12, 64, 3, padding=1)
        self.conv2 = nn.Conv2d(64, 128, 3, padding=1)
        self.conv3 = nn.Conv2d(128, 128, 3, padding=1)
        
        # Policy head (move prediction)
        self.policy_conv = nn.Conv2d(128, 2, 1)
        self.policy_fc = nn.Linear(2 * 8 * 8, 4096)
        
        # Value head (position evaluation)
        self.value_conv = nn.Conv2d(128, 1, 1)
        self.value_fc1 = nn.Linear(1 * 8 * 8, 256)
        self.value_fc2 = nn.Linear(256, 1)
    
    def forward(self, x):
        # Shared layers
        x = torch.relu(self.conv1(x))
        x = torch.relu(self.conv2(x))
        x = torch.relu(self.conv3(x))
        
        # Policy head
        policy = torch.relu(self.policy_conv(x))
        policy = policy.view(policy.size(0), -1)
        policy = self.policy_fc(policy)
        policy = torch.log_softmax(policy, dim=1)
        
        # Value head
        value = torch.relu(self.value_conv(x))
        value = value.view(value.size(0), -1)
        value = torch.relu(self.value_fc1(value))
        value = torch.tanh(self.value_fc2(value))
        
        return policy, value


def encode_board(board):
    """
    Encode chess board to neural network input.
    
    Returns:
        numpy array of shape (12, 8, 8)
    """
    import numpy as np
    
    # 12 planes: 6 piece types x 2 colors
    planes = np.zeros((12, 8, 8), dtype=np.float32)
    
    piece_to_plane = {
        (chess.PAWN, chess.WHITE): 0,
        (chess.KNIGHT, chess.WHITE): 1,
        (chess.BISHOP, chess.WHITE): 2,
        (chess.ROOK, chess.WHITE): 3,
        (chess.QUEEN, chess.WHITE): 4,
        (chess.KING, chess.WHITE): 5,
        (chess.PAWN, chess.BLACK): 6,
        (chess.KNIGHT, chess.BLACK): 7,
        (chess.BISHOP, chess.BLACK): 8,
        (chess.ROOK, chess.BLACK): 9,
        (chess.QUEEN, chess.BLACK): 10,
        (chess.KING, chess.BLACK): 11,
    }
    
    for square in chess.SQUARES:
        piece = board.piece_at(square)
        if piece:
            plane_idx = piece_to_plane[(piece.piece_type, piece.color)]
            row = 7 - (square // 8)
            col = square % 8
            planes[plane_idx, row, col] = 1.0
    
    return planes


def select_move_simple(board, model, backend, temperature=1.0):
    """
    Select a move using the neural network.
    
    Args:
        board: chess.Board
        model: Neural network model
        backend: TPU backend
        temperature: Sampling temperature
        
    Returns:
        chess.Move or None
    """
    import numpy as np
    
    legal_moves = list(board.legal_moves)
    if not legal_moves:
        return None
    
    # Encode board
    board_tensor = encode_board(board)
    board_tensor = np.expand_dims(board_tensor, axis=0)  # Add batch dimension
    
    # Get policy from model
    policy_logits, value = backend.inference(model, board_tensor)
    
    # Convert to numpy
    if TORCH_AVAILABLE and isinstance(policy_logits, torch.Tensor):
        policy_logits = policy_logits.detach().cpu().numpy()[0]
        value = value.detach().cpu().numpy()[0, 0]
    
    # Simple move selection: just pick a random legal move
    # (In real AlphaZero, we'd map policy to moves and use MCTS)
    move = np.random.choice(legal_moves)
    
    return move, value


def play_single_game(model, backend, game_id, max_moves=200):
    """
    Play a single self-play chess game.
    
    Args:
        model: Neural network model
        backend: TPU backend
        game_id: Game identifier
        max_moves: Maximum number of moves
        
    Returns:
        dict: Game results including training data
    """
    board = chess.Board()
    moves = []
    positions = []
    policies = []
    values = []
    players_to_move = []  # Track which player made each move
    
    start_time = time.time()
    
    for move_num in range(max_moves):
        if board.is_game_over():
            break
        
        # Select move
        move, value = select_move_simple(board, model, backend)
        if move is None:
            break
        
        # Record position, policy, value, and player
        positions.append(encode_board(board))
        players_to_move.append(board.turn)  # chess.WHITE or chess.BLACK
        
        # Store value from network
        values.append(float(value))
        
        # Create simple policy (uniform over legal moves for now)
        # In real AlphaZero, this would come from MCTS search
        legal_moves = list(board.legal_moves)
        policy = {m.uci(): 1.0 / len(legal_moves) for m in legal_moves}
        policies.append(policy)
        
        moves.append(move.uci())
        
        # Make move
        board.push(move)
    
    elapsed = time.time() - start_time
    
    # Determine result
    if board.is_checkmate():
        result = "checkmate"
        winner = "black" if board.turn == chess.WHITE else "white"
    elif board.is_stalemate():
        result = "stalemate"
        winner = "draw"
    elif board.is_insufficient_material():
        result = "insufficient_material"
        winner = "draw"
    else:
        result = "max_moves"
        winner = "draw"
    
    # Assign final game outcome to all positions (AlphaZero style)
    # Outcome from perspective of player to move at each position
    final_values = []
    for player in players_to_move:
        if winner == "draw":
            final_values.append(0.0)
        elif winner == "white":
            final_values.append(1.0 if player == chess.WHITE else -1.0)
        else:  # winner == "black"
            final_values.append(1.0 if player == chess.BLACK else -1.0)
    
    # Format training data for replay buffer
    training_examples = []
    for i in range(len(positions)):
        training_examples.append({
            'position': positions[i],
            'policy': policies[i],
            'value': final_values[i]
        })
    
    return {
        'game_id': game_id,
        'num_moves': len(moves),
        'num_positions': len(training_examples),
        'result': result,
        'winner': winner,
        'time_seconds': elapsed,
        'moves': moves[:10],  # First 10 moves for brevity
        'final_fen': board.fen(),
        'training_examples': training_examples
    }


def run_demo(num_games=10, backend_mode='auto', save_results=True):
    """
    Run the demo: play multiple self-play games.
    
    Args:
        num_games: Number of games to play
        backend_mode: TPU backend mode ('auto', 'simulated', 'jax', 'torch_xla')
        save_results: Save results to JSON file
        
    Returns:
        dict: Demo results
    """
    print("\n" + "="*60)
    print("TPU BACKEND DEMO - 10 SELF-PLAY CHESS GAMES")
    print("="*60 + "\n")
    
    # Print hardware info
    print_hardware_info()
    
    # Initialize TPU backend
    print(f"Initializing TPU backend (mode: {backend_mode})...")
    config = TPUConfig(batch_size=1, compile_model=True)
    backend = get_tpu_backend(mode=backend_mode, config=config)
    
    print(f"✓ Backend initialized: {backend.backend_name}")
    print(f"✓ Device info: {backend.get_device_info()}\n")
    
    # Initialize model
    print("Initializing chess model...")
    if not TORCH_AVAILABLE:
        print("ERROR: PyTorch not available. Cannot run demo.")
        return None
    
    model = SimplifiedChessNet()
    model = backend.compile_model(model)
    print("✓ Model compiled\n")
    
    # Initialize replay buffer
    try:
        from replay_buffer import ReplayBuffer
        replay_buffer = ReplayBuffer(max_size=1_000_000, checkpoint_dir="/data/training_logs/selfplay_44M")
        print("✓ Replay buffer initialized\n")
    except Exception as e:
        print(f"⚠️  Warning: Could not initialize replay buffer: {e}")
        replay_buffer = None
    
    # Run games
    print(f"Playing {num_games} self-play games...\n")
    
    games = []
    total_moves = 0
    total_time = 0
    total_positions = 0
    
    demo_start = time.time()
    
    for i in range(num_games):
        print(f"Game {i+1}/{num_games}...", end=" ", flush=True)
        
        game_result = play_single_game(model, backend, i+1, max_moves=200)
        games.append(game_result)
        
        total_moves += game_result['num_moves']
        total_time += game_result['time_seconds']
        num_positions = game_result.get('num_positions', 0)
        total_positions += num_positions
        
        # Add training examples to replay buffer
        if replay_buffer and 'training_examples' in game_result:
            replay_buffer.add(game_result['training_examples'])
            buffer_size = replay_buffer.size()
            print(f"✓ {game_result['num_moves']} moves, {num_positions} positions, {game_result['result']}, {game_result['time_seconds']:.2f}s | Buffer: {buffer_size:,}")
        else:
            print(f"✓ {game_result['num_moves']} moves, {num_positions} positions, {game_result['result']}, {game_result['time_seconds']:.2f}s")
    
    demo_elapsed = time.time() - demo_start
    
    # Summary
    print("\n" + "="*60)
    print("DEMO RESULTS")
    print("="*60)
    print(f"\nGames completed: {num_games}")
    print(f"Positions collected: {total_positions:,}")
    print(f"Total moves: {total_moves}")
    print(f"Average moves per game: {total_moves / num_games:.1f}")
    print(f"Average positions per game: {total_positions / num_games:.1f}")
    print(f"Total time: {total_time:.2f}s")
    print(f"Average time per game: {total_time / num_games:.2f}s")
    print(f"Average time per move: {total_time / total_moves:.3f}s")
    print(f"Demo elapsed time: {demo_elapsed:.2f}s")
    
    # Replay buffer stats
    if replay_buffer:
        buffer_stats = replay_buffer.get_stats()
        print(f"\n📊 Replay Buffer:")
        print(f"  Size: {buffer_stats['size']:,} positions")
        print(f"  Capacity: {buffer_stats['capacity']:,}")
        print(f"  Utilization: {buffer_stats['utilization']*100:.2f}%")
    
    # Results breakdown
    results_count = {}
    for game in games:
        result = game['result']
        results_count[result] = results_count.get(result, 0) + 1
    
    print(f"\nResults breakdown:")
    for result, count in results_count.items():
        print(f"  {result}: {count} ({count/num_games*100:.1f}%)")
    
    # Backend performance
    print(f"\nBackend: {backend.backend_name}")
    if hasattr(backend, 'get_performance_stats'):
        perf_stats = backend.get_performance_stats()
        print(f"  Total inferences: {perf_stats.get('num_inferences', 0)}")
        if 'avg_inference_time' in perf_stats:
            print(f"  Avg inference time: {perf_stats['avg_inference_time']*1000:.2f}ms")
    
    print("\n" + "="*60 + "\n")
    
    # Save results
    results = {
        'timestamp': datetime.now().isoformat(),
        'backend': backend.backend_name,
        'backend_info': backend.get_device_info(),
        'config': config.to_dict(),
        'num_games': num_games,
        'total_moves': total_moves,
        'total_positions': total_positions,
        'total_time': total_time,
        'demo_elapsed': demo_elapsed,
        'games': games,
        'summary': {
            'avg_moves_per_game': total_moves / num_games,
            'avg_positions_per_game': total_positions / num_games,
            'avg_time_per_game': total_time / num_games,
            'avg_time_per_move': total_time / total_moves,
            'results_breakdown': results_count,
        }
    }
    
    # Add replay buffer stats if available
    if replay_buffer:
        results['replay_buffer'] = replay_buffer.get_stats()
    
    if save_results:
        output_file = f'/app/backend/demo_results_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
        
        # Remove training_examples from games before saving (contains numpy arrays)
        games_for_json = []
        for game in results['games']:
            game_copy = game.copy()
            if 'training_examples' in game_copy:
                # Don't save the full training examples, just count
                game_copy['training_examples_count'] = len(game_copy['training_examples'])
                del game_copy['training_examples']
            games_for_json.append(game_copy)
        
        results_for_json = results.copy()
        results_for_json['games'] = games_for_json
        
        with open(output_file, 'w') as f:
            json.dump(results_for_json, f, indent=2)
        print(f"✓ Results saved to: {output_file}\n")
    
    return results


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description='TPU Backend Demo - Self-Play Chess Games')
    parser.add_argument('--games', type=int, default=10, help='Number of games to play')
    parser.add_argument('--backend', type=str, default='auto', 
                        choices=['auto', 'simulated', 'jax', 'torch_xla'],
                        help='TPU backend mode')
    parser.add_argument('--no-save', action='store_true', help='Do not save results')
    
    args = parser.parse_args()
    
    try:
        results = run_demo(
            num_games=args.games,
            backend_mode=args.backend,
            save_results=not args.no_save
        )
        
        if results:
            print("✓ Demo completed successfully!")
            return 0
        else:
            print("✗ Demo failed!")
            return 1
    
    except Exception as e:
        print(f"\n✗ Demo failed with error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
