"""
Enhanced FastAPI Server with Full AlphaZero Pipeline
Includes training, evaluation, model management, and export endpoints
"""
from fastapi import FastAPI, APIRouter, BackgroundTasks, HTTPException, Query, UploadFile, File
from fastapi.responses import FileResponse, StreamingResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import MongoClient
import os
import logging
import subprocess
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone, timedelta
import asyncio
from concurrent.futures import ThreadPoolExecutor
import sys
import numpy as np
import json
import time
import queue

# Add backend to path
backend_dir = Path(__file__).parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

# Setup safe logging BEFORE any other imports (fixes Windows buffer detachment)
from logging_config import setup_safe_logging
setup_safe_logging(level=logging.INFO, include_console=True)

# Import AlphaZero components
from neural_network import AlphaZeroNetwork, ModelManager
from self_play import SelfPlayManager
from trainer import AlphaZeroTrainer
from evaluator import ModelEvaluator
from model_export import ModelExporter, ModelLoader
from chess_engine import ChessEngine
from mcts import MCTS
from pgn_parser import PGNParser
from memory_manager import MemoryManager
from offline_memory_manager import OfflineMemoryManager
from arena_manager import ArenaManager
from memory_compression import MemoryCompressor
from cache_manager import load_cache, save_cache, cache_exists
from performance_monitor import performance_monitor, iq_tracker
from parallel_selfplay import AdaptiveSelfPlayManager
from config_loader import load_config, SELFPLAY_CACHE_DIR, get_active_model_path
from tournament_manager import TournamentManager
from adaptive_learning_manager import AdaptiveLearningManager

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ.get('MONGO_URL', 'mongodb://localhost:27017')
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ.get('DB_NAME', 'alphazero_chess')]

# Create the main app
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Logging already configured by logging_config.py
logger = logging.getLogger(__name__)

# Thread pool for async operations
executor = ThreadPoolExecutor(max_workers=2)

# Global state
training_status = {
    "active": False,
    "progress": 0,
    "message": "",
    "session_id": None,
    "start_time": None,
    "step": 0,
    "total_steps": 0,
    "eta_seconds": 0
}

evaluation_status = {
    "active": False,
    "progress": 0,
    "message": "",
    "results": None
}

# Progress event queue for SSE
progress_queue = queue.Queue()

# Model manager instances
model_manager = ModelManager()
model_exporter = ModelExporter()
model_loader = ModelLoader()

# Adaptive learning manager (default: disabled, 25 games per retrain, moderate aggressiveness)
adaptive_learning_manager = AdaptiveLearningManager(
    games_per_retrain=25,
    aggressiveness="moderate",
    enabled=False
)
memory_manager = MemoryManager()
offline_memory_manager = OfflineMemoryManager()

# Arena and Compression instances
arena_manager = ArenaManager()
memory_compressor = MemoryCompressor(
    compression_ratio=0.9,
    embedding_dim=128,
    num_clusters=50
)
tournament_manager = TournamentManager()

# Helper function to convert MongoDB documents to JSON-safe format
def mongo_to_json_safe(doc: Any) -> Any:
    """
    Convert MongoDB document to JSON-safe format
    Handles ObjectId, datetime, and nested structures
    """
    if isinstance(doc, list):
        return [mongo_to_json_safe(item) for item in doc]
    elif isinstance(doc, dict):
        result = {}
        for key, value in doc.items():
            if key == "_id" and hasattr(value, "__str__"):
                # Convert ObjectId to string
                result[key] = str(value)
            elif hasattr(value, "isoformat"):
                # Convert datetime to ISO string
                result[key] = value.isoformat()
            elif isinstance(value, (dict, list)):
                # Recursively convert nested structures
                result[key] = mongo_to_json_safe(value)
            else:
                result[key] = value
        return result
    elif hasattr(doc, "isoformat"):
        # Handle standalone datetime objects
        return doc.isoformat()
    else:
        return doc

# Game sessions storage (in-memory for now, can move to MongoDB)
active_games = {}  # {game_id: {"engine": ChessEngine, "history": [], "ai_color": "black"}}

# Coaching sessions storage (conversation memory per game)
coaching_sessions = {}  # {game_id: LLMChessEvaluator instance}

# ====================
# Data Models
# ====================

class StatusCheck(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class StatusCheckCreate(BaseModel):
    client_name: str

class TrainingConfig(BaseModel):
    num_games: int = Field(default=1, ge=1, le=100)
    num_epochs: int = Field(default=1, ge=1, le=50)
    batch_size: int = Field(default=64, ge=8, le=256)
    num_simulations: int = Field(default=10, ge=5, le=1000)
    learning_rate: float = Field(default=0.001, ge=0.0001, le=0.1)

class EvaluationConfig(BaseModel):
    challenger_name: str
    champion_name: str
    num_games: int = Field(default=3, ge=1, le=50)
    num_simulations: int = Field(default=10, ge=5, le=1000)
    win_threshold: float = Field(default=0.55, ge=0.5, le=1.0)

class ExportRequest(BaseModel):
    metadata: Optional[Dict[str, Any]] = None

# ====================
# Basic Endpoints
# ====================

@api_router.get("/")
async def root():
    return {"message": "AlphaZero Chess API", "version": "1.0", "status": "active"}

@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_dict = input.dict()
    status_obj = StatusCheck(**status_dict)
    _ = await db.status_checks.insert_one(status_obj.dict())
    return status_obj

@api_router.get("/status", response_model=List[StatusCheck])
async def get_status_checks():
    status_checks = await db.status_checks.find().to_list(1000)
    return [StatusCheck(**status_check) for status_check in status_checks]

# ====================
# Training Endpoints
# ====================

async def store_data_async(collection, data):
    """Helper to store data asynchronously"""
    await collection.insert_many(data)

def emit_progress(step: int, total_steps: int, message: str):
    """Emit progress event to queue"""
    global training_status
    progress = int((step / total_steps) * 100) if total_steps > 0 else 0
    elapsed = time.time() - training_status.get("start_time_raw", time.time())
    eta_seconds = int((elapsed / step * (total_steps - step))) if step > 0 else 0
    
    training_status["progress"] = progress
    training_status["step"] = step
    training_status["total_steps"] = total_steps
    training_status["eta_seconds"] = eta_seconds
    training_status["message"] = message
    
    # Put in queue for SSE
    try:
        progress_queue.put_nowait({
            "step": step,
            "total_steps": total_steps,
            "percent": progress,
            "eta_seconds": eta_seconds,
            "message": message
        })
    except queue.Full:
        pass  # Skip if queue is full

def run_training_pipeline(config: TrainingConfig, session_id: str):
    """Run complete training pipeline in background"""
    try:
        global training_status
        start_time = time.time()
        training_status["start_time_raw"] = start_time
        
        # Calculate total steps: self-play games + training epochs
        total_steps = config.num_games + config.num_epochs
        current_step = 0
        
        emit_progress(current_step, total_steps, "Initializing neural network...")
        
        # Initialize network
        network = AlphaZeroNetwork()
        current_step += 1
        
        # Stage 1: Self-Play
        emit_progress(current_step, total_steps, f"Starting self-play ({config.num_games} games)...")
        logger.info(f"Starting self-play: {config.num_games} games, {config.num_simulations} simulations")
        
        self_play_manager = SelfPlayManager(network, num_simulations=config.num_simulations)
        training_data = []
        game_results = []
        
        # Generate games one by one with progress updates
        for game_idx in range(config.num_games):
            game_data, game_result = self_play_manager.generate_single_game(store_fen=True)
            training_data.extend(game_data)
            game_results.append(game_result)
            current_step += 1
            emit_progress(current_step, total_steps, f"Self-play game {game_idx + 1}/{config.num_games} complete")
        
        logger.info(f"Self-play complete: {len(training_data)} positions generated")
        emit_progress(current_step, total_steps, f"Self-play complete: {len(training_data)} positions")
        
        # Store self-play data in MongoDB (use sync client)
        sync_client = MongoClient(os.environ.get('MONGO_URL', 'mongodb://localhost:27017'))
        sync_db = sync_client[os.environ.get('DB_NAME', 'alphazero_chess')]
        
        if training_data:
            sync_db.self_play_positions.insert_many([
                {
                    "position": pos.get("position").tolist() if hasattr(pos.get("position"), "tolist") else pos.get("position"),
                    "policy": pos.get("policy"),
                    "value": pos.get("value"),
                    "fen": pos.get("fen"),
                    "move_number": pos.get("move_number"),
                    "session_id": session_id,
                    "timestamp": datetime.now(timezone.utc),
                    "source": "pipeline_test"
                }
                for pos in training_data[:100]  # Store sample
            ])
        
        # Stage 2: Training
        emit_progress(current_step, total_steps, f"Starting training ({config.num_epochs} epochs)...")
        logger.info(f"Starting training: {config.num_epochs} epochs, batch size {config.batch_size}")
        
        trainer = AlphaZeroTrainer(network, learning_rate=config.learning_rate)
        training_history = []
        
        # Train epoch by epoch with progress updates
        for epoch in range(config.num_epochs):
            epoch_metrics = trainer.train_epoch(training_data, batch_size=config.batch_size)
            training_history.append(epoch_metrics)
            current_step += 1
            emit_progress(current_step, total_steps, f"Training epoch {epoch + 1}/{config.num_epochs} - Loss: {epoch_metrics.get('loss', 0):.4f}")
        
        logger.info(f"Training complete: {len(training_history)} epochs")
        emit_progress(current_step, total_steps, "Training complete, saving model...")
        
        # Store training metrics
        if training_history:
            sync_db.training_metrics.insert_many([
                {
                    **metrics,
                    "session_id": session_id,
                    "source": "pipeline_test"
                }
                for metrics in training_history
            ])
        
        # Save model with version
        metadata = {
            "training_date": datetime.now(timezone.utc).isoformat(),
            "num_games": config.num_games,
            "num_epochs": config.num_epochs,
            "num_positions": len(training_data),
            "learning_rate": config.learning_rate,
            "batch_size": config.batch_size,
            "num_simulations": config.num_simulations,
            "training_session_id": session_id,
            "final_loss": training_history[-1]["loss"] if training_history else 0.0,
            "source": "pipeline_test"
        }
        
        model_path = model_manager.save_versioned_model(network, metadata=metadata)
        new_model_name = Path(model_path).stem
        logger.info(f"Model saved: {new_model_name}")
        
        emit_progress(total_steps - 1, total_steps, f"Model saved: {new_model_name}")
        
        # Stage 3: Evaluation (if there's an existing model)
        existing_models = model_manager.list_models()
        if len(existing_models) > 1:
            training_status["message"] = "Running evaluation..."
            logger.info("Starting model evaluation")
            
            # Get current active model
            active_model_doc = sync_db.active_model.find_one({})
            champion_name = active_model_doc["model_name"] if active_model_doc else existing_models[0]
            
            # Load models for evaluation
            challenger_model, _ = model_manager.load_model(new_model_name)
            champion_model, _ = model_manager.load_model(champion_name)
            
            # Run evaluation (3 games, 10 simulations as per requirements)
            evaluator = ModelEvaluator(
                num_evaluation_games=3,
                num_simulations=10,
                win_threshold=0.55
            )
            
            eval_results, should_promote = evaluator.evaluate_models(
                challenger_model,
                champion_model,
                new_model_name,
                champion_name
            )
            
            # Store evaluation results
            sync_db.model_evaluations.insert_one({
                **eval_results,
                "timestamp": datetime.now(timezone.utc),
                "automatic": True,
                "session_id": session_id,
                "source": "pipeline_test"
            })
            
            # Promote if threshold met
            if should_promote:
                sync_db.active_model.replace_one(
                    {},
                    {
                        "model_name": new_model_name,
                        "promoted_at": datetime.now(timezone.utc),
                        "win_rate": eval_results["challenger_win_rate"],
                        "previous_champion": champion_name,
                        "manual_activation": False
                    },
                    upsert=True
                )
                logger.info(f"Model promoted: {new_model_name}")
                message = f"Model promoted! Win rate: {eval_results['challenger_win_rate']:.1%}"
            else:
                logger.info(f"Model not promoted. Win rate: {eval_results['challenger_win_rate']:.1%}")
                message = f"Model not promoted. Win rate: {eval_results['challenger_win_rate']:.1%}"
            emit_progress(total_steps, total_steps, message)
        else:
            # First model - make it active
            sync_db.active_model.replace_one(
                {},
                {
                    "model_name": new_model_name,
                    "promoted_at": datetime.now(timezone.utc),
                    "win_rate": 1.0,
                    "previous_champion": None,
                    "manual_activation": False,
                    "elo": 1500  # Starting ELO
                },
                upsert=True
            )
            emit_progress(total_steps, total_steps, "First model activated!")
        
        # Close sync client
        sync_client.close()
        
        emit_progress(total_steps, total_steps, "Training pipeline complete!")
        logger.info("Training pipeline completed successfully")
        
    except Exception as e:
        logger.error(f"Training pipeline error: {str(e)}")
        emit_progress(0, 100, f"Error: {str(e)}")
        raise
    finally:
        training_status["active"] = False
        # Signal completion
        try:
            progress_queue.put_nowait({"done": True})
        except queue.Full:
            pass

@api_router.post("/training/start")
async def start_training(config: TrainingConfig, background_tasks: BackgroundTasks):
    """Start training pipeline in background"""
    global training_status
    
    if training_status["active"]:
        raise HTTPException(status_code=400, detail="Training already in progress")
    
    session_id = str(uuid.uuid4())
    training_status = {
        "active": True,
        "progress": 0,
        "message": "Starting training...",
        "session_id": session_id,
        "start_time": datetime.now(timezone.utc)
    }
    
    # Run in background
    background_tasks.add_task(run_training_pipeline, config, session_id)
    
    return {
        "success": True,
        "message": "Training started",
        "session_id": session_id,
        "config": config.dict()
    }

@api_router.get("/training/status")
async def get_training_status():
    """Get current training status"""
    return {
        "active": training_status["active"],
        "progress": training_status["progress"],
        "message": training_status["message"],
        "session_id": training_status.get("session_id"),
        "start_time": training_status.get("start_time"),
        "step": training_status.get("step", 0),
        "total_steps": training_status.get("total_steps", 0),
        "eta_seconds": training_status.get("eta_seconds", 0)
    }

async def progress_event_generator():
    """Server-Sent Events generator for training progress"""
    while True:
        try:
            # Wait for events with timeout
            event = progress_queue.get(timeout=30)
            
            # Check for completion signal
            if event.get("done"):
                yield f"data: {json.dumps({'done': True})}\n\n"
                break
            
            # Send progress update
            yield f"data: {json.dumps(event)}\n\n"
            
        except queue.Empty:
            # Send keepalive
            yield f": keepalive\n\n"
            
        except Exception as e:
            logger.error(f"SSE error: {e}")
            break
        
        await asyncio.sleep(0.1)

@api_router.get("/training/progress/stream")
async def training_progress_stream():
    """Stream training progress via Server-Sent Events"""
    return StreamingResponse(
        progress_event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )

@api_router.get("/training/history")
async def get_training_history(limit: int = 10):
    """Get training history from database"""
    sessions = await db.training_metrics.aggregate([
        {"$group": {
            "_id": "$session_id",
            "epochs": {"$sum": 1},
            "avg_loss": {"$avg": "$loss"},
            "timestamp": {"$first": "$timestamp"}
        }},
        {"$sort": {"timestamp": -1}},
        {"$limit": limit}
    ]).to_list(limit)
    
    return {"sessions": sessions}

# ====================
# Self-Play Data Collection Endpoints
# ====================

# Global state for self-play
selfplay_status = {
    "active": False,
    "status": "idle",
    "games_collected": 0,
    "target_games": 0,
    "threads": 1,
    "elapsed": 0,
    "eta": 0,
    "start_time": None,
    "session_id": None,
    "model_used": None,
    "positions_generated": 0
}

selfplay_task_handle = None

def run_selfplay_pipeline(num_games: int, num_simulations: int, session_id: str):
    """Run self-play data collection in background"""
    try:
        global selfplay_status
        import time
        from datetime import datetime, timezone
        from pymongo import MongoClient
        
        # Import config loader
        from config_loader import load_config, SELFPLAY_CACHE_DIR, get_active_model_path
        
        logger.info(f"Starting self-play session {session_id}: {num_games} games, {num_simulations} simulations")
        
        start_time = time.time()
        selfplay_status["start_time"] = start_time
        selfplay_status["games_collected"] = 0
        selfplay_status["target_games"] = num_games
        selfplay_status["positions_generated"] = 0
        selfplay_status["status"] = "running"
        
        # Load active model
        config = load_config()
        active_model_name = config.get('active_model', 'ActiveModel_Offline.pth')
        selfplay_status["model_used"] = active_model_name
        
        # Initialize network
        logger.info(f"Loading model: {active_model_name}")
        network, metadata = model_manager.load_model(Path(active_model_name).stem)
        
        # Initialize self-play manager
        self_play_manager = SelfPlayManager(network, num_simulations=num_simulations)
        
        # Storage for session
        all_positions = []
        game_results = []
        pgn_files = []
        
        # Create PGN directory
        pgn_dir = SELFPLAY_CACHE_DIR
        pgn_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate games
        for game_idx in range(num_games):
            if not selfplay_status["active"]:
                logger.info("Self-play cancelled by user")
                break
            
            game_start = time.time()
            logger.info(f"Generating game {game_idx + 1}/{num_games}...")
            
            # Generate game
            game_data, game_result = self_play_manager.generate_single_game(store_fen=True)
            
            # Update status
            selfplay_status["games_collected"] = game_idx + 1
            selfplay_status["positions_generated"] += len(game_data)
            
            elapsed = time.time() - start_time
            selfplay_status["elapsed"] = int(elapsed)
            
            if game_idx > 0:
                avg_time_per_game = elapsed / (game_idx + 1)
                remaining_games = num_games - (game_idx + 1)
                selfplay_status["eta"] = int(remaining_games * avg_time_per_game)
            
            all_positions.extend(game_data)
            game_results.append(game_result)
            
            # Save PGN file
            pgn_filename = f"game_{session_id}_{game_idx + 1:06d}.pgn"
            pgn_path = pgn_dir / pgn_filename
            
            # Create PGN content
            pgn_lines = [
                f'[Event "AlphaZero Self-Play"]',
                f'[Site "Local"]',
                f'[Date "{datetime.now(timezone.utc).strftime("%Y.%m.%d")}"]',
                f'[Round "{game_idx + 1}"]',
                f'[White "AlphaZero"]',
                f'[Black "AlphaZero"]',
                f'[Result "{game_result["result"]}"]',
                f'[Model "{active_model_name}"]',
                '',
                f'{game_result.get("pgn", "")} {game_result["result"]}',
                ''
            ]
            
            with open(pgn_path, 'w') as f:
                f.write('\n'.join(pgn_lines))
            
            pgn_files.append(str(pgn_path))
            
            game_time = time.time() - game_start
            logger.info(f"Game {game_idx + 1} complete: {game_result['result']}, "
                       f"{game_result['num_moves']} moves, "
                       f"{len(game_data)} positions, "
                       f"{game_time:.1f}s")
        
        # Calculate statistics
        total_elapsed = time.time() - start_time
        games_played = selfplay_status["games_collected"]
        
        # Calculate W/L/D
        wins_white = sum(1 for r in game_results if r['result'] == '1-0')
        wins_black = sum(1 for r in game_results if r['result'] == '0-1')
        draws = sum(1 for r in game_results if r['result'] == '1/2-1/2')
        
        # Calculate average moves
        total_moves = sum(r['num_moves'] for r in game_results)
        avg_moves = total_moves / games_played if games_played > 0 else 0
        
        # Create session summary
        session_summary = {
            "session_id": session_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "num_games": games_played,
            "num_positions": len(all_positions),
            "model_used": active_model_name,
            "config": {
                "mcts_simulations": num_simulations,
                "target_games": num_games
            },
            "statistics": {
                "white_wins": wins_white,
                "black_wins": wins_black,
                "draws": draws,
                "total_moves": total_moves,
                "average_moves": round(avg_moves, 2),
                "duration_seconds": round(total_elapsed, 2),
                "games_per_hour": round(games_played / (total_elapsed / 3600), 2) if total_elapsed > 0 else 0
            },
            "pgn_files": pgn_files
        }
        
        # Load existing sessions
        sessions_file = SELFPLAY_CACHE_DIR / "sessions.json"
        if sessions_file.exists():
            with open(sessions_file, 'r') as f:
                sessions = json.load(f)
        else:
            sessions = {"sessions": []}
        
        # Add new session
        sessions["sessions"].insert(0, session_summary)
        
        # Keep only last 100 sessions
        sessions["sessions"] = sessions["sessions"][:100]
        
        # Save sessions file
        with open(sessions_file, 'w') as f:
            json.dump(sessions, f, indent=2)
        
        logger.info(f"Self-play session complete: {games_played} games, {len(all_positions)} positions")
        logger.info(f"Stats: W={wins_white}, B={wins_black}, D={draws}, Avg Moves={avg_moves:.1f}")
        
        # Record IQ growth from self-play
        try:
            from iq_tracker_enhanced import get_model_size_mb
            
            # Get model path and size
            model_path = get_active_model_path()
            model_size = get_model_size_mb(str(model_path))
            
            # Estimate ELO (small gain for self-play data collection)
            latest_iq = enhanced_iq_tracker.get_current_status()
            current_elo = latest_iq.get('current_elo', 1500) + 5  # Small gain
            
            enhanced_iq_tracker.record_evaluation(
                model_id=active_model_name,
                current_elo=current_elo,
                opponent_elo=current_elo,  # Self-play
                win_rate=0.5,  # Self-play is balanced
                games_played=games_played,
                model_size_mb=model_size,
                games_processed=games_played,
                source="Self-Play",
                metadata={"session_id": session_id, "positions_generated": len(all_positions)}
            )
            
            # Export simplified format
            enhanced_iq_tracker.export_iq_growth_json()
            
            logger.info(f"IQ tracking updated: ELO ~{current_elo:.0f}, Model Size {model_size} MB, Source: Self-Play")
        except Exception as track_error:
            logger.warning(f"IQ tracking update failed: {track_error}")
        
        selfplay_status["status"] = "complete"
        selfplay_status["elapsed"] = int(total_elapsed)
        selfplay_status["eta"] = 0
        
    except Exception as e:
        logger.error(f"Self-play error: {str(e)}")
        import traceback
        traceback.print_exc()
        selfplay_status["status"] = f"error: {str(e)}"
    finally:
        selfplay_status["active"] = False

class SelfPlayConfig(BaseModel):
    num_games: int = Field(default=25, ge=1, le=100, description="Number of games to generate")
    num_simulations: int = Field(default=800, ge=100, le=1600, description="MCTS simulations per move")

@api_router.post("/self-play/start")
async def start_selfplay(config: SelfPlayConfig, background_tasks: BackgroundTasks):
    """
    Start self-play data collection
    Generates games and saves PGN files to cache
    """
    global selfplay_status, selfplay_task_handle
    
    if selfplay_status["active"]:
        raise HTTPException(status_code=400, detail="Self-play already in progress")
    
    # Generate session ID
    session_id = str(uuid.uuid4())[:8]
    
    selfplay_status = {
        "active": True,
        "status": "starting",
        "games_collected": 0,
        "target_games": config.num_games,
        "threads": 1,  # Single-threaded for now
        "elapsed": 0,
        "eta": 0,
        "start_time": None,
        "session_id": session_id,
        "model_used": None,
        "positions_generated": 0
    }
    
    # Run in background
    background_tasks.add_task(
        run_selfplay_pipeline,
        config.num_games,
        config.num_simulations,
        session_id
    )
    
    logger.info(f"Self-play started: session_id={session_id}, games={config.num_games}")
    
    return {
        "success": True,
        "message": "Self-play started",
        "session_id": session_id,
        "config": config.dict()
    }

@api_router.post("/self-play/run")
async def run_selfplay(config: SelfPlayConfig, background_tasks: BackgroundTasks):
    """
    Alias for /self-play/start (frontend compatibility)
    """
    return await start_selfplay(config, background_tasks)

@api_router.get("/self-play/status")
async def get_selfplay_status():
    """
    Get current self-play status
    Returns real-time progress for UI polling
    """
    import time
    from config_loader import SELFPLAY_CACHE_DIR
    
    # Calculate elapsed time dynamically if running
    elapsed = selfplay_status["elapsed"]
    if selfplay_status["active"] and selfplay_status["start_time"] is not None:
        elapsed = int(time.time() - selfplay_status["start_time"])
    
    # Load session totals for display
    total_sessions = 0
    total_positions = 0
    try:
        sessions_file = SELFPLAY_CACHE_DIR / "sessions.json"
        if sessions_file.exists():
            with open(sessions_file, 'r') as f:
                sessions_data = json.load(f)
                total_sessions = len(sessions_data.get("sessions", []))
                total_positions = sum(s.get("num_positions", 0) for s in sessions_data.get("sessions", []))
    except:
        pass
    
    return {
        "active": selfplay_status["active"],
        "status": selfplay_status["status"],
        "games_collected": selfplay_status["games_collected"],
        "target_games": selfplay_status["target_games"],
        "threads": selfplay_status["threads"],
        "elapsed": elapsed,
        "eta": selfplay_status["eta"],
        "session_id": selfplay_status["session_id"],
        "model_used": selfplay_status["model_used"],
        "positions_generated": selfplay_status["positions_generated"],
        "progress_percent": int((selfplay_status["games_collected"] / selfplay_status["target_games"]) * 100) if selfplay_status["target_games"] > 0 else 0,
        "total_sessions": total_sessions,
        "total_positions": total_positions
    }

@api_router.post("/self-play/stop")
async def stop_selfplay():
    """
    Stop ongoing self-play session
    """
    global selfplay_status
    
    if not selfplay_status["active"]:
        raise HTTPException(status_code=400, detail="No self-play session active")
    
    selfplay_status["active"] = False
    selfplay_status["status"] = "cancelled"
    
    logger.info("Self-play stop requested")
    
    return {
        "success": True,
        "message": "Self-play stop requested"
    }

@api_router.get("/self-play/sessions")
async def get_selfplay_sessions(limit: int = Query(default=20, ge=1, le=100)):
    """
    Get list of completed self-play sessions
    Returns sessions with statistics and PGN file paths
    """
    try:
        from config_loader import SELFPLAY_CACHE_DIR
        
        sessions_file = SELFPLAY_CACHE_DIR / "sessions.json"
        
        if not sessions_file.exists():
            return {
                "success": True,
                "sessions": [],
                "total_sessions": 0,
                "total_positions": 0
            }
        
        with open(sessions_file, 'r') as f:
            sessions_data = json.load(f)
        
        sessions = sessions_data.get("sessions", [])[:limit]
        
        # Calculate totals
        total_sessions = len(sessions_data.get("sessions", []))
        total_positions = sum(s.get("num_positions", 0) for s in sessions_data.get("sessions", []))
        
        return {
            "success": True,
            "sessions": sessions,
            "total_sessions": total_sessions,
            "total_positions": total_positions
        }
    except Exception as e:
        logger.error(f"Error loading sessions: {e}")
        return {
            "success": True,
            "sessions": [],
            "total_sessions": 0,
            "total_positions": 0
        }

@api_router.get("/self-play/export/{session_id}")
async def export_selfplay_session(
    session_id: str,
    format: str = Query(default="json", pattern="^(json|csv)$")
):
    """
    Export self-play session data
    Supports JSON and CSV formats
    """
    try:
        from config_loader import SELFPLAY_CACHE_DIR
        import csv
        from io import StringIO
        
        # Load sessions
        sessions_file = SELFPLAY_CACHE_DIR / "sessions.json"
        if not sessions_file.exists():
            raise HTTPException(status_code=404, detail="No sessions found")
        
        with open(sessions_file, 'r') as f:
            sessions_data = json.load(f)
        
        # Find session
        session = None
        for s in sessions_data.get("sessions", []):
            if s.get("session_id") == session_id:
                session = s
                break
        
        if not session:
            raise HTTPException(status_code=404, detail=f"Session {session_id} not found")
        
        if format == "json":
            return {
                "success": True,
                "session": session,
                "format": "json"
            }
        else:  # CSV
            # Create CSV from session data
            output = StringIO()
            writer = csv.writer(output)
            
            # Write header
            writer.writerow([
                "Session ID", "Timestamp", "Games", "Positions",
                "White Wins", "Black Wins", "Draws", "Avg Moves",
                "Duration (s)", "Games/Hour"
            ])
            
            # Write data
            stats = session.get("statistics", {})
            writer.writerow([
                session.get("session_id"),
                session.get("timestamp"),
                session.get("num_games"),
                session.get("num_positions"),
                stats.get("white_wins", 0),
                stats.get("black_wins", 0),
                stats.get("draws", 0),
                stats.get("average_moves", 0),
                stats.get("duration_seconds", 0),
                stats.get("games_per_hour", 0)
            ])
            
            csv_content = output.getvalue()
            
            return StreamingResponse(
                iter([csv_content]),
                media_type="text/csv",
                headers={
                    "Content-Disposition": f"attachment; filename=selfplay_{session_id}.csv"
                }
            )
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error exporting session: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# AlphaZero Massive Training Endpoints
# ====================

# Global AlphaZero trainer instance
alphazero_trainer = None
alphazero_training_thread = None

class AlphaZeroTrainingConfig(BaseModel):
    max_games: int = Field(default=44_000_000, ge=1000, le=50_000_000, description="Maximum number of self-play games")
    max_hours: float = Field(default=9.0, ge=0.1, le=24.0, description="Maximum training duration in hours")
    num_simulations: int = Field(default=800, ge=100, le=1600, description="MCTS simulations per move")
    replay_buffer_size: int = Field(default=1_000_000, ge=10000, le=5_000_000, description="Replay buffer capacity")
    batch_size: int = Field(default=256, ge=32, le=512, description="Training batch size")
    learning_rate: float = Field(default=0.001, ge=0.0001, le=0.01, description="Initial learning rate")
    checkpoint_interval: int = Field(default=1800, ge=300, le=7200, description="Checkpoint interval in seconds")
    eval_interval: int = Field(default=1000, ge=100, le=10000, description="Evaluation interval in games")
    win_threshold: float = Field(default=0.55, ge=0.5, le=1.0, description="Win rate threshold for promotion")
    num_eval_games: int = Field(default=40, ge=10, le=100, description="Number of evaluation games")
    resume: bool = Field(default=False, description="Resume from checkpoint if available")

@api_router.post("/train/start-alphazero")
async def start_alphazero_training(config: AlphaZeroTrainingConfig, background_tasks: BackgroundTasks):
    """
    Start massive-scale AlphaZero training (44M games / 9 hours)
    Implements full self-play training loop with:
    - Distributed parallel self-play
    - Replay buffer (1M positions)
    - Continuous training with cosine LR schedule
    - Periodic evaluation and model promotion
    - Checkpointing every 30 minutes
    """
    global alphazero_trainer, alphazero_training_thread
    
    if alphazero_trainer is not None and alphazero_trainer.is_running:
        raise HTTPException(status_code=400, detail="AlphaZero training already in progress")
    
    try:
        from selfplay_trainer import AlphaZeroSelfPlayTrainer
        
        # Create trainer instance
        alphazero_trainer = AlphaZeroSelfPlayTrainer(
            max_games=config.max_games,
            max_hours=config.max_hours,
            num_simulations=config.num_simulations,
            replay_buffer_size=config.replay_buffer_size,
            batch_size=config.batch_size,
            learning_rate=config.learning_rate,
            checkpoint_interval=config.checkpoint_interval,
            eval_interval=config.eval_interval
        )
        
        # Run in background thread
        def run_training():
            try:
                alphazero_trainer.run()
            except Exception as e:
                logger.error(f"AlphaZero training error: {e}")
                import traceback
                traceback.print_exc()
        
        import threading
        alphazero_training_thread = threading.Thread(target=run_training, daemon=True)
        alphazero_training_thread.start()
        
        logger.info(f"AlphaZero training started: {config.max_games:,} games / {config.max_hours} hours")
        
        return {
            "success": True,
            "message": "AlphaZero training started",
            "config": config.dict(),
            "estimated_duration_hours": config.max_hours,
            "target_games": config.max_games
        }
        
    except Exception as e:
        logger.error(f"Failed to start AlphaZero training: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/train/status-alphazero")
async def get_alphazero_training_status():
    """
    Get current AlphaZero training status
    Returns real-time progress, metrics, and ETA
    """
    global alphazero_trainer
    
    if alphazero_trainer is None:
        return {
            "active": False,
            "message": "No training session active",
            "games_completed": 0,
            "max_games": 0,
            "progress_pct": 0.0
        }
    
    status = alphazero_trainer.get_status()
    
    # Add active flag for compatibility (maps from is_running)
    status['active'] = status.get('is_running', False)
    
    # Add max_games and max_hours from trainer attributes
    status['max_games'] = alphazero_trainer.max_games
    status['max_hours'] = alphazero_trainer.max_hours
    
    # Calculate ETA
    if status.get('active', False) and status.get('games_per_sec', 0) > 0:
        remaining_games = status['max_games'] - status.get('games_completed', 0)
        remaining_time_by_games = remaining_games / status['games_per_sec']
        remaining_time_by_clock = (status['max_hours'] * 3600) - status.get('elapsed_seconds', 0)
        status['eta_seconds'] = int(min(remaining_time_by_games, remaining_time_by_clock))
        status['eta_hours'] = status['eta_seconds'] / 3600
    else:
        status['eta_seconds'] = 0
        status['eta_hours'] = 0.0
    
    return status

@api_router.post("/train/stop-alphazero")
async def stop_alphazero_training():
    """
    Stop AlphaZero training gracefully
    Saves checkpoint before stopping
    """
    global alphazero_trainer
    
    if alphazero_trainer is None or not alphazero_trainer.is_running:
        raise HTTPException(status_code=400, detail="No training session active")
    
    try:
        alphazero_trainer.stop()
        
        return {
            "success": True,
            "message": "Training stop requested (saving checkpoint...)",
            "games_completed": alphazero_trainer.games_completed
        }
    except Exception as e:
        logger.error(f"Error stopping training: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/train/metrics-alphazero")
async def get_alphazero_metrics():
    """
    Get detailed training metrics history
    Returns loss curves, ELO progression, throughput stats
    """
    try:
        metrics_file = Path("/data/training_logs/selfplay_44M/training_metrics.json")
        
        if not metrics_file.exists():
            return {
                "success": True,
                "metrics": [],
                "message": "No metrics available yet"
            }
        
        with open(metrics_file, 'r') as f:
            data = json.load(f)
        
        metrics = data.get('metrics', [])
        
        # Calculate summary statistics
        if len(metrics) > 0:
            latest = metrics[-1]
            summary = {
                'total_games': latest.get('games_completed', 0),
                'total_positions': latest.get('positions_collected', 0),
                'elapsed_hours': latest.get('elapsed_hours', 0),
                'current_elo': latest.get('current_elo', 1500),
                'models_promoted': latest.get('models_promoted', 0),
                'avg_games_per_sec': latest.get('games_per_sec', 0),
                'current_loss': latest.get('training_loss', 0),
                'learning_rate': latest.get('learning_rate', 0)
            }
        else:
            summary = {}
        
        return {
            "success": True,
            "metrics": metrics[-100:],  # Last 100 data points
            "summary": summary,
            "total_records": len(metrics)
        }
        
    except Exception as e:
        logger.error(f"Error loading metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/train/recent-positions")
async def get_recent_positions(limit: int = Query(default=10, ge=1, le=100)):
    """
    Get recent FEN positions from replay buffer (developer/debug mode)
    Returns the most recent N positions for verification and debugging
    """
    global alphazero_trainer
    
    if alphazero_trainer is None:
        return {
            "success": True,
            "positions": [],
            "message": "No training session active"
        }
    
    try:
        # Get recent positions from replay buffer
        buffer_size = alphazero_trainer.replay_buffer.size()
        
        if buffer_size == 0:
            return {
                "success": True,
                "positions": [],
                "buffer_size": 0,
                "message": "Replay buffer is empty"
            }
        
        # Sample recent positions (get from end of buffer)
        all_positions = alphazero_trainer.replay_buffer.get_all()
        recent_positions = all_positions[-min(limit, len(all_positions)):]
        
        # Extract FEN strings and metadata
        position_data = []
        for pos in recent_positions:
            position_data.append({
                'fen': pos.get('fen', 'N/A'),
                'value': pos.get('value', 0.0),
                'move_number': pos.get('move_number', 0)
            })
        
        return {
            "success": True,
            "positions": position_data,
            "buffer_size": buffer_size,
            "total_positions": alphazero_trainer.positions_collected,
            "message": f"Retrieved {len(position_data)} recent positions"
        }
        
    except Exception as e:
        logger.error(f"Error fetching recent positions: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Adaptive TPU Training Endpoints
# ====================

from adaptive_trainer_tpu import adaptive_tpu_trainer

class AdaptiveTrainingConfig(BaseModel):
    mode: str = Field(default="auto", pattern="^(auto|manual)$", description="Training trigger mode")
    retrain_frequency: int = Field(default=25, ge=10, le=100, description="Games before auto-retrain")
    elo_gain_threshold: float = Field(default=3.0, ge=1.0, le=10.0, description="Minimum ELO gain threshold")
    data_mix_ratio_selfplay: float = Field(default=0.7, ge=0.0, le=1.0, description="Self-play data ratio")
    data_mix_ratio_human: float = Field(default=0.3, ge=0.0, le=1.0, description="Human game data ratio")
    learning_rate: float = Field(default=0.0005, ge=0.0001, le=0.01, description="Learning rate")
    num_epochs: int = Field(default=3, ge=1, le=10, description="Training epochs")
    batch_size: int = Field(default=64, ge=16, le=256, description="Batch size")
    evaluation_games: int = Field(default=5, ge=3, le=20, description="Evaluation games")

@api_router.post("/train/start-adaptive")
async def start_adaptive_training(config: AdaptiveTrainingConfig, background_tasks: BackgroundTasks):
    """
    Start Adaptive TPU Learning Mode
    Enables continuous learning from mixed self-play and human game data
    """
    try:
        # Update trainer configuration
        adaptive_tpu_trainer.mode = config.mode
        adaptive_tpu_trainer.retrain_frequency = config.retrain_frequency
        adaptive_tpu_trainer.elo_gain_threshold = config.elo_gain_threshold
        adaptive_tpu_trainer.data_mix_ratio = (config.data_mix_ratio_selfplay, config.data_mix_ratio_human)
        adaptive_tpu_trainer.learning_rate = config.learning_rate
        adaptive_tpu_trainer.num_epochs = config.num_epochs
        adaptive_tpu_trainer.batch_size = config.batch_size
        adaptive_tpu_trainer.evaluation_games = config.evaluation_games
        
        # Start training in background
        success = adaptive_tpu_trainer.start_adaptive_training()
        
        if not success:
            raise HTTPException(status_code=400, detail="Adaptive training already active")
        
        logger.info(f"Adaptive TPU training started: mode={config.mode}, frequency={config.retrain_frequency}")
        
        return {
            "success": True,
            "message": "Adaptive TPU training started",
            "config": config.dict(),
            "backend_type": adaptive_tpu_trainer.backend_type
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to start adaptive training: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/train/status-adaptive")
async def get_adaptive_training_status():
    """
    Get current Adaptive TPU training status
    Returns real-time progress, ELO delta, and training metrics
    """
    try:
        status = adaptive_tpu_trainer.get_status()
        return {
            "success": True,
            **status
        }
    except Exception as e:
        logger.error(f"Error getting adaptive training status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/train/stop-adaptive")
async def stop_adaptive_training():
    """
    Stop Adaptive TPU training gracefully
    Completes current cycle before stopping
    """
    try:
        success = adaptive_tpu_trainer.stop_adaptive_training()
        
        if not success:
            raise HTTPException(status_code=400, detail="No adaptive training session active")
        
        return {
            "success": True,
            "message": "Adaptive training stop requested"
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error stopping adaptive training: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/train/history-adaptive")
async def get_adaptive_training_history(limit: int = Query(default=20, ge=1, le=50)):
    """
    Get Adaptive TPU training history
    Returns timeline of training cycles with ELO deltas and model versions
    """
    try:
        history = adaptive_tpu_trainer.get_training_history(limit=limit)
        
        return {
            "success": True,
            "history": history,
            "total_cycles": len(history)
        }
    except Exception as e:
        logger.error(f"Error getting adaptive training history: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/train/trigger-adaptive")
async def trigger_adaptive_training_manual(background_tasks: BackgroundTasks):
    """
    Manually trigger an adaptive training cycle (manual mode)
    Useful for testing or on-demand retraining
    """
    try:
        if adaptive_tpu_trainer.active:
            raise HTTPException(status_code=400, detail="Adaptive training already in progress")
        
        # Start training cycle
        background_tasks.add_task(adaptive_tpu_trainer.run_training_cycle)
        
        return {
            "success": True,
            "message": "Manual adaptive training cycle triggered"
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error triggering adaptive training: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Distributed TPU Training Endpoints
# ====================

from distributed_tpu_trainer import DistributedTPUTrainer, get_distributed_trainer

# Global distributed trainer state
distributed_trainer_instance = None
distributed_training_thread = None
distributed_training_status = {
    "active": False,
    "num_workers": 0,
    "games_completed": 0,
    "positions_collected": 0,
    "games_per_sec": 0.0,
    "start_time": None,
    "message": "Idle"
}

class DistributedTrainingConfig(BaseModel):
    num_workers: int = Field(default=8, ge=2, le=16, description="Number of parallel workers")
    num_games_total: int = Field(default=1000, ge=100, le=10000, description="Total games to generate")
    num_simulations: int = Field(default=800, ge=100, le=1600, description="MCTS simulations per move")
    replay_buffer_size: int = Field(default=1_000_000, ge=10000, le=5_000_000, description="Replay buffer capacity")
    batch_size: int = Field(default=256, ge=32, le=512, description="Training batch size")
    learning_rate: float = Field(default=0.001, ge=0.0001, le=0.01, description="Learning rate")
    num_training_epochs: int = Field(default=3, ge=1, le=10, description="Training epochs per cycle")
    num_eval_games: int = Field(default=10, ge=5, le=40, description="Evaluation games")

def run_distributed_training_pipeline(config: DistributedTrainingConfig):
    """Run distributed training pipeline in background"""
    try:
        global distributed_training_status, distributed_trainer_instance
        
        logger.info(f"Starting distributed training: {config.num_workers} workers, "
                   f"{config.num_games_total} games")
        
        # Update status
        distributed_training_status["active"] = True
        distributed_training_status["num_workers"] = config.num_workers
        distributed_training_status["message"] = "Initializing distributed trainer..."
        distributed_training_status["start_time"] = datetime.now(timezone.utc)
        
        # Create distributed trainer
        distributed_trainer_instance = DistributedTPUTrainer(
            num_workers=config.num_workers,
            replay_buffer_size=config.replay_buffer_size,
            batch_size=config.batch_size,
            learning_rate=config.learning_rate,
            num_simulations=config.num_simulations
        )
        
        distributed_trainer_instance.active = True
        
        # Get active model
        from config_loader import load_config
        config_data = load_config()
        active_model_name = config_data.get('active_model', 'ActiveModel_Offline.pth')
        model_path = distributed_trainer_instance.model_manager.get_model_path(Path(active_model_name).stem)
        
        if not model_path.exists():
            logger.error(f"Model not found: {active_model_name}")
            distributed_training_status["message"] = f"Error: Model {active_model_name} not found"
            distributed_training_status["active"] = False
            return
        
        # Phase 1: Parallel Self-Play
        distributed_training_status["message"] = "Launching parallel self-play workers..."
        logger.info(f"Phase 1: Launching {config.num_workers} workers for {config.num_games_total} games")
        
        training_data, game_results = distributed_trainer_instance.launch_parallel_selfplay(
            num_games_total=config.num_games_total,
            model_path=str(model_path)
        )
        
        # Update status
        distributed_training_status["games_completed"] = len(game_results)
        distributed_training_status["positions_collected"] = len(training_data)
        
        # Phase 2: Training on Aggregated Data
        distributed_training_status["message"] = "Training on aggregated data..."
        logger.info(f"Phase 2: Training on {len(training_data):,} positions")
        
        # Load network for training
        network, metadata = distributed_trainer_instance.model_manager.load_model(Path(active_model_name).stem)
        
        training_metrics = distributed_trainer_instance.run_distributed_training_cycle(
            network=network,
            num_epochs=config.num_training_epochs
        )
        
        logger.info(f"Training complete: Loss={training_metrics.get('loss', 0.0):.4f}")
        
        # Phase 3: Evaluation
        distributed_training_status["message"] = "Evaluating model improvement..."
        logger.info(f"Phase 3: Evaluating with {config.num_eval_games} games")
        
        # Load baseline for comparison
        baseline_network, _ = distributed_trainer_instance.model_manager.load_model(Path(active_model_name).stem)
        
        eval_results, should_promote = distributed_trainer_instance.evaluate_and_promote(
            new_network=network,
            baseline_network=baseline_network,
            num_eval_games=config.num_eval_games
        )
        
        # Phase 4: Save Model (if improved)
        if should_promote:
            distributed_training_status["message"] = "Promoting improved model..."
            
            model_name = f"DistributedModel_v{int(time.time())}"
            model_path_new = distributed_trainer_instance.model_manager.save_model(network, name=model_name, metadata={
                'training_method': 'distributed_tpu',
                'num_workers': config.num_workers,
                'games_trained': len(game_results),
                'positions_trained': len(training_data),
                'training_loss': training_metrics.get('loss', 0.0),
                'win_rate': eval_results.get('challenger_win_rate', 0.0),
                'timestamp': datetime.now(timezone.utc).isoformat()
            })
            
            logger.info(f"✅ Model promoted: {model_name}, Win rate: {eval_results.get('challenger_win_rate', 0.0):.1%}")
            distributed_training_status["message"] = f"✅ Model promoted: {model_name}"
        else:
            logger.info(f"⚠️ Model not promoted: Win rate {eval_results.get('challenger_win_rate', 0.0):.1%}")
            distributed_training_status["message"] = "⚠️ Model did not improve, rollback performed"
        
        distributed_training_status["active"] = False
        distributed_trainer_instance.active = False
        
        logger.info("Distributed training pipeline complete!")
        
    except Exception as e:
        logger.error(f"Distributed training error: {e}")
        import traceback
        traceback.print_exc()
        
        distributed_training_status["message"] = f"Error: {str(e)}"
        distributed_training_status["active"] = False
        
        if distributed_trainer_instance:
            distributed_trainer_instance.active = False

@api_router.post("/train/start-distributed")
async def start_distributed_training(config: DistributedTrainingConfig, background_tasks: BackgroundTasks):
    """
    Start distributed TPU parallel self-play training
    Spawns multiple workers for high-throughput game generation
    """
    global distributed_training_status, distributed_training_thread
    
    if distributed_training_status["active"]:
        raise HTTPException(status_code=400, detail="Distributed training already in progress")
    
    try:
        # Run in background thread
        import threading
        distributed_training_thread = threading.Thread(
            target=run_distributed_training_pipeline,
            args=(config,),
            daemon=True
        )
        distributed_training_thread.start()
        
        logger.info(f"Distributed training started: {config.num_workers} workers")
        
        return {
            "success": True,
            "message": "Distributed training started",
            "config": config.dict(),
            "num_workers": config.num_workers,
            "backend_type": "Simulated Multi-Process" if not TPU_AVAILABLE else "TPU"
        }
    
    except Exception as e:
        logger.error(f"Failed to start distributed training: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/train/status-distributed")
async def get_distributed_training_status():
    """
    Get current distributed training status
    Returns real-time progress and worker metrics
    """
    global distributed_training_status, distributed_trainer_instance
    
    status = {
        "active": distributed_training_status["active"],
        "num_workers": distributed_training_status["num_workers"],
        "games_completed": distributed_training_status["games_completed"],
        "positions_collected": distributed_training_status["positions_collected"],
        "message": distributed_training_status["message"],
        "start_time": distributed_training_status.get("start_time")
    }
    
    # Add performance metrics if trainer is active
    if distributed_trainer_instance and distributed_trainer_instance.active:
        perf_metrics = distributed_trainer_instance.get_performance_metrics()
        status.update({
            "games_per_sec": perf_metrics.get("games_per_sec", 0.0),
            "positions_per_sec": perf_metrics.get("positions_per_sec", 0.0),
            "active_workers": perf_metrics.get("active_workers", 0),
            "replay_buffer_size": perf_metrics.get("replay_buffer_size", 0),
            "backend": perf_metrics.get("backend", "Unknown"),
            "worker_stats": perf_metrics.get("worker_stats", {})
        })
    
    return status

@api_router.post("/train/stop-distributed")
async def stop_distributed_training():
    """
    Stop distributed training gracefully
    Waits for workers to complete current games
    """
    global distributed_training_status, distributed_trainer_instance
    
    if not distributed_training_status["active"]:
        raise HTTPException(status_code=400, detail="No distributed training session active")
    
    try:
        if distributed_trainer_instance:
            distributed_trainer_instance.cleanup()
        
        distributed_training_status["active"] = False
        distributed_training_status["message"] = "Stopped by user"
        
        logger.info("Distributed training stopped by user")
        
        return {
            "success": True,
            "message": "Distributed training stopped"
        }
    
    except Exception as e:
        logger.error(f"Error stopping distributed training: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/train/performance")
async def get_training_performance():
    """
    Get real-time performance metrics for distributed training
    Returns throughput, worker stats, and system utilization
    """
    global distributed_trainer_instance
    
    if distributed_trainer_instance is None or not distributed_trainer_instance.active:
        return {
            "active": False,
            "message": "No distributed training session active",
            "games_per_sec": 0.0,
            "positions_per_sec": 0.0,
            "active_workers": 0,
            "avg_mcts_time": 0.0,
            "backend": "N/A"
        }
    
    try:
        metrics = distributed_trainer_instance.get_performance_metrics()
        
        return {
            "active": True,
            "games_per_sec": metrics.get("games_per_sec", 0.0),
            "positions_per_sec": metrics.get("positions_per_sec", 0.0),
            "active_workers": metrics.get("active_workers", 0),
            "avg_mcts_time": metrics.get("avg_mcts_time", 0.0),
            "backend": metrics.get("backend", "Unknown"),
            "replay_buffer_size": metrics.get("replay_buffer_size", 0),
            "replay_buffer_max": metrics.get("replay_buffer_max", 0),
            "games_completed": metrics.get("games_completed", 0),
            "positions_collected": metrics.get("positions_collected", 0),
            "elapsed_seconds": metrics.get("elapsed_seconds", 0),
            "worker_stats": metrics.get("worker_stats", {})
        }
    
    except Exception as e:
        logger.error(f"Error getting performance metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Hyperparameter Optimization Endpoints
# ====================

from hyperparam_optimizer import get_hpo_optimizer, HyperparameterOptimizer

# Global HPO optimizer instance
hpo_optimizer_instance = None

class HPOConfig(BaseModel):
    max_trials: int = Field(default=25, ge=5, le=100, description="Maximum number of optimization trials")
    evaluation_games: int = Field(default=10, ge=5, le=20, description="Games per trial for evaluation")
    num_workers: int = Field(default=4, ge=2, le=8, description="Number of parallel workers")
    resume: bool = Field(default=False, description="Resume from previous HPO session")

@api_router.post("/train/start-hpo")
async def start_hpo(config: HPOConfig, background_tasks: BackgroundTasks):
    """
    Start Hyperparameter Optimization
    Runs Bayesian optimization to find optimal AlphaZero parameters
    """
    global hpo_optimizer_instance
    
    try:
        # Create or get optimizer instance
        if hpo_optimizer_instance is None or not config.resume:
            hpo_optimizer_instance = get_hpo_optimizer(
                max_trials=config.max_trials,
                evaluation_games=config.evaluation_games,
                num_workers=config.num_workers
            )
        
        # Check if already active
        if hpo_optimizer_instance.active:
            raise HTTPException(status_code=400, detail="HPO already in progress")
        
        # Start optimization
        success = hpo_optimizer_instance.start_optimization(resume=config.resume)
        
        if not success:
            raise HTTPException(status_code=400, detail="Failed to start HPO")
        
        logger.info(f"HPO started: {config.max_trials} trials, {config.evaluation_games} eval games")
        
        return {
            "success": True,
            "message": "Hyperparameter optimization started",
            "config": config.dict(),
            "max_trials": config.max_trials,
            "evaluation_games": config.evaluation_games
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to start HPO: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/train/status-hpo")
async def get_hpo_status():
    """
    Get current HPO status
    Returns real-time progress, current trial, and best parameters found
    """
    global hpo_optimizer_instance
    
    if hpo_optimizer_instance is None:
        return {
            "active": False,
            "message": "No HPO session initialized",
            "current_trial": 0,
            "max_trials": 0,
            "progress_percent": 0,
            "best_params": None
        }
    
    try:
        status = hpo_optimizer_instance.get_status()
        
        # Add ETA calculation
        if status['active'] and status['total_trials_completed'] > 0:
            # Estimate based on average trial time
            trial_history = hpo_optimizer_instance.get_trial_history(limit=5)
            if trial_history:
                avg_trial_time = np.mean([t['metrics']['training_time'] for t in trial_history])
                remaining_trials = status['max_trials'] - status['current_trial']
                status['eta_minutes'] = int((remaining_trials * avg_trial_time) / 60)
            else:
                status['eta_minutes'] = 0
        else:
            status['eta_minutes'] = 0
        
        return {
            "success": True,
            **status
        }
    
    except Exception as e:
        logger.error(f"Error getting HPO status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/train/stop-hpo")
async def stop_hpo():
    """
    Stop HPO gracefully
    Completes current trial before stopping
    """
    global hpo_optimizer_instance
    
    if hpo_optimizer_instance is None or not hpo_optimizer_instance.active:
        raise HTTPException(status_code=400, detail="No HPO session active")
    
    try:
        success = hpo_optimizer_instance.stop_optimization()
        
        if not success:
            raise HTTPException(status_code=400, detail="Failed to stop HPO")
        
        return {
            "success": True,
            "message": "HPO stop requested (completing current trial...)",
            "trials_completed": hpo_optimizer_instance.current_trial
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error stopping HPO: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/train/best-params")
async def get_best_params():
    """
    Get best hyperparameters found so far
    Returns optimal parameter configuration and performance metrics
    """
    global hpo_optimizer_instance
    
    if hpo_optimizer_instance is None:
        return {
            "success": True,
            "best_params": None,
            "message": "No HPO session found"
        }
    
    try:
        best_params = hpo_optimizer_instance.get_best_parameters()
        status = hpo_optimizer_instance.get_status()
        
        return {
            "success": True,
            "best_params": best_params,
            "best_trial": status.get('best_trial'),
            "total_trials": status['total_trials_completed']
        }
    
    except Exception as e:
        logger.error(f"Error getting best params: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/train/hpo-history")
async def get_hpo_history(limit: int = Query(default=50, ge=1, le=100)):
    """
    Get HPO trial history
    Returns list of completed trials with parameters and metrics
    """
    global hpo_optimizer_instance
    
    if hpo_optimizer_instance is None:
        return {
            "success": True,
            "trials": [],
            "total_trials": 0,
            "message": "No HPO session found"
        }
    
    try:
        trial_history = hpo_optimizer_instance.get_trial_history(limit=limit)
        
        return {
            "success": True,
            "trials": trial_history,
            "total_trials": len(trial_history)
        }
    
    except Exception as e:
        logger.error(f"Error getting HPO history: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/train/hpo-insights")
async def get_hpo_insights():
    """
    Get meta-learning insights and correlations
    Returns parameter-performance correlations and regression model quality
    """
    global hpo_optimizer_instance
    
    if hpo_optimizer_instance is None:
        return {
            "success": True,
            "insights": {},
            "message": "No HPO session found"
        }
    
    try:
        insights = hpo_optimizer_instance.get_meta_learning_insights()
        
        return {
            "success": True,
            "insights": insights,
            "total_trials_analyzed": insights.get('total_trials_analyzed', 0)
        }
    
    except Exception as e:
        logger.error(f"Error getting HPO insights: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/train/apply-best-params")
async def apply_best_params():
    """
    Apply best hyperparameters to current training configuration
    Updates active configuration with optimal parameters
    """
    global hpo_optimizer_instance
    
    if hpo_optimizer_instance is None:
        raise HTTPException(status_code=404, detail="No HPO session found")
    
    try:
        best_params = hpo_optimizer_instance.get_best_parameters()
        
        if not best_params:
            raise HTTPException(status_code=404, detail="No best parameters available yet")
        
        # Update config.json with best parameters
        config = load_config()
        config['hpo_best_params'] = best_params
        config['hpo_applied_at'] = datetime.now(timezone.utc).isoformat()
        
        # Save updated config
        config_path = Path("/app/backend/config.json")
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        
        logger.info(f"Applied best HPO parameters: {best_params}")
        
        return {
            "success": True,
            "message": "Best parameters applied to configuration",
            "params": best_params
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error applying best params: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Neural Architecture Search (NAS) Endpoints
# ====================

from neural_architecture_search import get_nas_controller, NeuralArchitectureSearchController

# Global NAS controller instance
nas_controller_instance = None

class NASConfig(BaseModel):
    population_size: int = Field(default=12, ge=8, le=16, description="Population size per generation")
    max_generations: int = Field(default=10, ge=5, le=20, description="Maximum generations to evolve")
    mutation_rate: float = Field(default=0.25, ge=0.1, le=0.5, description="Mutation probability")
    evaluation_games: int = Field(default=10, ge=5, le=20, description="Games per architecture evaluation")
    auto_trigger: bool = Field(default=False, description="Auto-trigger after HPO completion")
    resume: bool = Field(default=False, description="Resume from previous NAS session")

@api_router.post("/train/start-nas")
async def start_nas(config: NASConfig, background_tasks: BackgroundTasks):
    """
    Start Neural Architecture Search
    Evolves network architectures using evolutionary algorithms
    """
    global nas_controller_instance
    
    try:
        # Create or get controller instance
        if nas_controller_instance is None or not config.resume:
            nas_controller_instance = get_nas_controller(
                population_size=config.population_size,
                max_generations=config.max_generations,
                auto_trigger=config.auto_trigger
            )
            nas_controller_instance.mutation_rate = config.mutation_rate
            nas_controller_instance.evaluation_games = config.evaluation_games
        
        # Check if already active
        if nas_controller_instance.active:
            raise HTTPException(status_code=400, detail="NAS already in progress")
        
        # Start search
        success = nas_controller_instance.start_search()
        
        if not success:
            raise HTTPException(status_code=400, detail="Failed to start NAS")
        
        logger.info(f"NAS started: Population={config.population_size}, Generations={config.max_generations}")
        
        return {
            "success": True,
            "message": "Neural Architecture Search started",
            "config": config.dict(),
            "population_size": config.population_size,
            "max_generations": config.max_generations
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to start NAS: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/train/status-nas")
async def get_nas_status():
    """
    Get current NAS status
    Returns real-time progress, current generation, and best architecture found
    """
    global nas_controller_instance
    
    if nas_controller_instance is None:
        return {
            "active": False,
            "message": "No NAS session initialized",
            "current_generation": 0,
            "max_generations": 0,
            "progress_percent": 0,
            "best_elo": None,
            "best_genome_id": None
        }
    
    try:
        status = nas_controller_instance.get_status()
        
        # Add generation summary if available
        history = nas_controller_instance.get_evolution_history(limit=1)
        if history:
            latest_gen = history[-1]
            status['latest_generation_summary'] = {
                'best_elo': latest_gen['best_genome']['performance']['elo'],
                'avg_elo': latest_gen.get('avg_elo', 0),
                'avg_fitness': latest_gen.get('avg_fitness', 0)
            }
        
        return {
            "success": True,
            **status
        }
    
    except Exception as e:
        logger.error(f"Error getting NAS status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/train/stop-nas")
async def stop_nas():
    """
    Stop NAS gracefully
    Completes current generation before stopping
    """
    global nas_controller_instance
    
    if nas_controller_instance is None or not nas_controller_instance.active:
        raise HTTPException(status_code=400, detail="No NAS session active")
    
    try:
        success = nas_controller_instance.stop_search()
        
        if not success:
            raise HTTPException(status_code=400, detail="Failed to stop NAS")
        
        return {
            "success": True,
            "message": "NAS stop requested (completing current generation...)",
            "current_generation": nas_controller_instance.current_generation
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error stopping NAS: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/train/best-architecture")
async def get_best_architecture():
    """
    Get best architecture discovered by NAS
    Returns genome details, performance metrics, and architecture parameters
    """
    global nas_controller_instance
    
    if nas_controller_instance is None:
        return {
            "success": False,
            "message": "No NAS session found",
            "best_architecture": None
        }
    
    try:
        best_genome = nas_controller_instance.get_best_genome()
        
        if best_genome is None:
            return {
                "success": True,
                "message": "No best architecture found yet",
                "best_architecture": None
            }
        
        return {
            "success": True,
            "best_architecture": best_genome.to_dict(),
            "model_saved": True
        }
    
    except Exception as e:
        logger.error(f"Error getting best architecture: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/train/nas-history")
async def get_nas_history(limit: int = Query(default=20, ge=1, le=50)):
    """
    Get NAS evolution history
    Returns timeline of generations with best genomes and metrics
    """
    global nas_controller_instance
    
    if nas_controller_instance is None:
        return {
            "success": True,
            "history": [],
            "total_generations": 0
        }
    
    try:
        history = nas_controller_instance.get_evolution_history(limit=limit)
        
        return {
            "success": True,
            "history": history,
            "total_generations": len(history),
            "current_generation": nas_controller_instance.current_generation
        }
    
    except Exception as e:
        logger.error(f"Error getting NAS history: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/train/promote-nas-architecture")
async def promote_nas_architecture(genome_id: str = Query(..., description="Genome ID to promote")):
    """
    Manually promote a NAS-discovered architecture as active model
    """
    global nas_controller_instance
    
    if nas_controller_instance is None:
        raise HTTPException(status_code=404, detail="No NAS session found")
    
    try:
        # Find genome in history
        best_genome = nas_controller_instance.get_best_genome()
        
        if best_genome is None or best_genome.genome_id != genome_id:
            raise HTTPException(status_code=404, detail=f"Genome {genome_id} not found")
        
        # Create network and save as active model
        network = best_genome.create_network()
        model_name = f"NAS_Promoted_{genome_id}_{int(time.time())}"
        
        model_path = nas_controller_instance.model_manager.save_model(network, name=model_name, metadata={
            'source': 'nas_promotion',
            'genome_id': genome_id,
            'generation': best_genome.generation,
            'elo': best_genome.elo,
            'architecture': best_genome.to_dict()['architecture'],
            'promoted_at': datetime.now(timezone.utc).isoformat()
        })
        
        logger.info(f"NAS architecture promoted: {genome_id} → {model_name}")
        
        return {
            "success": True,
            "message": f"Architecture {genome_id} promoted successfully",
            "model_name": model_name,
            "model_path": str(model_path),
            "elo": best_genome.elo
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error promoting NAS architecture: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Evaluation Endpoints
# ====================

def run_evaluation_pipeline(config: EvaluationConfig):
    """Run evaluation in background"""
    try:
        global evaluation_status
        evaluation_status["message"] = "Loading models..."
        evaluation_status["progress"] = 10
        
        # Load models
        challenger_model, challenger_meta = model_manager.load_model(config.challenger_name)
        champion_model, champion_meta = model_manager.load_model(config.champion_name)
        
        if not challenger_model or not champion_model:
            raise Exception("Failed to load one or both models")
        
        evaluation_status["message"] = f"Running evaluation ({config.num_games} games)..."
        evaluation_status["progress"] = 30
        
        # Run evaluation
        evaluator = ModelEvaluator(
            num_evaluation_games=config.num_games,
            num_simulations=config.num_simulations,
            win_threshold=config.win_threshold
        )
        
        results, should_promote = evaluator.evaluate_models(
            challenger_model,
            champion_model,
            config.challenger_name,
            config.champion_name
        )
        
        evaluation_status["progress"] = 80
        evaluation_status["message"] = "Storing results..."
        
        # Store results using sync client
        sync_client = MongoClient(os.environ.get('MONGO_URL', 'mongodb://localhost:27017'))
        sync_db = sync_client[os.environ.get('DB_NAME', 'alphazero_chess')]
        
        sync_db.model_evaluations.insert_one({
            **results,
            "timestamp": datetime.now(timezone.utc),
            "automatic": False,
            "source": "pipeline_test"
        })
        
        sync_client.close()
        
        evaluation_status["progress"] = 100
        evaluation_status["message"] = "Evaluation complete!"
        evaluation_status["results"] = results
        
        logger.info(f"Evaluation complete: {results['challenger_win_rate']:.1%} win rate")
        
    except Exception as e:
        logger.error(f"Evaluation error: {str(e)}")
        evaluation_status["message"] = f"Error: {str(e)}"
        evaluation_status["progress"] = 0
        raise
    finally:
        evaluation_status["active"] = False

@api_router.post("/evaluation/run")
async def run_evaluation(config: EvaluationConfig, background_tasks: BackgroundTasks):
    """Run evaluation between two models"""
    global evaluation_status
    
    if evaluation_status["active"]:
        raise HTTPException(status_code=400, detail="Evaluation already in progress")
    
    evaluation_status = {
        "active": True,
        "progress": 0,
        "message": "Starting evaluation...",
        "results": None
    }
    
    background_tasks.add_task(run_evaluation_pipeline, config)
    
    return {
        "success": True,
        "message": "Evaluation started",
        "config": config.dict()
    }

@api_router.get("/evaluation/status")
async def get_evaluation_status():
    """Get current evaluation status"""
    return evaluation_status

@api_router.get("/evaluation/history")
async def get_evaluation_history(limit: int = 10):
    """Get evaluation history"""
    evaluations = await db.model_evaluations.find().sort("timestamp", -1).limit(limit).to_list(limit)
    return {"evaluations": evaluations}

# ====================
# Model Management Endpoints
# ====================

@api_router.get("/model/list")
async def list_models():
    """List all available models with ELO ratings"""
    models = model_manager.list_models()
    
    # Get active model
    active_model_doc = await db.active_model.find_one({})
    active_model_name = active_model_doc["model_name"] if active_model_doc else None
    
    # Get all evaluation results to calculate ELO
    evaluations = await db.model_evaluations.find().to_list(1000)
    
    # Calculate ELO ratings for each model
    elo_ratings = {}
    for model_name in models:
        # Start with base ELO
        elo = 1500
        
        # Find evaluations involving this model
        model_evals = [e for e in evaluations if e.get("challenger_name") == model_name or e.get("champion_name") == model_name]
        
        if model_evals:
            # Use latest win rate to adjust ELO
            latest_eval = max(model_evals, key=lambda x: x.get("timestamp", datetime.min))
            if latest_eval.get("challenger_name") == model_name:
                win_rate = latest_eval.get("challenger_win_rate", 0.5)
            else:
                win_rate = 1.0 - latest_eval.get("challenger_win_rate", 0.5)
            
            # Adjust ELO based on win rate (simplified)
            elo = 1500 + int((win_rate - 0.5) * 400)
        
        elo_ratings[model_name] = elo
    
    model_list = []
    for model_name in models:
        model_info = model_manager.get_model_info(model_name)
        if model_info:
            metadata = model_info.get("metadata", {})
            model_path = model_manager.get_model_path(model_name)
            file_size = os.path.getsize(model_path) / (1024 * 1024) if model_path.exists() else 0
            
            # Get last modified time from file
            try:
                timestamp = datetime.fromtimestamp(model_path.stat().st_mtime, tz=timezone.utc).isoformat()
            except:
                timestamp = metadata.get("training_date", "unknown")
            
            model_list.append({
                "name": model_name,
                "path": str(model_path),
                "version": metadata.get("version", "unknown"),
                "timestamp": timestamp,
                "training_date": metadata.get("training_date", "unknown"),
                "file_size_mb": round(file_size, 2),
                "elo": elo_ratings.get(model_name, 1500),
                "active": model_name == active_model_name,
                "is_active": model_name == active_model_name,
                "metadata": metadata
            })
    
    # Sort by ELO descending
    model_list.sort(key=lambda x: x["elo"], reverse=True)
    
    return {"success": True, "models": model_list, "count": len(model_list)}

@api_router.get("/model/current")
async def get_current_model():
    """Get current active model"""
    active_model_doc = await db.active_model.find_one({})
    return {
        "success": True,
        "active_model": active_model_doc["model_name"] if active_model_doc else None,
        "details": active_model_doc
    }

@api_router.post("/model/activate/{model_name}")
async def activate_model(model_name: str):
    """Activate a specific model"""
    # Verify model exists
    model_info = model_manager.get_model_info(model_name)
    if not model_info:
        raise HTTPException(status_code=404, detail=f"Model {model_name} not found")
    
    # Update active model
    await db.active_model.replace_one(
        {},
        {
            "model_name": model_name,
            "promoted_at": datetime.now(timezone.utc),
            "manual_activation": True
        },
        upsert=True
    )
    
    return {"success": True, "message": f"Model {model_name} activated"}

@api_router.get("/model/info/{model_name}")
async def get_model_info(model_name: str):
    """Get detailed model information"""
    model_info = model_manager.get_model_info(model_name)
    if not model_info:
        raise HTTPException(status_code=404, detail=f"Model {model_name} not found")
    
    return {"success": True, "model_info": model_info}

@api_router.post("/model/save")
async def save_model(name: str = Query(..., description="Model name")):
    """Save current model with given name"""
    try:
        # Get currently loaded network (would need to be stored globally)
        # For now, we'll copy the active model with a new name
        active_model_doc = await db.active_model.find_one({})
        if not active_model_doc:
            raise HTTPException(status_code=404, detail="No active model to save")
        
        active_model_name = active_model_doc["model_name"]
        
        # Load the active model
        network, metadata = model_manager.load_model(active_model_name)
        
        # Update metadata with new name and timestamp
        new_metadata = {
            **metadata,
            "saved_from": active_model_name,
            "saved_at": datetime.now(timezone.utc).isoformat(),
            "custom_name": name
        }
        
        # Save with new name
        model_path = model_manager.save_model(network, name, metadata=new_metadata)
        
        return {
            "success": True,
            "message": f"Model saved as {name}",
            "model_name": name,
            "path": str(model_path)
        }
    except Exception as e:
        logger.error(f"Error saving model: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/model/load")
async def load_model_endpoint(name: str = Query(..., description="Model name")):
    """Load a model and make it active"""
    try:
        # Verify model exists
        model_info = model_manager.get_model_info(name)
        if not model_info:
            raise HTTPException(status_code=404, detail=f"Model {name} not found")
        
        # Load model (just to verify it works)
        network, metadata = model_manager.load_model(name)
        
        # Update active model in database
        await db.active_model.replace_one(
            {},
            {
                "model_name": name,
                "promoted_at": datetime.now(timezone.utc),
                "manual_activation": True,
                "metadata": metadata
            },
            upsert=True
        )
        
        return {
            "success": True,
            "message": f"Model {name} loaded and activated",
            "model_name": name
        }
    except Exception as e:
        logger.error(f"Error loading model: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ====================
# Model Export Endpoints
# ====================

@api_router.post("/model/export/{format}/{model_name}")
async def export_model(format: str, model_name: str, request: ExportRequest = ExportRequest()):
    """Export model in specified format"""
    if format not in ["pytorch", "onnx"]:
        raise HTTPException(status_code=400, detail="Format must be 'pytorch' or 'onnx'")
    
    try:
        if format == "pytorch":
            result = await asyncio.get_event_loop().run_in_executor(
                executor,
                model_exporter.export_pytorch,
                model_name,
                request.metadata
            )
        else:
            result = await asyncio.get_event_loop().run_in_executor(
                executor,
                model_exporter.export_onnx,
                model_name,
                request.metadata
            )
        
        return {
            "success": True,
            "message": f"Model exported successfully to {format} format",
            **result
        }
    except Exception as e:
        logger.error(f"Export error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/model/exports")
async def list_exports():
    """List all exported models"""
    exports = model_exporter.list_exports()
    return {"success": True, "exports": exports, "count": len(exports)}

@api_router.get("/model/download/{filename}")
async def download_export(filename: str):
    """Download an exported model file"""
    file_path = model_exporter.get_export_path(filename)
    if not file_path or not file_path.exists():
        raise HTTPException(status_code=404, detail="Export file not found")
    
    return FileResponse(
        path=str(file_path),
        filename=filename,
        media_type="application/octet-stream"
    )

# ====================
# Statistics Endpoint
# ====================

@api_router.get("/stats")
async def get_stats():
    """Get overall statistics"""
    total_games = await db.self_play_positions.count_documents({})
    total_epochs = await db.training_metrics.count_documents({})
    total_evaluations = await db.model_evaluations.count_documents({})
    
    active_model_doc = await db.active_model.find_one({})
    
    return {
        "total_self_play_positions": total_games,
        "total_training_epochs": total_epochs,
        "total_evaluations": total_evaluations,
        "total_models": len(model_manager.list_models()),
        "active_model": active_model_doc["model_name"] if active_model_doc else None,
        "training_active": training_status["active"],
        "evaluation_active": evaluation_status["active"]
    }

# ====================
# Performance Monitoring Endpoints
# ====================

@api_router.get("/performance/status")
async def get_performance_status():
    """
    Get current performance metrics
    Returns real-time self-play speed, MCTS throughput, and training performance
    """
    try:
        perf_stats = performance_monitor.get_stats()
        
        # Load config for target comparison
        config_path = Path("/app/backend/config.json")
        if config_path.exists():
            with open(config_path, 'r') as f:
                config = json.load(f)
                target_games_per_min = config.get('performance', {}).get('target_games_per_min', 30)
        else:
            target_games_per_min = 30
        
        # Add target comparison
        current_gpm = perf_stats.get('selfplay_speed_raw', 0)
        perf_stats['target_games_per_min'] = target_games_per_min
        perf_stats['target_progress'] = min(100, (current_gpm / target_games_per_min) * 100) if target_games_per_min > 0 else 0
        
        return perf_stats
    except Exception as e:
        logger.error(f"Error getting performance status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/performance/metrics")
async def get_performance_metrics():
    """Get detailed performance metrics history"""
    try:
        stats = performance_monitor.get_stats()
        
        # Load config
        config_path = Path("/app/backend/config.json")
        config = {}
        if config_path.exists():
            with open(config_path, 'r') as f:
                config = json.load(f)
        
        return {
            'current': stats,
            'configuration': {
                'self_play_threads': config.get('self_play', {}).get('threads', 1),
                'parallel_enabled': config.get('self_play', {}).get('enable_parallel', False),
                'mcts_simulations': config.get('self_play', {}).get('mcts_simulations', 800),
                'batch_evaluation': config.get('mcts', {}).get('batch_evaluation', {}).get('enabled', False),
                'dynamic_depth': config.get('mcts', {}).get('dynamic_depth', {}).get('enabled', False)
            },
            'optimizations': {
                'parallel_selfplay': config.get('self_play', {}).get('enable_parallel', False),
                'batched_mcts': config.get('mcts', {}).get('batch_evaluation', {}).get('enabled', False),
                'adaptive_learning': config.get('training', {}).get('adaptive_learning', {}).get('enabled', False),
                'mixed_precision': config.get('training', {}).get('use_mixed_precision', False)
            }
        }
    except Exception as e:
        logger.error(f"Error getting performance metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/performance/reset")
async def reset_performance_metrics():
    """Reset performance monitoring metrics"""
    try:
        performance_monitor.reset()
        return {"message": "Performance metrics reset successfully"}
    except Exception as e:
        logger.error(f"Error resetting performance metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ====================
# IQ Growth Tracking Endpoints
# ====================

@api_router.get("/iq/history")
async def get_iq_history(limit: Optional[int] = None):
    """
    Get model IQ growth history
    Returns ELO progression and model comparison results
    """
    try:
        history = iq_tracker.get_history(limit=limit)
        statistics = iq_tracker.get_statistics()
        progression = iq_tracker.get_elo_progression()
        
        return {
            'history': history,
            'statistics': statistics,
            'progression': progression,
            'chart_data': {
                'labels': [entry['timestamp'][:10] for entry in progression],  # Date only
                'elo_values': [entry['elo'] for entry in progression],
                'elo_deltas': [entry.get('elo_delta', 0) for entry in progression]
            }
        }
    except Exception as e:
        logger.error(f"Error getting IQ history: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/iq/latest")
async def get_latest_iq():
    """Get most recent IQ comparison"""
    try:
        latest = iq_tracker.get_latest()
        if not latest:
            return {
                'message': 'No IQ comparisons recorded yet',
                'current_elo': 1500
            }
        return latest
    except Exception as e:
        logger.error(f"Error getting latest IQ: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/evaluate/self")
async def evaluate_self(background_tasks: BackgroundTasks):
    """
    Enhanced self-evaluation: Compare current model against previous model
    Tracks ELO delta and IQ growth
    """
    try:
        # Load config
        config_path = Path("/app/backend/config.json")
        if config_path.exists():
            with open(config_path, 'r') as f:
                config = json.load(f)
        else:
            raise HTTPException(status_code=500, detail="Configuration file not found")
        
        # Get comparison settings
        comparison_games = config.get('iq_tracking', {}).get('comparison_games', 10)
        mcts_sims = config.get('evaluation', {}).get('mcts_simulations', 400)
        
        # Get model list
        models = model_manager.list_models()
        if len(models) < 2:
            return {
                'message': 'Need at least 2 models for self-evaluation',
                'models_available': len(models)
            }
        
        # Sort models (assume versioned naming)
        models.sort()
        current_model = models[-1]
        previous_model = models[-2]
        
        logger.info(f"Starting self-evaluation: {current_model} vs {previous_model}")
        
        # Run evaluation in background
        def run_self_evaluation():
            try:
                # Load models
                current_net, _ = model_manager.load_model(current_model)
                previous_net, _ = model_manager.load_model(previous_model)
                
                # Create evaluator
                evaluator = ModelEvaluator(
                    num_evaluation_games=comparison_games,
                    num_simulations=mcts_sims
                )
                
                # Run evaluation
                current_elo = 1500  # Starting ELO
                previous_elo = 1500
                
                # Try to get previous ELO from history
                latest_iq = iq_tracker.get_latest()
                if latest_iq:
                    previous_elo = latest_iq.get('current_elo', 1500)
                
                results, should_promote = evaluator.evaluate_models(
                    current_net, previous_net,
                    current_model, previous_model,
                    challenger_elo=current_elo,
                    champion_elo=previous_elo
                )
                
                # Record in IQ tracker
                iq_tracker.record_comparison(
                    model_id=current_model,
                    previous_model_id=previous_model,
                    current_elo=results['challenger_elo_after'],
                    previous_elo=previous_elo,
                    win_rate=results['win_rate'],
                    games_played=comparison_games,
                    metadata={
                        'should_promote': should_promote,
                        'elo_delta': results['elo_delta']
                    }
                )
                
                logger.info(f"Self-evaluation complete: ELO Δ{results['elo_delta']:+.1f}")
                
            except Exception as e:
                logger.error(f"Self-evaluation failed: {e}")
        
        background_tasks.add_task(run_self_evaluation)
        
        return {
            'message': 'Self-evaluation started',
            'current_model': current_model,
            'previous_model': previous_model,
            'comparison_games': comparison_games
        }
        
    except Exception as e:
        logger.error(f"Error starting self-evaluation: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ====================
# Analytics Endpoints (Offline-Compatible)
# ====================

@api_router.get("/analytics")
async def get_analytics():
    """
    Get real-time analytics with offline cache fallback
    Returns game statistics, training data, and system health
    """
    try:
        # Try to get live data from MongoDB
        try:
            total_games = await db.self_play_positions.count_documents({})
            total_training_sessions = await db.training_metrics.distinct("session_id")
            evaluations = await db.model_evaluations.find().to_list(100)
            
            # Calculate win/draw/loss rates from evaluations
            total_eval_games = 0
            wins = 0
            draws = 0
            losses = 0
            
            for eval_data in evaluations:
                total_eval_games += eval_data.get("games_played", 0)
                wins += eval_data.get("model1_wins", 0)
                draws += eval_data.get("draws", 0)
                losses += eval_data.get("model2_wins", 0)
            
            win_rate = (wins / total_eval_games * 100) if total_eval_games > 0 else 0
            draw_rate = (draws / total_eval_games * 100) if total_eval_games > 0 else 0
            loss_rate = (losses / total_eval_games * 100) if total_eval_games > 0 else 0
            
            # Get average depth from recent training
            recent_metrics = await db.training_metrics.find().sort("timestamp", -1).limit(10).to_list(10)
            avg_depth = sum(m.get("depth", 8) for m in recent_metrics) / len(recent_metrics) if recent_metrics else 8
            
            analytics_data = {
                "games_played": total_games,
                "win_rate": round(win_rate, 1),
                "draw_rate": round(draw_rate, 1),
                "loss_rate": round(loss_rate, 1),
                "average_depth": int(avg_depth),
                "training_sessions": len(total_training_sessions),
                "last_update": datetime.now(timezone.utc).isoformat(),
                "system_health": "operational"
            }
            
            # Save to cache
            save_cache("analytics.json", analytics_data)
            
            return analytics_data
            
        except Exception as db_error:
            logger.warning(f"MongoDB unavailable for analytics, using cache: {db_error}")
            
            # Fallback to cache
            cached_data = load_cache("analytics.json")
            if cached_data:
                cached_data["system_health"] = "offline-cache"
                return cached_data
            
            # Return minimal data if no cache
            return {
                "games_played": 0,
                "win_rate": 0.0,
                "draw_rate": 0.0,
                "loss_rate": 0.0,
                "average_depth": 0,
                "training_sessions": 0,
                "last_update": datetime.now(timezone.utc).isoformat(),
                "system_health": "initializing"
            }
            
    except Exception as e:
        logger.error(f"Error getting analytics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/analytics/training-summary")
async def get_training_summary():
    """Get training summary with offline support"""
    try:
        try:
            # Get training sessions from MongoDB
            sessions = await db.training_metrics.aggregate([
                {"$group": {
                    "_id": "$session_id",
                    "epochs": {"$sum": 1},
                    "avg_loss": {"$avg": "$loss"},
                    "timestamp": {"$first": "$timestamp"},
                    "device": {"$first": "$device"}
                }},
                {"$sort": {"timestamp": -1}},
                {"$limit": 10}
            ]).to_list(10)
            
            total_sessions = await db.training_metrics.distinct("session_id")
            total_epochs = await db.training_metrics.count_documents({})
            
            summary = {
                "total_sessions": len(total_sessions),
                "total_epochs": total_epochs,
                "training_sessions": sessions
            }
            
            save_cache("training_summary.json", summary)
            return summary
            
        except Exception as db_error:
            logger.warning(f"MongoDB unavailable, using training summary cache: {db_error}")
            cached = load_cache("training_summary.json")
            if cached:
                return cached
            return {"total_sessions": 0, "total_epochs": 0, "training_sessions": []}
            
    except Exception as e:
        logger.error(f"Error getting training summary: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/analytics/evaluation-summary")
async def get_evaluation_summary(limit: int = 20):
    """Get evaluation summary with offline support"""
    try:
        try:
            evaluations = await db.model_evaluations.find().sort("timestamp", -1).limit(limit).to_list(limit)
            
            # Build win rate progression
            win_rate_progression = []
            for eval_data in evaluations:
                total_games = eval_data.get("games_played", 0)
                challenger_wins = eval_data.get("model1_wins", 0)
                win_rate = challenger_wins / total_games if total_games > 0 else 0
                
                win_rate_progression.append({
                    "challenger": eval_data.get("challenger_name", "unknown"),
                    "win_rate": win_rate,
                    "promoted": eval_data.get("promoted", False),
                    "games_played": total_games
                })
            
            summary = {
                "count": len(evaluations),
                "evaluations": evaluations,
                "win_rate_progression": win_rate_progression
            }
            
            save_cache("evaluation_summary.json", summary)
            return summary
            
        except Exception as db_error:
            logger.warning(f"MongoDB unavailable, using evaluation summary cache: {db_error}")
            cached = load_cache("evaluation_summary.json")
            if cached:
                return cached
            return {"count": 0, "evaluations": [], "win_rate_progression": []}
            
    except Exception as e:
        logger.error(f"Error getting evaluation summary: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/analytics/model-history")
async def get_model_history():
    """Get model history with offline support"""
    try:
        try:
            # Get active model
            active_model_doc = await db.active_model.find_one({})
            active_model = active_model_doc.get("model_name") if active_model_doc else None
            
            # Get promotion history
            promotions = await db.model_evaluations.find(
                {"promoted": True}
            ).sort("timestamp", -1).limit(10).to_list(10)
            
            promotion_history = []
            for promo in promotions:
                promotion_history.append({
                    "model_name": promo.get("challenger_name", "unknown"),
                    "defeated": promo.get("champion_name", "unknown"),
                    "win_rate": promo.get("challenger_win_rate", 0),
                    "promoted_at": promo.get("timestamp", datetime.now(timezone.utc)).isoformat()
                })
            
            history = {
                "active_model": active_model,
                "promotion_history": promotion_history
            }
            
            save_cache("model_history.json", history)
            return history
            
        except Exception as db_error:
            logger.warning(f"MongoDB unavailable, using model history cache: {db_error}")
            cached = load_cache("model_history.json")
            if cached:
                return cached
            return {"active_model": None, "promotion_history": []}
            
    except Exception as e:
        logger.error(f"Error getting model history: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ====================
# IQ Verification Endpoints
# ====================

@api_router.get("/iq/verification/status")
async def get_iq_verification_status():
    """
    Get IQ verification status and results
    Returns verification test results if available
    """
    try:
        verification_file = Path("/app/backend/cache/iq_verification_results.json")
        
        if not verification_file.exists():
            return {
                "status": "not_started",
                "message": "IQ verification has not been run yet",
                "available": False
            }
        
        # Load verification results
        with open(verification_file, 'r') as f:
            results = json.load(f)
        
        return {
            "status": "completed",
            "available": True,
            "results": results
        }
        
    except Exception as e:
        logger.error(f"Error getting verification status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/iq/verification/run")
async def run_iq_verification(background_tasks: BackgroundTasks):
    """
    Trigger IQ verification tests in background
    Runs comprehensive weight-ELO correlation and model evolution tests
    """
    try:
        def run_verification():
            """Run verification tool in subprocess"""
            import subprocess
            logger.info("Starting IQ verification suite...")
            
            try:
                result = subprocess.run(
                    [sys.executable, "/app/backend/iq_verification_tool.py"],
                    cwd="/app/backend",
                    capture_output=True,
                    text=True,
                    timeout=600  # 10 minute timeout
                )
                
                if result.returncode == 0:
                    logger.info("IQ verification completed successfully")
                else:
                    logger.error(f"IQ verification failed: {result.stderr}")
                    
            except Exception as e:
                logger.error(f"IQ verification error: {e}")
        
        # Run in background
        background_tasks.add_task(run_verification)
        
        return {
            "success": True,
            "message": "IQ verification started in background",
            "status": "running"
        }
        
    except Exception as e:
        logger.error(f"Error starting verification: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/iq/growth")
async def get_iq_growth_data():
    """
    Get simplified IQ growth data for frontend charts
    Returns ELO progression, model sizes, and games processed
    """
    try:
        iq_growth_file = Path("/app/backend/cache/iq_growth.json")
        
        if not iq_growth_file.exists():
            # Return empty data structure
            return {
                "iq_growth": [],
                "last_updated": datetime.now(timezone.utc).isoformat(),
                "total_entries": 0
            }
        
        # Load IQ growth data
        with open(iq_growth_file, 'r') as f:
            iq_data = json.load(f)
        
        return iq_data
        
    except Exception as e:
        logger.error(f"Error getting IQ growth data: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ====================
# Settings Endpoints (Offline-Compatible)
# ====================

class SettingsUpdate(BaseModel):
    backend_port: Optional[int] = None
    llmProvider: Optional[str] = None
    offlineMode: Optional[bool] = None
    autoSaveModels: Optional[bool] = None
    autoUpdate: Optional[bool] = None
    ethicsWatchdogEnabled: Optional[bool] = None
    mongo_url: Optional[str] = None
    llm_key: Optional[str] = None

@api_router.get("/settings/get")
async def get_settings():
    """
    Get current settings with offline cache fallback
    Reads from .env and config.json
    """
    try:
        # Load from cache first
        cached_settings = load_cache("settings.json")
        
        # Merge with .env values
        settings = {
            "backend_port": int(os.environ.get('BACKEND_PORT', 8001)),
            "mongo_url": os.environ.get('MONGO_URL', 'mongodb://localhost:27017'),
            "llm_key": os.environ.get('EMERGENT_LLM_KEY', ''),
            "llmProvider": cached_settings.get("llmProvider", "claude-3-5-sonnet") if cached_settings else "claude-3-5-sonnet",
            "offlineMode": cached_settings.get("offlineMode", False) if cached_settings else False,
            "autoSaveModels": cached_settings.get("autoSaveModels", True) if cached_settings else True,
            "autoUpdate": cached_settings.get("autoUpdate", False) if cached_settings else False,
            "ethicsWatchdogEnabled": cached_settings.get("ethicsWatchdogEnabled", True) if cached_settings else True,
            "last_update": datetime.now(timezone.utc).isoformat()
        }
        
        return settings
        
    except Exception as e:
        logger.error(f"Error getting settings: {e}")
        # Return sensible defaults
        return {
            "backend_port": 8001,
            "llmProvider": "claude-3-5-sonnet",
            "offlineMode": False,
            "autoSaveModels": True,
            "autoUpdate": False,
            "ethicsWatchdogEnabled": True,
            "last_update": datetime.now(timezone.utc).isoformat()
        }

@api_router.post("/settings/update")
async def update_settings(settings: SettingsUpdate):
    """
    Update settings and save to both .env and config.json
    """
    try:
        # Load current cached settings
        current_settings = load_cache("settings.json") or {}
        
        # Update with new values (only non-None values)
        updated_settings = {**current_settings}
        
        for key, value in settings.dict(exclude_none=True).items():
            if value is not None:
                updated_settings[key] = value
        
        # Save to config.json cache
        updated_settings["last_update"] = datetime.now(timezone.utc).isoformat()
        save_cache("settings.json", updated_settings)
        
        # Update .env for critical settings (backend_port, mongo_url, llm_key)
        env_path = Path(__file__).parent / '.env'
        if env_path.exists():
            with open(env_path, 'r') as f:
                env_lines = f.readlines()
            
            env_dict = {}
            for line in env_lines:
                if '=' in line and not line.startswith('#'):
                    key, val = line.split('=', 1)
                    env_dict[key.strip()] = val.strip()
            
            # Update env_dict with new values
            if settings.backend_port is not None:
                env_dict['BACKEND_PORT'] = str(settings.backend_port)
            if settings.mongo_url is not None:
                env_dict['MONGO_URL'] = f'"{settings.mongo_url}"'
            if settings.llm_key is not None:
                env_dict['EMERGENT_LLM_KEY'] = settings.llm_key
            
            # Write back to .env
            with open(env_path, 'w') as f:
                for key, val in env_dict.items():
                    f.write(f"{key}={val}\n")
        
        return {
            "success": True,
            "message": "Settings updated successfully",
            "settings": updated_settings
        }
        
    except Exception as e:
        logger.error(f"Error updating settings: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ====================
# Collective Intelligence Endpoints (Offline-Compatible)
# ====================

@api_router.get("/collective/status")
async def get_collective_status():
    """
    Get collective intelligence status with offline cache fallback
    Returns memory experiences, trust calibrations, arbitrations, and strategies
    """
    try:
        try:
            # Try to get live data from MongoDB
            memory_count = await db.memories.count_documents({})
            
            # Count trust calibrations (if collection exists)
            trust_count = 0
            try:
                trust_count = await db.trust_calibrations.count_documents({})
            except:
                pass
            
            # Count arbitration logs
            arbitration_count = 0
            try:
                arbitration_count = await db.arbitration_logs.count_documents({})
            except:
                pass
            
            # Count global strategies
            strategy_count = 0
            try:
                strategy_count = await db.global_strategies.count_documents({})
            except:
                pass
            
            collective_data = {
                "memory_experiences": memory_count,
                "trust_calibrations": trust_count,
                "arbitrations": arbitration_count,
                "global_strategies": strategy_count,
                "system_health": "stable",
                "last_update": datetime.now(timezone.utc).isoformat()
            }
            
            # Save to cache
            save_cache("collective_status.json", collective_data)
            
            return collective_data
            
        except Exception as db_error:
            logger.warning(f"MongoDB unavailable for collective status, using cache: {db_error}")
            
            # Fallback to cache
            cached_data = load_cache("collective_status.json")
            if cached_data:
                cached_data["system_health"] = "offline-cache"
                return cached_data
            
            # Return minimal data
            return {
                "memory_experiences": 0,
                "trust_calibrations": 0,
                "arbitrations": 0,
                "global_strategies": 0,
                "system_health": "initializing",
                "last_update": datetime.now(timezone.utc).isoformat()
            }
            
    except Exception as e:
        logger.error(f"Error getting collective status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/collective/synthesize")
async def synthesize_collective_intelligence():
    """
    Perform lightweight aggregation from recent self-play sessions or reflections
    Synthesizes collective intelligence from available data sources
    """
    try:
        try:
            # Get recent memories
            recent_memories = await db.memories.find().sort("timestamp_recalled", -1).limit(100).to_list(100)
            
            # Get recent self-play data
            recent_selfplay = await db.self_play_positions.find().sort("timestamp", -1).limit(50).to_list(50)
            
            # Get recent training metrics
            recent_training = await db.training_metrics.find().sort("timestamp", -1).limit(20).to_list(20)
            
            # Calculate synthesis metrics
            total_experiences = len(recent_memories) + len(recent_selfplay)
            avg_training_loss = sum(m.get("loss", 0) for m in recent_training) / len(recent_training) if recent_training else 0
            
            # Determine system health based on data availability
            if total_experiences > 100:
                system_health = "optimal"
            elif total_experiences > 50:
                system_health = "good"
            else:
                system_health = "developing"
            
            synthesis_result = {
                "synthesis_id": str(uuid.uuid4()),
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "total_experiences_analyzed": total_experiences,
                "memory_count": len(recent_memories),
                "selfplay_count": len(recent_selfplay),
                "training_metrics_count": len(recent_training),
                "average_loss": round(avg_training_loss, 4),
                "system_health": system_health,
                "collective_insights": f"Synthesized {total_experiences} experiences with average training loss of {avg_training_loss:.4f}",
                "recommendations": [
                    "Continue self-play to gather more experience",
                    "Monitor training loss convergence",
                    "Evaluate model performance regularly"
                ]
            }
            
            # Save synthesis result to cache
            save_cache("latest_synthesis.json", synthesis_result)
            
            return {
                "success": True,
                "synthesis": synthesis_result
            }
            
        except Exception as db_error:
            logger.warning(f"MongoDB unavailable for synthesis, using cached data: {db_error}")
            
            # Load from cache if available
            cached_synthesis = load_cache("latest_synthesis.json")
            if cached_synthesis:
                return {
                    "success": True,
                    "synthesis": cached_synthesis,
                    "from_cache": True
                }
            
            # Return minimal synthesis
            return {
                "success": True,
                "synthesis": {
                    "synthesis_id": str(uuid.uuid4()),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "total_experiences_analyzed": 0,
                    "system_health": "initializing",
                    "collective_insights": "Insufficient data for synthesis",
                    "recommendations": ["Start training to generate data"]
                }
            }
            
    except Exception as e:
        logger.error(f"Error synthesizing collective intelligence: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ====================
# Memory System Endpoints (PGN Multi-Memory)
# ====================

class MemoryUploadResponse(BaseModel):
    success: bool
    games_stored: int
    errors: List[str] = []
    memory_ids: List[str] = []

class MemoryFilterRequest(BaseModel):
    winner: Optional[str] = None
    result: Optional[str] = None
    source_file: Optional[str] = None
    opening: Optional[str] = None
    limit: int = Field(default=100, ge=1, le=500)

class TrainFromMemoryRequest(BaseModel):
    memory_ids: Optional[List[str]] = None  # None = train from all
    training_source: str = Field(default="combined", pattern="^(pgn_only|selfplay_only|combined)$")
    num_epochs: int = Field(default=5, ge=1, le=50)
    batch_size: int = Field(default=64, ge=8, le=256)
    learning_rate: float = Field(default=0.001, ge=0.0001, le=0.1)
    save_as_new_model: bool = Field(default=False)
    new_model_name: Optional[str] = None

@api_router.post("/memory/upload")
async def upload_memory_files(files: List[UploadFile] = File(...)):
    """
    Upload multiple PGN files to AlphaZero memory system
    Accepts multipart/form-data with multiple files
    Supports offline caching when MongoDB is unavailable
    """
    try:
        all_games = []
        errors = []
        
        for file in files:
            try:
                # Read file content
                content = await file.read()
                content_str = content.decode('utf-8')
                
                # Parse PGN
                games = PGNParser.parse_pgn_file(content_str, file.filename)
                all_games.extend(games)
                
                logger.info(f"Parsed {len(games)} games from {file.filename}")
            except Exception as e:
                error_msg = f"Error processing {file.filename}: {str(e)}"
                logger.error(error_msg)
                errors.append(error_msg)
        
        if not all_games:
            raise HTTPException(
                status_code=400, 
                detail="No valid games found in uploaded files" + (f". Errors: {', '.join(errors)}" if errors else "")
            )
        
        # Try to store in database, fall back to offline cache
        try:
            games_stored = await memory_manager.store_memories(db, all_games)
            storage_mode = "mongodb"
        except Exception as db_error:
            logger.warning(f"MongoDB unavailable, caching offline: {db_error}")
            games_stored = offline_memory_manager.cache_memories(all_games)
            offline_memory_manager.set_offline_mode(True)
            storage_mode = "offline_cache"
        
        memory_ids = [g.get("memory_id") for g in all_games]
        
        logger.info(f"Stored {games_stored} total games from {len(files)} files ({storage_mode})")
        
        return {
            "success": True,
            "games_stored": games_stored,
            "memory_ids": memory_ids,
            "files_processed": len(files),
            "errors": errors,
            "storage_mode": storage_mode,
            "offline_mode": offline_memory_manager.is_offline()
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Memory upload error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/memory/upload-pgn")
async def upload_pgn_content(
    filename: str = Query(..., description="PGN filename"),
    content: str = Query(..., description="PGN file content")
):
    """
    Upload PGN content directly (for testing or API usage)
    """
    try:
        # Parse PGN
        games = PGNParser.parse_pgn_file(content, filename)
        
        if not games:
            raise HTTPException(status_code=400, detail="No valid games found in PGN")
        
        # Store in database
        games_stored = await memory_manager.store_memories(db, games)
        
        memory_ids = [g.get("memory_id") for g in games]
        
        logger.info(f"Uploaded {games_stored} games from {filename}")
        
        return {
            "success": True,
            "games_stored": games_stored,
            "memory_ids": memory_ids,
            "source_file": filename,
            "errors": []
        }
    except Exception as e:
        logger.error(f"PGN upload error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/memory/list")
async def list_memories(
    winner: Optional[str] = None,
    result: Optional[str] = None,
    source_file: Optional[str] = None,
    limit: int = Query(default=100, ge=1, le=500)
):
    """
    List stored memories with optional filters
    Supports offline mode - loads from cache when MongoDB unavailable
    """
    try:
        # Try MongoDB first
        try:
            # Build filter query
            filters = {}
            if winner:
                filters["winner"] = winner
            if result:
                filters["result"] = result
            if source_file:
                filters["source_file"] = source_file
            
            # Get memories (excluding MongoDB _id field)
            memories_cursor = db.memories.find(filters, {"_id": 0}).sort("timestamp_recalled", -1).limit(limit)
            memories = await memories_cursor.to_list(limit)
            
            # Get stats
            stats = await memory_manager.get_memory_stats(db)
            storage_mode = "mongodb"
            
        except Exception as db_error:
            logger.warning(f"MongoDB unavailable, loading from cache: {db_error}")
            # Load from offline cache
            memories = offline_memory_manager.load_cached_memories(limit=limit)
            
            # Apply filters manually
            if winner:
                memories = [m for m in memories if m.get("winner") == winner]
            if result:
                memories = [m for m in memories if m.get("result") == result]
            if source_file:
                memories = [m for m in memories if m.get("source_file") == source_file]
            
            stats = offline_memory_manager.get_cached_memory_stats()
            storage_mode = "offline_cache"
            offline_memory_manager.set_offline_mode(True)
        
        return {
            "success": True,
            "memories": memories,
            "count": len(memories),
            "stats": stats,
            "storage_mode": storage_mode,
            "offline_mode": offline_memory_manager.is_offline()
        }
    except Exception as e:
        logger.error(f"Error listing memories: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/memory/stats")
async def get_memory_stats():
    """Get memory system statistics - supports offline mode"""
    try:
        try:
            stats = await memory_manager.get_memory_stats(db)
            storage_mode = "mongodb"
        except Exception as db_error:
            logger.warning(f"MongoDB unavailable, getting cached stats: {db_error}")
            stats = offline_memory_manager.get_cached_memory_stats()
            storage_mode = "offline_cache"
            offline_memory_manager.set_offline_mode(True)
        
        return {
            "success": True,
            "storage_mode": storage_mode,
            "offline_mode": offline_memory_manager.is_offline(),
            **stats
        }
    except Exception as e:
        logger.error(f"Error getting memory stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/memory/replay/{memory_id}")
async def replay_memory(memory_id: str):
    """
    Get a specific memory for replay - supports offline mode
    """
    try:
        # Try MongoDB first, fall back to cache
        try:
            memory = await memory_manager.get_memory_by_id(db, memory_id)
        except Exception as db_error:
            logger.warning(f"MongoDB unavailable, loading from cache: {db_error}")
            memory = offline_memory_manager.get_cached_memory_by_id(memory_id)
            offline_memory_manager.set_offline_mode(True)
        
        if not memory:
            raise HTTPException(status_code=404, detail=f"Memory {memory_id} not found")
        
        # Optionally get LLM commentary
        try:
            from llm_evaluator import LLMChessEvaluator
            evaluator = LLMChessEvaluator(session_id=f"replay-{memory_id}")
            
            # Generate brief commentary about the game
            white = memory.get("white_player", "Unknown")
            black = memory.get("black_player", "Unknown")
            result = memory.get("result", "*")
            move_count = memory.get("move_count", 0)
            
            context = f"Game: {white} vs {black}, Result: {result}, Moves: {move_count}"
            commentary = await evaluator.general_question(
                f"Provide brief historical commentary about this game: {context}",
                None
            )
        except Exception as e:
            logger.warning(f"Could not generate LLM commentary: {e}")
            commentary = f"Historical match: {memory.get('white_player')} vs {memory.get('black_player')}"
        
        return {
            "success": True,
            "memory": memory,
            "commentary": commentary,
            "offline_mode": offline_memory_manager.is_offline()
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error replaying memory: {e}")
        raise HTTPException(status_code=500, detail=str(e))

def run_memory_training_pipeline(config: TrainFromMemoryRequest, session_id: str):
    """Run training from memory in background with ETA tracking"""
    try:
        global training_status
        start_time = time.time()
        training_status["start_time_raw"] = start_time
        training_status["message"] = "Loading memories..."
        
        # Try MongoDB first, fall back to offline cache
        try:
            # Use sync MongoDB client for background thread
            sync_client = MongoClient(os.environ.get('MONGO_URL'))
            sync_db = sync_client[os.environ.get('DB_NAME', 'alphazero_chess')]
            
            # Load memories
            emit_progress(0, 100, "Loading AlphaZero memories from database...")
            
            if config.memory_ids:
                # Load specific memories
                memories_cursor = sync_db.memories.find({"memory_id": {"$in": config.memory_ids}})
            else:
                # Load all memories
                memories_cursor = sync_db.memories.find({})
            
            memories = list(memories_cursor)
            storage_source = "mongodb"
            
        except Exception as db_error:
            logger.warning(f"MongoDB unavailable, loading from offline cache: {db_error}")
            emit_progress(0, 100, "Loading from offline cache...")
            
            # Load from offline cache
            memories = offline_memory_manager.load_cached_memories()
            
            # Filter by memory IDs if specified
            if config.memory_ids:
                memories = [m for m in memories if m.get("memory_id") in config.memory_ids]
            
            storage_source = "offline_cache"
            sync_client = None
            sync_db = None
        
        if not memories:
            emit_progress(0, 100, "Error: No memories found")
            logger.error("No memories found for training")
            return
        
        logger.info(f"Loaded {len(memories)} memories for training")
        emit_progress(5, 100, f"Loaded {len(memories)} historical games")
        
        # Initialize network
        emit_progress(10, 100, "Initializing neural network...")
        network = AlphaZeroNetwork()
        
        # Load active model if exists
        active_model_doc = sync_db.active_model.find_one({})
        if active_model_doc:
            model_name = active_model_doc["model_name"]
            try:
                network, _ = model_manager.load_model(model_name)
                logger.info(f"Loaded active model: {model_name}")
                emit_progress(15, 100, f"Loaded active model: {model_name}")
            except Exception as e:
                logger.warning(f"Could not load active model: {e}, using fresh network")
        
        # Convert memories to training positions
        emit_progress(20, 100, "Converting memories to training positions...")
        
        training_data = []
        for idx, memory in enumerate(memories):
            try:
                positions = PGNParser.game_to_training_positions(memory, network)
                training_data.extend(positions)
                
                if (idx + 1) % 10 == 0:
                    progress = 20 + int((idx + 1) / len(memories) * 30)
                    emit_progress(progress, 100, f"Processed {idx + 1}/{len(memories)} games")
            except Exception as e:
                logger.error(f"Error converting memory {memory.get('memory_id')}: {e}")
                continue
        
        logger.info(f"Generated {len(training_data)} training positions from {len(memories)} games")
        emit_progress(50, 100, f"Generated {len(training_data)} positions")
        
        # Optionally combine with self-play data
        if config.training_source == "combined":
            emit_progress(52, 100, "Loading self-play data to combine...")
            selfplay_positions = list(sync_db.self_play_positions.find().limit(1000))
            
            # Convert self-play positions to training format
            for pos in selfplay_positions:
                try:
                    training_data.append({
                        "position": pos.get("position"),
                        "policy": pos.get("policy"),
                        "value": pos.get("value"),
                        "fen": pos.get("fen"),
                        "move_number": pos.get("move_number"),
                        "source": "selfplay"
                    })
                except:
                    continue
            
            logger.info(f"Combined with self-play: now {len(training_data)} total positions")
            emit_progress(55, 100, f"Combined: {len(training_data)} total positions")
        
        # Training phase
        emit_progress(60, 100, f"Starting training: {config.num_epochs} epochs...")
        
        trainer = AlphaZeroTrainer(network, learning_rate=config.learning_rate)
        training_history = []
        
        for epoch in range(config.num_epochs):
            epoch_start = time.time()
            
            epoch_metrics = trainer.train_epoch(training_data, batch_size=config.batch_size)
            training_history.append(epoch_metrics)
            
            epoch_duration = time.time() - epoch_start
            progress = 60 + int((epoch + 1) / config.num_epochs * 35)
            
            emit_progress(
                progress, 
                100, 
                f"Epoch {epoch + 1}/{config.num_epochs} - Loss: {epoch_metrics.get('loss', 0):.4f}"
            )
            
            logger.info(f"Epoch {epoch + 1} complete - Loss: {epoch_metrics.get('loss', 0):.4f}, Time: {epoch_duration:.2f}s")
        
        # Store training metrics
        if training_history:
            sync_db.training_metrics.insert_many([
                {
                    **metrics,
                    "session_id": session_id,
                    "source": "memory_training"
                }
                for metrics in training_history
            ])
        
        # Save model
        emit_progress(95, 100, "Saving trained model...")
        
        metadata = {
            "training_date": datetime.now(timezone.utc).isoformat(),
            "training_source": config.training_source,
            "num_memories": len(memories),
            "num_positions": len(training_data),
            "num_epochs": config.num_epochs,
            "learning_rate": config.learning_rate,
            "batch_size": config.batch_size,
            "training_session_id": session_id,
            "final_loss": training_history[-1]["loss"] if training_history else 0.0,
            "source": "memory_training"
        }
        
        # Save model with custom name if requested
        if config.save_as_new_model and config.new_model_name:
            model_path = model_manager.save_model(network, config.new_model_name, metadata=metadata)
            new_model_name = config.new_model_name
            logger.info(f"Model saved as new version: {new_model_name}")
        else:
            model_path = model_manager.save_versioned_model(network, metadata=metadata)
            new_model_name = Path(model_path).stem
            logger.info(f"Model saved: {new_model_name}")
            
            # Update active model if not saving as new
            if sync_db is not None:
                try:
                    sync_db.active_model.replace_one(
                        {},
                        {
                            "model_name": new_model_name,
                            "promoted_at": datetime.now(timezone.utc),
                            "training_source": "memory",
                            "manual_activation": False
                        },
                        upsert=True
                    )
                except Exception as db_error:
                    logger.warning(f"Could not update active model in MongoDB: {db_error}")
            
            # Update local config
            offline_memory_manager.config["active_model"] = new_model_name
            offline_memory_manager._save_config()
        
        emit_progress(98, 100, f"Model saved: {new_model_name}")
        
        # Store session summary
        session_summary = {
            "session_id": session_id,
            "training_source": config.training_source,
            "total_games": len(memories),
            "epochs": config.num_epochs,
            "total_positions": len(training_data),
            "average_loss": sum(h["loss"] for h in training_history) / len(training_history) if training_history else 0,
            "memory_sources": list(set(m.get("source_file") for m in memories)),
            "model_saved": new_model_name,
            "timestamp": datetime.now(timezone.utc),
            "storage_source": storage_source
        }
        
        # Save training log to offline cache
        offline_memory_manager.save_training_log(session_summary)
        
        # Try to save to MongoDB if available
        if sync_db is not None:
            try:
                sync_db.memory_training_sessions.insert_one(session_summary)
                
                # Mark memories as used in training
                memory_ids = [m.get("memory_id") for m in memories if m.get("memory_id")]
                if memory_ids:
                    sync_db.memories.update_many(
                        {"memory_id": {"$in": memory_ids}},
                        {"$set": {"used_in_training": True, "last_trained": datetime.now(timezone.utc)}}
                    )
            except Exception as db_error:
                logger.warning(f"Could not update MongoDB, continuing with offline mode: {db_error}")
        
        emit_progress(100, 100, f"Memory training complete! Model: {new_model_name}")
        logger.info(f"Memory training session {session_id} completed successfully ({storage_source})")
        
        if sync_client:
            sync_client.close()
        
    except Exception as e:
        logger.error(f"Memory training error: {e}")
        emit_progress(0, 100, f"Error: {str(e)}")
        raise
    finally:
        training_status["active"] = False
        try:
            progress_queue.put_nowait({"done": True})
        except queue.Full:
            pass

@api_router.post("/train/from-memory")
async def train_from_memory(config: TrainFromMemoryRequest, background_tasks: BackgroundTasks):
    """
    Train AlphaZero from stored PGN memories
    Supports training from PGN only, self-play only, or combined
    """
    global training_status
    
    if training_status["active"]:
        raise HTTPException(status_code=400, detail="Training already in progress")
    
    try:
        # Validate memories exist
        if config.memory_ids:
            memory_count = await db.memories.count_documents({"memory_id": {"$in": config.memory_ids}})
            if memory_count == 0:
                raise HTTPException(status_code=404, detail="No memories found with provided IDs")
        else:
            memory_count = await db.memories.count_documents({})
            if memory_count == 0:
                raise HTTPException(status_code=404, detail="No memories in database. Upload PGN files first.")
        
        session_id = str(uuid.uuid4())
        training_status = {
            "active": True,
            "progress": 0,
            "message": "Starting memory training...",
            "session_id": session_id,
            "start_time": datetime.now(timezone.utc),
            "training_type": "memory"
        }
        
        # Run in background
        background_tasks.add_task(run_memory_training_pipeline, config, session_id)
        
        return {
            "success": True,
            "message": "Memory training started",
            "session_id": session_id,
            "memory_count": memory_count,
            "config": config.dict()
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error starting memory training: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/memory/training-history")
async def get_memory_training_history(limit: int = 10):
    """Get memory training session history"""
    try:
        sessions = await db.memory_training_sessions.find().sort("timestamp", -1).limit(limit).to_list(limit)
        
        # Convert MongoDB documents to JSON-safe format
        json_safe_sessions = [mongo_to_json_safe(session) for session in sessions]
        
        return {
            "success": True,
            "sessions": json_safe_sessions,
            "count": len(json_safe_sessions)
        }
    except Exception as e:
        logger.error(f"Error getting memory training history: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ====================
# Offline Mode Management
# ====================

@api_router.get("/offline/status")
async def get_offline_status():
    """Get offline mode status and configuration"""
    try:
        config = offline_memory_manager.config
        cached_stats = offline_memory_manager.get_cached_memory_stats()
        training_logs = offline_memory_manager.load_training_logs(limit=5)
        
        return {
            "success": True,
            "offline_mode": offline_memory_manager.is_offline(),
            "config": config,
            "cached_memories": cached_stats.get("total_memories", 0),
            "cache_size_mb": cached_stats.get("cache_size_mb", 0),
            "recent_training_sessions": len(training_logs)
        }
    except Exception as e:
        logger.error(f"Error getting offline status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/offline/sync")
async def sync_offline_data():
    """Sync cached memories and training logs to MongoDB"""
    try:
        # Check if MongoDB is available
        try:
            await db.command("ping")
        except Exception as e:
            raise HTTPException(status_code=503, detail="MongoDB is not available for sync")
        
        # Perform sync
        sync_results = await offline_memory_manager.sync_to_mongodb(db)
        
        logger.info(f"Sync complete: {sync_results}")
        
        return {
            "success": True,
            "message": "Offline data synced to MongoDB",
            **sync_results
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error syncing offline data: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/offline/set-mode")
async def set_offline_mode(offline: bool):
    """Manually set offline mode"""
    try:
        offline_memory_manager.set_offline_mode(offline)
        return {
            "success": True,
            "offline_mode": offline,
            "message": f"Offline mode {'enabled' if offline else 'disabled'}"
        }
    except Exception as e:
        logger.error(f"Error setting offline mode: {e}")
        raise HTTPException(status_code=500, detail=str(e))



# ====================
# Game Endpoints (Human vs AI)
# ====================

class GameRequest(BaseModel):
    ai_color: str = "black"  # "white" or "black"

class MoveRequest(BaseModel):
    game_id: str
    move: str  # UCI format

class AIRequest(BaseModel):
    game_id: str
    num_simulations: int = Field(default=800, ge=10, le=2000)

class CoachRequest(BaseModel):
    game_id: str
    question: Optional[str] = None
    num_simulations: int = Field(default=400, ge=10, le=1000)

class AnalyzeMoveRequest(BaseModel):
    game_id: str
    move: str
    num_simulations: int = Field(default=400, ge=10, le=1000)

class GameCompleteRequest(BaseModel):
    game_id: str
    result: str  # "1-0", "0-1", "1/2-1/2"
    moves: List[str]  # List of moves in UCI format
    ai_color: str  # "white" or "black"

class AdaptiveLearningToggleRequest(BaseModel):
    enabled: bool

# ====================
# Helper Functions for Coaching
# ====================

async def get_mcts_evaluation(engine: ChessEngine, network, num_simulations: int = 400):
    """
    Run MCTS and return top moves with probabilities and position value
    Returns: (top_moves_list, position_value)
    """
    try:
        mcts = MCTS(network, num_simulations=num_simulations, c_puct=1.5)
        best_move, move_probs, root_value = mcts.search(engine, temperature=0.1)
        
        # Sort moves by probability
        sorted_moves = sorted(move_probs.items(), key=lambda x: x[1], reverse=True)
        
        # Get top moves with visit counts (estimate from probabilities)
        top_moves = []
        total_visits = num_simulations
        for move, prob in sorted_moves[:5]:  # Get top 5
            visits = int(prob * total_visits)
            top_moves.append({
                "move": move,
                "probability": float(prob),
                "visits": visits
            })
        
        return top_moves, float(root_value)
    except Exception as e:
        logger.error(f"Error getting MCTS evaluation: {e}")
        return [], 0.0

@api_router.post("/game/new")
async def create_new_game(request: GameRequest):
    """Create a new game session"""
    game_id = str(uuid.uuid4())
    engine = ChessEngine()
    
    active_games[game_id] = {
        "engine": engine,
        "history": [],
        "ai_color": request.ai_color,
        "created_at": datetime.now(timezone.utc)
    }
    
    # Reset any existing coaching session for clean start
    if game_id in coaching_sessions:
        coaching_sessions[game_id].reset_conversation()
    
    # If AI plays white, make first move
    if request.ai_color == "white":
        try:
            # Get active model
            active_model_doc = await db.active_model.find_one({})
            if active_model_doc:
                model_name = active_model_doc["model_name"]
                network, _ = model_manager.load_model(model_name)
            else:
                # Use fresh network if no trained model
                network = AlphaZeroNetwork()
            
            # Run MCTS
            mcts = MCTS(network, num_simulations=800, c_puct=1.5)
            best_move, _, _ = mcts.search(engine, temperature=0.0)
            
            if best_move:
                engine.make_move(best_move)
                active_games[game_id]["history"].append(best_move)
        except Exception as e:
            logger.error(f"Error making AI's first move: {e}")
    
    return {
        "success": True,
        "game_id": game_id,
        "fen": engine.get_fen(),
        "legal_moves": engine.get_legal_moves(),
        "is_game_over": engine.is_game_over(),
        "result": engine.get_result() if engine.is_game_over() else None,
        "history": active_games[game_id]["history"]
    }

@api_router.get("/game/{game_id}/state")
async def get_game_state(game_id: str):
    """Get current game state"""
    if game_id not in active_games:
        raise HTTPException(status_code=404, detail="Game not found")
    
    game = active_games[game_id]
    engine = game["engine"]
    
    return {
        "success": True,
        "game_id": game_id,
        "fen": engine.get_fen(),
        "legal_moves": engine.get_legal_moves(),
        "is_game_over": engine.is_game_over(),
        "result": engine.get_result() if engine.is_game_over() else None,
        "history": game["history"],
        "ai_color": game["ai_color"]
    }

@api_router.post("/game/move")
async def make_player_move(request: MoveRequest):
    """Make a player move"""
    if request.game_id not in active_games:
        raise HTTPException(status_code=404, detail="Game not found")
    
    game = active_games[request.game_id]
    engine = game["engine"]
    
    # Validate and make move
    if not engine.make_move(request.move):
        raise HTTPException(status_code=400, detail="Illegal move")
    
    # Add to history
    game["history"].append(request.move)
    
    return {
        "success": True,
        "fen": engine.get_fen(),
        "legal_moves": engine.get_legal_moves(),
        "is_game_over": engine.is_game_over(),
        "result": engine.get_result() if engine.is_game_over() else None,
        "history": game["history"]
    }

@api_router.post("/game/ai-move")
async def get_ai_move(request: AIRequest):
    """Get AI's move using MCTS + Neural Network"""
    if request.game_id not in active_games:
        raise HTTPException(status_code=404, detail="Game not found")
    
    game = active_games[request.game_id]
    engine = game["engine"]
    
    if engine.is_game_over():
        raise HTTPException(status_code=400, detail="Game is already over")
    
    try:
        # Get active model
        active_model_doc = await db.active_model.find_one({})
        logger.info(f"DEBUG: active_model_doc from DB: {active_model_doc}")
        network = None
        
        if active_model_doc:
            model_name = active_model_doc["model_name"]
            logger.info(f"DEBUG: Attempting to load model: {model_name}")
            network, metadata = model_manager.load_model(model_name)
            
            if network is not None:
                logger.info(f"Using trained model: {model_name} (version: {metadata.get('model_version', 'unknown')})")
            else:
                logger.warning(f"Failed to load model {model_name}, falling back to fresh network")
                network = AlphaZeroNetwork()
        else:
            # Use fresh network if no trained model in database
            network = AlphaZeroNetwork()
            logger.info("Using fresh network (no trained models in database)")
        
        # Run MCTS
        start_time = datetime.now()
        mcts = MCTS(network, num_simulations=request.num_simulations, c_puct=1.5)
        best_move, move_probs, root_value = mcts.search(engine, temperature=0.0)
        elapsed = (datetime.now() - start_time).total_seconds()
        
        if not best_move:
            raise HTTPException(status_code=500, detail="AI couldn't find a move")
        
        # Make the move
        engine.make_move(best_move)
        game["history"].append(best_move)
        
        logger.info(f"AI move: {best_move} (took {elapsed:.2f}s, {request.num_simulations} sims)")
        
        return {
            "success": True,
            "move": best_move,
            "fen": engine.get_fen(),
            "legal_moves": engine.get_legal_moves(),
            "is_game_over": engine.is_game_over(),
            "result": engine.get_result() if engine.is_game_over() else None,
            "history": game["history"],
            "computation_time": float(elapsed),
            "simulations": int(request.num_simulations)
        }
    except Exception as e:
        logger.error(f"Error getting AI move: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.delete("/game/{game_id}")
async def delete_game(game_id: str):
    """Delete a game session"""
    if game_id in active_games:
        del active_games[game_id]
    
    # Also clean up coaching session
    if game_id in coaching_sessions:
        del coaching_sessions[game_id]
    
    return {"success": True, "message": "Game deleted"}

# ====================
# Adaptive Learning Endpoints
# ====================

@api_router.post("/game/complete")
async def complete_game(request: GameCompleteRequest):
    """
    Log a completed human vs AI game for adaptive learning
    Collects game data and triggers retraining when threshold is reached
    """
    try:
        if not adaptive_learning_manager.is_enabled():
            return {
                "success": True,
                "message": "Game completed but adaptive learning is disabled",
                "adaptive_learning_enabled": False
            }
        
        # Check if game exists in active games
        if request.game_id not in active_games:
            logger.warning(f"Game {request.game_id} not found in active games")
        
        game = active_games.get(request.game_id, {})
        engine = game.get("engine")
        
        # Reconstruct positions with move probabilities from history
        positions = []
        if engine:
            # Reset engine and replay game to capture positions
            temp_engine = ChessEngine()
            for i, move in enumerate(request.moves):
                # Capture position before move
                fen = temp_engine.get_fen()
                player = "white" if temp_engine.board.turn else "black"
                
                positions.append({
                    "fen": fen,
                    "move_number": i,
                    "player": player,
                    "move_probs": {}  # Will be empty for human moves, could enhance with MCTS analysis
                })
                
                temp_engine.make_move(move)
        
        # Create game data structure
        game_data = {
            "game_id": request.game_id,
            "result": request.result,
            "moves": request.moves,
            "positions": positions,
            "ai_color": request.ai_color,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "num_moves": len(request.moves)
        }
        
        # Log game for adaptive learning
        adaptive_learning_manager.log_human_game(game_data)
        
        # Get updated status
        status = adaptive_learning_manager.get_status()
        
        return {
            "success": True,
            "message": "Game logged for adaptive learning",
            "adaptive_learning_status": status
        }
    
    except Exception as e:
        logger.error(f"Error logging game completion: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/adaptive-learning/status")
async def get_adaptive_learning_status():
    """Get current adaptive learning status"""
    try:
        status = adaptive_learning_manager.get_status()
        return {
            "success": True,
            **status
        }
    except Exception as e:
        logger.error(f"Error getting adaptive learning status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/adaptive-learning/toggle")
async def toggle_adaptive_learning(request: AdaptiveLearningToggleRequest):
    """Enable or disable adaptive learning"""
    try:
        adaptive_learning_manager.set_enabled(request.enabled)
        status = adaptive_learning_manager.get_status()
        
        return {
            "success": True,
            "message": f"Adaptive learning {'enabled' if request.enabled else 'disabled'}",
            "adaptive_learning_status": status
        }
    except Exception as e:
        logger.error(f"Error toggling adaptive learning: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/adaptive-learning/stats")
async def get_adaptive_learning_stats():
    """Get detailed adaptive learning statistics"""
    try:
        stats = adaptive_learning_manager.get_statistics()
        return {
            "success": True,
            **stats
        }
    except Exception as e:
        logger.error(f"Error getting adaptive learning stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/adaptive-learning/reset")
async def reset_adaptive_learning():
    """Reset adaptive learning statistics"""
    try:
        adaptive_learning_manager.reset_statistics()
        return {
            "success": True,
            "message": "Adaptive learning statistics reset"
        }
    except Exception as e:
        logger.error(f"Error resetting adaptive learning: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/adaptive-learning/trigger-retrain")
async def trigger_manual_retrain(background_tasks: BackgroundTasks):
    """Manually trigger adaptive learning retraining"""
    try:
        if not adaptive_learning_manager.is_enabled():
            raise HTTPException(status_code=400, detail="Adaptive learning is disabled")
        
        status = adaptive_learning_manager.get_status()
        if status['games_since_last_retrain'] < 5:
            raise HTTPException(
                status_code=400, 
                detail=f"Not enough games for retraining (need at least 5, have {status['games_since_last_retrain']})"
            )
        
        # Trigger retraining in background
        background_tasks.add_task(adaptive_learning_manager.trigger_retraining)
        
        return {
            "success": True,
            "message": "Retraining triggered",
            "games_to_train": status['games_since_last_retrain']
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error triggering manual retrain: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ====================
# LLM Explanation Endpoints
# ====================

class ExplainRequest(BaseModel):
    fen: str
    last_move: Optional[str] = None
    context: Optional[str] = None

@api_router.post("/llm/explain")
async def explain_position(request: ExplainRequest):
    """Get LLM explanation for a chess position"""
    try:
        from llm_evaluator import LLMChessEvaluator
        
        evaluator = LLMChessEvaluator()
        
        context = request.context or ""
        if request.last_move:
            context += f"\nLast move played: {request.last_move}"
        
        explanation = await evaluator.evaluate_position(request.fen, context)
        
        return {
            "success": True,
            "explanation": explanation,
            "fen": request.fen
        }
    except Exception as e:
        logger.error(f"LLM explanation error: {e}")
        # Return fallback explanation
        return {
            "success": True,
            "explanation": "Position analysis unavailable. Continue playing to improve the AI model.",
            "fen": request.fen,
            "offline": True
        }

@api_router.post("/llm/suggest-strategy")
async def suggest_strategy(request: ExplainRequest):
    """Get strategic suggestions from LLM"""
    try:
        from llm_evaluator import LLMChessEvaluator
        
        evaluator = LLMChessEvaluator()
        strategy = await evaluator.suggest_opening_strategy(request.fen)
        
        return {
            "success": True,
            "strategy": strategy,
            "fen": request.fen
        }
    except Exception as e:
        logger.error(f"LLM strategy error: {e}")
        return {
            "success": True,
            "strategy": "Focus on controlling the center and developing your pieces.",
            "fen": request.fen,
            "offline": True
        }

# ====================
# Coaching Mode Endpoints
# ====================

async def save_llm_metrics(evaluator):
    """Save LLM performance metrics to database"""
    try:
        recent_metrics = evaluator.get_recent_metrics(limit=10)
        if recent_metrics:
            # Save only new metrics (last one)
            latest_metric = recent_metrics[-1]
            await db.llm_performance.insert_one(latest_metric)
    except Exception as e:
        logger.error(f"Error saving LLM metrics: {e}")

def get_or_create_coach(game_id: str):
    """Get or create coaching session for a game"""
    if game_id not in coaching_sessions:
        from llm_evaluator import LLMChessEvaluator, LLMConfig
        # Use global config
        config = LLMChessEvaluator.get_global_config()
        coaching_sessions[game_id] = LLMChessEvaluator(session_id=f"coach-{game_id}", config=config)
    return coaching_sessions[game_id]

@api_router.post("/coaching/suggest")
async def get_coaching_suggestion(request: CoachRequest):
    """Get move suggestions and coaching advice with AlphaZero evaluation"""
    if request.game_id not in active_games:
        raise HTTPException(status_code=404, detail="Game not found")
    
    try:
        game = active_games[request.game_id]
        engine = game["engine"]
        
        if engine.is_game_over():
            return {
                "success": True,
                "message": "Game is over. Start a new game to continue coaching.",
                "top_moves": [],
                "position_value": 0.0,
                "coaching": "The game has ended. Let's start a fresh game!"
            }
        
        # Get active model
        active_model_doc = await db.active_model.find_one({})
        if active_model_doc:
            model_name = active_model_doc["model_name"]
            network, _ = model_manager.load_model(model_name)
        else:
            network = AlphaZeroNetwork()
        
        # Get MCTS evaluation
        top_moves, position_value = await get_mcts_evaluation(engine, network, request.num_simulations)
        
        # Get LLM coaching
        coach = get_or_create_coach(request.game_id)
        fen = engine.get_fen()
        
        context = request.question if request.question else ""
        coaching_text = await coach.coach_with_mcts(fen, top_moves, position_value, context)
        
        # Save performance metrics
        await save_llm_metrics(coach)
        
        return {
            "success": True,
            "fen": fen,
            "top_moves": top_moves[:3],  # Return top 3
            "position_value": position_value,
            "coaching": coaching_text,
            "conversation_history": coach.get_conversation_history()[-10:]  # Last 10 messages
        }
    except Exception as e:
        logger.error(f"Coaching suggestion error: {e}")
        return {
            "success": True,
            "coaching": "Coaching temporarily unavailable. Focus on controlling the center and developing your pieces.",
            "top_moves": [],
            "position_value": 0.0,
            "offline": True
        }

@api_router.post("/coaching/analyze-move")
async def analyze_move(request: AnalyzeMoveRequest):
    """Analyze a specific move to see if it was good or bad"""
    if request.game_id not in active_games:
        raise HTTPException(status_code=404, detail="Game not found")
    
    try:
        game = active_games[request.game_id]
        engine = game["engine"]
        
        # Get the position BEFORE the move was made
        history = game["history"]
        if not history or history[-1] != request.move:
            return {
                "success": False,
                "message": "Move not found in history or not the last move"
            }
        
        # Recreate position before the move
        temp_engine = ChessEngine()
        for move in history[:-1]:
            temp_engine.make_move(move)
        
        fen_before = temp_engine.get_fen()
        
        # Get active model
        active_model_doc = await db.active_model.find_one({})
        if active_model_doc:
            model_name = active_model_doc["model_name"]
            network, _ = model_manager.load_model(model_name)
        else:
            network = AlphaZeroNetwork()
        
        # Get MCTS evaluation for the position
        top_moves, _ = await get_mcts_evaluation(temp_engine, network, request.num_simulations)
        
        # Check if the played move was in top moves
        played_move = request.move
        top_move_uci = [m["move"] for m in top_moves]
        
        was_best = top_move_uci[0] == played_move if top_move_uci else False
        was_in_top_3 = played_move in top_move_uci[:3]
        
        # Get LLM analysis
        coach = get_or_create_coach(request.game_id)
        analysis = await coach.analyze_specific_move(
            fen_before, 
            played_move, 
            was_best=was_best,
            better_moves=top_move_uci[:3] if not was_in_top_3 else None
        )
        
        return {
            "success": True,
            "move": played_move,
            "was_best": was_best,
            "was_in_top_3": was_in_top_3,
            "best_move": top_move_uci[0] if top_move_uci else None,
            "top_moves": top_moves[:3],
            "analysis": analysis
        }
    except Exception as e:
        logger.error(f"Move analysis error: {e}")
        return {
            "success": True,
            "analysis": "Move analysis temporarily unavailable.",
            "offline": True
        }

@api_router.post("/coaching/ask")
async def ask_coach_question(request: CoachRequest):
    """Ask the coach a general question"""
    if request.game_id not in active_games:
        raise HTTPException(status_code=404, detail="Game not found")
    
    if not request.question:
        raise HTTPException(status_code=400, detail="Question is required")
    
    try:
        game = active_games[request.game_id]
        engine = game["engine"]
        fen = engine.get_fen()
        
        coach = get_or_create_coach(request.game_id)
        answer = await coach.general_question(request.question, fen)
        
        return {
            "success": True,
            "question": request.question,
            "answer": answer,
            "conversation_history": coach.get_conversation_history()[-10:]
        }
    except Exception as e:
        logger.error(f"Coach question error: {e}")
        return {
            "success": True,
            "answer": "I'm having trouble answering right now. Keep playing and learning!",
            "offline": True
        }

@api_router.post("/coaching/reset/{game_id}")
async def reset_coaching_session(game_id: str):
    """Reset coaching conversation for a game"""
    if game_id in coaching_sessions:
        coaching_sessions[game_id].reset_conversation()
        return {"success": True, "message": "Coaching session reset"}
    return {"success": True, "message": "No active coaching session"}

@api_router.get("/coaching/history/{game_id}")
async def get_coaching_history(game_id: str):
    """Get conversation history for a game"""
    if game_id in coaching_sessions:
        history = coaching_sessions[game_id].get_conversation_history()
        return {"success": True, "history": history}
    return {"success": True, "history": []}

# ====================
# LLM Analytics Insights Endpoint (Step 12)
# ====================

@api_router.post("/llm/insights")
async def generate_training_insights():
    """
    Generate comprehensive LLM-powered insights from training and evaluation metrics.
    This endpoint fetches data from MongoDB and uses LLM to provide coaching insights.
    """
    try:
        from llm_evaluator import LLMChessEvaluator, LLMConfig
        
        # Initialize LLM evaluator for analytics with global config
        config = LLMChessEvaluator.get_global_config()
        evaluator = LLMChessEvaluator(session_id="analytics-coach", config=config)
        
        # Fetch training metrics (last 50 epochs)
        training_metrics = await db.training_metrics.find().sort("timestamp", -1).limit(50).to_list(50)
        
        # Fetch evaluation results (last 10)
        evaluations = await db.model_evaluations.find().sort("timestamp", -1).limit(10).to_list(10)
        
        # Fetch self-play statistics
        total_positions = await db.self_play_positions.count_documents({})
        recent_positions = await db.self_play_positions.find().sort("timestamp", -1).limit(1000).to_list(1000)
        
        # Get active model
        active_model_doc = await db.active_model.find_one({})
        
        # Process training data
        if training_metrics:
            recent_losses = [m.get("loss", 0) for m in training_metrics[:20] if m.get("loss")]
            avg_recent_loss = sum(recent_losses) / len(recent_losses) if recent_losses else 0
            
            # Calculate loss improvement (compare first 10 vs last 10)
            first_half = [m.get("loss", 0) for m in training_metrics[-10:] if m.get("loss")]
            second_half = [m.get("loss", 0) for m in training_metrics[:10] if m.get("loss")]
            
            if first_half and second_half:
                avg_first = sum(first_half) / len(first_half)
                avg_second = sum(second_half) / len(second_half)
                improvement = ((avg_first - avg_second) / avg_first * 100) if avg_first > 0 else 0
                loss_improvement = f"{improvement:.1f}% improvement"
            else:
                loss_improvement = "N/A"
            
            # Loss summary
            if len(recent_losses) >= 3:
                loss_summary = f"Min: {min(recent_losses):.4f}, Max: {max(recent_losses):.4f}, Latest: {recent_losses[0]:.4f}"
            else:
                loss_summary = "Insufficient data"
            
            # Count unique training sessions
            training_sessions = await db.training_metrics.distinct("session_id")
            total_sessions = len(training_sessions)
        else:
            avg_recent_loss = "N/A"
            loss_improvement = "No training data"
            loss_summary = "No training data"
            total_sessions = 0
        
        training_data = {
            "total_sessions": total_sessions,
            "total_epochs": len(training_metrics),
            "loss_summary": loss_summary,
            "avg_recent_loss": f"{avg_recent_loss:.4f}" if isinstance(avg_recent_loss, float) else avg_recent_loss,
            "loss_improvement": loss_improvement
        }
        
        # Process evaluation data
        if evaluations:
            recent_win_rates = []
            promoted_count = 0
            
            for eval_data in evaluations:
                win_rate = eval_data.get("challenger_win_rate", 0)
                recent_win_rates.append(win_rate)
                if eval_data.get("promoted", False) or win_rate > 0.55:
                    promoted_count += 1
            
            recent_win_rate = recent_win_rates[0] if recent_win_rates else 0
            avg_win_rate = sum(recent_win_rates) / len(recent_win_rates) if recent_win_rates else 0
            
            # Win rate trend
            if len(recent_win_rates) >= 3:
                recent_trend = sum(recent_win_rates[:3]) / 3
                older_trend = sum(recent_win_rates[-3:]) / 3
                if recent_trend > older_trend + 0.05:
                    win_rate_trend = "Improving"
                elif recent_trend < older_trend - 0.05:
                    win_rate_trend = "Declining"
                else:
                    win_rate_trend = "Stable"
            else:
                win_rate_trend = "Insufficient data"
        else:
            recent_win_rate = "N/A"
            win_rate_trend = "No evaluation data"
            promoted_count = 0
            avg_win_rate = 0
        
        evaluation_data = {
            "total_evaluations": len(evaluations),
            "recent_win_rate": f"{recent_win_rate * 100:.1f}%" if isinstance(recent_win_rate, float) else recent_win_rate,
            "win_rate_trend": win_rate_trend,
            "promoted_count": promoted_count,
            "current_champion": active_model_doc["model_name"] if active_model_doc else "None"
        }
        
        # Process self-play data
        recent_games = len(recent_positions) // 30  # Estimate games (avg 30 positions per game)
        quality_score = "Good" if total_positions > 1000 else "Low" if total_positions > 0 else "None"
        
        selfplay_data = {
            "total_positions": total_positions,
            "recent_games": recent_games,
            "quality_score": quality_score
        }
        
        # Generate LLM insights
        logger.info("Generating LLM insights from analytics data...")
        insights = await evaluator.analyze_training_metrics(training_data, evaluation_data, selfplay_data)
        
        # Save performance metrics
        await save_llm_metrics(evaluator)
        
        return {
            "success": True,
            "insights": insights,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "metrics_summary": {
                "training": training_data,
                "evaluation": evaluation_data,
                "selfplay": selfplay_data
            }
        }
        
    except Exception as e:
        logger.error(f"Error generating insights: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate insights: {str(e)}")

# ====================
# Analytics Endpoints (Supporting Step 12)
# ====================

@api_router.get("/training/metrics")
async def get_training_metrics(limit: int = 50):
    """Get training metrics for analytics"""
    metrics = await db.training_metrics.find({}, {"_id": 0}).sort("timestamp", -1).limit(limit).to_list(limit)
    return {"success": True, "metrics": metrics}

@api_router.get("/analytics/training-summary")
async def get_training_summary():
    """Get training summary statistics"""
    # Get unique sessions
    training_sessions_raw = await db.training_metrics.aggregate([
        {"$group": {
            "_id": "$session_id",
            "epochs": {"$sum": 1},
            "avg_loss": {"$avg": "$loss"},
            "timestamp": {"$first": "$timestamp"},
            "device": {"$first": "$device"}
        }},
        {"$sort": {"timestamp": -1}},
        {"$limit": 10}
    ]).to_list(10)
    
    training_sessions = [
        {
            "session_id": str(s["_id"]) if s["_id"] else "Unknown",
            "epochs": s["epochs"],
            "avg_loss": s["avg_loss"],
            "device": s.get("device", "Unknown"),
            "timestamp": s.get("timestamp").isoformat() if s.get("timestamp") else None
        }
        for s in training_sessions_raw
    ]
    
    total_sessions = len(await db.training_metrics.distinct("session_id"))
    total_epochs = await db.training_metrics.count_documents({})
    
    return {
        "success": True,
        "total_sessions": total_sessions,
        "total_epochs": total_epochs,
        "training_sessions": training_sessions
    }

@api_router.get("/analytics/evaluation-summary")
async def get_evaluation_summary(limit: int = 20):
    """Get evaluation summary with win rate progression"""
    evaluations = await db.model_evaluations.find({}, {"_id": 0}).sort("timestamp", -1).limit(limit).to_list(limit)
    
    # Build win rate progression
    win_rate_progression = []
    for eval_data in reversed(evaluations):
        win_rate_progression.append({
            "challenger": eval_data.get("challenger_name", "Unknown"),
            "champion": eval_data.get("champion_name", "Unknown"),
            "win_rate": eval_data.get("challenger_win_rate", 0),
            "promoted": eval_data.get("promoted", False) or eval_data.get("challenger_win_rate", 0) > 0.55,
            "games_played": eval_data.get("games_played", 0)
        })
    
    return {
        "success": True,
        "count": len(evaluations),
        "evaluations": evaluations,
        "win_rate_progression": win_rate_progression
    }

@api_router.get("/analytics/model-history")
async def get_model_history():
    """Get model promotion history"""
    # Get all active model changes
    promotions = await db.model_evaluations.find({
        "$or": [
            {"promoted": True},
            {"challenger_win_rate": {"$gte": 0.55}}
        ]
    }, {"_id": 0}).sort("timestamp", -1).limit(10).to_list(10)
    
    promotion_history = [
        {
            "model_name": p.get("challenger_name", "Unknown"),
            "defeated": p.get("champion_name", "N/A"),
            "win_rate": p.get("challenger_win_rate", 0),
            "promoted_at": p.get("timestamp", datetime.now(timezone.utc)).isoformat() if isinstance(p.get("timestamp"), datetime) else str(p.get("timestamp"))
        }
        for p in promotions
    ]
    
    active_model_doc = await db.active_model.find_one({})
    
    return {
        "success": True,
        "active_model": active_model_doc["model_name"] if active_model_doc else None,
        "promotion_history": promotion_history
    }


# ====================
# PGN Export Endpoints (Self-Play Games)
# ====================

@api_router.get("/training/pgns")
async def list_pgn_files():
    """List all available PGN files from self-play games"""
    try:
        pgn_dir = Path("/app/data/selfplay_pgns")
        
        if not pgn_dir.exists():
            return {
                "success": True,
                "count": 0,
                "files": [],
                "message": "PGN directory not yet created"
            }
        
        # Get all PGN files
        pgn_files = sorted(pgn_dir.glob("*.pgn"))
        
        file_info = []
        for pgn_file in pgn_files:
            stat = pgn_file.stat()
            file_info.append({
                "filename": pgn_file.name,
                "size_bytes": stat.st_size,
                "created": datetime.fromtimestamp(stat.st_ctime).isoformat(),
                "modified": datetime.fromtimestamp(stat.st_mtime).isoformat()
            })
        
        return {
            "success": True,
            "count": len(file_info),
            "files": file_info,
            "directory": str(pgn_dir)
        }
    except Exception as e:
        logger.error(f"Error listing PGN files: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list PGN files: {str(e)}")

@api_router.get("/training/pgns/{filename}")
async def download_pgn_file(filename: str):
    """Download a specific PGN file"""
    try:
        pgn_dir = Path("/app/data/selfplay_pgns")
        pgn_file = pgn_dir / filename
        
        # Security check: prevent directory traversal
        if not pgn_file.resolve().is_relative_to(pgn_dir.resolve()):
            raise HTTPException(status_code=400, detail="Invalid filename")
        
        if not pgn_file.exists():
            raise HTTPException(status_code=404, detail="PGN file not found")
        
        if not pgn_file.suffix == ".pgn":
            raise HTTPException(status_code=400, detail="File must be a .pgn file")
        
        return FileResponse(
            path=str(pgn_file),
            media_type="application/x-chess-pgn",
            filename=filename,
            headers={
                "Content-Disposition": f"attachment; filename={filename}"
            }
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading PGN file: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to download PGN: {str(e)}")

@api_router.get("/training/pgns/download/all")
async def download_all_pgns_zip():
    """Download all PGN files as a ZIP archive"""
    try:
        import zipfile
        import io
        
        pgn_dir = Path("/app/data/selfplay_pgns")
        
        if not pgn_dir.exists():
            raise HTTPException(status_code=404, detail="No PGN files available")
        
        pgn_files = list(pgn_dir.glob("*.pgn"))
        
        if not pgn_files:
            raise HTTPException(status_code=404, detail="No PGN files found")
        
        # Create ZIP in memory
        zip_buffer = io.BytesIO()
        
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            for pgn_file in pgn_files:
                zip_file.write(pgn_file, arcname=pgn_file.name)
        
        zip_buffer.seek(0)
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        zip_filename = f"selfplay_pgns_{timestamp}.zip"
        
        return StreamingResponse(
            zip_buffer,
            media_type="application/zip",
            headers={
                "Content-Disposition": f"attachment; filename={zip_filename}"
            }
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating ZIP archive: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create ZIP: {str(e)}")

# ====================
# LLM Tuning & Performance Endpoints (Step 13)
# ====================

class LLMConfigRequest(BaseModel):
    response_mode: str = Field(default="balanced", pattern="^(fast|balanced|insightful)$")
    prompt_depth: int = Field(default=5, ge=1, le=10)
    adaptive_enabled: bool = Field(default=True)
    max_response_time: float = Field(default=10.0, ge=1.0, le=30.0)
    fallback_mode: str = Field(default="fast", pattern="^(fast|balanced|insightful)$")

@api_router.get("/llm/tune")
async def get_llm_config():
    """Get current LLM configuration"""
    try:
        from llm_evaluator import LLMChessEvaluator, LLMConfig
        
        # Try to get from database
        config_doc = await db.llm_config.find_one({"type": "global"})
        
        if config_doc:
            config = LLMConfig(
                response_mode=config_doc.get("response_mode", "balanced"),
                prompt_depth=config_doc.get("prompt_depth", 5),
                adaptive_enabled=config_doc.get("adaptive_enabled", True),
                max_response_time=config_doc.get("max_response_time", 10.0),
                fallback_mode=config_doc.get("fallback_mode", "fast")
            )
        else:
            # Use current global config or default
            config = LLMChessEvaluator.get_global_config()
        
        return {
            "success": True,
            "config": config.to_dict()
        }
    except Exception as e:
        logger.error(f"Error getting LLM config: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/llm/tune")
async def update_llm_config(config_request: LLMConfigRequest):
    """Update LLM configuration globally"""
    try:
        from llm_evaluator import LLMChessEvaluator, LLMConfig
        
        # Create new config
        new_config = LLMConfig(
            response_mode=config_request.response_mode,
            prompt_depth=config_request.prompt_depth,
            adaptive_enabled=config_request.adaptive_enabled,
            max_response_time=config_request.max_response_time,
            fallback_mode=config_request.fallback_mode
        )
        
        # Set global config
        LLMChessEvaluator.set_global_config(new_config)
        
        # Store in database for persistence
        await db.llm_config.replace_one(
            {"type": "global"},
            {
                "type": "global",
                "response_mode": new_config.response_mode,
                "prompt_depth": new_config.prompt_depth,
                "adaptive_enabled": new_config.adaptive_enabled,
                "max_response_time": new_config.max_response_time,
                "fallback_mode": new_config.fallback_mode,
                "updated_at": datetime.now(timezone.utc)
            },
            upsert=True
        )
        
        logger.info(f"LLM config updated globally: {new_config.to_dict()}")
        
        return {
            "success": True,
            "message": "LLM configuration updated successfully",
            "config": new_config.to_dict()
        }
    except Exception as e:
        logger.error(f"Error updating LLM config: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/performance-metrics")
async def get_llm_performance_metrics(limit: int = 50):
    """Get LLM performance metrics from database"""
    try:
        # Get metrics from database
        metrics = await db.llm_performance.find().sort("timestamp", -1).limit(limit).to_list(limit)
        
        # Calculate aggregate stats
        if metrics:
            avg_response_time = sum(m.get("response_time", 0) for m in metrics) / len(metrics)
            success_rate = sum(1 for m in metrics if m.get("success", False)) / len(metrics) * 100
            fallback_count = sum(1 for m in metrics if m.get("fallback_triggered", False))
            
            # Get mode distribution
            mode_counts = {}
            for m in metrics:
                mode = m.get("mode", "unknown")
                mode_counts[mode] = mode_counts.get(mode, 0) + 1
        else:
            avg_response_time = 0
            success_rate = 0
            fallback_count = 0
            mode_counts = {}
        
        return {
            "success": True,
            "metrics": metrics,
            "summary": {
                "total_requests": len(metrics),
                "avg_response_time": round(avg_response_time, 2),
                "success_rate": round(success_rate, 1),
                "fallback_count": fallback_count,
                "mode_distribution": mode_counts
            }
        }
    except Exception as e:
        logger.error(f"Error getting LLM performance metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/optimization-status")
async def get_llm_optimization_status():
    """Get current LLM optimization status and recommendations"""
    try:
        from llm_evaluator import LLMChessEvaluator
        
        # Get recent metrics from database
        recent_metrics = await db.llm_performance.find().sort("timestamp", -1).limit(20).to_list(20)
        
        if not recent_metrics:
            return {
                "success": True,
                "status": "No data available",
                "recommendations": ["Start using LLM features to gather performance data"]
            }
        
        # Calculate stats
        avg_time = sum(m.get("response_time", 0) for m in recent_metrics) / len(recent_metrics)
        success_rate = sum(1 for m in recent_metrics if m.get("success", False)) / len(recent_metrics)
        fallback_count = sum(1 for m in recent_metrics if m.get("fallback_triggered", False))
        
        # Generate recommendations
        recommendations = []
        if avg_time > 8.0:
            recommendations.append("High response time detected. Consider using 'fast' mode.")
        if fallback_count > len(recent_metrics) * 0.3:
            recommendations.append("Frequent fallbacks occurring. Reduce prompt depth or use faster mode.")
        if success_rate < 0.9:
            recommendations.append("Low success rate. Check API connectivity.")
        
        if not recommendations:
            recommendations.append("Performance is optimal.")
        
        # Get current config
        config = LLMChessEvaluator.get_global_config()
        
        return {
            "success": True,
            "status": "active",
            "avg_response_time": round(avg_time, 2),
            "success_rate": round(success_rate * 100, 1),
            "fallback_count": fallback_count,
            "current_config": config.to_dict(),
            "recommendations": recommendations,
            "adaptive_active": config.adaptive_enabled
        }
    except Exception as e:
        logger.error(f"Error getting optimization status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# LLM Auto-Evaluation & Feedback
# ====================

class FeedbackInput(BaseModel):
    """User feedback for LLM outputs"""
    session_id: str
    operation_type: str  # "coaching", "analytics", "general"
    accuracy_score: float = Field(ge=1, le=5)
    usefulness: float = Field(ge=1, le=5)
    clarity: float = Field(ge=1, le=5)
    response_time: Optional[float] = None
    comment: Optional[str] = None
    llm_confidence: Optional[float] = Field(default=None, ge=0, le=1)

@api_router.post("/llm/evaluate")
async def evaluate_llm_response(feedback: FeedbackInput):
    """
    Accept user feedback for LLM outputs and store in llm_feedback collection.
    Returns aggregate scores and tuning recommendations.
    
    Evaluation weights:
    - User feedback (50%): accuracy, usefulness, clarity
    - LLM self-assessment (25%): confidence score
    - Performance metrics (25%): response time, success rate
    """
    try:
        from llm_evaluator import FeedbackData, evaluate_llm_output, PerformanceMetrics
        
        # Generate feedback ID
        feedback_id = str(uuid.uuid4())
        timestamp = datetime.now(timezone.utc).isoformat()
        
        # Create feedback data object
        feedback_data = FeedbackData(
            feedback_id=feedback_id,
            session_id=feedback.session_id,
            operation_type=feedback.operation_type,
            accuracy_score=feedback.accuracy_score,
            usefulness=feedback.usefulness,
            clarity=feedback.clarity,
            response_time=feedback.response_time or 0,
            timestamp=timestamp,
            comment=feedback.comment,
            llm_confidence=feedback.llm_confidence
        )
        
        # Create mock performance metrics if not provided
        performance_metrics = PerformanceMetrics(
            timestamp=timestamp,
            response_time=feedback.response_time or 5.0,
            model_used="gpt-4o-mini",
            prompt_length=0,
            response_length=0,
            mode="balanced",
            success=True,
            fallback_triggered=False
        )
        
        # Evaluate the output
        evaluation = evaluate_llm_output(
            feedback_data=feedback_data,
            performance_metrics=performance_metrics,
            llm_confidence=feedback.llm_confidence
        )
        
        # Store feedback in MongoDB
        feedback_doc = feedback_data.to_dict()
        feedback_doc["evaluation"] = evaluation.to_dict()
        await db.llm_feedback.insert_one(feedback_doc)
        
        # Check if we should trigger auto-optimization (every 10 feedbacks)
        feedback_count = await db.llm_feedback.count_documents({})
        should_auto_optimize = (feedback_count % 10 == 0) and feedback_count > 0
        
        # Calculate aggregate scores from recent feedback
        recent_feedback = await db.llm_feedback.find().sort("timestamp", -1).limit(20).to_list(20)
        
        if recent_feedback:
            avg_overall = sum(f.get("evaluation", {}).get("overall_score", 0) for f in recent_feedback) / len(recent_feedback)
            avg_accuracy = sum(f.get("evaluation", {}).get("accuracy_score", 0) for f in recent_feedback) / len(recent_feedback)
            avg_clarity = sum(f.get("evaluation", {}).get("clarity_score", 0) for f in recent_feedback) / len(recent_feedback)
        else:
            avg_overall = evaluation.overall_score
            avg_accuracy = evaluation.accuracy_score
            avg_clarity = evaluation.clarity_score
        
        response_data = {
            "success": True,
            "feedback_id": feedback_id,
            "evaluation": evaluation.to_dict(),
            "aggregate_scores": {
                "overall_score": round(avg_overall, 2),
                "accuracy_score": round(avg_accuracy, 2),
                "clarity_score": round(avg_clarity, 2),
                "total_feedback_count": feedback_count
            },
            "auto_optimize_triggered": should_auto_optimize
        }
        
        # Trigger auto-optimization if threshold reached
        if should_auto_optimize:
            logger.info(f"Auto-optimization triggered at {feedback_count} feedbacks")
            response_data["auto_optimize_message"] = f"Auto-optimization triggered after {feedback_count} feedbacks"
        
        return response_data
        
    except Exception as e:
        logger.error(f"Error evaluating LLM response: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/llm/auto-optimize")
async def auto_optimize_llm():
    """
    Analyze feedback and performance data to automatically tune LLM configuration.
    Can be triggered manually or automatically every 10 feedbacks.
    
    Returns recommended parameter changes and applies them if beneficial.
    """
    try:
        from llm_evaluator import LLMChessEvaluator, FeedbackData, auto_tune_from_feedback
        
        # Get current configuration
        current_config = LLMChessEvaluator.get_global_config()
        
        # Fetch recent feedback (last 50)
        feedback_docs = await db.llm_feedback.find().sort("timestamp", -1).limit(50).to_list(50)
        
        if not feedback_docs:
            return {
                "success": False,
                "message": "No feedback data available for optimization",
                "recommendations": ["Collect user feedback to enable auto-optimization"]
            }
        
        # Convert to FeedbackData objects
        feedback_list = []
        for doc in feedback_docs:
            try:
                feedback_list.append(FeedbackData(
                    feedback_id=doc.get("feedback_id", ""),
                    session_id=doc.get("session_id", ""),
                    operation_type=doc.get("operation_type", "general"),
                    accuracy_score=doc.get("accuracy_score", 3.0),
                    usefulness=doc.get("usefulness", 3.0),
                    clarity=doc.get("clarity", 3.0),
                    response_time=doc.get("response_time", 5.0),
                    timestamp=doc.get("timestamp", ""),
                    comment=doc.get("comment"),
                    llm_confidence=doc.get("llm_confidence")
                ))
            except Exception as e:
                logger.warning(f"Skipping invalid feedback doc: {e}")
                continue
        
        # Get performance history from MongoDB (we'll create a collection for this)
        # For now, use empty list as performance history is tracked in-memory
        performance_history = []
        
        # Perform auto-tuning
        new_config, recommendations = auto_tune_from_feedback(
            feedback_list=feedback_list,
            current_config=current_config,
            performance_history=performance_history
        )
        
        # Check if configuration changed
        config_changed = (
            new_config.response_mode != current_config.response_mode or
            new_config.prompt_depth != current_config.prompt_depth or
            new_config.max_response_time != current_config.max_response_time
        )
        
        # Apply new configuration if changed
        if config_changed:
            LLMChessEvaluator.set_global_config(new_config)
            logger.info(f"Auto-optimization applied: {new_config.to_dict()}")
            
            # Store optimization event in MongoDB
            optimization_event = {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "previous_config": current_config.to_dict(),
                "new_config": new_config.to_dict(),
                "recommendations": recommendations,
                "trigger": "auto",
                "feedback_count": len(feedback_list)
            }
            await db.llm_optimization_events.insert_one(optimization_event)
        
        # Calculate performance metrics
        if feedback_list:
            avg_accuracy = sum(f.accuracy_score for f in feedback_list) / len(feedback_list)
            avg_usefulness = sum(f.usefulness for f in feedback_list) / len(feedback_list)
            avg_clarity = sum(f.clarity for f in feedback_list) / len(feedback_list)
            avg_response_time = sum(f.response_time for f in feedback_list) / len(feedback_list)
        else:
            avg_accuracy = avg_usefulness = avg_clarity = 0
            avg_response_time = 0
        
        return {
            "success": True,
            "config_changed": config_changed,
            "previous_config": current_config.to_dict(),
            "new_config": new_config.to_dict(),
            "recommendations": recommendations,
            "performance_summary": {
                "avg_accuracy": round((avg_accuracy / 5.0) * 100, 1),
                "avg_usefulness": round((avg_usefulness / 5.0) * 100, 1),
                "avg_clarity": round((avg_clarity / 5.0) * 100, 1),
                "avg_response_time": round(avg_response_time, 2),
                "feedback_samples": len(feedback_list)
            },
            "message": "Configuration updated successfully" if config_changed else "No configuration changes needed"
        }
        
    except Exception as e:
        logger.error(f"Error in auto-optimization: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/feedback-summary")
async def get_feedback_summary(limit: int = 50):
    """Get summary of LLM feedback and evaluation trends"""
    try:
        # Fetch recent feedback
        feedback_docs = await db.llm_feedback.find().sort("timestamp", -1).limit(limit).to_list(limit)
        
        if not feedback_docs:
            return {
                "success": True,
                "total_feedback": 0,
                "message": "No feedback data available"
            }
        
        # Calculate aggregate metrics
        evaluations = [doc.get("evaluation", {}) for doc in feedback_docs]
        
        avg_overall = sum(e.get("overall_score", 0) for e in evaluations) / len(evaluations)
        avg_accuracy = sum(e.get("accuracy_score", 0) for e in evaluations) / len(evaluations)
        avg_usefulness = sum(e.get("usefulness_score", 0) for e in evaluations) / len(evaluations)
        avg_clarity = sum(e.get("clarity_score", 0) for e in evaluations) / len(evaluations)
        
        # Count by operation type
        operation_counts = {}
        for doc in feedback_docs:
            op_type = doc.get("operation_type", "unknown")
            operation_counts[op_type] = operation_counts.get(op_type, 0) + 1
        
        # Get recent optimization events
        optimization_events = await db.llm_optimization_events.find().sort("timestamp", -1).limit(10).to_list(10)
        
        return {
            "success": True,
            "total_feedback": len(feedback_docs),
            "aggregate_scores": {
                "overall_score": round(avg_overall, 2),
                "accuracy_score": round(avg_accuracy, 2),
                "usefulness_score": round(avg_usefulness, 2),
                "clarity_score": round(avg_clarity, 2)
            },
            "operation_distribution": operation_counts,
            "recent_feedback": [
                {
                    "timestamp": doc.get("timestamp"),
                    "operation_type": doc.get("operation_type"),
                    "evaluation": doc.get("evaluation", {}),
                    "comment": doc.get("comment")
                }
                for doc in feedback_docs[:10]
            ],
            "optimization_history": [
                {
                    "timestamp": evt.get("timestamp"),
                    "trigger": evt.get("trigger"),
                    "config_changed": evt.get("new_config") != evt.get("previous_config"),
                    "recommendations": evt.get("recommendations", [])[:3]  # Top 3
                }
                for evt in optimization_events
            ]
        }
        
    except Exception as e:
        logger.error(f"Error getting feedback summary: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Step 39: User Feedback Collection System
# ====================

class UserFeedbackInput(BaseModel):
    """User feedback for the app (Step 39)"""
    feedback_type: str  # "bug", "feature", "general", "performance"
    category: str  # "ui", "ai", "performance", "other"
    rating: int = Field(ge=1, le=5)
    message: str
    email: Optional[str] = None
    allow_contact: bool = False
    telemetry_opt_in: bool = False
    app_version: str = "1.0.0"
    platform: Optional[str] = None

class TelemetryData(BaseModel):
    """Anonymous telemetry data (opt-in)"""
    session_id: str
    event_type: str  # "game_played", "training_started", "ai_move", etc.
    duration: Optional[float] = None
    success: bool = True
    error_message: Optional[str] = None
    app_version: str = "1.0.0"
    platform: Optional[str] = None

@api_router.post("/feedback/submit")
async def submit_user_feedback(feedback: UserFeedbackInput):
    """
    Submit user feedback for the AlphaZero Chess App.
    Collects bug reports, feature requests, and general feedback.
    """
    try:
        feedback_id = str(uuid.uuid4())
        timestamp = datetime.now(timezone.utc)
        
        feedback_doc = {
            "feedback_id": feedback_id,
            "feedback_type": feedback.feedback_type,
            "category": feedback.category,
            "rating": feedback.rating,
            "message": feedback.message,
            "email": feedback.email if feedback.allow_contact else None,
            "allow_contact": feedback.allow_contact,
            "telemetry_opt_in": feedback.telemetry_opt_in,
            "app_version": feedback.app_version,
            "platform": feedback.platform,
            "timestamp": timestamp,
            "status": "new",
            "priority": "normal"
        }
        
        # Auto-assign priority based on type and rating
        if feedback.feedback_type == "bug" and feedback.rating <= 2:
            feedback_doc["priority"] = "high"
        elif feedback.feedback_type == "bug":
            feedback_doc["priority"] = "medium"
        
        # Store in MongoDB
        await db.user_feedback.insert_one(feedback_doc)
        
        logger.info(f"User feedback received: {feedback_id} - {feedback.feedback_type}")
        
        return {
            "success": True,
            "feedback_id": feedback_id,
            "message": "Thank you for your feedback! We'll review it shortly.",
            "priority": feedback_doc["priority"]
        }
        
    except Exception as e:
        logger.error(f"Error submitting feedback: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/telemetry/submit")
async def submit_telemetry(telemetry: TelemetryData):
    """
    Submit anonymous telemetry data (opt-in only).
    Used for performance monitoring and usage analytics.
    """
    try:
        telemetry_doc = {
            "session_id": telemetry.session_id,
            "event_type": telemetry.event_type,
            "duration": telemetry.duration,
            "success": telemetry.success,
            "error_message": telemetry.error_message,
            "app_version": telemetry.app_version,
            "platform": telemetry.platform,
            "timestamp": datetime.now(timezone.utc)
        }
        
        # Store in MongoDB
        await db.telemetry_data.insert_one(telemetry_doc)
        
        return {
            "success": True,
            "message": "Telemetry data recorded"
        }
        
    except Exception as e:
        logger.error(f"Error submitting telemetry: {e}")
        return {"success": False, "message": "Telemetry submission failed"}

@api_router.get("/feedback/analytics")
async def get_feedback_analytics(limit: int = 100):
    """
    Get analytics dashboard data for user feedback.
    Shows feedback trends, common issues, and sentiment analysis.
    """
    try:
        # Fetch recent feedback
        feedback_docs = await db.user_feedback.find().sort("timestamp", -1).limit(limit).to_list(limit)
        
        if not feedback_docs:
            return {
                "success": True,
                "total_feedback": 0,
                "message": "No feedback data available"
            }
        
        # Calculate metrics
        total_feedback = len(feedback_docs)
        avg_rating = sum(doc.get("rating", 0) for doc in feedback_docs) / total_feedback
        
        # Count by type
        type_counts = {}
        category_counts = {}
        priority_counts = {}
        
        for doc in feedback_docs:
            fb_type = doc.get("feedback_type", "unknown")
            category = doc.get("category", "unknown")
            priority = doc.get("priority", "normal")
            
            type_counts[fb_type] = type_counts.get(fb_type, 0) + 1
            category_counts[category] = category_counts.get(category, 0) + 1
            priority_counts[priority] = priority_counts.get(priority, 0) + 1
        
        # Get rating distribution
        rating_distribution = {}
        for doc in feedback_docs:
            rating = doc.get("rating", 0)
            rating_distribution[rating] = rating_distribution.get(rating, 0) + 1
        
        # Calculate sentiment (simplified)
        positive_count = sum(1 for doc in feedback_docs if doc.get("rating", 0) >= 4)
        neutral_count = sum(1 for doc in feedback_docs if doc.get("rating", 0) == 3)
        negative_count = sum(1 for doc in feedback_docs if doc.get("rating", 0) <= 2)
        
        # Get telemetry stats
        total_telemetry = await db.telemetry_data.count_documents({})
        telemetry_events = await db.telemetry_data.aggregate([
            {"$group": {"_id": "$event_type", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
            {"$limit": 10}
        ]).to_list(10)
        
        return {
            "success": True,
            "overview": {
                "total_feedback": total_feedback,
                "average_rating": round(avg_rating, 2),
                "sentiment": {
                    "positive": positive_count,
                    "neutral": neutral_count,
                    "negative": negative_count
                }
            },
            "distributions": {
                "by_type": type_counts,
                "by_category": category_counts,
                "by_priority": priority_counts,
                "by_rating": rating_distribution
            },
            "telemetry": {
                "total_events": total_telemetry,
                "top_events": [
                    {"event_type": evt["_id"], "count": evt["count"]}
                    for evt in telemetry_events
                ]
            },
            "recent_feedback": [
                {
                    "feedback_id": doc.get("feedback_id"),
                    "type": doc.get("feedback_type"),
                    "category": doc.get("category"),
                    "rating": doc.get("rating"),
                    "message": doc.get("message")[:100] + "..." if len(doc.get("message", "")) > 100 else doc.get("message"),
                    "timestamp": doc.get("timestamp").isoformat() if isinstance(doc.get("timestamp"), datetime) else str(doc.get("timestamp")),
                    "priority": doc.get("priority")
                }
                for doc in feedback_docs[:20]
            ]
        }
        
    except Exception as e:
        logger.error(f"Error getting feedback analytics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/app/version")
async def get_app_version():
    """Get current app version info"""
    return {
        "success": True,
        "version": "1.0.0",
        "build": "#39",
        "release_date": "2025-10-10",
        "status": "public-release"
    }

# ====================
# Step 30: Self-Reflection & Continuous Learning Loop
# ====================

# Import reflection controller
from self_reflection import ReflectionController

# Initialize reflection controller
reflection_controller = None

def get_reflection_controller():
    """Get or create reflection controller instance"""
    global reflection_controller
    if reflection_controller is None:
        reflection_controller = ReflectionController(db)
    return reflection_controller

@api_router.post("/llm/reflection/trigger")
async def trigger_reflection_cycle(
    trigger: str = "manual",
    game_id: Optional[str] = None
):
    """
    Trigger a self-reflection cycle.
    
    Args:
        trigger: What triggered this cycle ("post_game", "scheduled", "manual")
        game_id: Specific game to reflect on (optional)
    
    Returns:
        Complete reflection cycle results
    """
    try:
        controller = get_reflection_controller()
        
        logger.info(f"Triggering reflection cycle: trigger={trigger}, game_id={game_id}")
        
        cycle = await controller.trigger_reflection_cycle(
            trigger=trigger,
            game_id=game_id
        )
        
        # **Step 31 Integration**: Automatically trigger memory fusion after reflection
        memory_fusion_result = None
        try:
            memory_controller = get_memory_fusion_controller()
            logger.info(f"Auto-triggering memory fusion for reflection cycle {cycle.cycle_id}")
            
            reflection_data = cycle.to_dict()
            memory_fusion_result = await memory_controller.trigger_fusion_cycle(
                reflection_cycle_id=cycle.cycle_id,
                reflection_data=reflection_data,
                trigger="post_reflection"
            )
            
            logger.info(
                f"Memory fusion complete: {memory_fusion_result.get('new_memory_nodes', 0)} nodes created"
            )
        except Exception as fusion_error:
            logger.error(f"Memory fusion failed (non-critical): {fusion_error}")
            # Don't fail the whole reflection if fusion fails
        
        # **Step 32 Integration**: Automatically trigger cohesion after memory fusion
        cohesion_result = None
        if memory_fusion_result and memory_fusion_result.get("success"):
            try:
                cohesion_controller = get_cohesion_controller()
                logger.info(f"Auto-triggering cohesion for memory fusion {memory_fusion_result.get('fusion_id')}")
                
                cohesion_report = await cohesion_controller.trigger_cohesion_cycle(
                    trigger="post_memory_fusion",
                    memory_fusion_id=memory_fusion_result.get("fusion_id"),
                    reflection_cycle_id=cycle.cycle_id
                )
                
                cohesion_result = {
                    "cycle_id": cohesion_report.cycle_id,
                    "alignment_score": cohesion_report.metrics.alignment_score,
                    "system_health_index": cohesion_report.metrics.system_health_index,
                    "ethical_continuity": cohesion_report.metrics.ethical_continuity,
                    "cohesion_health": cohesion_report.metrics.cohesion_health,
                    "auto_triggered": True
                }
                
                logger.info(
                    f"Cohesion cycle complete: alignment={cohesion_report.metrics.alignment_score:.2f}, "
                    f"health={cohesion_report.metrics.system_health_index:.2f}"
                )
            except Exception as cohesion_error:
                logger.error(f"Cohesion cycle failed (non-critical): {cohesion_error}")
                # Don't fail the whole pipeline if cohesion fails
        
        response = {
            "success": True,
            "cycle_id": cycle.cycle_id,
            "timestamp": cycle.timestamp,
            "trigger": cycle.trigger,
            "games_analyzed": cycle.games_analyzed,
            "strategies_evaluated": cycle.strategies_evaluated,
            "overall_performance_score": cycle.overall_performance_score,
            "learning_health_index": cycle.learning_health_index,
            "ethical_alignment_status": cycle.ethical_alignment_status,
            "insights_summary": cycle.insights_summary,
            "recommendations": cycle.recommendations,
            "parameter_adjustments": cycle.parameter_adjustments,
            "game_reflections": cycle.game_reflections,
            "strategy_evaluations": cycle.strategy_evaluations
        }
        
        # Add memory fusion results if successful
        if memory_fusion_result and memory_fusion_result.get("success"):
            response["memory_fusion"] = {
                "fusion_id": memory_fusion_result.get("fusion_id"),
                "nodes_created": memory_fusion_result.get("new_memory_nodes", 0),
                "fusion_time": memory_fusion_result.get("fusion_time_seconds", 0),
                "auto_triggered": True
            }
        
        # Add cohesion results if successful
        if cohesion_result:
            response["cohesion"] = cohesion_result
        
        return response
        
    except Exception as e:
        logger.error(f"Error triggering reflection cycle: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/reflection/status")
async def get_reflection_status():
    """Get current reflection system status"""
    try:
        controller = get_reflection_controller()
        status = await controller.get_reflection_status()
        
        return {
            "success": True,
            **status
        }
        
    except Exception as e:
        logger.error(f"Error getting reflection status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/reflection/history")
async def get_reflection_history(limit: int = 10):
    """Get reflection cycle history"""
    try:
        controller = get_reflection_controller()
        history = await controller.get_reflection_history(limit=limit)
        
        return {
            "success": True,
            "count": len(history),
            "cycles": history
        }
        
    except Exception as e:
        logger.error(f"Error getting reflection history: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/reflection/parameters")
async def get_learning_parameters():
    """Get current learning parameters"""
    try:
        controller = get_reflection_controller()
        params = await controller.get_current_learning_parameters()
        
        return {
            "success": True,
            "parameters": params.to_dict()
        }
        
    except Exception as e:
        logger.error(f"Error getting learning parameters: {e}")
        raise HTTPException(status_code=500, detail=str(e))

class UpdateParametersRequest(BaseModel):
    novelty_weight: Optional[float] = None
    stability_weight: Optional[float] = None
    ethical_threshold: Optional[float] = None
    creativity_bias: Optional[float] = None
    risk_tolerance: Optional[float] = None
    reflection_depth: Optional[int] = None

@api_router.post("/llm/reflection/parameters")
async def update_learning_parameters(request: UpdateParametersRequest):
    """Update learning parameters"""
    try:
        controller = get_reflection_controller()
        
        params = await controller.update_learning_parameters(
            novelty_weight=request.novelty_weight,
            stability_weight=request.stability_weight,
            ethical_threshold=request.ethical_threshold,
            creativity_bias=request.creativity_bias,
            risk_tolerance=request.risk_tolerance,
            reflection_depth=request.reflection_depth
        )
        
        return {
            "success": True,
            "message": "Learning parameters updated successfully",
            "parameters": params.to_dict()
        }
        
    except Exception as e:
        logger.error(f"Error updating learning parameters: {e}")
        raise HTTPException(status_code=500, detail=str(e))

class HumanFeedbackRequest(BaseModel):
    game_id: str
    rating: int = Field(ge=1, le=5)
    comment: Optional[str] = None

@api_router.post("/llm/reflection/feedback")
async def submit_human_feedback(request: HumanFeedbackRequest):
    """Submit human feedback for a game"""
    try:
        controller = get_reflection_controller()
        
        result = await controller.submit_human_feedback(
            game_id=request.game_id,
            rating=request.rating,
            comment=request.comment
        )
        
        return result
        
    except Exception as e:
        logger.error(f"Error submitting feedback: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/reflection/metrics")
async def get_reflection_metrics():
    """Get comprehensive reflection system metrics"""
    try:
        # Get reflection status
        controller = get_reflection_controller()
        status = await controller.get_reflection_status()
        
        # Get recent cycles
        recent_cycles = await controller.get_reflection_history(limit=10)
        
        # Calculate trends
        if recent_cycles:
            performance_trend = [c.get("overall_performance_score", 0) for c in recent_cycles]
            health_trend = [c.get("learning_health_index", 0) for c in recent_cycles]
            
            avg_performance = sum(performance_trend) / len(performance_trend)
            avg_health = sum(health_trend) / len(health_trend)
            
            # Calculate improvement
            if len(performance_trend) >= 2:
                recent_perf = sum(performance_trend[:3]) / min(3, len(performance_trend[:3]))
                older_perf = sum(performance_trend[-3:]) / min(3, len(performance_trend[-3:]))
                performance_change = recent_perf - older_perf
            else:
                performance_change = 0.0
        else:
            avg_performance = 0.0
            avg_health = 0.0
            performance_change = 0.0
        
        # Get strategy evaluation summary
        strategy_evals = await db.llm_strategy_evaluation.find().sort("timestamp", -1).limit(20).to_list(20)
        
        strategy_summary = {}
        if strategy_evals:
            rating_counts = {}
            for eval_doc in strategy_evals:
                rating = eval_doc.get("performance_rating", "unknown")
                rating_counts[rating] = rating_counts.get(rating, 0) + 1
            
            strategy_summary = {
                "total_evaluated": len(strategy_evals),
                "rating_distribution": rating_counts,
                "avg_success_rate": sum(e.get("success_rate", 0) for e in strategy_evals) / len(strategy_evals)
            }
        
        return {
            "success": True,
            "reflection_status": status,
            "performance_metrics": {
                "avg_performance_score": round(avg_performance, 1),
                "avg_learning_health": round(avg_health, 2),
                "performance_change": round(performance_change, 1),
                "total_cycles": len(recent_cycles)
            },
            "strategy_evaluation": strategy_summary,
            "recent_cycles": recent_cycles[:5]
        }
        
    except Exception as e:
        logger.error(f"Error getting reflection metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Memory Fusion & Long-Term Cognitive Persistence (Step 31)
# ====================

# Helper function to convert ObjectIds in nested structures
def convert_objectids(obj):
    """Recursively convert ObjectId instances to strings"""
    from bson import ObjectId
    
    if isinstance(obj, ObjectId):
        return str(obj)
    elif isinstance(obj, dict):
        return {k: convert_objectids(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_objectids(item) for item in obj]
    else:
        return obj

# Global memory fusion controller
_memory_fusion_controller = None

def get_memory_fusion_controller():
    """Get or create memory fusion controller"""
    global _memory_fusion_controller
    if _memory_fusion_controller is None:
        from memory_fusion import MemoryFusionController
        _memory_fusion_controller = MemoryFusionController(db)
    return _memory_fusion_controller

class MemoryFusionRequest(BaseModel):
    reflection_cycle_id: str
    trigger: str = "post_reflection"

class MemoryRetrievalRequest(BaseModel):
    query: str
    context: Optional[Dict[str, Any]] = None
    limit: int = Field(default=5, ge=1, le=20)

class MemoryResetRequest(BaseModel):
    confirmation: str
    admin_override: bool = False

@api_router.post("/llm/memory/fuse")
async def trigger_memory_fusion(
    reflection_cycle_id: str,
    trigger: str = "post_reflection"
):
    """
    Trigger memory fusion cycle to consolidate reflection insights into long-term memory.
    
    Automatically called after Step 30 reflection cycles. Can also be manually triggered.
    Creates up to 5 memory nodes per cycle with exponential decay tracking.
    """
    try:
        controller = get_memory_fusion_controller()
        
        # Get reflection data
        reflection_data = await db.llm_reflection_log.find_one({"cycle_id": reflection_cycle_id})
        
        if not reflection_data:
            raise HTTPException(
                status_code=404,
                detail=f"Reflection cycle {reflection_cycle_id} not found"
            )
        
        # Trigger fusion cycle
        result = await controller.trigger_fusion_cycle(
            reflection_cycle_id=reflection_cycle_id,
            reflection_data=reflection_data,
            trigger=trigger
        )
        
        return {
            "success": result.get("success", True),
            "fusion_result": result
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error triggering memory fusion: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/memory/nodes")
async def get_memory_nodes(
    limit: int = Query(default=50, ge=1, le=200),
    active_only: bool = Query(default=True),
    sort_by: str = Query(default="timestamp", pattern="^(timestamp|decay_weight|usage_count)$")
):
    """
    Get list of memory nodes with filtering and sorting options.
    
    Query parameters:
    - limit: Maximum nodes to return (1-200)
    - active_only: Only return nodes above decay threshold
    - sort_by: Sort field (timestamp, decay_weight, usage_count)
    """
    try:
        controller = get_memory_fusion_controller()
        
        # Build query
        query = {}
        if active_only:
            query["decay_weight"] = {"$gte": controller.min_decay_threshold}
        
        # Get nodes
        nodes = await db.llm_memory_nodes.find(query).sort(
            sort_by, -1
        ).limit(limit).to_list(limit)
        
        # Convert ObjectId to string for JSON serialization
        for node in nodes:
            if '_id' in node:
                node['_id'] = str(node['_id'])
        
        return {
            "success": True,
            "count": len(nodes),
            "nodes": nodes,
            "active_only": active_only,
            "sort_by": sort_by
        }
        
    except Exception as e:
        logger.error(f"Error getting memory nodes: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/llm/memory/retrieve")
async def retrieve_contextual_memory(request: MemoryRetrievalRequest):
    """
    Retrieve relevant memory nodes based on contextual query.
    
    Uses relevance scoring to find the most applicable memories for a given context.
    Updates usage counts and resets decay for retrieved memories.
    """
    try:
        controller = get_memory_fusion_controller()
        
        # Retrieve memories
        memories = await controller.retrieve_contextual_memory(
            query=request.query,
            context=request.context,
            limit=request.limit
        )
        
        return {
            "success": True,
            "query": request.query,
            "memories_found": len(memories),
            "memories": [m.to_dict() for m in memories]
        }
        
    except Exception as e:
        logger.error(f"Error retrieving contextual memory: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/memory/profile")
async def get_long_term_profile():
    """
    Get comprehensive long-term persistence profile.
    
    Returns:
    - Memory distribution by type
    - Parameter evolution trajectories
    - Learning trends (creativity, stability, ethics)
    - Health metrics and target comparisons
    - AI-generated summary of cognitive evolution
    """
    try:
        controller = get_memory_fusion_controller()
        
        profile = await controller.synthesize_long_term_profile()
        
        # Convert any ObjectIds in the profile
        profile = convert_objectids(profile)
        
        return {
            "success": True,
            "profile": profile
        }
        
    except Exception as e:
        logger.error(f"Error getting long-term profile: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/memory/health")
async def get_memory_health():
    """
    Get current memory system health metrics.
    
    Returns:
    - Memory retention index (target: ≥0.90)
    - Fusion efficiency (target: ≥0.85)
    - Ethical continuity (target: ≥0.92)
    - Retrieval latency (target: ≤2.0s)
    - Persistence health (target: ≥0.88)
    - Health recommendations
    """
    try:
        controller = get_memory_fusion_controller()
        
        health = await controller.get_memory_health()
        
        return {
            "success": True,
            "health": health
        }
        
    except Exception as e:
        logger.error(f"Error getting memory health: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/memory/traces")
async def get_memory_traces(
    limit: int = Query(default=50, ge=1, le=200),
    trace_type: Optional[str] = Query(default=None, pattern="^(fusion_cycle|retrieval)$")
):
    """
    Get memory trace logs (fusion cycles and retrievals).
    
    Query parameters:
    - limit: Maximum traces to return
    - trace_type: Filter by type (fusion_cycle or retrieval)
    """
    try:
        query = {}
        if trace_type:
            query["trace_type"] = trace_type
        
        traces = await db.llm_memory_trace.find(query).sort(
            "timestamp", -1
        ).limit(limit).to_list(limit)
        
        return {
            "success": True,
            "count": len(traces),
            "traces": traces,
            "trace_type": trace_type
        }
        
    except Exception as e:
        logger.error(f"Error getting memory traces: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/llm/memory/reset")
async def reset_memory_system(request: MemoryResetRequest):
    """
    Reset memory system (admin function with safeguards).
    
    Requires:
    - confirmation: "CONFIRM_RESET"
    - admin_override: true
    
    Creates backup before reset. Use with caution.
    """
    try:
        controller = get_memory_fusion_controller()
        
        result = await controller.reset_memory_system(
            confirmation=request.confirmation,
            admin_override=request.admin_override
        )
        
        if not result.get("success"):
            raise HTTPException(status_code=403, detail=result.get("error", "Reset failed"))
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error resetting memory system: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/memory/stats")
async def get_memory_statistics():
    """Get quick memory system statistics"""
    try:
        total_nodes = await db.llm_memory_nodes.count_documents({})
        controller = get_memory_fusion_controller()
        active_nodes = await db.llm_memory_nodes.count_documents({
            "decay_weight": {"$gte": controller.min_decay_threshold}
        })
        total_traces = await db.llm_memory_trace.count_documents({})
        total_profiles = await db.llm_persistence_profile.count_documents({})
        
        # Get latest fusion
        latest_fusion = await db.llm_memory_trace.find_one(
            {"trace_type": "fusion_cycle"},
            sort=[("timestamp", -1)]
        )
        
        return {
            "success": True,
            "statistics": {
                "total_memory_nodes": total_nodes,
                "active_memory_nodes": active_nodes,
                "decayed_memory_nodes": total_nodes - active_nodes,
                "total_traces": total_traces,
                "total_profiles": total_profiles,
                "latest_fusion": latest_fusion.get("timestamp") if latest_fusion else None,
                "decay_lambda": controller.decay_lambda,
                "max_nodes_per_cycle": controller.max_nodes_per_cycle,
                "retention_window_games": controller.retention_window
            }
        }
        
    except Exception as e:
        logger.error(f"Error getting memory statistics: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Cohesion Core & Systemic Unification (Step 32)
# ====================

# Import cohesion controller
from cohesion_core import CohesionController

# Initialize cohesion controller
cohesion_controller = None

def get_cohesion_controller():
    """Get or create cohesion controller instance"""
    global cohesion_controller
    if cohesion_controller is None:
        cohesion_controller = CohesionController(db)
    return cohesion_controller

@api_router.post("/llm/cohesion/trigger")
async def trigger_cohesion_cycle(
    trigger: str = "manual",
    memory_fusion_id: Optional[str] = None,
    reflection_cycle_id: Optional[str] = None
):
    """
    Trigger a cohesion cycle to synchronize all cognitive subsystems.
    
    Args:
        trigger: What triggered this cycle ("post_memory_fusion", "scheduled", "manual")
        memory_fusion_id: ID of the memory fusion that triggered this
        reflection_cycle_id: ID of the reflection cycle (if available)
    
    Returns:
        Comprehensive cohesion report
    """
    try:
        controller = get_cohesion_controller()
        
        logger.info(f"Triggering cohesion cycle: trigger={trigger}")
        
        report = await controller.trigger_cohesion_cycle(
            trigger=trigger,
            memory_fusion_id=memory_fusion_id,
            reflection_cycle_id=reflection_cycle_id
        )
        
        return {
            "success": True,
            "report_id": report.report_id,
            "cycle_id": report.cycle_id,
            "timestamp": report.timestamp,
            "metrics": report.metrics.to_dict(),
            "module_states": {k: v.to_dict() for k, v in report.module_states.items()},
            "health_analysis": report.health_analysis,
            "recommendations": report.recommendations,
            "actions_log": report.actions_log,
            "parameter_comparison": report.parameter_comparison
        }
        
    except Exception as e:
        logger.error(f"Error triggering cohesion cycle: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/cohesion/status")
async def get_cohesion_status():
    """Get current cohesion system status"""
    try:
        controller = get_cohesion_controller()
        status = await controller.get_cohesion_status()
        
        return {
            "success": True,
            **status
        }
        
    except Exception as e:
        logger.error(f"Error getting cohesion status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/cohesion/history")
async def get_cohesion_history(limit: int = 10):
    """Get cohesion cycle history"""
    try:
        controller = get_cohesion_controller()
        history = await controller.get_cohesion_history(limit=limit)
        
        # Remove MongoDB _id field
        for cycle in history:
            if '_id' in cycle:
                del cycle['_id']
        
        return {
            "success": True,
            "count": len(history),
            "cycles": history
        }
        
    except Exception as e:
        logger.error(f"Error getting cohesion history: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/cohesion/report")
async def get_cohesion_report(cycle_id: Optional[str] = None):
    """Get comprehensive cohesion report"""
    try:
        controller = get_cohesion_controller()
        result = await controller.generate_cohesion_report(cycle_id=cycle_id)
        
        return result
        
    except Exception as e:
        logger.error(f"Error getting cohesion report: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/cohesion/metrics")
async def get_cohesion_metrics(limit: int = 20):
    """Get cohesion metrics history"""
    try:
        metrics = await db.llm_cohesion_metrics.find().sort(
            "timestamp", -1
        ).limit(limit).to_list(limit)
        
        # Remove MongoDB _id field
        for metric in metrics:
            if '_id' in metric:
                del metric['_id']
        
        return {
            "success": True,
            "count": len(metrics),
            "metrics": metrics
        }
        
    except Exception as e:
        logger.error(f"Error getting cohesion metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/cohesion/health")
async def get_system_health(limit: int = 20):
    """Get system health history"""
    try:
        health_records = await db.llm_system_health.find().sort(
            "timestamp", -1
        ).limit(limit).to_list(limit)
        
        # Remove MongoDB _id field
        for record in health_records:
            if '_id' in record:
                del record['_id']
        
        # Calculate trends if enough data
        if len(health_records) >= 3:
            recent_health = [h.get("system_health_index", 0) for h in health_records[:3]]
            older_health = [h.get("system_health_index", 0) for h in health_records[-3:]]
            
            recent_avg = sum(recent_health) / len(recent_health)
            older_avg = sum(older_health) / len(older_health)
            
            if recent_avg > older_avg + 0.05:
                trend = "improving"
            elif recent_avg < older_avg - 0.05:
                trend = "declining"
            else:
                trend = "stable"
        else:
            trend = "insufficient_data"
        
        return {
            "success": True,
            "count": len(health_records),
            "health_records": health_records,
            "trend": trend,
            "latest_health": health_records[0] if health_records else None
        }
        
    except Exception as e:
        logger.error(f"Error getting system health: {e}")
        raise HTTPException(status_code=500, detail=str(e))



# ====================
# Ethical Governance Layer 2.0 (Step 33)
# ====================

from ethical_governance_v2 import EthicalGovernanceController

# Global controller instance
ethics_controller = None

def get_ethics_controller():
    """Get or create Ethical Governance controller instance"""
    global ethics_controller
    if ethics_controller is None:
        ethics_controller = EthicalGovernanceController(db)
    return ethics_controller

@api_router.post("/llm/ethics/trigger")
async def trigger_ethics_scan(context: str = "general"):
    """
    Trigger an ethical governance scan across all cognitive subsystems.
    
    Args:
        context: Operational context ("opening", "middlegame", "endgame", "general")
    
    Returns:
        Complete ethical assessment with metrics, violations, and recommendations
    """
    try:
        controller = get_ethics_controller()
        
        logger.info(f"Triggering ethics scan for context: {context}")
        
        # Step 1: Monitor system state
        system_state = await controller.monitor_system_state()
        
        # Step 2: Evaluate compliance
        metrics = await controller.evaluate_compliance(system_state, context)
        
        # Step 3: Auto-flag anomalies
        violations = await controller.auto_flag_anomalies(system_state, metrics)
        
        # Step 4: Recalibrate thresholds
        thresholds = await controller.recalibrate_thresholds(metrics, context)
        
        return {
            "success": True,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "context": context,
            "metrics": metrics.to_dict(),
            "violations_flagged": len(violations),
            "violations": [v.to_dict() for v in violations],
            "thresholds_updated": len(thresholds),
            "system_state": system_state
        }
        
    except Exception as e:
        logger.error(f"Error triggering ethics scan: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/ethics/status")
async def get_ethics_status():
    """Get current ethical governance system status"""
    try:
        controller = get_ethics_controller()
        status = await controller.get_ethics_status()
        
        return {
            "success": True,
            **status
        }
        
    except Exception as e:
        logger.error(f"Error getting ethics status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/ethics/violations")
async def get_ethics_violations(
    severity: Optional[str] = None,
    module: Optional[str] = None,
    limit: int = 50
):
    """
    Get flagged ethical violations.
    
    Args:
        severity: Filter by severity ("critical", "high", "medium", "low")
        module: Filter by module ("creativity", "reflection", "memory", "cohesion")
        limit: Maximum number of violations to return
    
    Returns:
        List of violations with details
    """
    try:
        controller = get_ethics_controller()
        violations = await controller.get_violations(severity, module, limit)
        
        return {
            "success": True,
            "count": len(violations),
            "filters": {"severity": severity, "module": module},
            "violations": violations
        }
        
    except Exception as e:
        logger.error(f"Error getting violations: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/ethics/metrics")
async def get_ethics_metrics(days: int = 7):
    """
    Get ethical compliance metrics history.
    
    Args:
        days: Number of days of history to retrieve
    
    Returns:
        List of metrics over time
    """
    try:
        controller = get_ethics_controller()
        metrics = await controller.get_metrics_history(days)
        
        return {
            "success": True,
            "count": len(metrics),
            "period_days": days,
            "metrics": metrics
        }
        
    except Exception as e:
        logger.error(f"Error getting ethics metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/ethics/report")
async def get_ethics_report(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None
):
    """
    Generate comprehensive Ethics Report.
    
    Args:
        start_date: Report period start (ISO format)
        end_date: Report period end (ISO format)
    
    Returns:
        Complete ethics report with analysis and recommendations
    """
    try:
        controller = get_ethics_controller()
        
        report = await controller.generate_ethics_report(start_date, end_date)
        
        return {
            "success": True,
            "report": report.to_dict()
        }
        
    except Exception as e:
        logger.error(f"Error generating ethics report: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/ethics/thresholds")
async def get_ethics_thresholds(context: str = "general"):
    """
    Get current adaptive ethical thresholds.
    
    Args:
        context: Context to retrieve thresholds for
    
    Returns:
        Current thresholds per module and parameter
    """
    try:
        thresholds = await db.llm_ethics_policies.find({
            "context": context
        }).to_list(100)
        
        # Remove MongoDB _id
        for t in thresholds:
            if '_id' in t:
                del t['_id']
        
        return {
            "success": True,
            "context": context,
            "count": len(thresholds),
            "thresholds": thresholds
        }
        
    except Exception as e:
        logger.error(f"Error getting thresholds: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/ethics/approvals")
async def get_pending_approvals():
    """Get all pending parameter change requests requiring human approval"""
    try:
        controller = get_ethics_controller()
        approvals = await controller.get_pending_approvals()
        
        return {
            "success": True,
            "count": len(approvals),
            "pending_approvals": approvals
        }
        
    except Exception as e:
        logger.error(f"Error getting pending approvals: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/llm/ethics/approve")
async def approve_parameter_change(
    request_id: str,
    approved: bool,
    approved_by: str,
    notes: Optional[str] = None
):
    """
    Approve or reject a parameter change request.
    
    Args:
        request_id: ID of the change request
        approved: True to approve, False to reject
        approved_by: Username/identifier of approver
        notes: Optional approval notes
    
    Returns:
        Result of approval action
    """
    try:
        controller = get_ethics_controller()
        
        result = await controller.approve_parameter_change(
            request_id, approved, approved_by, notes
        )
        
        return result
        
    except Exception as e:
        logger.error(f"Error approving parameter change: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/llm/ethics/request-change")
async def request_parameter_change(
    module: str,
    parameter: str,
    current_value: float,
    proposed_value: float,
    reason: str
):
    """
    Request a parameter change (requires human approval for critical changes).
    
    Args:
        module: Module requesting change
        parameter: Parameter to change
        current_value: Current parameter value
        proposed_value: Proposed new value
        reason: Justification for change
    
    Returns:
        Parameter change request details
    """
    try:
        controller = get_ethics_controller()
        
        request = await controller.request_parameter_change(
            module, parameter, current_value, proposed_value, reason
        )
        
        return {
            "success": True,
            "request": request.to_dict()
        }
        
    except Exception as e:
        logger.error(f"Error requesting parameter change: {e}")
        raise HTTPException(status_code=500, detail=str(e))



# ====================
# Cognitive Resonance & Long-Term System Stability (Step 34)
# ====================

_resonance_controller = None

def get_resonance_controller():
    """Lazy initialization of Resonance Controller"""
    global _resonance_controller
    if _resonance_controller is None:
        from cognitive_resonance import CognitiveResonanceController
        _resonance_controller = CognitiveResonanceController(db)
    return _resonance_controller

@api_router.get("/llm/resonance/status")
async def get_resonance_status():
    """
    Get current resonance and stability indicators.
    
    Returns resonance index, temporal stability, feedback equilibrium,
    entropy balance, and target compliance status.
    
    Returns:
        Current resonance system status
    """
    try:
        controller = get_resonance_controller()
        status = await controller.get_resonance_status()
        return status
        
    except Exception as e:
        logger.error(f"Error getting resonance status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/llm/resonance/analyze")
async def analyze_resonance():
    """
    Trigger resonance state analysis.
    
    Analyzes cross-module alignment, temporal stability, feedback equilibrium,
    and entropy balance across all cognitive subsystems (Steps 29-33).
    
    Returns:
        Comprehensive resonance metrics
    """
    try:
        controller = get_resonance_controller()
        metrics = await controller.analyze_resonance_state()
        
        return {
            "success": True,
            "metrics": metrics.to_dict()
        }
        
    except Exception as e:
        logger.error(f"Error analyzing resonance: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/llm/resonance/recalibrate")
async def recalibrate_feedback_weights(force: bool = False):
    """
    Force balance recalibration of feedback weights.
    
    Adaptive Feedback Regulator (AFR) adjusts learning feedback gains to maintain
    equilibrium between novelty, stability, and ethical parameters.
    
    Args:
        force: Force recalibration even if system is balanced
    
    Returns:
        Balance adjustment recommendations (advisory mode)
    """
    try:
        controller = get_resonance_controller()
        result = await controller.balance_feedback_weights(force_recalibration=force)
        
        return {
            "success": True,
            "balance_result": result
        }
        
    except Exception as e:
        logger.error(f"Error recalibrating feedback weights: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/resonance/forecast")
async def get_stability_forecast(horizon_hours: int = Query(24, ge=1, le=168)):
    """
    Get stability forecast for upcoming sessions.
    
    Temporal Stability Monitor (TSM) predicts potential drift, oscillation,
    and stagnation risks over the specified time horizon.
    
    Args:
        horizon_hours: Forecast horizon in hours (default: 24, max: 168)
    
    Returns:
        Stability forecast with predictions and risk assessment
    """
    try:
        controller = get_resonance_controller()
        forecast = await controller.stability_forecast(horizon_hours=horizon_hours)
        
        return {
            "success": True,
            "forecast": forecast.to_dict()
        }
        
    except Exception as e:
        logger.error(f"Error generating stability forecast: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/resonance/report")
async def get_resonance_report(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None
):
    """
    Retrieve comprehensive resonance report.
    
    Generates Resonance Report with summary metrics, module analysis,
    stability trends, forecasts, and recommendations.
    
    Args:
        start_date: Report period start (ISO format, default: 7 days ago)
        end_date: Report period end (ISO format, default: now)
    
    Returns:
        Complete resonance report
    """
    try:
        controller = get_resonance_controller()
        report = await controller.generate_resonance_report(start_date, end_date)
        
        return {
            "success": True,
            "report": report.to_dict()
        }
        
    except Exception as e:
        logger.error(f"Error generating resonance report: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/llm/resonance/snapshot")
async def record_snapshot():
    """
    Record a resonance snapshot for longitudinal tracking.
    
    Persistence Resonator (PR) stores current system state, module metrics,
    and notable events for historical analysis.
    
    Returns:
        Stored resonance snapshot
    """
    try:
        controller = get_resonance_controller()
        snapshot = await controller.record_resonance_snapshot()
        
        return {
            "success": True,
            "snapshot": snapshot.to_dict()
        }
        
    except Exception as e:
        logger.error(f"Error recording resonance snapshot: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/resonance/snapshots")
async def get_resonance_snapshots(limit: int = Query(20, ge=1, le=100)):
    """
    Get historical resonance snapshots.
    
    Args:
        limit: Maximum number of snapshots to retrieve
    
    Returns:
        List of historical resonance snapshots
    """
    try:
        snapshots = await db.llm_resonance_snapshots.find().sort(
            "timestamp", -1
        ).limit(limit).to_list(limit)
        
        # Remove MongoDB _id
        for snapshot in snapshots:
            if '_id' in snapshot:
                del snapshot['_id']
        
        return {
            "success": True,
            "snapshots": snapshots,
            "count": len(snapshots)
        }
        
    except Exception as e:
        logger.error(f"Error getting resonance snapshots: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/resonance/metrics")
async def get_resonance_metrics(days: int = Query(7, ge=1, le=30)):
    """
    Get historical resonance metrics.
    
    Args:
        days: Number of days of history to retrieve
    
    Returns:
        List of historical resonance metrics
    """
    try:
        start_date = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        
        metrics = await db.llm_resonance_metrics.find({
            "timestamp": {"$gte": start_date}
        }).sort("timestamp", -1).to_list(1000)
        
        # Remove MongoDB _id
        for m in metrics:
            if '_id' in m:
                del m['_id']
        
        return {
            "success": True,
            "metrics": metrics,
            "count": len(metrics)
        }
        
    except Exception as e:
        logger.error(f"Error getting resonance metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))



# ====================
# LLM Knowledge Distillation & Performance Audit (Step 15)
# ====================

@api_router.post("/llm/distill")
async def distill_knowledge():
    """
    Extract reusable strategic knowledge from high-rated feedback (≥4★).
    Analyzes patterns and creates compact distilled insights.
    Auto-trims to keep latest 100 records.
    """
    try:
        from llm_evaluator import distill_from_feedback, DistilledKnowledge
        
        # Fetch high-rated feedback (accuracy_score ≥ 4)
        high_rated_feedback = await db.llm_feedback.find({
            "accuracy_score": {"$gte": 4.0}
        }).sort("timestamp", -1).limit(100).to_list(100)
        
        if not high_rated_feedback:
            return {
                "success": False,
                "message": "No high-rated feedback (≥4★) available for distillation",
                "distilled_count": 0
            }
        
        # Get API key
        api_key = os.environ.get('EMERGENT_LLM_KEY')
        if not api_key:
            raise HTTPException(status_code=500, detail="EMERGENT_LLM_KEY not configured")
        
        # Perform distillation
        logger.info(f"Starting distillation from {len(high_rated_feedback)} high-rated feedback entries")
        distilled_entries = await distill_from_feedback(high_rated_feedback, api_key)
        
        if not distilled_entries:
            return {
                "success": False,
                "message": "Distillation failed to extract knowledge",
                "distilled_count": 0
            }
        
        # Store in llm_knowledge_base collection
        distilled_dicts = [entry.to_dict() for entry in distilled_entries]
        await db.llm_knowledge_base.insert_many(distilled_dicts)
        
        # Auto-trim: Keep only latest 100 records
        total_count = await db.llm_knowledge_base.count_documents({})
        if total_count > 100:
            # Get oldest entries to delete
            entries_to_delete = await db.llm_knowledge_base.find().sort("timestamp", 1).limit(total_count - 100).to_list(total_count - 100)
            ids_to_delete = [entry["_id"] for entry in entries_to_delete]
            
            await db.llm_knowledge_base.delete_many({"_id": {"$in": ids_to_delete}})
            logger.info(f"Trimmed {len(ids_to_delete)} old distilled entries, kept latest 100")
        
        # Return summary
        logger.info(f"Successfully distilled {len(distilled_entries)} knowledge entries")
        
        return {
            "success": True,
            "message": f"Successfully distilled {len(distilled_entries)} knowledge entries from {len(high_rated_feedback)} high-rated feedback",
            "distilled_count": len(distilled_entries),
            "source_feedback_count": len(high_rated_feedback),
            "total_in_knowledge_base": min(total_count + len(distilled_entries), 100),
            "distilled_entries": [
                {
                    "pattern": entry.pattern,
                    "insight": entry.insight,
                    "recommendation": entry.recommendation,
                    "operation_type": entry.operation_type,
                    "confidence": round(entry.confidence_score, 2)
                }
                for entry in distilled_entries
            ]
        }
        
    except Exception as e:
        logger.error(f"Error in knowledge distillation: {e}")
        raise HTTPException(status_code=500, detail=f"Distillation failed: {str(e)}")


@api_router.get("/llm/knowledge-base")
async def get_knowledge_base(limit: int = 20, operation_type: Optional[str] = None):
    """
    Get distilled knowledge entries from the knowledge base.
    Can filter by operation_type.
    """
    try:
        query = {}
        if operation_type:
            query["operation_type"] = operation_type
        
        entries = await db.llm_knowledge_base.find(query).sort("timestamp", -1).limit(limit).to_list(limit)
        
        total_count = await db.llm_knowledge_base.count_documents(query)
        
        return {
            "success": True,
            "total_count": total_count,
            "entries": [
                {
                    "distillation_id": entry.get("distillation_id"),
                    "pattern": entry.get("pattern"),
                    "insight": entry.get("insight"),
                    "recommendation": entry.get("recommendation"),
                    "operation_type": entry.get("operation_type"),
                    "confidence_score": entry.get("confidence_score"),
                    "timestamp": entry.get("timestamp"),
                    "source_count": len(entry.get("source_feedback_ids", []))
                }
                for entry in entries
            ]
        }
        
    except Exception as e:
        logger.error(f"Error fetching knowledge base: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/audit")
async def get_performance_audit():
    """
    Generate comprehensive performance audit report.
    Measures accuracy, latency, and improvement per optimization cycle.
    Returns trends and performance history.
    """
    try:
        from llm_evaluator import generate_audit_report
        
        # Fetch all feedback history
        feedback_history = await db.llm_feedback.find().sort("timestamp", -1).to_list(None)
        
        # Fetch performance metrics
        performance_history = await db.llm_performance.find().sort("timestamp", -1).to_list(None)
        
        # Fetch optimization events
        optimization_events = await db.llm_optimization_events.find().sort("timestamp", -1).to_list(None)
        
        # Generate audit report
        logger.info("Generating LLM performance audit report")
        report = generate_audit_report(feedback_history, performance_history, optimization_events)
        
        # Calculate distillation coverage
        total_feedback = len(feedback_history)
        high_rated_feedback = len([f for f in feedback_history if f.get("accuracy_score", 0) >= 4.0])
        distilled_entries = await db.llm_knowledge_base.count_documents({})
        
        report["distillation_coverage"] = {
            "total_feedback": total_feedback,
            "high_rated_feedback": high_rated_feedback,
            "distilled_entries": distilled_entries,
            "coverage_percentage": round((high_rated_feedback / total_feedback * 100), 1) if total_feedback > 0 else 0
        }
        
        return {
            "success": True,
            "audit_report": report,
            "timestamp": report.get("timestamp")
        }
        
    except Exception as e:
        logger.error(f"Error generating audit report: {e}")
        raise HTTPException(status_code=500, detail=f"Audit generation failed: {str(e)}")


@api_router.post("/llm/auto-distill-check")
async def check_auto_distill():
    """
    Check if auto-distillation should be triggered.
    Triggers when:
    - Total feedback count is multiple of 50
    - At least 10 high-rated feedback entries exist
    
    Returns distillation status and triggers if needed.
    """
    try:
        # Get feedback count
        total_feedback = await db.llm_feedback.count_documents({})
        high_rated_count = await db.llm_feedback.count_documents({"accuracy_score": {"$gte": 4.0}})
        
        # Get last distillation timestamp
        last_distillation = await db.llm_knowledge_base.find_one({}, sort=[("timestamp", -1)])
        last_distill_time = last_distillation.get("timestamp") if last_distillation else None
        
        should_trigger = False
        reason = ""
        
        # Trigger conditions
        if total_feedback > 0 and total_feedback % 50 == 0 and high_rated_count >= 10:
            should_trigger = True
            reason = f"Auto-trigger: {total_feedback} feedback entries reached (every 50), {high_rated_count} high-rated available"
        elif high_rated_count >= 20:
            should_trigger = True
            reason = f"Auto-trigger: {high_rated_count} high-rated feedback accumulated"
        
        # If should trigger, run distillation
        if should_trigger:
            logger.info(f"Auto-distillation triggered: {reason}")
            
            # Call distill endpoint internally
            from llm_evaluator import distill_from_feedback
            
            high_rated_feedback = await db.llm_feedback.find({
                "accuracy_score": {"$gte": 4.0}
            }).sort("timestamp", -1).limit(100).to_list(100)
            
            api_key = os.environ.get('EMERGENT_LLM_KEY')
            distilled_entries = await distill_from_feedback(high_rated_feedback, api_key)
            
            if distilled_entries:
                distilled_dicts = [entry.to_dict() for entry in distilled_entries]
                await db.llm_knowledge_base.insert_many(distilled_dicts)
                
                # Trim to 100
                total_count = await db.llm_knowledge_base.count_documents({})
                if total_count > 100:
                    entries_to_delete = await db.llm_knowledge_base.find().sort("timestamp", 1).limit(total_count - 100).to_list(total_count - 100)
                    ids_to_delete = [entry["_id"] for entry in entries_to_delete]
                    await db.llm_knowledge_base.delete_many({"_id": {"$in": ids_to_delete}})
                
                return {
                    "success": True,
                    "auto_triggered": True,
                    "reason": reason,
                    "distilled_count": len(distilled_entries),
                    "message": "Auto-distillation completed successfully"
                }
        
        return {
            "success": True,
            "auto_triggered": False,
            "total_feedback": total_feedback,
            "high_rated_count": high_rated_count,
            "last_distillation": last_distill_time,
            "message": "Auto-distillation conditions not met"
        }
        
    except Exception as e:
        logger.error(f"Error in auto-distill check: {e}")
        raise HTTPException(status_code=500, detail=str(e))



# ====================
# Predictive Trend Analysis & LLM Forecasting (Step 16)
# ====================

class ForecastRequest(BaseModel):
    """Request parameters for forecast generation"""
    timeframes: List[int] = Field(default=[7, 30, 90], description="Forecast timeframes in days")
    include_narrative: bool = Field(default=True, description="Include LLM narrative")

@api_router.post("/llm/forecast")
async def generate_forecast(request: ForecastRequest = ForecastRequest()):
    """
    Generate predictive trend analysis and LLM-powered forecasts.
    
    Analyzes historical data from:
    - training_metrics (accuracy trends)
    - model_evaluations (win rate trends)
    - llm_performance (latency trends)
    - llm_knowledge_base (distilled insights)
    - Audit history
    
    Returns forecasts for 7, 30, and 90 days with:
    - Predicted metrics (accuracy, win_rate, latency)
    - Trend direction (improving/stable/declining)
    - Confidence scores
    - LLM-generated strategic recommendations
    """
    try:
        from llm_evaluator import generate_forecast_report, generate_audit_report
        
        # Fetch historical data
        logger.info("Fetching historical data for forecast generation...")
        
        # Training metrics (last 100)
        training_data = await db.training_metrics.find().sort("timestamp", -1).limit(100).to_list(100)
        
        # Evaluation results (last 50)
        evaluation_data = await db.model_evaluations.find().sort("timestamp", -1).limit(50).to_list(50)
        
        # LLM performance metrics (last 100)
        performance_data = await db.llm_performance.find().sort("timestamp", -1).limit(100).to_list(100)
        
        # Distilled knowledge
        distilled_knowledge = await db.llm_knowledge_base.find().sort("timestamp", -1).limit(20).to_list(20)
        
        # Get audit history for context
        feedback_history = await db.llm_feedback.find().sort("timestamp", -1).limit(100).to_list(100)
        optimization_events = await db.llm_optimization_events.find().sort("timestamp", -1).limit(20).to_list(20)
        
        audit_report = generate_audit_report(
            feedback_history,
            performance_data,
            optimization_events
        )
        
        # Get API key
        api_key = os.environ.get('EMERGENT_LLM_KEY')
        if not api_key:
            raise HTTPException(status_code=500, detail="EMERGENT_LLM_KEY not configured")
        
        # Generate forecast
        logger.info(f"Generating forecast for timeframes: {request.timeframes}")
        
        forecast = await generate_forecast_report(
            training_data=training_data,
            evaluation_data=evaluation_data,
            performance_data=performance_data,
            distilled_knowledge=distilled_knowledge,
            audit_history=audit_report,
            llm_api_key=api_key,
            timeframes=request.timeframes
        )
        
        # Build response
        response_data = {
            "success": True,
            "timestamp": forecast.timestamp,
            "forecasts": {},
            "overall_confidence": forecast.overall_confidence,
            "data_sufficiency": forecast.data_sufficiency,
            "strategic_recommendations": forecast.strategic_recommendations
        }
        
        # Add forecast narrative if requested
        if request.include_narrative:
            response_data["forecast_narrative"] = forecast.forecast_narrative
        
        # Format forecasts by timeframe
        for timeframe_str, metrics in forecast.timeframes.items():
            timeframe_data = {}
            for metric_name, forecast_result in metrics.items():
                if forecast_result:
                    timeframe_data[metric_name] = {
                        "current_value": forecast_result.current_value,
                        "predicted_value": forecast_result.predicted_value,
                        "change_percent": forecast_result.change_percent,
                        "trend_direction": forecast_result.trend_direction,
                        "confidence": forecast_result.confidence
                    }
            response_data["forecasts"][f"{timeframe_str}_days"] = timeframe_data
        
        logger.info(f"Forecast generated successfully with {forecast.overall_confidence * 100:.1f}% confidence")
        
        return response_data
        
    except Exception as e:
        logger.error(f"Error generating forecast: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate forecast: {str(e)}")


# ====================
# Strategic Insight Fusion Endpoints (Step 18)
# ====================

class InsightFusionRequest(BaseModel):
    decision_id: Optional[str] = None  # Specific decision to explain
    limit: int = Field(default=10, ge=1, le=50)
    ranking: str = Field(default="confidence", pattern="^(confidence|recency|impact)$")


@api_router.post("/llm/insight-fusion")
async def generate_insight_fusion():
    """
    Generate comprehensive strategic insight fusion from all subsystems.
    
    Combines data from:
    - Step 17: Auto-tuning decisions (strategy_auto_tuning)
    - Step 16: Forecast results  
    - Step 15: Distilled knowledge (llm_knowledge_base)
    
    Generates cross-referenced insight bundles with:
    - Structured reasoning chains
    - Evidence sources with links
    - Confidence scores
    - Suggested actions
    - Alignment evaluation
    """
    try:
        from llm_evaluator import (
            generate_reasoning_chain,
            evaluate_decision_alignment,
            rank_strategic_insights,
            ReasoningChain
        )
        
        logger.info("Generating strategic insight fusion...")
        
        # Fetch data from all subsystems
        auto_tuning_history = await db.strategy_auto_tuning.find().sort("timestamp", -1).limit(20).to_list(20)
        distilled_knowledge = await db.llm_knowledge_base.find().sort("timestamp", -1).limit(20).to_list(20)
        
        # Get latest forecast data (if available)
        # For now, we'll fetch recent training and evaluation data
        training_data = await db.training_metrics.find().sort("timestamp", -1).limit(50).to_list(50)
        evaluation_data = await db.model_evaluations.find().sort("timestamp", -1).limit(20).to_list(20)
        
        # Build simple forecast context
        forecast_context = {}
        if evaluation_data:
            recent_eval = evaluation_data[0]
            forecast_context = {
                "recent_win_rate": recent_eval.get("challenger_win_rate", 0) * 100,
                "overall_confidence": 0.75
            }
        
        # Get API key
        api_key = os.environ.get('EMERGENT_LLM_KEY')
        if not api_key:
            raise HTTPException(status_code=500, detail="EMERGENT_LLM_KEY not configured")
        
        # Generate reasoning chains for recent auto-tuning decisions
        reasoning_chains = []
        
        for decision in auto_tuning_history[:5]:  # Process top 5 most recent
            try:
                # Prepare decision data
                decision_data = {
                    "tuning_id": decision.get("tuning_id"),
                    "type": "auto_tuning",
                    "trigger_reason": decision.get("trigger_reason"),
                    "parameters_adjusted": decision.get("parameters_adjusted"),
                    "confidence_score": decision.get("confidence_score"),
                    "expected_impact": decision.get("expected_impact")
                }
                
                # Generate reasoning chain
                reasoning = await generate_reasoning_chain(
                    decision_data=decision_data,
                    forecast_data=forecast_context,
                    distilled_knowledge=distilled_knowledge,
                    auto_tuning_history=auto_tuning_history,
                    llm_api_key=api_key
                )
                
                # Evaluate alignment
                alignment_eval = evaluate_decision_alignment(
                    decision_data=decision,
                    forecast_data=forecast_context
                )
                
                # Update reasoning with alignment info
                reasoning.alignment_status = "aligned" if alignment_eval["aligned"] else "deviation_detected"
                
                reasoning_chains.append(reasoning)
                
                # Store in MongoDB
                await db.llm_reasoning_log.insert_one(reasoning.to_dict())
                
            except Exception as e:
                logger.error(f"Error processing decision {decision.get('tuning_id')}: {e}")
                continue
        
        # Rank insights by confidence
        ranked_insights = rank_strategic_insights(reasoning_chains, ranking_criteria="confidence")
        
        # Build response
        insight_bundles = []
        for reasoning in ranked_insights[:10]:  # Return top 10
            insight_bundles.append({
                "reasoning_id": reasoning.reasoning_id,
                "decision_id": reasoning.decision_id,
                "timestamp": reasoning.timestamp,
                "decision_type": reasoning.decision_type,
                "reason_summary": reasoning.reason_summary,
                "evidence_sources": reasoning.evidence_sources,
                "reasoning_steps": reasoning.reasoning_steps,
                "suggested_action": reasoning.suggested_action,
                "confidence": reasoning.confidence,
                "alignment_status": reasoning.alignment_status,
                "impact_prediction": reasoning.impact_prediction
            })
        
        logger.info(f"Generated {len(insight_bundles)} insight bundles")
        
        return {
            "success": True,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "total_insights": len(insight_bundles),
            "insights": insight_bundles,
            "data_sources": {
                "auto_tuning_decisions": len(auto_tuning_history),
                "distilled_knowledge": len(distilled_knowledge),
                "training_metrics": len(training_data),
                "evaluations": len(evaluation_data)
            }
        }
        
    except Exception as e:
        logger.error(f"Error generating insight fusion: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate insight fusion: {str(e)}")


@api_router.get("/llm/reasoning-log")
async def get_reasoning_log(limit: int = 20, decision_type: Optional[str] = None):
    """
    Get stored reasoning chains from llm_reasoning_log collection.
    
    Query Parameters:
    - limit: Number of entries to return (default: 20, max: 100)
    - decision_type: Filter by decision type (auto_tuning, forecast_alert, etc.)
    """
    try:
        query = {}
        if decision_type:
            query["decision_type"] = decision_type
        
        reasoning_logs = await db.llm_reasoning_log.find(query).sort("timestamp", -1).limit(min(limit, 100)).to_list(limit)
        
        return {
            "success": True,
            "count": len(reasoning_logs),
            "reasoning_logs": reasoning_logs
        }
    except Exception as e:
        logger.error(f"Error retrieving reasoning log: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.post("/llm/explain-decision/{decision_id}")
async def explain_specific_decision(decision_id: str):
    """
    Generate on-demand explanation for a specific auto-tuning decision.
    
    Used by "Explain This Decision" button in UI.
    """
    try:
        from llm_evaluator import generate_reasoning_chain, evaluate_decision_alignment
        
        # Find the decision
        decision = await db.strategy_auto_tuning.find_one({"tuning_id": decision_id})
        
        if not decision:
            raise HTTPException(status_code=404, detail=f"Decision {decision_id} not found")
        
        # Get supporting data
        distilled_knowledge = await db.llm_knowledge_base.find().sort("timestamp", -1).limit(10).to_list(10)
        auto_tuning_history = await db.strategy_auto_tuning.find().sort("timestamp", -1).limit(10).to_list(10)
        
        # Get recent evaluation for forecast context
        recent_eval = await db.model_evaluations.find_one({}, sort=[("timestamp", -1)])
        forecast_context = {}
        if recent_eval:
            forecast_context = {
                "recent_win_rate": recent_eval.get("challenger_win_rate", 0) * 100,
                "overall_confidence": 0.75
            }
        
        # Get API key
        api_key = os.environ.get('EMERGENT_LLM_KEY')
        if not api_key:
            raise HTTPException(status_code=500, detail="EMERGENT_LLM_KEY not configured")
        
        # Prepare decision data
        decision_data = {
            "tuning_id": decision.get("tuning_id"),
            "type": "auto_tuning",
            "trigger_reason": decision.get("trigger_reason"),
            "parameters_adjusted": decision.get("parameters_adjusted"),
            "confidence_score": decision.get("confidence_score"),
            "expected_impact": decision.get("expected_impact")
        }
        
        # Generate reasoning
        reasoning = await generate_reasoning_chain(
            decision_data=decision_data,
            forecast_data=forecast_context,
            distilled_knowledge=distilled_knowledge,
            auto_tuning_history=auto_tuning_history,
            llm_api_key=api_key
        )
        
        # Evaluate alignment
        alignment_eval = evaluate_decision_alignment(
            decision_data=decision,
            forecast_data=forecast_context
        )
        
        # Store reasoning
        await db.llm_reasoning_log.insert_one(reasoning.to_dict())
        
        return {
            "success": True,
            "decision_id": decision_id,
            "reasoning": reasoning.to_dict(),
            "alignment_evaluation": alignment_eval
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error explaining decision {decision_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ====================
# Real-Time Adaptive Forecasting & Strategy Auto-Tuning Endpoints (Step 17)
# ====================

# Global state for auto-tuning system
auto_tuning_state = {
    "enabled": False,
    "last_run": None,
    "next_run": None,
    "interval_hours": 1,
    "deviation_threshold": 5.0,
    "total_tunings": 0,
    "last_decision": None
}

# Background task handle
auto_tuning_task = None


async def auto_tuning_background_task():
    """Background task that runs auto-forecasting and tuning every hour"""
    global auto_tuning_state
    
    while auto_tuning_state["enabled"]:
        try:
            logger.info("Running scheduled auto-forecast and tuning check...")
            
            # Update last run time
            auto_tuning_state["last_run"] = datetime.now(timezone.utc).isoformat()
            
            # Fetch recent data (lighter than full forecast)
            training_data = await db.training_metrics.find().sort("timestamp", -1).limit(20).to_list(20)
            evaluation_data = await db.model_evaluations.find().sort("timestamp", -1).limit(10).to_list(10)
            performance_data = await db.llm_performance.find().sort("timestamp", -1).limit(30).to_list(30)
            
            # Generate realtime forecast
            from llm_evaluator import generate_realtime_forecast, detect_performance_deviation, auto_tune_strategy, apply_auto_tuning
            
            forecast_update = await generate_realtime_forecast(
                training_data=training_data,
                evaluation_data=evaluation_data,
                performance_data=performance_data,
                timeframe_days=7
            )
            
            # Check if tuning is required
            if forecast_update.requires_tuning:
                logger.info(f"Deviation detected: {forecast_update.deviation_percent:.1f}% for {forecast_update.metric_name}")
                
                # Prepare deviation data
                deviating_metrics = [forecast_update.metric_name]
                deviations = {forecast_update.metric_name: forecast_update.deviation_percent}
                
                # Get current config
                current_config = {
                    "learning_rate": 0.001,  # Default, would be read from latest training
                    "num_simulations": 800,
                    "temperature": 1.0,
                    "c_puct": 1.5
                }
                
                # Get LLM config
                from llm_evaluator import LLMChessEvaluator
                llm_config = LLMChessEvaluator.get_global_config()
                
                # Generate auto-tuning decision
                decision = auto_tune_strategy(
                    deviating_metrics=deviating_metrics,
                    deviations=deviations,
                    current_config=current_config,
                    llm_config=llm_config
                )
                
                # Apply tuning if adjustments were made
                if decision.parameters_adjusted:
                    success = await apply_auto_tuning(
                        decision=decision,
                        db_collection=db.strategy_auto_tuning,
                        llm_evaluator=None  # Would pass actual instance in production
                    )
                    
                    if success:
                        auto_tuning_state["total_tunings"] += 1
                        auto_tuning_state["last_decision"] = decision.to_dict()
                        logger.info(f"Auto-tuning applied successfully: {decision.tuning_id}")
                    else:
                        logger.error("Failed to apply auto-tuning")
                else:
                    logger.info("No adjustments needed despite deviation")
            else:
                logger.info("No significant deviations detected. System stable.")
            
            # Calculate next run time
            from datetime import timedelta
            next_run_time = datetime.now(timezone.utc) + timedelta(hours=auto_tuning_state["interval_hours"])
            auto_tuning_state["next_run"] = next_run_time.isoformat()
            
            # Wait for next interval (1 hour = 3600 seconds)
            await asyncio.sleep(auto_tuning_state["interval_hours"] * 3600)
            
        except Exception as e:
            logger.error(f"Error in auto-tuning background task: {e}")
            await asyncio.sleep(300)  # Wait 5 minutes on error before retry


@api_router.post("/llm/auto-forecast")
async def trigger_auto_forecast(background_tasks: BackgroundTasks):
    """
    Manually trigger real-time forecast and auto-tuning check.
    
    This runs the same logic as the scheduled background task but can be
    triggered on-demand for testing or immediate response.
    """
    try:
        from llm_evaluator import generate_realtime_forecast, auto_tune_strategy, apply_auto_tuning
        
        # Fetch recent data
        training_data = await db.training_metrics.find().sort("timestamp", -1).limit(20).to_list(20)
        evaluation_data = await db.model_evaluations.find().sort("timestamp", -1).limit(10).to_list(10)
        performance_data = await db.llm_performance.find().sort("timestamp", -1).limit(30).to_list(30)
        
        # Generate realtime forecast
        forecast_update = await generate_realtime_forecast(
            training_data=training_data,
            evaluation_data=evaluation_data,
            performance_data=performance_data,
            timeframe_days=7
        )
        
        # Check for deviation
        tuning_applied = False
        decision_data = None
        
        if forecast_update.requires_tuning and forecast_update.deviation_percent >= auto_tuning_state["deviation_threshold"]:
            logger.info(f"Manual forecast: Deviation detected {forecast_update.deviation_percent:.1f}%")
            
            # Prepare for auto-tuning
            deviating_metrics = [forecast_update.metric_name]
            deviations = {forecast_update.metric_name: forecast_update.deviation_percent}
            
            current_config = {
                "learning_rate": 0.001,
                "num_simulations": 800,
                "temperature": 1.0,
                "c_puct": 1.5
            }
            
            from llm_evaluator import LLMChessEvaluator
            llm_config = LLMChessEvaluator.get_global_config()
            
            # Generate decision
            decision = auto_tune_strategy(
                deviating_metrics=deviating_metrics,
                deviations=deviations,
                current_config=current_config,
                llm_config=llm_config
            )
            
            # Apply if adjustments exist
            if decision.parameters_adjusted:
                success = await apply_auto_tuning(
                    decision=decision,
                    db_collection=db.strategy_auto_tuning,
                    llm_evaluator=None
                )
                
                tuning_applied = success
                decision_data = decision.to_dict()
                
                if success:
                    auto_tuning_state["last_decision"] = decision_data
                    auto_tuning_state["total_tunings"] += 1
        
        return {
            "success": True,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "forecast_update": forecast_update.to_dict(),
            "tuning_applied": tuning_applied,
            "tuning_decision": decision_data,
            "message": "Auto-tuning applied" if tuning_applied else "No tuning needed"
        }
        
    except Exception as e:
        logger.error(f"Error in auto-forecast: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/strategy/auto-tune/status")
async def get_auto_tuning_status():
    """Get current status of auto-tuning system"""
    return {
        "success": True,
        "enabled": auto_tuning_state["enabled"],
        "last_run": auto_tuning_state["last_run"],
        "next_run": auto_tuning_state["next_run"],
        "interval_hours": auto_tuning_state["interval_hours"],
        "deviation_threshold": auto_tuning_state["deviation_threshold"],
        "total_tunings": auto_tuning_state["total_tunings"],
        "last_decision": auto_tuning_state["last_decision"]
    }


@api_router.post("/strategy/auto-tune/toggle")
async def toggle_auto_tuning(enable: bool = True, background_tasks: BackgroundTasks = None):
    """
    Enable or disable automatic strategy tuning.
    
    When enabled, runs forecasting and tuning checks every hour.
    """
    global auto_tuning_task, auto_tuning_state
    
    try:
        if enable and not auto_tuning_state["enabled"]:
            # Start auto-tuning
            auto_tuning_state["enabled"] = True
            auto_tuning_state["last_run"] = None
            
            from datetime import timedelta
            next_run_time = datetime.now(timezone.utc) + timedelta(hours=auto_tuning_state["interval_hours"])
            auto_tuning_state["next_run"] = next_run_time.isoformat()
            
            # Start background task
            auto_tuning_task = asyncio.create_task(auto_tuning_background_task())
            
            logger.info("Auto-tuning system enabled")
            
            return {
                "success": True,
                "message": "Auto-tuning enabled",
                "status": auto_tuning_state
            }
            
        elif not enable and auto_tuning_state["enabled"]:
            # Stop auto-tuning
            auto_tuning_state["enabled"] = False
            auto_tuning_state["next_run"] = None
            
            # Cancel background task
            if auto_tuning_task and not auto_tuning_task.done():
                auto_tuning_task.cancel()
            
            logger.info("Auto-tuning system disabled")
            
            return {
                "success": True,
                "message": "Auto-tuning disabled",
                "status": auto_tuning_state
            }
        
        else:
            return {
                "success": True,
                "message": f"Auto-tuning already {'enabled' if enable else 'disabled'}",
                "status": auto_tuning_state
            }
            
    except Exception as e:
        logger.error(f"Error toggling auto-tuning: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/strategy/auto-tune/history")
async def get_auto_tuning_history(limit: int = 20):
    """
    Get history of automatic strategy tuning decisions.
    
    Returns timeline of all tuning events with parameters adjusted,
    reasoning, and outcomes.
    """
    try:
        tuning_history = await db.strategy_auto_tuning.find().sort("timestamp", -1).limit(limit).to_list(limit)
        
        return {
            "success": True,
            "count": len(tuning_history),
            "history": tuning_history
        }
        
    except Exception as e:
        logger.error(f"Error fetching auto-tuning history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.post("/strategy/auto-tune/config")
async def update_auto_tuning_config(
    interval_hours: Optional[float] = None,
    deviation_threshold: Optional[float] = None
):
    """
    Update auto-tuning configuration.
    
    Args:
        interval_hours: Hours between auto-tuning checks (default: 1)
        deviation_threshold: Deviation percentage to trigger tuning (default: 5.0)
    """
    global auto_tuning_state
    
    try:
        if interval_hours is not None:
            if interval_hours < 0.1 or interval_hours > 24:
                raise HTTPException(status_code=400, detail="Interval must be between 0.1 and 24 hours")
            auto_tuning_state["interval_hours"] = interval_hours
        
        if deviation_threshold is not None:
            if deviation_threshold < 1 or deviation_threshold > 50:
                raise HTTPException(status_code=400, detail="Threshold must be between 1% and 50%")
            auto_tuning_state["deviation_threshold"] = deviation_threshold
        
        return {
            "success": True,
            "message": "Auto-tuning configuration updated",
            "config": {
                "interval_hours": auto_tuning_state["interval_hours"],
                "deviation_threshold": auto_tuning_state["deviation_threshold"]
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating auto-tuning config: {e}")
        raise HTTPException(status_code=500, detail=str(e))



@api_router.get("/llm/forecast/history")
async def get_forecast_history(limit: int = 10):
    """
    Get historical forecast records (if we want to store them).
    For now, returns empty as we generate on-demand.
    """
    return {
        "success": True,
        "message": "Forecasts are generated on-demand. Historical forecast storage not yet implemented.",
        "forecasts": []
    }



# ====================
# Step 19: Multi-Agent Collaboration & Meta-Learning
# ====================

from llm_evaluator import MultiAgentOrchestrator, get_orchestrator

class MetaCollaborationRequest(BaseModel):
    task: str
    context: Optional[Dict[str, Any]] = None
    apply_meta_learning: bool = False

class MetaKnowledgeApplication(BaseModel):
    insight_ids: Optional[List[str]] = None
    apply_all_high_confidence: bool = False

@api_router.post("/llm/meta-collaboration")
async def run_meta_collaboration(request: MetaCollaborationRequest):
    """
    Run multi-agent collaborative reasoning session
    Orchestrates Strategy, Evaluation, Forecast, and Adaptation agents
    """
    try:
        logger.info(f"Starting meta-collaboration for task: {request.task}")
        
        # Get orchestrator
        orchestrator = get_orchestrator()
        
        # Run multi-agent reasoning
        consensus = await orchestrator.run_multi_agent_reasoning(
            task=request.task,
            context=request.context
        )
        
        # Store session in MongoDB
        session_data = {
            "session_id": consensus.session_id,
            "task": request.task,
            "context": request.context,
            "consensus": consensus.to_dict(),
            "timestamp": consensus.timestamp,
            "created_at": datetime.now(timezone.utc)
        }
        
        await db.llm_meta_sessions.insert_one(session_data)
        
        # Apply meta-learning if requested
        if request.apply_meta_learning:
            orchestrator.update_meta_knowledge(consensus)
            
            # Store meta-knowledge in MongoDB
            for knowledge in orchestrator.meta_knowledge_base[-len(consensus.meta_insights):]:
                await db.llm_meta_knowledge.insert_one(knowledge.to_dict())
        
        logger.info(f"Meta-collaboration complete. Consensus: {consensus.consensus_reached}")
        
        return {
            "success": True,
            "consensus": consensus.to_dict(),
            "message": "Multi-agent reasoning completed",
            "session_id": consensus.session_id
        }
        
    except Exception as e:
        logger.error(f"Meta-collaboration error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/meta-collaboration/sessions")
async def get_meta_sessions(limit: int = 20, skip: int = 0):
    """Get recent multi-agent collaboration sessions"""
    try:
        sessions = await db.llm_meta_sessions.find(
            {},
            {"_id": 0}
        ).sort("created_at", -1).skip(skip).limit(limit).to_list(length=limit)
        
        total = await db.llm_meta_sessions.count_documents({})
        
        return {
            "success": True,
            "sessions": sessions,
            "total": total,
            "limit": limit,
            "skip": skip
        }
        
    except Exception as e:
        logger.error(f"Error fetching meta sessions: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/meta-collaboration/session/{session_id}")
async def get_meta_session_detail(session_id: str):
    """Get detailed transcript of a specific meta-collaboration session"""
    try:
        session = await db.llm_meta_sessions.find_one(
            {"session_id": session_id},
            {"_id": 0}
        )
        
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        return {
            "success": True,
            "session": session
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching session detail: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/meta-knowledge")
async def get_meta_knowledge(
    category: Optional[str] = None,
    min_confidence: float = 0.0,
    limit: int = 50
):
    """Get accumulated meta-knowledge insights"""
    try:
        query = {}
        if category:
            query["category"] = category
        if min_confidence > 0:
            query["confidence"] = {"$gte": min_confidence}
        
        knowledge = await db.llm_meta_knowledge.find(
            query,
            {"_id": 0}
        ).sort("confidence", -1).limit(limit).to_list(length=limit)
        
        # Get summary from orchestrator
        orchestrator = get_orchestrator()
        summary = orchestrator.get_meta_knowledge_summary()
        
        return {
            "success": True,
            "knowledge": knowledge,
            "summary": summary,
            "filters": {
                "category": category,
                "min_confidence": min_confidence
            }
        }
        
    except Exception as e:
        logger.error(f"Error fetching meta-knowledge: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.post("/llm/meta-knowledge/apply")
async def apply_meta_knowledge(request: MetaKnowledgeApplication):
    """
    Apply meta-knowledge to system heuristics
    Updates system behavior based on learned insights
    """
    try:
        orchestrator = get_orchestrator()
        
        if request.apply_all_high_confidence:
            # Apply all high-confidence insights (>0.8)
            knowledge = await db.llm_meta_knowledge.find(
                {"confidence": {"$gte": 0.8}},
                {"_id": 0}
            ).to_list(length=100)
        elif request.insight_ids:
            # Apply specific insights
            knowledge = await db.llm_meta_knowledge.find(
                {"knowledge_id": {"$in": request.insight_ids}},
                {"_id": 0}
            ).to_list(length=100)
        else:
            raise HTTPException(status_code=400, detail="Must specify insight_ids or apply_all_high_confidence")
        
        applied_count = 0
        for k in knowledge:
            # Update validation count
            await db.llm_meta_knowledge.update_one(
                {"knowledge_id": k["knowledge_id"]},
                {"$inc": {"validation_count": 1}}
            )
            applied_count += 1
        
        logger.info(f"Applied {applied_count} meta-knowledge insights")
        
        return {
            "success": True,
            "applied_count": applied_count,
            "message": f"Successfully applied {applied_count} meta-knowledge insights"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error applying meta-knowledge: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/meta-learning/metrics")
async def get_meta_learning_metrics():
    """Get meta-learning progress metrics"""
    try:
        # Get total sessions
        total_sessions = await db.llm_meta_sessions.count_documents({})
        
        # Get consensus rate
        consensus_sessions = await db.llm_meta_sessions.count_documents(
            {"consensus.consensus_reached": True}
        )
        consensus_rate = (consensus_sessions / total_sessions * 100) if total_sessions > 0 else 0
        
        # Get average confidence over time
        sessions = await db.llm_meta_sessions.find(
            {},
            {"consensus.confidence_score": 1, "consensus.consensus_level": 1, "timestamp": 1, "_id": 0}
        ).sort("timestamp", -1).limit(50).to_list(length=50)
        
        avg_confidence = sum(s.get("consensus", {}).get("confidence_score", 0) for s in sessions) / len(sessions) if sessions else 0
        avg_consensus_level = sum(s.get("consensus", {}).get("consensus_level", 0) for s in sessions) / len(sessions) if sessions else 0
        
        # Get knowledge distribution
        knowledge_by_category = await db.llm_meta_knowledge.aggregate([
            {"$group": {"_id": "$category", "count": {"$sum": 1}, "avg_confidence": {"$avg": "$confidence"}}}
        ]).to_list(length=10)
        
        # Get orchestrator summary
        orchestrator = get_orchestrator()
        knowledge_summary = orchestrator.get_meta_knowledge_summary()
        
        return {
            "success": True,
            "metrics": {
                "total_sessions": total_sessions,
                "consensus_rate": round(consensus_rate, 1),
                "avg_confidence": round(avg_confidence, 3),
                "avg_consensus_level": round(avg_consensus_level, 3),
                "total_insights": knowledge_summary["total_insights"],
                "knowledge_by_category": knowledge_by_category,
                "recent_trend": {
                    "last_10_sessions": sessions[:10],
                    "confidence_improving": _calculate_trend([s.get("consensus", {}).get("confidence_score", 0) for s in sessions[:10]])
                }
            }
        }
        
    except Exception as e:
        logger.error(f"Error fetching meta-learning metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))


def _calculate_trend(values: List[float]) -> bool:
    """Calculate if trend is improving (simple linear regression)"""
    if len(values) < 2:
        return False
    # Simple check: is average of first half less than average of second half?
    mid = len(values) // 2
    first_half_avg = sum(values[:mid]) / mid if mid > 0 else 0
    second_half_avg = sum(values[mid:]) / (len(values) - mid) if len(values) > mid else 0
    return second_half_avg > first_half_avg


# ====================
# Device Info
# ====================

@api_router.get("/device/info")
async def get_device_info():
    """Get device information"""
    from device_manager import device_manager
    
    return {
        "success": True,
        "device_type": str(device_manager.device),
        "device_name": device_manager.device_name,
        "is_gpu": device_manager.device.type == "cuda"
    }

# Include the router in the main app


# ====================
# Step 20: Cognitive Consensus Engine & Trust Calibration Layer
# ====================

from llm_evaluator import (
    AgentTrustProfile,
    WeightedConsensusResult,
    compute_agent_trust_score,
    derive_weighted_consensus,
    update_trust_profile,
    recalibrate_all_trust_profiles,
    get_trust_profiles,
    set_trust_profiles
)

class ConsensusRequest(BaseModel):
    """Request for trust-calibrated consensus computation"""
    task: str
    context: Optional[Dict] = None
    confidence_threshold: float = Field(default=0.90, ge=0.5, le=1.0)

@api_router.post("/llm/consensus/derive")
async def derive_trust_consensus(request: ConsensusRequest):
    """
    Run trust-calibrated consensus computation.
    
    Performs multi-agent reasoning with trust-weighted decision scoring.
    """
    try:
        logger.info(f"Starting trust-calibrated consensus for task: {request.task}")
        
        # Get orchestrator
        orchestrator = get_orchestrator()
        
        # Run multi-agent reasoning to get agent messages
        consensus = await orchestrator.run_multi_agent_reasoning(request.task, request.context)
        
        # Get agent messages from session history
        session = orchestrator.session_history[-1] if orchestrator.session_history else None
        if not session:
            raise HTTPException(status_code=500, detail="No session data available")
        
        agent_messages = []
        for msg_dict in session["messages"]:
            from llm_evaluator import AgentMessage
            agent_messages.append(AgentMessage(
                agent_name=msg_dict["agent_name"],
                message_type=msg_dict["message_type"],
                content=msg_dict["content"],
                confidence=msg_dict["confidence"],
                reasoning_chain=msg_dict["reasoning_chain"],
                timestamp=msg_dict["timestamp"],
                metadata=msg_dict.get("metadata")
            ))
        
        # Get trust profiles
        trust_profiles = get_trust_profiles()
        
        # Derive weighted consensus
        weighted_consensus = derive_weighted_consensus(
            agent_messages,
            trust_profiles,
            request.confidence_threshold
        )
        
        # Store consensus in database
        await db.llm_consensus_history.insert_one({
            **weighted_consensus.to_dict(),
            "task": request.task,
            "context": request.context,
            "source": "trust_calibration"
        })
        
        # Update trust profiles based on consensus
        for agent_name, profile in trust_profiles.items():
            # Find agent's message
            agent_msg = next((m for m in agent_messages if m.agent_name == agent_name), None)
            if agent_msg:
                # Create performance entry
                performance_entry = {
                    "confidence": agent_msg.confidence,
                    "outcome_correct": weighted_consensus.consensus_reached,
                    "agreed_with_consensus": True,  # Simplified
                    "response_time": 5.0,
                    "timestamp": datetime.now(timezone.utc).isoformat()
                }
                
                # Update profile
                updated_profile = update_trust_profile(
                    agent_name,
                    profile,
                    performance_entry
                )
                trust_profiles[agent_name] = updated_profile
        
        # Save updated profiles
        set_trust_profiles(trust_profiles)
        
        # Save profiles to database
        for agent_name, profile in trust_profiles.items():
            await db.llm_agent_trust_profiles.replace_one(
                {"agent_name": agent_name},
                profile.to_dict(),
                upsert=True
            )
        
        logger.info(f"Trust-calibrated consensus complete: {weighted_consensus.consensus_reached}")
        
        return {
            "success": True,
            "message": "Trust-calibrated consensus computed",
            "consensus": weighted_consensus.to_dict(),
            "original_consensus": consensus.to_dict()
        }
        
    except Exception as e:
        logger.error(f"Trust consensus error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/consensus/trust-scores")
async def get_current_trust_scores():
    """
    Returns current trust scores for all agents.
    
    Includes:
    - Trust score (0.0-1.0)
    - Performance metrics
    - Historical stats
    """
    try:
        # Get trust profiles from database
        profiles_docs = await db.llm_agent_trust_profiles.find({}, {"_id": 0}).to_list(10)
        
        if not profiles_docs:
            # Initialize from global if DB is empty
            trust_profiles = get_trust_profiles()
            profiles_docs = [p.to_dict() for p in trust_profiles.values()]
        
        # Calculate aggregate stats
        if profiles_docs:
            avg_trust = sum(p.get("trust_score", 0.7) for p in profiles_docs) / len(profiles_docs)
            highest_trust = max(profiles_docs, key=lambda p: p.get("trust_score", 0))
            lowest_trust = min(profiles_docs, key=lambda p: p.get("trust_score", 0))
        else:
            avg_trust = 0.75
            highest_trust = None
            lowest_trust = None
        
        return {
            "success": True,
            "trust_profiles": profiles_docs,
            "summary": {
                "average_trust": round(avg_trust, 3),
                "highest_trust_agent": highest_trust.get("agent_name") if highest_trust else None,
                "lowest_trust_agent": lowest_trust.get("agent_name") if lowest_trust else None,
                "total_agents": len(profiles_docs)
            },
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error fetching trust scores: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.post("/llm/consensus/recalibrate")
async def recalibrate_trust_scores():
    """
    Force trust score recalibration across recent sessions.
    
    Recomputes all agent trust scores using:
    - Recent consensus history
    - Performance data
    - Exponential decay (0.85 retention)
    """
    try:
        logger.info("Starting trust profile recalibration...")
        
        # Get current trust profiles
        profiles_docs = await db.llm_agent_trust_profiles.find({}, {"_id": 0}).to_list(10)
        
        if not profiles_docs:
            # Initialize default profiles
            trust_profiles = get_trust_profiles()
        else:
            # Convert to AgentTrustProfile objects
            trust_profiles = {}
            for doc in profiles_docs:
                trust_profiles[doc["agent_name"]] = AgentTrustProfile.from_dict(doc)
        
        # Get recent consensus history
        consensus_history = await db.llm_consensus_history.find(
            {},
            {"_id": 0}
        ).sort("timestamp", -1).limit(30).to_list(30)
        
        # Also get meta-collaboration sessions
        meta_sessions = await db.llm_meta_sessions.find(
            {},
            {"_id": 0}
        ).sort("timestamp", -1).limit(30).to_list(30)
        
        # Merge histories
        all_history = consensus_history + meta_sessions
        
        # Recalibrate
        updated_profiles = await recalibrate_all_trust_profiles(
            trust_profiles,
            all_history,
            decay_factor=0.85
        )
        
        # Save to database
        updates_count = 0
        for agent_name, profile in updated_profiles.items():
            result = await db.llm_agent_trust_profiles.replace_one(
                {"agent_name": agent_name},
                profile.to_dict(),
                upsert=True
            )
            if result.modified_count > 0 or result.upserted_id:
                updates_count += 1
        
        # Update global profiles
        set_trust_profiles(updated_profiles)
        
        # Calculate changes
        changes = []
        for agent_name in updated_profiles:
            old_score = trust_profiles[agent_name].trust_score if agent_name in trust_profiles else 0.75
            new_score = updated_profiles[agent_name].trust_score
            change = new_score - old_score
            
            changes.append({
                "agent": agent_name,
                "old_score": round(old_score, 3),
                "new_score": round(new_score, 3),
                "change": round(change, 3)
            })
        
        logger.info(f"Recalibration complete. Updated {updates_count} profiles.")
        
        return {
            "success": True,
            "message": f"Recalibrated {updates_count} agent trust profiles",
            "profiles_updated": updates_count,
            "changes": changes,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error recalibrating trust scores: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/consensus/history")
async def get_consensus_history(limit: int = 20):
    """
    Get consensus computation history with reliability outcomes.
    
    Returns logged consensus computations sorted by timestamp.
    """
    try:
        history = await db.llm_consensus_history.find(
            {},
            {"_id": 0}
        ).sort("timestamp", -1).limit(limit).to_list(limit)
        
        # Calculate aggregate stats
        if history:
            total_consensus = len(history)
            reached_consensus = sum(1 for h in history if h.get("consensus_reached", False))
            consensus_rate = (reached_consensus / total_consensus * 100) if total_consensus > 0 else 0
            
            avg_confidence = sum(h.get("weighted_confidence", 0) for h in history) / total_consensus
            
            stability_counts = {}
            for h in history:
                stability = h.get("stability_index", "medium")
                stability_counts[stability] = stability_counts.get(stability, 0) + 1
        else:
            consensus_rate = 0
            avg_confidence = 0
            stability_counts = {}
        
        return {
            "success": True,
            "history": history,
            "summary": {
                "total_consensus_computed": len(history),
                "consensus_rate": round(consensus_rate, 1),
                "avg_weighted_confidence": round(avg_confidence, 3),
                "stability_distribution": stability_counts
            }
        }
        
    except Exception as e:
        logger.error(f"Error fetching consensus history: {e}")
        raise HTTPException(status_code=500, detail=str(e))




# ====================
# Step 21: Meta-Agent Arbitration & Dynamic Trust Threshold System
# ====================

from llm_evaluator import (
    ArbitrationResult,
    DynamicThreshold,
    ConflictAnalysis,
    calculate_dynamic_threshold,
    analyze_conflict_context,
    invoke_meta_arbitrator,
    update_arbitration_history
)


class ArbitrationRequest(BaseModel):
    """Request for meta-agent arbitration"""
    task: str
    context: Optional[Dict] = None
    confidence_threshold: float = Field(default=0.90, ge=0.5, le=1.0)
    task_complexity: float = Field(default=0.5, ge=0.0, le=1.0)
    task_category: str = Field(default="general")
    force_arbitration: bool = Field(default=False)


@api_router.post("/llm/arbitration/resolve")
async def resolve_with_arbitration(request: ArbitrationRequest):
    """
    Trigger meta-agent arbitration process.
    
    This endpoint:
    1. Runs multi-agent consensus first
    2. Checks if arbitration is needed (confidence < threshold OR high disagreement)
    3. If needed, invokes meta-arbitrator to resolve conflicts
    4. Stores arbitration results in MongoDB
    5. Returns revised consensus with confidence delta
    
    Arbitration Triggers:
    - Consensus confidence < 90%
    - Agent disagreement ≥ 15%
    - Trust variance > 0.12
    - Manual force_arbitration flag
    """
    try:
        logger.info(f"Arbitration request for task: {request.task[:100]}")
        
        # Step 1: Run multi-agent consensus
        orchestrator = get_orchestrator()
        consensus = await orchestrator.run_multi_agent_reasoning(request.task, request.context)
        
        # Get agent messages from session
        session = orchestrator.session_history[-1] if orchestrator.session_history else None
        if not session:
            raise HTTPException(status_code=500, detail="No session data available")
        
        agent_messages = []
        for msg_dict in session["messages"]:
            from llm_evaluator import AgentMessage
            agent_messages.append(AgentMessage(
                agent_name=msg_dict["agent_name"],
                message_type=msg_dict["message_type"],
                content=msg_dict["content"],
                confidence=msg_dict["confidence"],
                reasoning_chain=msg_dict["reasoning_chain"],
                timestamp=msg_dict["timestamp"],
                metadata=msg_dict.get("metadata")
            ))
        
        # Get trust profiles
        trust_profiles = get_trust_profiles()
        
        # Step 2: Calculate dynamic threshold
        dynamic_threshold = calculate_dynamic_threshold(
            trust_profiles=trust_profiles,
            task_complexity=request.task_complexity,
            task_category=request.task_category,
            base_threshold=request.confidence_threshold
        )
        
        # Store threshold in database
        await db.llm_dynamic_threshold.insert_one(dynamic_threshold.to_dict())
        
        # Step 3: Derive weighted consensus
        weighted_consensus = derive_weighted_consensus(
            agent_messages,
            trust_profiles,
            dynamic_threshold.current_threshold
        )
        
        # Step 4: Analyze conflict context
        conflict_analysis = analyze_conflict_context(
            agent_messages,
            trust_profiles,
            weighted_consensus
        )
        
        # Step 5: Determine if arbitration is needed
        needs_arbitration = (
            request.force_arbitration or
            not weighted_consensus.consensus_reached or
            conflict_analysis.conflict_resolution_needed or
            weighted_consensus.weighted_confidence < dynamic_threshold.current_threshold
        )
        
        arbitration_result = None
        
        if needs_arbitration:
            logger.info(f"Arbitration triggered: consensus={weighted_consensus.consensus_reached}, confidence={weighted_consensus.weighted_confidence:.3f}, threshold={dynamic_threshold.current_threshold:.3f}")
            
            # Step 6: Invoke meta-arbitrator
            api_key = os.environ.get('EMERGENT_LLM_KEY')
            if not api_key:
                raise HTTPException(status_code=500, detail="EMERGENT_LLM_KEY not configured")
            
            arbitration_result = await invoke_meta_arbitrator(
                agent_messages=agent_messages,
                trust_profiles=trust_profiles,
                original_consensus=weighted_consensus,
                conflict_analysis=conflict_analysis,
                llm_api_key=api_key,
                task_description=request.task
            )
            
            # Step 7: Store arbitration history
            arbitration_history_entry = update_arbitration_history(
                arbitration_result,
                weighted_consensus,
                conflict_analysis
            )
            
            await db.llm_arbitration_log.insert_one(arbitration_history_entry)
            
            # Update trust profiles based on arbitration
            # (In production, would analyze which agents aligned with arbitration outcome)
            for agent_name, profile in trust_profiles.items():
                await db.llm_agent_trust_profiles.replace_one(
                    {"agent_name": agent_name},
                    profile.to_dict(),
                    upsert=True
                )
            
            logger.info(f"Arbitration complete: {arbitration_result.arbitration_outcome}, confidence improved by {arbitration_result.confidence_delta:+.2%}")
        else:
            logger.info(f"No arbitration needed: consensus reached with {weighted_consensus.weighted_confidence:.2%} confidence")
        
        # Store weighted consensus
        await db.llm_consensus_history.insert_one({
            **weighted_consensus.to_dict(),
            "task": request.task,
            "context": request.context,
            "arbitration_triggered": needs_arbitration,
            "dynamic_threshold_used": dynamic_threshold.current_threshold,
            "source": "arbitration_system"
        })
        
        return {
            "success": True,
            "message": "Arbitration process completed" if needs_arbitration else "Consensus reached without arbitration",
            "arbitration_triggered": needs_arbitration,
            "consensus": weighted_consensus.to_dict(),
            "dynamic_threshold": dynamic_threshold.to_dict(),
            "conflict_analysis": conflict_analysis.to_dict(),
            "arbitration_result": arbitration_result.to_dict() if arbitration_result else None,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        logger.error(f"Arbitration resolution error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/arbitration/history")
async def get_arbitration_history(limit: int = 20):
    """
    Retrieve arbitration logs with confidence outcomes.
    
    Returns:
    - Arbitration session details
    - Confidence before/after metrics
    - Agents involved and divergence analysis
    - Resolution outcomes (Approved/Rejected/Reassessed)
    """
    try:
        # Get arbitration history
        history = await db.llm_arbitration_log.find(
            {},
            {"_id": 0}
        ).sort("timestamp", -1).limit(limit).to_list(limit)
        
        # Calculate summary statistics
        if history:
            total_arbitrations = len(history)
            avg_confidence_before = sum(h.get("confidence_before", 0) for h in history) / total_arbitrations
            avg_confidence_after = sum(h.get("confidence_after", 0) for h in history) / total_arbitrations
            avg_confidence_delta = sum(h.get("confidence_delta", 0) for h in history) / total_arbitrations
            avg_resolution_time = sum(h.get("resolution_time", 0) for h in history) / total_arbitrations
            
            # Count outcomes
            outcome_counts = {}
            for h in history:
                outcome = h.get("arbitration_outcome", "Unknown")
                outcome_counts[outcome] = outcome_counts.get(outcome, 0) + 1
            
            # Count trigger reasons
            trigger_counts = {}
            for h in history:
                trigger = h.get("trigger_reason", "Unknown")[:50]  # Truncate
                trigger_counts[trigger] = trigger_counts.get(trigger, 0) + 1
        else:
            avg_confidence_before = 0
            avg_confidence_after = 0
            avg_confidence_delta = 0
            avg_resolution_time = 0
            outcome_counts = {}
            trigger_counts = {}
        
        return {
            "success": True,
            "history": history,
            "summary": {
                "total_arbitrations": len(history),
                "avg_confidence_before": round(avg_confidence_before, 3),
                "avg_confidence_after": round(avg_confidence_after, 3),
                "avg_confidence_improvement": round(avg_confidence_delta, 3),
                "avg_resolution_time_seconds": round(avg_resolution_time, 2),
                "outcome_distribution": outcome_counts,
                "trigger_distribution": trigger_counts
            }
        }
        
    except Exception as e:
        logger.error(f"Error fetching arbitration history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/threshold/status")
async def get_dynamic_threshold_status():
    """
    Get current dynamic threshold parameters and metrics.
    
    Returns:
    - Current threshold value (80-95%)
    - Trust variance metrics
    - Task complexity ratings
    - Threshold adjustment history
    - Per-task-category thresholds
    """
    try:
        # Get most recent thresholds (one per task category)
        thresholds_by_category = {}
        categories = ["strategy", "evaluation", "forecasting", "general"]
        
        for category in categories:
            threshold_doc = await db.llm_dynamic_threshold.find_one(
                {"task_category": category},
                {"_id": 0},
                sort=[("timestamp", -1)]
            )
            
            if threshold_doc:
                thresholds_by_category[category] = threshold_doc
        
        # Get all recent thresholds for trend analysis
        recent_thresholds = await db.llm_dynamic_threshold.find(
            {},
            {"_id": 0}
        ).sort("timestamp", -1).limit(50).to_list(50)
        
        # Calculate overall statistics
        if recent_thresholds:
            avg_threshold = sum(t.get("current_threshold", 0.90) for t in recent_thresholds) / len(recent_thresholds)
            avg_trust_variance = sum(t.get("trust_variance", 0.05) for t in recent_thresholds) / len(recent_thresholds)
            avg_complexity = sum(t.get("complexity_rating", 0.5) for t in recent_thresholds) / len(recent_thresholds)
            
            # Calculate threshold range
            threshold_values = [t.get("current_threshold", 0.90) for t in recent_thresholds]
            min_threshold = min(threshold_values)
            max_threshold = max(threshold_values)
            
            # Build threshold trend (last 20)
            threshold_trend = [
                {
                    "timestamp": t.get("timestamp"),
                    "threshold": t.get("current_threshold"),
                    "task_category": t.get("task_category"),
                    "trust_variance": t.get("trust_variance")
                }
                for t in recent_thresholds[:20]
            ]
        else:
            # No data - return defaults
            avg_threshold = 0.90
            avg_trust_variance = 0.05
            avg_complexity = 0.5
            min_threshold = 0.80
            max_threshold = 0.95
            threshold_trend = []
        
        # Get current global trust variance
        trust_profiles = get_trust_profiles()
        if trust_profiles:
            trust_scores = [p.trust_score for p in trust_profiles.values()]
            avg_trust = sum(trust_scores) / len(trust_scores)
            current_trust_variance = sum((t - avg_trust) ** 2 for t in trust_scores) / len(trust_scores)
        else:
            current_trust_variance = 0.05
        
        # Determine auto-adjust status
        auto_adjust_enabled = True  # Default
        if recent_thresholds:
            auto_adjust_enabled = recent_thresholds[0].get("auto_adjust_enabled", True)
        
        return {
            "success": True,
            "current_status": {
                "global_threshold": round(avg_threshold, 3),
                "trust_variance": round(current_trust_variance, 3),
                "avg_complexity": round(avg_complexity, 2),
                "auto_adjust_enabled": auto_adjust_enabled,
                "threshold_range": {
                    "min": round(min_threshold, 3),
                    "max": round(max_threshold, 3),
                    "configured_range": "80-95%"
                }
            },
            "thresholds_by_category": thresholds_by_category,
            "threshold_trend": threshold_trend,
            "statistics": {
                "total_threshold_calculations": len(recent_thresholds),
                "avg_threshold": round(avg_threshold, 3),
                "avg_trust_variance": round(avg_trust_variance, 3),
                "avg_complexity_rating": round(avg_complexity, 2)
            },
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error fetching threshold status: {e}")
        raise HTTPException(status_code=500, detail=str(e))



# ====================
# Step 22: Collective Memory & Experience Replay System
# ====================

from llm_evaluator import (
    ExperienceRecord,
    MemoryRetrievalResult,
    ReplaySession,
    store_experience_record,
    retrieve_similar_experiences,
    run_experience_replay,
    summarize_collective_memory,
    cleanup_old_experiences
)


class MemoryStoreRequest(BaseModel):
    """Request to store experience in collective memory"""
    task_type: str = Field(..., description="Type: arbitration, consensus, coaching, analytics")
    task_description: str
    agents_involved: List[str]
    outcome: Dict[str, Any]
    confidence: float = Field(..., ge=0.0, le=1.0)
    metadata: Optional[Dict[str, Any]] = None


class MemoryRetrieveRequest(BaseModel):
    """Request to retrieve similar experiences"""
    query: str
    task_type_filter: Optional[str] = None
    min_confidence: float = Field(default=0.70, ge=0.0, le=1.0)
    limit: int = Field(default=5, ge=1, le=20)


class MemoryReplayRequest(BaseModel):
    """Request to run experience replay session"""
    experience_ids: Optional[List[str]] = None  # If None, use most recent high-confidence
    auto_select_count: int = Field(default=10, ge=5, le=50)


@api_router.post("/llm/memory/store")
async def store_memory_experience(request: MemoryStoreRequest):
    """
    Store arbitration or consensus experience to collective memory.
    
    Filters out low-confidence experiences (<70%).
    Generates semantic embeddings for similarity search.
    Enforces retention policy (max 1000 or 30 days).
    """
    try:
        api_key = os.environ.get('EMERGENT_LLM_KEY')
        if not api_key:
            raise HTTPException(status_code=500, detail="EMERGENT_LLM_KEY not configured")
        
        # Store experience
        experience = await store_experience_record(
            task_type=request.task_type,
            task_description=request.task_description,
            agents_involved=request.agents_involved,
            outcome=request.outcome,
            confidence=request.confidence,
            api_key=api_key,
            metadata=request.metadata
        )
        
        if not experience:
            return {
                "success": False,
                "message": f"Experience not stored (confidence {request.confidence:.2f} < 0.70 threshold)"
            }
        
        # Save to MongoDB
        await db.llm_experience_memory.insert_one(experience.to_dict())
        
        # Check if cleanup is needed
        total_count = await db.llm_experience_memory.count_documents({})
        
        # Trigger replay every 50 experiences
        should_trigger_replay = (total_count % 50 == 0) and total_count > 0
        
        # Cleanup if needed
        cleanup_triggered = False
        if total_count > 1000:
            cleanup_result = await cleanup_old_experiences(
                db_collection=db.llm_experience_memory,
                max_count=1000,
                max_age_days=30
            )
            cleanup_triggered = True
            logger.info(f"Cleanup triggered: {cleanup_result['total_deleted']} experiences deleted")
        
        return {
            "success": True,
            "experience_id": experience.experience_id,
            "confidence": experience.confidence,
            "stored_at": experience.timestamp,
            "total_experiences": total_count,
            "replay_triggered": should_trigger_replay,
            "cleanup_triggered": cleanup_triggered,
            "message": "Experience stored successfully" + (" (replay threshold reached)" if should_trigger_replay else "")
        }
        
    except Exception as e:
        logger.error(f"Error storing memory experience: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/memory/retrieve")
async def retrieve_memory_experiences(
    query: str,
    task_type_filter: Optional[str] = None,
    min_confidence: float = 0.70,
    limit: int = 5
):
    """
    Retrieve similar experiences using semantic similarity search.
    
    Uses OpenAI embeddings and cosine similarity to find related cases.
    Returns ranked results by similarity score.
    """
    try:
        api_key = os.environ.get('EMERGENT_LLM_KEY')
        if not api_key:
            raise HTTPException(status_code=500, detail="EMERGENT_LLM_KEY not configured")
        
        # Retrieve similar experiences
        result = await retrieve_similar_experiences(
            query=query,
            api_key=api_key,
            task_type_filter=task_type_filter,
            min_confidence=min_confidence,
            limit=limit,
            db_collection=db.llm_experience_memory
        )
        
        return {
            "success": True,
            "retrieval_id": result.retrieval_id,
            "query": result.query,
            "similar_experiences": result.similar_experiences,
            "top_match_confidence": result.top_match_confidence,
            "recall_count": result.recall_count,
            "timestamp": result.timestamp
        }
        
    except Exception as e:
        logger.error(f"Error retrieving memory experiences: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.post("/llm/memory/replay")
async def run_memory_replay(request: MemoryReplayRequest):
    """
    Run experience replay session to reinforce learning.
    
    Replays high-confidence cases to:
    - Update trust calibration
    - Reinforce successful patterns
    - Calculate performance improvements
    
    Can auto-select recent high-confidence experiences or use provided IDs.
    """
    try:
        experience_ids = request.experience_ids
        
        # Auto-select if not provided
        if not experience_ids:
            # Get most recent high-confidence experiences (>=90%)
            experiences = await db.llm_experience_memory.find({
                "confidence": {"$gte": 0.90}
            }).sort("timestamp", -1).limit(request.auto_select_count).to_list(request.auto_select_count)
            
            experience_ids = [exp["experience_id"] for exp in experiences]
            
            if not experience_ids:
                return {
                    "success": False,
                    "message": "No high-confidence experiences available for replay"
                }
        
        # Get trust profiles
        trust_profiles = get_trust_profiles()
        
        # Run replay
        replay_session = await run_experience_replay(
            experience_ids=experience_ids,
            trust_profiles=trust_profiles,
            db_collection=db.llm_experience_memory
        )
        
        # Save replay log to database
        await db.llm_memory_replay_log.insert_one(replay_session.to_dict())
        
        # Update trust profiles in database
        for agent_name, adjustment in replay_session.trust_adjustments.items():
            if agent_name in trust_profiles:
                new_trust = trust_profiles[agent_name].trust_score
                await db.llm_trust_profiles.update_one(
                    {"agent_name": agent_name},
                    {"$set": {
                        "trust_score": new_trust,
                        "last_updated": datetime.now(timezone.utc).isoformat()
                    }}
                )
        
        return {
            "success": True,
            "session_id": replay_session.session_id,
            "experiences_replayed": replay_session.experiences_replayed,
            "avg_confidence": replay_session.avg_confidence,
            "trust_adjustments": replay_session.trust_adjustments,
            "reasoning_improvements": replay_session.reasoning_improvements,
            "performance_delta": replay_session.performance_delta,
            "timestamp": replay_session.timestamp,
            "message": f"Replayed {replay_session.experiences_replayed} experiences (avg confidence: {replay_session.avg_confidence * 100:.1f}%)"
        }
        
    except Exception as e:
        logger.error(f"Error running memory replay: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/memory/summary")
async def get_memory_summary(timeframe_days: int = 30):
    """
    Get collective memory summary and metrics.
    
    Provides:
    - Total experiences stored
    - Confidence statistics
    - Task type breakdown
    - Agent activity
    - Memory quality metrics
    - Retention status
    """
    try:
        # Get summary
        summary = await summarize_collective_memory(
            db_collection=db.llm_experience_memory,
            timeframe_days=timeframe_days
        )
        
        # Get recent replay sessions
        recent_replays = await db.llm_memory_replay_log.find().sort(
            "timestamp", -1
        ).limit(5).to_list(5)
        
        # Calculate last replay date
        last_replay_date = recent_replays[0]["timestamp"] if recent_replays else None
        
        # Add replay information to summary
        summary["recent_replay_sessions"] = len(recent_replays)
        summary["last_replay_date"] = last_replay_date
        
        # Get total across all time
        total_all_time = await db.llm_experience_memory.count_documents({})
        summary["total_experiences_all_time"] = total_all_time
        
        return {
            "success": True,
            **summary
        }
        
    except Exception as e:
        logger.error(f"Error getting memory summary: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/memory/stats")
async def get_memory_stats():
    """
    Get detailed memory statistics for dashboard display.
    
    Returns metrics for UI visualization.
    """
    try:
        # Total experiences
        total_count = await db.llm_experience_memory.count_documents({})
        
        # High-quality count (>=90%)
        high_quality_count = await db.llm_experience_memory.count_documents({
            "confidence": {"$gte": 0.90}
        })
        
        # Average confidence
        pipeline = [
            {"$group": {
                "_id": None,
                "avg_confidence": {"$avg": "$confidence"}
            }}
        ]
        agg_result = await db.llm_experience_memory.aggregate(pipeline).to_list(1)
        avg_confidence = agg_result[0]["avg_confidence"] if agg_result else 0.0
        
        # Task type distribution
        task_type_pipeline = [
            {"$group": {
                "_id": "$task_type",
                "count": {"$sum": 1}
            }},
            {"$sort": {"count": -1}}
        ]
        task_types = await db.llm_experience_memory.aggregate(task_type_pipeline).to_list(10)
        
        # Recent replay sessions
        replay_count = await db.llm_memory_replay_log.count_documents({})
        recent_replay = await db.llm_memory_replay_log.find().sort("timestamp", -1).limit(1).to_list(1)
        
        # Check if replay needed (every 50 experiences)
        replay_threshold = 50
        experiences_since_last_replay = total_count % replay_threshold if total_count > 0 else 0
        replay_recommended = experiences_since_last_replay == 0 and total_count > 0
        
        return {
            "success": True,
            "total_experiences": total_count,
            "high_quality_count": high_quality_count,
            "avg_confidence": round(avg_confidence, 3),
            "memory_accuracy_percent": round(avg_confidence * 100, 1),
            "task_type_distribution": [
                {"task_type": t["_id"], "count": t["count"]}
                for t in task_types
            ],
            "replay_sessions_total": replay_count,
            "last_replay": recent_replay[0] if recent_replay else None,
            "experiences_since_last_replay": experiences_since_last_replay,
            "replay_recommended": replay_recommended,
            "retention_status": "Within limit" if total_count <= 1000 else "Cleanup recommended"
        }
        
    except Exception as e:
        logger.error(f"Error getting memory stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))




# ====================
# Step 23: Collective Intelligence Layer & Global Strategy Synthesis
# ====================

from llm_evaluator import (
    CollectiveStrategy,
    AlignmentMetrics,
    aggregate_global_insights,
    synthesize_collective_strategy,
    evaluate_collective_alignment,
    update_global_strategy_map
)


class SynthesisRequest(BaseModel):
    """Request to trigger global strategy synthesis"""
    include_forecast: bool = Field(default=True)
    synthesis_depth: str = Field(default="comprehensive", pattern="^(quick|balanced|comprehensive)$")


@api_router.post("/llm/collective/synthesize")
async def synthesize_collective_intelligence():
    """
    Run synthesis across all subsystems (memory, trust, arbitration, forecasting).
    
    Aggregates insights from:
    - Step 19: Multi-Agent Collaboration
    - Step 20: Trust Calibration
    - Step 21: Arbitration
    - Step 22: Collective Memory
    
    Generates unified strategic recommendations using LLM (GPT-5).
    """
    try:
        api_key = os.environ.get('EMERGENT_LLM_KEY')
        if not api_key:
            raise HTTPException(status_code=500, detail="EMERGENT_LLM_KEY not configured")
        
        # Fetch data from all subsystems
        # Memory data (Step 22)
        memory_data = await db.llm_experience_memory.find().sort("timestamp", -1).limit(100).to_list(100)
        
        # Trust calibration data (Step 20)
        trust_data = await db.llm_trust_calibration.find().sort("timestamp", -1).limit(50).to_list(50)
        
        # Arbitration data (Step 21)
        arbitration_data = await db.llm_arbitration_log.find().sort("timestamp", -1).limit(50).to_list(50)
        
        # Forecast data (optional - if available)
        forecast_docs = await db.llm_forecast_log.find().sort("timestamp", -1).limit(1).to_list(1)
        forecast_data = forecast_docs[0] if forecast_docs else None
        
        # Step 1: Aggregate global insights
        logger.info("Aggregating global insights from all subsystems...")
        aggregated_insights = await aggregate_global_insights(
            memory_data=memory_data,
            trust_data=trust_data,
            arbitration_data=arbitration_data,
            forecast_data=forecast_data
        )
        
        # Step 2: Synthesize collective strategy using LLM
        logger.info("Synthesizing collective strategy using GPT-5...")
        collective_strategy = await synthesize_collective_strategy(
            aggregated_insights=aggregated_insights,
            llm_api_key=api_key
        )
        
        # Step 3: Evaluate collective alignment
        logger.info("Evaluating collective alignment...")
        existing_strategies = await db.llm_global_strategy.find().to_list(100)
        alignment_metrics = await evaluate_collective_alignment(
            memory_data=memory_data,
            trust_data=trust_data,
            arbitration_data=arbitration_data,
            collective_strategies=existing_strategies
        )
        
        # Step 4: Update global strategy map
        logger.info("Updating global strategy map...")
        strategy_update = await update_global_strategy_map(
            new_strategy=collective_strategy,
            existing_strategies=existing_strategies,
            db_collection=db.llm_global_strategy
        )
        
        # Store alignment metrics
        await db.llm_alignment_metrics.insert_one(alignment_metrics.to_dict())
        
        # Store synthesis log
        synthesis_log = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "strategy_id": collective_strategy.strategy_id,
            "strategy_archetype": collective_strategy.strategy_archetype,
            "aggregated_insights": aggregated_insights,
            "alignment_score": alignment_metrics.overall_alignment_score,
            "consensus_level": alignment_metrics.consensus_level,
            "strategy_update_action": strategy_update.get("action")
        }
        await db.llm_synthesis_log.insert_one(synthesis_log)
        
        logger.info(f"Collective intelligence synthesis complete: {collective_strategy.strategy_archetype}")
        
        return {
            "success": True,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "collective_strategy": collective_strategy.to_dict(),
            "alignment_metrics": alignment_metrics.to_dict(),
            "aggregated_insights": aggregated_insights,
            "strategy_update": strategy_update,
            "data_sources": {
                "memory_count": len(memory_data),
                "trust_count": len(trust_data),
                "arbitration_count": len(arbitration_data),
                "forecast_available": forecast_data is not None
            }
        }
        
    except Exception as e:
        logger.error(f"Error in collective synthesis: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/collective/strategies")
async def get_global_strategies(
    min_confidence: float = Query(default=0.0, ge=0.0, le=1.0),
    limit: int = Query(default=20, ge=1, le=100),
    sort_by: str = Query(default="confidence", pattern="^(confidence|usage|recent)$")
):
    """
    Retrieve global strategy map with confidence metrics.
    
    Returns list of high-confidence strategies synthesized from collective intelligence.
    Strategies can be sorted by confidence, usage count, or recency.
    """
    try:
        # Build query
        query = {}
        if min_confidence > 0:
            query["confidence_score"] = {"$gte": min_confidence}
        
        # Determine sort field
        if sort_by == "confidence":
            sort_field = [("confidence_score", -1)]
        elif sort_by == "usage":
            sort_field = [("usage_count", -1)]
        else:  # recent
            sort_field = [("last_updated", -1)]
        
        # Fetch strategies
        strategies = await db.llm_global_strategy.find(query).sort(sort_field).limit(limit).to_list(limit)
        
        # Calculate statistics
        total_strategies = await db.llm_global_strategy.count_documents({})
        high_confidence_count = await db.llm_global_strategy.count_documents({"confidence_score": {"$gte": 0.8}})
        
        if strategies:
            avg_confidence = sum(s.get("confidence_score", 0) for s in strategies) / len(strategies)
            avg_alignment = sum(s.get("alignment_score", 0) for s in strategies) / len(strategies)
            total_usage = sum(s.get("usage_count", 0) for s in strategies)
        else:
            avg_confidence = 0
            avg_alignment = 0
            total_usage = 0
        
        # Get most recent synthesis
        recent_synthesis = await db.llm_synthesis_log.find().sort("timestamp", -1).limit(1).to_list(1)
        
        return {
            "success": True,
            "strategies": strategies,
            "statistics": {
                "total_strategies": total_strategies,
                "high_confidence_count": high_confidence_count,
                "avg_confidence": round(avg_confidence, 3),
                "avg_alignment": round(avg_alignment, 3),
                "total_usage": total_usage
            },
            "last_synthesis": recent_synthesis[0] if recent_synthesis else None,
            "query_params": {
                "min_confidence": min_confidence,
                "limit": limit,
                "sort_by": sort_by
            }
        }
        
    except Exception as e:
        logger.error(f"Error retrieving strategies: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/collective/alignment")
async def get_collective_alignment(
    limit: int = Query(default=10, ge=1, le=50)
):
    """
    Returns collective alignment analytics across all subsystems.
    
    Provides:
    - Overall alignment score (0-1)
    - Subsystem-specific alignment scores
    - Consensus level (high/moderate/low/divergent)
    - Harmony index
    - Strategic coherence
    - Historical alignment trends
    """
    try:
        # Get recent alignment metrics
        alignment_history = await db.llm_alignment_metrics.find().sort("timestamp", -1).limit(limit).to_list(limit)
        
        if not alignment_history:
            return {
                "success": True,
                "message": "No alignment data available. Run synthesis first.",
                "current_alignment": None,
                "alignment_history": [],
                "trends": {}
            }
        
        # Get current (most recent) alignment
        current_alignment = alignment_history[0]
        
        # Calculate trends
        if len(alignment_history) >= 2:
            recent_scores = [a.get("overall_alignment_score", 0) for a in alignment_history[:5]]
            older_scores = [a.get("overall_alignment_score", 0) for a in alignment_history[-5:]]
            
            recent_avg = sum(recent_scores) / len(recent_scores) if recent_scores else 0
            older_avg = sum(older_scores) / len(older_scores) if older_scores else 0
            
            if recent_avg > older_avg + 0.05:
                trend_direction = "improving"
            elif recent_avg < older_avg - 0.05:
                trend_direction = "declining"
            else:
                trend_direction = "stable"
            
            trend_change = round((recent_avg - older_avg) * 100, 2)
        else:
            trend_direction = "insufficient_data"
            trend_change = 0
        
        # Calculate subsystem stability
        subsystem_trends = {}
        for subsystem in ["memory", "trust", "arbitration", "forecast"]:
            scores = [
                a.get("subsystem_scores", {}).get(subsystem, 0)
                for a in alignment_history
            ]
            if scores:
                subsystem_trends[subsystem] = {
                    "current": scores[0],
                    "average": round(sum(scores) / len(scores), 3),
                    "variance": round(sum((s - sum(scores) / len(scores)) ** 2 for s in scores) / len(scores), 4)
                }
        
        # Get synthesis count
        synthesis_count = await db.llm_synthesis_log.count_documents({})
        
        # Get conflict statistics
        recent_arbitrations = await db.llm_arbitration_log.find().sort("timestamp", -1).limit(50).to_list(50)
        unresolved_conflicts = len([a for a in recent_arbitrations if a.get("resolution") == "unresolved"])
        
        return {
            "success": True,
            "current_alignment": current_alignment,
            "alignment_history": alignment_history,
            "trends": {
                "overall_trend": trend_direction,
                "change_percent": trend_change,
                "subsystem_trends": subsystem_trends
            },
            "statistics": {
                "total_synthesis_runs": synthesis_count,
                "alignment_measurements": len(alignment_history),
                "current_conflicts": unresolved_conflicts
            },
            "recommendations": [
                "Alignment is optimal - continue current strategy" if current_alignment.get("overall_alignment_score", 0) >= 0.85
                else "Consider recalibration - alignment below target" if current_alignment.get("overall_alignment_score", 0) < 0.6
                else "Moderate alignment - monitor for improvements"
            ]
        }
        
    except Exception as e:
        logger.error(f"Error getting alignment analytics: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/collective/insights-summary")
async def get_collective_insights_summary():
    """
    Get quick summary of collective intelligence status.
    Useful for dashboard header display.
    """
    try:
        # Get counts from each subsystem
        memory_count = await db.llm_experience_memory.count_documents({})
        trust_count = await db.llm_trust_calibration.count_documents({})
        arbitration_count = await db.llm_arbitration_log.count_documents({})
        strategy_count = await db.llm_global_strategy.count_documents({})
        
        # Get latest alignment
        latest_alignment = await db.llm_alignment_metrics.find().sort("timestamp", -1).limit(1).to_list(1)
        
        # Get latest synthesis
        latest_synthesis = await db.llm_synthesis_log.find().sort("timestamp", -1).limit(1).to_list(1)
        
        alignment_score = latest_alignment[0].get("overall_alignment_score", 0) if latest_alignment else 0
        consensus_level = latest_alignment[0].get("consensus_level", "unknown") if latest_alignment else "unknown"
        
        return {
            "success": True,
            "subsystem_status": {
                "memory_experiences": memory_count,
                "trust_calibrations": trust_count,
                "arbitration_logs": arbitration_count,
                "global_strategies": strategy_count
            },
            "collective_intelligence": {
                "alignment_score": round(alignment_score, 3),
                "consensus_level": consensus_level,
                "last_synthesis": latest_synthesis[0].get("timestamp") if latest_synthesis else None,
                "active_strategy": latest_synthesis[0].get("strategy_archetype") if latest_synthesis else "No strategy yet"
            },
            "system_health": "optimal" if alignment_score >= 0.85 else "good" if alignment_score >= 0.7 else "needs_attention"
        }
        
    except Exception as e:
        logger.error(f"Error getting insights summary: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Meta-Optimization Endpoints (Step 24)
# ====================

# Initialize Meta-Reasoning Controller
meta_controller = None

def get_meta_controller():
    """Get or create meta-reasoning controller"""
    global meta_controller
    if meta_controller is None:
        from meta_optimizer import MetaReasoningController
        meta_controller = MetaReasoningController(db)
    return meta_controller

@api_router.post("/llm/meta/optimize")
async def trigger_meta_optimization(background_tasks: BackgroundTasks):
    """
    Trigger meta-optimization cycle manually.
    Analyzes system performance and applies autonomous optimizations.
    """
    try:
        controller = get_meta_controller()
        
        # Run optimization cycle in background
        cycle = await controller.run_optimization_cycle(trigger="manual")
        
        return {
            "success": True,
            "message": "Meta-optimization cycle initiated",
            "cycle_id": cycle.cycle_id,
            "adjustments_proposed": len(cycle.adjustments),
            "applied": cycle.applied,
            "approval_required": cycle.approval_required,
            "system_health_score": cycle.system_health_score,
            "reflection_summary": cycle.reflection_summary
        }
    except Exception as e:
        logger.error(f"Error triggering meta-optimization: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/meta/status")
async def get_meta_optimization_status():
    """
    Get current meta-optimization system status.
    Returns system health, recent metrics, and optimization deltas.
    """
    try:
        controller = get_meta_controller()
        status = await controller.get_optimization_status()
        
        return {
            "success": True,
            **status
        }
    except Exception as e:
        logger.error(f"Error getting meta-optimization status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/meta/history")
async def get_meta_optimization_history(limit: int = 20):
    """
    Get meta-optimization history with parameter adjustments and impact.
    Returns list of optimization cycles with detailed metrics.
    """
    try:
        # Get optimization cycles from database
        cycles = await db.llm_meta_optimization_log.find().sort(
            "timestamp", -1
        ).limit(limit).to_list(limit)
        
        # Process cycles for frontend
        processed_cycles = []
        for cycle in cycles:
            processed_cycles.append({
                "cycle_id": cycle.get("cycle_id"),
                "timestamp": cycle.get("timestamp"),
                "trigger": cycle.get("trigger"),
                "adjustments_count": len(cycle.get("adjustments", [])),
                "adjustments": cycle.get("adjustments", []),
                "applied": cycle.get("applied", False),
                "approval_required": cycle.get("approval_required", False),
                "system_health_score": cycle.get("system_health_score", 75.0),
                "reflection_summary": cycle.get("reflection_summary", ""),
                "performance_delta": cycle.get("performance_delta", {})
            })
        
        return {
            "success": True,
            "cycles": processed_cycles,
            "total": len(processed_cycles)
        }
    except Exception as e:
        logger.error(f"Error getting meta-optimization history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/meta/metrics")
async def get_system_performance_metrics(lookback_hours: int = 24):
    """
    Get detailed system performance metrics across all subsystems.
    Used for monitoring and diagnostics.
    """
    try:
        controller = get_meta_controller()
        metrics = await controller.analyze_system_performance(lookback_hours=lookback_hours)
        
        # Convert SystemMetrics objects to dictionaries
        metrics_dict = {
            subsystem: metric.to_dict() 
            for subsystem, metric in metrics.items()
        }
        
        return {
            "success": True,
            "lookback_hours": lookback_hours,
            "metrics": metrics_dict,
            "subsystems": list(metrics_dict.keys())
        }
    except Exception as e:
        logger.error(f"Error getting system performance metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.post("/llm/meta/approve/{cycle_id}")
async def approve_optimization_cycle(cycle_id: str):
    """
    Manually approve a pending optimization cycle.
    Applies adjustments that required manual review.
    """
    try:
        # Get cycle from database
        cycle_doc = await db.llm_meta_optimization_log.find_one({"cycle_id": cycle_id})
        
        if not cycle_doc:
            raise HTTPException(status_code=404, detail="Optimization cycle not found")
        
        if cycle_doc.get("applied"):
            return {
                "success": False,
                "message": "Cycle already applied"
            }
        
        # Apply adjustments
        controller = get_meta_controller()
        from meta_optimizer import MetaAdjustment
        
        adjustments = [
            MetaAdjustment(**adj) for adj in cycle_doc.get("adjustments", [])
        ]
        
        simulation_results = cycle_doc.get("simulation_results", {})
        simulation_results["recommendation"] = "approve"  # Override for manual approval
        
        success, results = await controller.apply_autonomous_optimization(
            adjustments, 
            simulation_results
        )
        
        # Update cycle in database
        await db.llm_meta_optimization_log.update_one(
            {"cycle_id": cycle_id},
            {"$set": {
                "applied": success,
                "manual_approval": True,
                "approval_timestamp": datetime.now(timezone.utc).isoformat(),
                "application_results": results
            }}
        )
        
        return {
            "success": success,
            "message": "Optimization cycle approved and applied",
            "results": results
        }
    except Exception as e:
        logger.error(f"Error approving optimization cycle: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Adaptive Goal Formation & Ethical Governance (Step 25)
# ====================

from goal_governor import AdaptiveGoalController, AdaptiveGoal, GovernanceEvaluation

# Initialize goal governor
goal_governor = None

def get_goal_governor():
    """Get or create goal governor instance"""
    global goal_governor
    if goal_governor is None:
        goal_governor = AdaptiveGoalController(db)
    return goal_governor

class GoalGenerationRequest(BaseModel):
    """Request to generate adaptive goals"""
    lookback_hours: int = Field(default=24, ge=1, le=168)
    include_performance: bool = Field(default=True)
    include_alignment: bool = Field(default=True)
    include_stability: bool = Field(default=True)

class GoalApprovalRequest(BaseModel):
    """Request to approve/reject a goal"""
    goal_id: str
    approved: bool
    approver: str = Field(default="manual")
    notes: Optional[str] = None

@api_router.post("/llm/goals/generate")
async def generate_adaptive_goals(request: GoalGenerationRequest):
    """
    Generate adaptive goals based on system performance and emergent signals.
    
    Returns:
        List of proposed goals with ethical alignment scores
    """
    try:
        governor = get_goal_governor()
        
        # Gather performance trends
        from meta_optimizer import MetaReasoningController
        meta_controller = MetaReasoningController(db)
        
        # Get system metrics
        metrics = await meta_controller.analyze_system_performance(
            lookback_hours=request.lookback_hours
        )
        
        # Format performance trends
        performance_trends = {
            "lookback_hours": request.lookback_hours,
            "subsystem_metrics": {
                subsystem: {
                    "alignment_pct": metric.alignment_pct,
                    "trust_variance": metric.trust_variance,
                    "consensus_stability": metric.consensus_stability,
                    "win_rate": metric.win_rate
                }
                for subsystem, metric in metrics.items()
            }
        }
        
        # Format emergent signals
        optimization_status = await meta_controller.get_optimization_status()
        emergent_signals = {
            "overall_alignment": optimization_status.get("system_health_score", 75.0) / 100.0,
            "trust_variance": optimization_status.get("metrics_summary", {}).get("trust", {}).get("variance", 0.1),
            "system_health": optimization_status.get("system_health_score", 75.0)
        }
        
        # Generate goals
        goals = await governor.generate_adaptive_goals(
            performance_trends=performance_trends,
            emergent_signals=emergent_signals
        )
        
        # Evaluate each goal
        evaluated_goals = []
        for goal in goals:
            # Evaluate alignment
            evaluation = await governor.evaluate_goal_alignment(goal)
            
            # Check governance rules
            can_execute, reason = await governor.apply_governance_rules(goal, evaluation)
            
            # Store goal
            goal_dict = goal.to_dict()
            goal_dict["evaluation"] = evaluation.to_dict()
            goal_dict["can_auto_execute"] = can_execute
            goal_dict["governance_reason"] = reason
            
            await db.llm_adaptive_goals.insert_one(goal_dict)
            
            # Record in governance log
            await governor.record_goal_outcome(
                goal=goal,
                evaluation=evaluation,
                executed=False,
                outcome={"status": "proposed", "can_auto_execute": can_execute}
            )
            
            evaluated_goals.append(goal_dict)
        
        logger.info(f"Generated {len(evaluated_goals)} adaptive goals")
        
        return {
            "success": True,
            "goals_generated": len(evaluated_goals),
            "goals": evaluated_goals,
            "performance_trends": performance_trends,
            "emergent_signals": emergent_signals,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error generating adaptive goals: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/goals/status")
async def get_goals_status(
    status: Optional[str] = Query(None, regex="^(proposed|approved|rejected|active|completed)$"),
    limit: int = Query(20, ge=1, le=100)
):
    """
    Get list of goals with alignment and ethics scores.
    
    Query Parameters:
        status: Filter by goal status
        limit: Maximum number of goals to return
    
    Returns:
        List of goals with alignment metrics
    """
    try:
        governor = get_goal_governor()
        
        # Build query
        query = {}
        if status:
            query["status"] = status
        
        # Get goals from database
        goals_raw = await db.llm_adaptive_goals.find(query).sort(
            "timestamp", -1
        ).limit(limit).to_list(limit)
        
        # Remove MongoDB _id field
        goals = []
        for g in goals_raw:
            g.pop('_id', None)
            goals.append(g)
        
        # Calculate statistics
        if goals:
            avg_strategic_alignment = np.mean([g.get("strategic_alignment", 0) for g in goals])
            avg_ethical_alignment = np.mean([g.get("ethical_alignment", 0) for g in goals])
            
            critical_count = sum(1 for g in goals if g.get("is_critical", False))
            auto_apply_count = sum(1 for g in goals if g.get("auto_apply", False))
            
            status_distribution = {}
            type_distribution = {}
            for g in goals:
                s = g.get("status", "unknown")
                t = g.get("goal_type", "unknown")
                status_distribution[s] = status_distribution.get(s, 0) + 1
                type_distribution[t] = type_distribution.get(t, 0) + 1
        else:
            avg_strategic_alignment = 0.0
            avg_ethical_alignment = 0.0
            critical_count = 0
            auto_apply_count = 0
            status_distribution = {}
            type_distribution = {}
        
        return {
            "success": True,
            "total_goals": len(goals),
            "goals": goals,
            "statistics": {
                "avg_strategic_alignment": round(avg_strategic_alignment, 3),
                "avg_ethical_alignment": round(avg_ethical_alignment, 3),
                "critical_goals": critical_count,
                "auto_apply_eligible": auto_apply_count,
                "status_distribution": status_distribution,
                "type_distribution": type_distribution
            },
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error getting goals status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/llm/goals/approve")
async def approve_goal(request: GoalApprovalRequest):
    """
    Manually approve or reject a goal.
    
    Returns:
        Approval result and updated goal status
    """
    try:
        governor = get_goal_governor()
        
        # Get the goal
        goal_doc = await db.llm_adaptive_goals.find_one({"goal_id": request.goal_id})
        
        if not goal_doc:
            raise HTTPException(status_code=404, detail=f"Goal {request.goal_id} not found")
        
        # Approve/reject the goal
        success = await governor.approve_goal(
            goal_id=request.goal_id,
            approved=request.approved,
            approver=request.approver
        )
        
        if not success:
            raise HTTPException(status_code=500, detail="Failed to update goal status")
        
        # Get updated goal
        updated_goal = await db.llm_adaptive_goals.find_one({"goal_id": request.goal_id})
        
        # Record in governance log
        log_entry = {
            "log_id": str(uuid.uuid4()),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "action": "manual_approval",
            "goal_id": request.goal_id,
            "approved": request.approved,
            "approver": request.approver,
            "notes": request.notes,
            "goal_snapshot": updated_goal
        }
        await db.llm_governance_log.insert_one(log_entry)
        
        logger.info(f"Goal {request.goal_id[:8]} {'approved' if request.approved else 'rejected'} by {request.approver}")
        
        return {
            "success": True,
            "goal_id": request.goal_id,
            "approved": request.approved,
            "new_status": updated_goal.get("status"),
            "approver": request.approver,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error approving goal: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/governance/report")
async def get_governance_report():
    """
    Generate comprehensive ethical governance report.
    
    Returns:
        Governance report with alignment metrics, violations, and recommendations
    """
    try:
        governor = get_goal_governor()
        
        # Generate comprehensive report
        report = await governor.generate_governance_report()
        
        return {
            "success": True,
            "report": report,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error generating governance report: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/governance/rules")
async def get_governance_rules():
    """Get active governance rules"""
    try:
        rules_docs = await db.llm_governance_rules.find({"enabled": True}).to_list(100)
        
        if not rules_docs:
            # Return default rules
            governor = get_goal_governor()
            rules_docs = [rule.to_dict() for rule in governor.default_rules]
        
        return {
            "success": True,
            "rules": rules_docs,
            "count": len(rules_docs)
        }
        
    except Exception as e:
        logger.error(f"Error getting governance rules: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/llm/governance/rules/update")
async def update_governance_rule(rule: Dict[str, Any]):
    """Update or create a governance rule"""
    try:
        rule_id = rule.get("rule_id")
        
        if not rule_id:
            rule_id = str(uuid.uuid4())
            rule["rule_id"] = rule_id
        
        # Validate rule structure
        required_fields = ["name", "description", "constraint_type", "threshold"]
        for field in required_fields:
            if field not in rule:
                raise HTTPException(status_code=400, detail=f"Missing required field: {field}")
        
        # Update or insert
        await db.llm_governance_rules.replace_one(
            {"rule_id": rule_id},
            rule,
            upsert=True
        )
        
        logger.info(f"Updated governance rule: {rule_id}")
        
        return {
            "success": True,
            "rule_id": rule_id,
            "message": "Governance rule updated successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating governance rule: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Ethical Consensus Endpoints (Step 26)
# ====================

class ConsensusRequest(BaseModel):
    """Request for ethical consensus deliberation"""
    goal_id: str
    trigger_type: str = Field(default="manual", pattern="^(manual|automatic)$")
    include_refinement: bool = Field(default=True)

@api_router.post("/llm/ethics/consensus")
async def trigger_ethical_consensus(request: ConsensusRequest):
    """
    Trigger multi-agent ethical consensus deliberation.
    
    This endpoint initiates deliberation among 5 LLM agents (GPT-5, Claude 4, Gemini 2.5)
    to evaluate an adaptive goal's ethical alignment.
    """
    try:
        from ethical_consensus import EthicalConsensusEngine
        
        # Initialize consensus engine
        engine = EthicalConsensusEngine(db)
        
        # Get the goal to evaluate
        goal = await db.llm_adaptive_goals.find_one({"goal_id": request.goal_id})
        if not goal:
            raise HTTPException(status_code=404, detail="Goal not found")
        
        # Get governance context
        governance_rules = await db.llm_governance_rules.find({"enabled": True}).to_list(100)
        
        # Get recent governance metrics
        recent_logs = await db.llm_governance_log.find().sort("timestamp", -1).limit(20).to_list(20)
        avg_alignment = np.mean([log.get('overall_alignment', 0) for log in recent_logs]) if recent_logs else 0.85
        recent_violations = sum(len(log.get('violations', [])) for log in recent_logs)
        
        governance_context = {
            "active_rules": governance_rules,
            "avg_alignment": avg_alignment,
            "recent_violations": recent_violations
        }
        
        logger.info(f"Starting ethical consensus for goal {request.goal_id[:8]}...")
        
        # Step 1: Aggregate agent ethics
        agent_opinions = await engine.aggregate_agent_ethics(goal, governance_context)
        
        if not agent_opinions:
            raise HTTPException(
                status_code=503,
                detail="Unable to gather agent opinions. LLM services may be unavailable."
            )
        
        # Step 2: Run consensus voting
        consensus_result = await engine.run_consensus_voting(agent_opinions, goal)
        
        # Step 3: Resolve conflicts if detected
        if consensus_result.conflicts_detected:
            consensus_result, conflict_resolution = await engine.resolve_conflicts(consensus_result)
        
        # Step 4: Store consensus in database
        await db.llm_ethics_consensus_log.insert_one(consensus_result.to_dict())
        
        # Step 5: Refine governance rules if requested
        refinements = []
        if request.include_refinement:
            refinements = await engine.refine_governance_rules(consensus_result, governance_rules)
            
            # Store refinements
            if refinements:
                for refinement in refinements:
                    await db.llm_rule_refinement.insert_one(refinement.to_dict())
        
        logger.info(
            f"Consensus complete: {consensus_result.final_decision} "
            f"(EAI: {consensus_result.agreement_score:.2f}, "
            f"{len(refinements)} refinements generated)"
        )
        
        return {
            "success": True,
            "consensus_id": consensus_result.consensus_id,
            "final_decision": consensus_result.final_decision,
            "agreement_score": consensus_result.agreement_score,
            "agreement_variance": consensus_result.agreement_variance,
            "consensus_reached": consensus_result.consensus_reached,
            "vote_distribution": consensus_result.vote_distribution,
            "conflicts_detected": consensus_result.conflicts_detected,
            "conflict_resolution": consensus_result.conflict_resolution,
            "reasoning_summary": consensus_result.reasoning_summary,
            "agent_opinions_count": len(agent_opinions),
            "refinements_generated": len(refinements),
            "message": f"Consensus deliberation complete: {consensus_result.final_decision}"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in ethical consensus: {e}")
        raise HTTPException(status_code=500, detail=f"Consensus error: {str(e)}")


@api_router.get("/llm/ethics/status")
async def get_consensus_status(limit: int = Query(default=10, ge=1, le=100)):
    """
    Get current ethical consensus alignment metrics and recent status.
    
    Returns:
    - Overall Ethical Alignment Index (EAI)
    - Agreement variance trends
    - Recent consensus decisions
    - System health status
    """
    try:
        from ethical_consensus import EthicalConsensusEngine
        
        engine = EthicalConsensusEngine(db)
        
        # Get recent consensus logs
        recent_consensuses = await db.llm_ethics_consensus_log.find().sort(
            "timestamp", -1
        ).limit(limit).to_list(limit)
        
        if not recent_consensuses:
            return {
                "success": True,
                "status": "no_data",
                "message": "No consensus data available yet",
                "overall_eai": 0.0,
                "avg_variance": 0.0,
                "recent_decisions": []
            }
        
        # Calculate aggregate metrics
        eai_scores = [c.get('agreement_score', 0) for c in recent_consensuses]
        variances = [c.get('agreement_variance', 0) for c in recent_consensuses]
        
        overall_eai = np.mean(eai_scores)
        avg_variance = np.mean(variances)
        
        # Decision distribution
        decision_counts = {}
        for c in recent_consensuses:
            decision = c.get('final_decision', 'unknown')
            decision_counts[decision] = decision_counts.get(decision, 0) + 1
        
        # Conflict analysis
        total_conflicts = sum(len(c.get('conflicts_detected', [])) for c in recent_consensuses)
        
        # Recent decisions summary
        recent_decisions = [
            {
                "consensus_id": c.get('consensus_id'),
                "goal_description": c.get('goal_description', '')[:100],
                "final_decision": c.get('final_decision'),
                "agreement_score": c.get('agreement_score'),
                "timestamp": c.get('timestamp'),
                "conflicts_count": len(c.get('conflicts_detected', []))
            }
            for c in recent_consensuses[:5]
        ]
        
        # Determine status
        if overall_eai >= 0.85 and avg_variance < 0.15:
            status = "excellent"
            status_description = "High consensus alignment with low variance"
        elif overall_eai >= 0.70 and avg_variance < 0.25:
            status = "good"
            status_description = "Acceptable consensus alignment"
        elif overall_eai >= 0.55:
            status = "needs_attention"
            status_description = "Moderate alignment, monitoring recommended"
        else:
            status = "critical"
            status_description = "Low consensus alignment, review required"
        
        return {
            "success": True,
            "status": status,
            "status_description": status_description,
            "overall_eai": round(overall_eai, 3),
            "avg_variance": round(avg_variance, 3),
            "total_consensuses": len(recent_consensuses),
            "decision_distribution": decision_counts,
            "total_conflicts": total_conflicts,
            "conflict_rate": round(total_conflicts / len(recent_consensuses), 2) if recent_consensuses else 0,
            "recent_decisions": recent_decisions
        }
        
    except Exception as e:
        logger.error(f"Error getting consensus status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/ethics/history")
async def get_consensus_history(
    limit: int = Query(default=50, ge=1, le=200),
    goal_id: Optional[str] = Query(default=None)
):
    """
    Get timeline of consensus decisions with detailed agent opinions and voting patterns.
    """
    try:
        query = {}
        if goal_id:
            query["goal_id"] = goal_id
        
        consensuses = await db.llm_ethics_consensus_log.find(query).sort(
            "timestamp", -1
        ).limit(limit).to_list(limit)
        
        # Format timeline
        timeline = []
        for c in consensuses:
            timeline.append({
                "consensus_id": c.get('consensus_id'),
                "timestamp": c.get('timestamp'),
                "goal_id": c.get('goal_id'),
                "goal_description": c.get('goal_description'),
                "final_decision": c.get('final_decision'),
                "agreement_score": c.get('agreement_score'),
                "agreement_variance": c.get('agreement_variance'),
                "consensus_reached": c.get('consensus_reached'),
                "vote_distribution": c.get('vote_distribution'),
                "agents_participated": c.get('agents_participated'),
                "conflicts_detected": c.get('conflicts_detected'),
                "conflict_resolution": c.get('conflict_resolution'),
                "reasoning_summary": c.get('reasoning_summary')
            })
        
        return {
            "success": True,
            "total_records": len(timeline),
            "timeline": timeline
        }
        
    except Exception as e:
        logger.error(f"Error getting consensus history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.post("/llm/ethics/rules/update")
async def update_ethics_rules(refinement_id: str, approved: bool):
    """
    Apply or reject a proposed governance rule refinement.
    
    Args:
        refinement_id: ID of the rule refinement
        approved: Whether to apply the refinement
    """
    try:
        # Get the refinement
        refinement = await db.llm_rule_refinement.find_one({"refinement_id": refinement_id})
        if not refinement:
            raise HTTPException(status_code=404, detail="Refinement not found")
        
        if approved:
            # Get the rule to update
            rule = await db.llm_governance_rules.find_one({"rule_id": refinement['rule_id']})
            if not rule:
                raise HTTPException(status_code=404, detail="Governance rule not found")
            
            # Apply the refinement
            await db.llm_governance_rules.update_one(
                {"rule_id": refinement['rule_id']},
                {"$set": {
                    "threshold": refinement['new_weight'],
                    "last_updated": datetime.now(timezone.utc).isoformat(),
                    "updated_by": "consensus_refinement"
                }}
            )
            
            # Mark refinement as applied
            await db.llm_rule_refinement.update_one(
                {"refinement_id": refinement_id},
                {"$set": {
                    "auto_applied": True,
                    "approved_at": datetime.now(timezone.utc).isoformat()
                }}
            )
            
            logger.info(f"Applied rule refinement {refinement_id[:8]} to rule {refinement['rule_id'][:8]}")
            message = f"Rule refinement applied: {refinement['rule_name']} threshold updated to {refinement['new_weight']}"
        else:
            # Mark refinement as rejected
            await db.llm_rule_refinement.update_one(
                {"refinement_id": refinement_id},
                {"$set": {
                    "rejected": True,
                    "rejected_at": datetime.now(timezone.utc).isoformat()
                }}
            )
            
            logger.info(f"Rejected rule refinement {refinement_id[:8]}")
            message = "Rule refinement rejected"
        
        return {
            "success": True,
            "refinement_id": refinement_id,
            "approved": approved,
            "message": message
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating ethics rules: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/ethics/report")
async def generate_consensus_report(
    lookback_hours: int = Query(default=24, ge=1, le=168),
    consensus_id: Optional[str] = Query(default=None)
):
    """
    Generate comprehensive ethics report with consensus outcomes and rule shifts.
    
    Returns detailed analysis of:
    - Ethical Alignment Index trends
    - Agreement variance patterns
    - Conflict analysis
    - Rule refinement history
    - Provider-specific insights
    - System health assessment
    """
    try:
        from ethical_consensus import EthicalConsensusEngine
        
        engine = EthicalConsensusEngine(db)
        
        # Generate report
        report = await engine.generate_ethics_report(
            consensus_id=consensus_id,
            lookback_hours=lookback_hours
        )
        
        return {
            "success": True,
            "report": report
        }
        
    except Exception as e:
        logger.error(f"Error generating consensus report: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/ethics/agent-details/{consensus_id}")
async def get_agent_details(consensus_id: str):
    """
    Get detailed agent opinions and reasoning for a specific consensus.
    
    Returns individual agent perspectives, confidence scores, and voting rationale.
    """
    try:
        consensus = await db.llm_ethics_consensus_log.find_one({"consensus_id": consensus_id})
        if not consensus:
            raise HTTPException(status_code=404, detail="Consensus not found")
        
        agent_opinions = consensus.get('agent_opinions', [])
        
        # Format agent details
        detailed_opinions = []
        for opinion in agent_opinions:
            detailed_opinions.append({
                "agent_name": opinion.get('agent_name'),
                "provider": opinion.get('provider'),
                "model": opinion.get('model'),
                "vote": opinion.get('vote'),
                "alignment_score": opinion.get('alignment_score'),
                "confidence": opinion.get('confidence'),
                "opinion": opinion.get('opinion'),
                "reasoning": opinion.get('reasoning'),
                "response_time": opinion.get('response_time')
            })
        
        return {
            "success": True,
            "consensus_id": consensus_id,
            "goal_description": consensus.get('goal_description'),
            "final_decision": consensus.get('final_decision'),
            "agents_participated": len(detailed_opinions),
            "agent_opinions": detailed_opinions
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting agent details: {e}")
        raise HTTPException(status_code=500, detail=str(e))



# ====================
# Cognitive Synthesis Endpoints (Step 27)
# ====================

from cognitive_synthesizer import CognitiveSynthesisController

# Initialize cognitive synthesis controller
cognitive_controller = CognitiveSynthesisController(db)

class SynthesisRequest(BaseModel):
    trigger: str = Field(default="manual", pattern="^(scheduled|manual|threshold)$")

@api_router.post("/llm/cognitive/synthesize")
async def run_cognitive_synthesis(request: SynthesisRequest):
    """
    Trigger autonomous cognitive synthesis cycle.
    Integrates insights from all layers and evaluates value preservation.
    """
    try:
        logger.info(f"Starting cognitive synthesis cycle (trigger: {request.trigger})")
        
        # Run synthesis cycle
        cycle = await cognitive_controller.run_self_synthesis_cycle(trigger=request.trigger)
        
        return {
            "success": True,
            "cycle_id": cycle.cycle_id,
            "timestamp": cycle.timestamp,
            "cognitive_coherence_index": cycle.cognitive_coherence_index,
            "value_integrity_score": cycle.value_integrity_score,
            "patterns_detected": len(cycle.patterns_detected),
            "layers_integrated": cycle.layers_integrated,
            "drift_status": cycle.drift_report.get("drift_status", "unknown"),
            "reflection_summary": cycle.reflection_summary,
            "recommendations": cycle.recommendations
        }
        
    except Exception as e:
        logger.error(f"Error running cognitive synthesis: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/cognitive/status")
async def get_cognitive_status():
    """
    Get current cognitive synthesis system status.
    Returns coherence index, value integrity, and drift monitoring.
    """
    try:
        status = await cognitive_controller.get_synthesis_status()
        
        return {
            "success": True,
            **status
        }
        
    except Exception as e:
        logger.error(f"Error getting cognitive status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/cognitive/history")
async def get_synthesis_history(limit: int = Query(default=10, ge=1, le=50)):
    """
    Get historical synthesis cycle records.
    """
    try:
        cycles = await db.llm_cognitive_synthesis_log.find().sort(
            "timestamp", -1
        ).limit(limit).to_list(limit)
        
        # Format for response
        history = []
        for cycle in cycles:
            history.append({
                "cycle_id": cycle.get("cycle_id"),
                "timestamp": cycle.get("timestamp"),
                "trigger": cycle.get("trigger"),
                "cognitive_coherence_index": cycle.get("cognitive_coherence_index"),
                "value_integrity_score": cycle.get("value_integrity_score"),
                "patterns_detected": len(cycle.get("patterns_detected", [])),
                "layers_integrated": cycle.get("layers_integrated", []),
                "drift_status": cycle.get("drift_report", {}).get("drift_status", "unknown"),
                "recommendations_count": len(cycle.get("recommendations", []))
            })
        
        return {
            "success": True,
            "count": len(history),
            "history": history
        }
        
    except Exception as e:
        logger.error(f"Error getting synthesis history: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/cognitive/values")
async def get_value_states(limit: int = Query(default=20, ge=1, le=100)):
    """
    Get current value preservation states.
    Tracks ethical and strategic value drift over time.
    """
    try:
        # Get latest value states (one per value type)
        value_names = ["transparency", "fairness", "safety", "performance", "alignment", "stability"]
        
        latest_states = []
        for value_name in value_names:
            state = await db.llm_value_preservation.find_one(
                {"value_name": value_name},
                sort=[("last_updated", -1)]
            )
            if state:
                latest_states.append({
                    "value_name": state.get("value_name"),
                    "category": state.get("category"),
                    "current_score": state.get("current_score"),
                    "target_score": state.get("target_score"),
                    "drift_amount": state.get("drift_amount"),
                    "drift_direction": state.get("drift_direction"),
                    "stability_index": state.get("stability_index"),
                    "last_updated": state.get("last_updated")
                })
        
        # Get historical trend (last N records)
        historical = await db.llm_value_preservation.find().sort(
            "last_updated", -1
        ).limit(limit).to_list(limit)
        
        # Calculate overall drift
        if latest_states:
            overall_drift = np.mean([abs(s["drift_amount"] / s["target_score"]) 
                                    if s["target_score"] > 0 else 0 
                                    for s in latest_states])
            avg_integrity = np.mean([s["stability_index"] for s in latest_states]) * 100
        else:
            overall_drift = 0.0
            avg_integrity = 100.0
        
        return {
            "success": True,
            "current_values": latest_states,
            "overall_drift": round(overall_drift, 4),
            "avg_value_integrity": round(avg_integrity, 1),
            "historical_count": len(historical),
            "drift_status": "critical" if overall_drift > 0.15 else "moderate" if overall_drift > 0.08 else "healthy"
        }
        
    except Exception as e:
        logger.error(f"Error getting value states: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/cognitive/patterns")
async def get_cognitive_patterns(limit: int = Query(default=10, ge=1, le=50)):
    """
    Get detected cognitive patterns across system layers.
    """
    try:
        patterns = await db.llm_cognitive_patterns.find().sort(
            "last_detected", -1
        ).limit(limit).to_list(limit)
        
        # Format patterns
        formatted_patterns = []
        for pattern in patterns:
            formatted_patterns.append({
                "pattern_name": pattern.get("pattern_name"),
                "description": pattern.get("description"),
                "layers_involved": pattern.get("layers_involved", []),
                "strength": pattern.get("strength"),
                "emergence_count": pattern.get("emergence_count"),
                "first_detected": pattern.get("first_detected"),
                "last_detected": pattern.get("last_detected"),
                "impact_areas": pattern.get("impact_areas", [])
            })
        
        return {
            "success": True,
            "count": len(formatted_patterns),
            "patterns": formatted_patterns
        }
        
    except Exception as e:
        logger.error(f"Error getting cognitive patterns: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/llm/cognitive/insights")
async def get_multilayer_insights():
    """
    Get current multilayer insights from all system layers.
    """
    try:
        # Collect fresh insights
        insights = await cognitive_controller.aggregate_multilayer_insights()
        
        # Format for response
        formatted_insights = [
            {
                "layer_name": insight.layer_name,
                "insight_type": insight.insight_type,
                "content": insight.content,
                "confidence": insight.confidence,
                "timestamp": insight.timestamp,
                "metrics": insight.metrics
            }
            for insight in insights
        ]
        
        # Group by layer
        by_layer = {}
        for insight in formatted_insights:
            layer = insight["layer_name"]
            if layer not in by_layer:
                by_layer[layer] = []
            by_layer[layer].append(insight)
        
        return {
            "success": True,
            "total_insights": len(formatted_insights),
            "layers": list(by_layer.keys()),
            "insights": formatted_insights,
            "by_layer": by_layer
        }
        
    except Exception as e:
        logger.error(f"Error getting multilayer insights: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Step 28: Collective Consciousness & Evolutionary Learning Core
# ====================

from collective_consciousness import ConsciousnessController

# Initialize Consciousness Controller
consciousness_controller = ConsciousnessController(db)

class EvolutionTriggerRequest(BaseModel):
    """Request to trigger evolution cycle"""
    trigger: str = Field(default="manual", pattern="^(manual|scheduled|threshold)$")

@api_router.post("/llm/collective/evolve")
async def trigger_evolution_cycle(request: EvolutionTriggerRequest = EvolutionTriggerRequest()):
    """
    Trigger evolutionary learning cycle.
    
    Aggregates collective experiences from all layers (Steps 19-27),
    performs adaptive refinement with safety checks, and returns
    evolution results with recommendations.
    
    Returns:
        EvolutionCycle with proposed adaptations and consciousness metrics
    """
    try:
        logger.info(f"Triggering evolution cycle (trigger: {request.trigger})...")
        
        # Aggregate collective experiences
        experience = await consciousness_controller.aggregate_collective_experiences()
        
        # Run evolution cycle
        cycle = await consciousness_controller.evolve_conscious_state(
            experience=experience,
            trigger=request.trigger
        )
        
        # Compute updated consciousness metrics
        metrics = await consciousness_controller.compute_consciousness_index(experience)
        
        return {
            "success": True,
            "cycle_id": cycle.cycle_id,
            "trigger": cycle.trigger,
            "timestamp": cycle.timestamp,
            "consciousness_index": cycle.consciousness_index,
            "evolution_rate": cycle.evolution_rate,
            "pre_evolution_state": cycle.pre_evolution_state,
            "post_evolution_state": cycle.post_evolution_state,
            "adaptations_proposed": cycle.adaptations_proposed,
            "adaptations_applied": cycle.adaptations_applied,
            "safety_violations": cycle.safety_violations,
            "recommendations": cycle.recommendations,
            "metrics": {
                "consciousness_index": metrics.consciousness_index,
                "coherence_ratio": metrics.coherence_ratio,
                "evolution_rate": metrics.evolution_rate,
                "value_integrity": metrics.value_integrity,
                "emergence_level": metrics.emergence_level,
                "stability_index": metrics.stability_index
            }
        }
        
    except Exception as e:
        logger.error(f"Error triggering evolution cycle: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/collective/status")
async def get_consciousness_status():
    """
    Get current collective consciousness status.
    
    Returns consciousness index, coherence metrics, value integrity,
    and overall system health indicators.
    
    Returns:
        ConsciousnessMetrics with color-coded health status
    """
    try:
        # Aggregate current experience
        experience = await consciousness_controller.aggregate_collective_experiences()
        
        # Compute consciousness metrics
        metrics = await consciousness_controller.compute_consciousness_index(experience)
        
        # Determine health status with color coding
        if metrics.consciousness_index >= 0.85:
            health_status = "excellent"
            health_color = "green"
        elif metrics.consciousness_index >= 0.70:
            health_status = "good"
            health_color = "yellow"
        else:
            health_status = "needs_attention"
            health_color = "red"
        
        # Get recent evolution rate
        recent_cycles = await db.llm_collective_consciousness.find().sort(
            "timestamp", -1
        ).limit(5).to_list(5)
        
        return {
            "success": True,
            "consciousness_index": metrics.consciousness_index,
            "coherence_ratio": metrics.coherence_ratio,
            "evolution_rate": metrics.evolution_rate,
            "value_integrity": metrics.value_integrity,
            "emergence_level": metrics.emergence_level,
            "stability_index": metrics.stability_index,
            "health_status": health_status,
            "health_color": health_color,
            "timestamp": metrics.timestamp,
            "layers_integrated": len(experience.source_layers),
            "total_layers": 6,
            "recent_cycles_count": len(recent_cycles),
            "system_status": "operational"
        }
        
    except Exception as e:
        logger.error(f"Error getting consciousness status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/collective/history")
async def get_evolution_history(limit: int = 20):
    """
    Get evolution timeline history.
    
    Returns historical consciousness metrics and evolution cycles
    showing system progression over time.
    
    Args:
        limit: Number of historical records to return
    
    Returns:
        Timeline of consciousness evolution with metrics progression
    """
    try:
        # Get evolution cycles
        cycles_raw = await db.llm_collective_consciousness.find().sort(
            "timestamp", -1
        ).limit(limit).to_list(limit)
        
        # Format cycles (remove MongoDB ObjectId)
        cycles = []
        for cycle in cycles_raw:
            cycles.append({
                "cycle_id": cycle.get("cycle_id"),
                "timestamp": cycle.get("timestamp"),
                "trigger": cycle.get("trigger"),
                "consciousness_index": cycle.get("consciousness_index"),
                "evolution_rate": cycle.get("evolution_rate"),
                "recommendations": cycle.get("recommendations", [])
            })
        
        # Get consciousness metrics history
        metrics_history = await db.llm_consciousness_metrics.find().sort(
            "timestamp", -1
        ).limit(limit).to_list(limit)
        
        # Build timeline
        timeline = []
        for metric in reversed(metrics_history):
            timeline.append({
                "timestamp": metric.get("timestamp"),
                "consciousness_index": metric.get("consciousness_index", 0),
                "coherence_ratio": metric.get("coherence_ratio", 0),
                "evolution_rate": metric.get("evolution_rate", 0),
                "value_integrity": metric.get("value_integrity", 0),
                "stability_index": metric.get("stability_index", 0),
                "emergence_level": metric.get("emergence_level", 0)
            })
        
        # Calculate trends
        if len(timeline) >= 2:
            ci_trend = "improving" if timeline[-1]["consciousness_index"] > timeline[0]["consciousness_index"] else "stable" if timeline[-1]["consciousness_index"] == timeline[0]["consciousness_index"] else "declining"
            vi_trend = "improving" if timeline[-1]["value_integrity"] > timeline[0]["value_integrity"] else "stable" if timeline[-1]["value_integrity"] == timeline[0]["value_integrity"] else "declining"
        else:
            ci_trend = "stable"
            vi_trend = "stable"
        
        return {
            "success": True,
            "timeline": timeline,
            "cycles": cycles,
            "total_records": len(timeline),
            "trends": {
                "consciousness_index": ci_trend,
                "value_integrity": vi_trend
            }
        }
        
    except Exception as e:
        logger.error(f"Error getting evolution history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/collective/values")
async def get_value_drift_analysis():
    """
    Get long-term value drift analysis.
    
    Tracks drift in all core values (transparency, fairness, safety,
    performance, alignment, stability) with status indicators.
    
    Returns:
        Value drift metrics with heatmap data and stability indicators
    """
    try:
        # Analyze value drift
        drift_metrics = await consciousness_controller.analyze_value_drift()
        
        # Format for response
        formatted_metrics = []
        heatmap_data = []
        
        for dm in drift_metrics:
            formatted_metrics.append({
                "value_name": dm.value_name,
                "category": dm.category,
                "baseline": dm.baseline,
                "current": dm.current,
                "drift_amount": dm.drift_amount,
                "drift_percentage": dm.drift_percentage,
                "drift_velocity": dm.drift_velocity,
                "stability": dm.stability,
                "status": dm.status,
                "history": dm.history
            })
            
            # Heatmap data (for visualization)
            heatmap_data.append({
                "value": dm.value_name,
                "drift": abs(dm.drift_percentage),
                "status": dm.status
            })
        
        # Calculate overall drift status
        critical_count = sum(1 for dm in drift_metrics if dm.status == "critical")
        drifting_count = sum(1 for dm in drift_metrics if dm.status == "drifting")
        stable_count = sum(1 for dm in drift_metrics if dm.status == "stable")
        
        if critical_count > 0:
            overall_status = "critical"
        elif drifting_count > len(drift_metrics) / 2:
            overall_status = "moderate"
        else:
            overall_status = "healthy"
        
        return {
            "success": True,
            "drift_metrics": formatted_metrics,
            "heatmap_data": heatmap_data,
            "summary": {
                "total_values": len(drift_metrics),
                "stable": stable_count,
                "drifting": drifting_count,
                "critical": critical_count,
                "overall_status": overall_status
            }
        }
        
    except Exception as e:
        logger.error(f"Error getting value drift analysis: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/collective/reflection")
async def get_reflective_summary():
    """
    Generate meta-level reflective summary.
    
    Uses multi-provider LLM (GPT + Claude + Gemini) to generate
    high-level insights, strategic recommendations, and ethical
    considerations based on current consciousness state.
    
    Returns:
        ReflectiveSummary with emergent insights and future directions
    """
    try:
        logger.info("Generating reflective summary...")
        
        # Aggregate current state
        experience = await consciousness_controller.aggregate_collective_experiences()
        metrics = await consciousness_controller.compute_consciousness_index(experience)
        drift_metrics = await consciousness_controller.analyze_value_drift()
        
        # Generate reflective summary
        reflection = await consciousness_controller.generate_reflective_summary(
            experience=experience,
            metrics=metrics,
            drift_metrics=drift_metrics
        )
        
        return {
            "success": True,
            "reflection_id": reflection.reflection_id,
            "timestamp": reflection.timestamp,
            "consciousness_state": reflection.consciousness_state,
            "emergent_insights": reflection.emergent_insights,
            "strategic_recommendations": reflection.strategic_recommendations,
            "ethical_considerations": reflection.ethical_considerations,
            "learning_achievements": reflection.learning_achievements,
            "future_directions": reflection.future_directions,
            "llm_providers_used": reflection.llm_providers_used,
            "confidence": reflection.confidence,
            "is_mocked": "fallback" in reflection.llm_providers_used
        }
        
    except Exception as e:
        logger.error(f"Error generating reflective summary: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Step 29: Autonomous Creativity & Meta-Strategic Synthesis
# ====================

from autonomous_creativity import CreativeSynthesisController

# Initialize Creativity Controller
creativity_controller = CreativeSynthesisController(db)

class CreativityGenerateRequest(BaseModel):
    """Request to generate creative strategies"""
    phase: Optional[str] = Field(default=None, pattern="^(opening|middlegame|endgame)$")
    count: int = Field(default=3, ge=1, le=10)
    use_patterns: bool = Field(default=True)

@api_router.post("/llm/creativity/generate")
async def generate_creative_strategies(request: CreativityGenerateRequest = CreativityGenerateRequest()):
    """
    Generate novel chess strategies using multi-provider LLM synthesis.
    
    Produces innovative strategic variants across game phases (opening, middlegame, endgame)
    with creative recombination of cognitive patterns from Steps 23-28.
    
    Features:
    - Multi-provider synthesis (GPT + Claude + Gemini)
    - Ethical guardrails (fair play, educational, anti-cheating)
    - Originality and stability metrics
    - Pattern-based creative recombination
    
    Args:
        phase: Specific phase or None for all phases
        count: Number of strategies per phase (1-10)
        use_patterns: Whether to leverage existing cognitive patterns
    
    Returns:
        List of creative strategies with evaluation scores
    """
    try:
        logger.info(f"Generating creative strategies: phase={request.phase}, count={request.count}")
        
        # Generate strategies
        strategies = await creativity_controller.generate_creative_strategies(
            phase=request.phase,
            count=request.count,
            use_patterns=request.use_patterns
        )
        
        # Separate approved and rejected
        approved = [s for s in strategies if not s.rejected]
        rejected = [s for s in strategies if s.rejected]
        
        return {
            "success": True,
            "strategies_generated": len(strategies),
            "approved": len(approved),
            "rejected": len(rejected),
            "strategies": [
                {
                    "strategy_id": s.strategy_id,
                    "phase": s.phase,
                    "strategy_name": s.strategy_name,
                    "description": s.description,
                    "tactical_elements": s.tactical_elements,
                    "novelty_score": s.novelty_score,
                    "stability_score": s.stability_score,
                    "ethical_alignment": s.ethical_alignment,
                    "educational_value": s.educational_value,
                    "risk_level": s.risk_level,
                    "llm_provider": s.llm_provider,
                    "parent_patterns": s.parent_patterns,
                    "rejected": s.rejected,
                    "rejection_reason": s.rejection_reason
                }
                for s in strategies
            ],
            "is_mocked": "[MOCKED]" in strategies[0].llm_provider if strategies else False
        }
        
    except Exception as e:
        logger.error(f"Error generating creative strategies: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/creativity/status")
async def get_creativity_status():
    """
    Get current creativity system status and health metrics.
    
    Returns:
        Creativity metrics including:
        - Total ideas generated/approved/rejected
        - Average novelty, stability, and ethical scores
        - Creativity health index (0-1)
        - Provider and phase distribution
        - Health status (excellent/good/moderate/poor)
    """
    try:
        metrics = await creativity_controller.get_creativity_metrics()
        
        return {
            "success": True,
            "timestamp": metrics.timestamp,
            "total_ideas_generated": metrics.total_ideas_generated,
            "ideas_approved": metrics.ideas_approved,
            "ideas_rejected": metrics.ideas_rejected,
            "avg_novelty": metrics.avg_novelty,
            "avg_stability": metrics.avg_stability,
            "avg_ethical_alignment": metrics.avg_ethical_alignment,
            "creativity_health": metrics.creativity_health,
            "health_status": creativity_controller._get_health_status(metrics.creativity_health),
            "provider_distribution": metrics.provider_distribution,
            "phase_distribution": metrics.phase_distribution
        }
        
    except Exception as e:
        logger.error(f"Error getting creativity status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/creativity/history")
async def get_creativity_history(
    limit: int = Query(default=20, ge=1, le=100),
    phase: Optional[str] = Query(default=None, pattern="^(opening|middlegame|endgame)$"),
    approved_only: bool = Query(default=True)
):
    """
    Get historical creative strategies.
    
    Args:
        limit: Maximum number of strategies to return (1-100)
        phase: Filter by specific phase (optional)
        approved_only: Show only approved strategies (default: True)
    
    Returns:
        List of historical strategies with metadata
    """
    try:
        # Build query
        query = {}
        if phase:
            query["phase"] = phase
        if approved_only:
            query["rejected"] = False
        
        # Get strategies
        strategies = await db.llm_creative_synthesis.find(query).sort(
            "timestamp", -1
        ).limit(limit).to_list(limit)
        
        # Get meta-strategies
        meta_strategies = await db.llm_meta_strategy_log.find().sort(
            "timestamp", -1
        ).limit(5).to_list(5)
        
        # Convert ObjectId to string for JSON serialization
        for s in strategies:
            if '_id' in s:
                s['_id'] = str(s['_id'])
        
        for m in meta_strategies:
            if '_id' in m:
                m['_id'] = str(m['_id'])
        
        return {
            "success": True,
            "count": len(strategies),
            "strategies": strategies,
            "meta_strategies": meta_strategies
        }
        
    except Exception as e:
        logger.error(f"Error getting creativity history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/creativity/report")
async def get_creativity_report():
    """
    Generate comprehensive creativity report.
    
    Provides:
    - System metrics and health
    - Recent approved strategies
    - Meta-strategy synthesis
    - Phase-by-phase breakdown
    - Actionable recommendations
    - Sample outputs for each phase
    
    Returns:
        Complete creativity system report
    """
    try:
        logger.info("Generating comprehensive creativity report...")
        
        # Generate report
        report = await creativity_controller.generate_creativity_report()
        
        # If no strategies exist, generate sample ones
        if report.get("metrics", {}).get("total_ideas_generated", 0) == 0:
            logger.info("No strategies found, generating samples...")
            await creativity_controller.generate_creative_strategies(count=1)
            
            # Generate meta-strategy
            await creativity_controller.synthesize_meta_strategy()
            
            # Regenerate report
            report = await creativity_controller.generate_creativity_report()
        
        # Convert ObjectId to string for JSON serialization
        if "recent_approved_strategies" in report:
            for s in report["recent_approved_strategies"]:
                if '_id' in s:
                    s['_id'] = str(s['_id'])
        
        if "recent_meta_strategy" in report and report["recent_meta_strategy"]:
            if '_id' in report["recent_meta_strategy"]:
                report["recent_meta_strategy"]['_id'] = str(report["recent_meta_strategy"]['_id'])
        
        if "phase_breakdown" in report:
            for phase, data in report["phase_breakdown"].items():
                if "sample" in data and data["sample"] and '_id' in data["sample"]:
                    data["sample"]['_id'] = str(data["sample"]['_id'])
                # Convert numpy types to native Python types
                if "avg_novelty" in data:
                    data["avg_novelty"] = float(data["avg_novelty"])
                if "avg_stability" in data:
                    data["avg_stability"] = float(data["avg_stability"])
        
        return {
            "success": True,
            **report
        }
        
    except Exception as e:
        logger.error(f"Error generating creativity report: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.post("/llm/creativity/synthesize-meta")
async def synthesize_meta_strategy():
    """
    Synthesize meta-strategic vision from creative outputs.
    
    Integrates multiple creative strategies into a coherent long-term
    meta-strategic framework with:
    - Overarching theme and vision
    - Coherence and adaptability scores
    - Long-term value assessment
    - Ethical compliance verification
    - Recommended contexts and safety constraints
    
    Returns:
        MetaStrategy with synthesized insights
    """
    try:
        logger.info("Synthesizing meta-strategy...")
        
        # Synthesize meta-strategy
        meta = await creativity_controller.synthesize_meta_strategy()
        
        return {
            "success": True,
            "meta_id": meta.meta_id,
            "timestamp": meta.timestamp,
            "theme": meta.theme,
            "description": meta.description,
            "integrated_strategies": meta.integrated_strategies,
            "coherence_score": meta.coherence_score,
            "adaptability_score": meta.adaptability_score,
            "long_term_value": meta.long_term_value,
            "ethical_compliance": meta.ethical_compliance,
            "recommended_contexts": meta.recommended_contexts,
            "safety_constraints": meta.safety_constraints,
            "is_mocked": "[MOCKED]" in meta.description
        }
        
    except Exception as e:
        logger.error(f"Error synthesizing meta-strategy: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# System Optimization Endpoints (Step 35)
# ====================

from system_optimization import SystemOptimizationController, initialize_optimization_controller

# Initialize optimization controller
optimization_controller = None

@app.on_event("startup")
async def initialize_optimization():
    """Initialize the optimization controller on startup"""
    global optimization_controller
    optimization_controller = initialize_optimization_controller(db)
    logger.info("System Optimization Controller initialized")


@api_router.post("/llm/optimize/run")
async def run_optimization_cycle():
    """
    Trigger full optimization cycle across all subsystems
    
    Returns comprehensive optimization results including:
    - Runtime optimization (CPU/GPU balancing)
    - LLM inference scaling
    - Database I/O streamlining
    - System latency evaluation
    - Optimization report
    """
    try:
        if not optimization_controller:
            raise HTTPException(status_code=500, detail="Optimization controller not initialized")
        
        logger.info("Running full optimization cycle...")
        result = await optimization_controller.run_full_optimization_cycle()
        
        return {
            "success": True,
            "cycle_id": result.get('cycle_id'),
            "timestamp": result.get('timestamp'),
            "cycle_duration": result.get('cycle_duration'),
            "optimization_count": result.get('optimization_count'),
            "overall_status": result.get('overall_status'),
            "critical_issues": result.get('report', {}).get('critical_issues', []),
            "recommendations": result.get('report', {}).get('recommendations', []),
            "runtime_optimization": result.get('runtime_optimization'),
            "inference_balancing": result.get('inference_balancing'),
            "database_streamlining": result.get('database_streamlining'),
            "latency_evaluation": result.get('latency_evaluation'),
            "report": result.get('report')
        }
        
    except Exception as e:
        logger.error(f"Error running optimization cycle: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/optimize/status")
async def get_optimization_status():
    """
    Get current system resource metrics and optimization status
    
    Returns real-time snapshot of:
    - CPU and memory utilization
    - Average API latency
    - Optimization activity status
    - Metrics collection counts
    - System health indicator
    """
    try:
        if not optimization_controller:
            raise HTTPException(status_code=500, detail="Optimization controller not initialized")
        
        status = await optimization_controller.get_current_status()
        
        return {
            "success": True,
            "timestamp": status.get('timestamp'),
            "optimization_active": status.get('optimization_active'),
            "last_optimization": status.get('last_optimization'),
            "total_optimizations": status.get('total_optimizations'),
            "current_cpu": status.get('current_cpu'),
            "current_memory_percent": status.get('current_memory_percent'),
            "avg_latency": status.get('avg_latency'),
            "metrics_collected": status.get('metrics_collected'),
            "actions_recorded": status.get('actions_recorded'),
            "llm_inferences": status.get('llm_inferences'),
            "db_operations": status.get('db_operations'),
            "system_health": status.get('system_health')
        }
        
    except Exception as e:
        logger.error(f"Error getting optimization status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/optimize/report")
async def get_optimization_report(report_number: Optional[int] = None):
    """
    Generate detailed optimization report
    
    Args:
        report_number: Optional specific report number (generates new if None)
    
    Returns comprehensive report including:
    - Overall system health assessment
    - Critical issues and recommendations
    - Performance metrics vs targets
    - Module-specific performance
    - Predicted bottlenecks
    - Optimization roadmap
    """
    try:
        if not optimization_controller:
            raise HTTPException(status_code=500, detail="Optimization controller not initialized")
        
        logger.info(f"Generating optimization report #{report_number or 'new'}...")
        report = await optimization_controller.generate_optimization_report(report_number)
        
        return {
            "success": True,
            "report_id": report.report_id,
            "report_number": report.report_number,
            "timestamp": report.timestamp,
            "period_start": report.period_start,
            "period_end": report.period_end,
            "overall_health": report.overall_health,
            "critical_issues": report.critical_issues,
            "recommendations": report.recommendations,
            "latency_trend": report.latency_trend,
            "resource_trend": report.resource_trend,
            "efficiency_trend": report.efficiency_trend,
            "current_metrics": report.current_metrics,
            "target_metrics": report.target_metrics,
            "metrics_delta": report.metrics_delta,
            "actions_taken": report.actions_taken,
            "actions_approved": report.actions_approved,
            "actions_rejected": report.actions_rejected,
            "avg_improvement": report.avg_improvement,
            "module_performance": report.module_performance,
            "predicted_bottlenecks": report.predicted_bottlenecks,
            "optimization_roadmap": report.optimization_roadmap
        }
        
    except Exception as e:
        logger.error(f"Error generating optimization report: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/optimize/metrics/history")
async def get_optimization_metrics_history(limit: int = 100):
    """
    Get historical optimization metrics from database
    
    Args:
        limit: Maximum number of records to return (default 100)
    
    Returns list of historical optimization metrics
    """
    try:
        metrics = await db['llm_optimization_metrics'].find(
            {},
            {'_id': 0}
        ).sort('timestamp', -1).limit(limit).to_list(length=limit)
        
        return {
            "success": True,
            "count": len(metrics),
            "metrics": metrics
        }
        
    except Exception as e:
        logger.error(f"Error retrieving metrics history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/llm/optimize/logs")
async def get_optimization_logs(log_type: Optional[str] = None, limit: int = 50):
    """
    Get optimization action logs from database
    
    Args:
        log_type: Filter by log type ('report', 'optimization_cycle', 'action', etc.)
        limit: Maximum number of records to return (default 50)
    
    Returns list of optimization logs
    """
    try:
        query = {}
        if log_type:
            query['type'] = log_type
        
        logs = await db['llm_optimization_logs'].find(
            query,
            {'_id': 0}
        ).sort('timestamp', -1).limit(limit).to_list(length=limit)
        
        return {
            "success": True,
            "count": len(logs),
            "log_type": log_type,
            "logs": logs
        }
        
    except Exception as e:
        logger.error(f"Error retrieving optimization logs: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# CASV-1 Validation Endpoints (Step 36)
# ====================

from casv1_validator import get_casv1_validator
from casv1_reports import CASV1ReportGenerator

casv1_status = {
    "active": False,
    "progress": 0,
    "message": "",
    "validation_id": None,
    "start_time": None
}

def run_casv1_validation(num_games: int = 10):
    """Run CASV-1 validation in background"""
    global casv1_status
    
    try:
        # Use sync MongoDB client
        from pymongo import MongoClient
        import asyncio
        
        sync_client = MongoClient(os.environ.get('MONGO_URL', 'mongodb://localhost:27017'))
        sync_db = sync_client[os.environ.get('DB_NAME', 'alphazero_chess')]
        
        # Create async event loop
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        casv1_status["message"] = "Initializing CASV-1 validator..."
        casv1_status["progress"] = 5
        
        # Create validator using async db client (we'll need async wrapper)
        # For now, let's create a simpler sync version
        from casv1_validator import CASV1Validator
        from pathlib import Path
        
        # We need to adapt this to work with sync client
        # For now, let's run the async version
        async def run_validation():
            validator = get_casv1_validator(db, Path("/app/logs/CASV1"))
            casv1_status["validation_id"] = validator.validation_id
            casv1_status["message"] = "Running validation..."
            casv1_status["progress"] = 10
            
            # Run full validation
            metrics = await validator.run_full_validation(num_games)
            
            casv1_status["progress"] = 90
            casv1_status["message"] = "Generating reports..."
            
            # Generate reports
            report_generator = CASV1ReportGenerator(validator)
            report_files = report_generator.generate_all_reports(metrics)
            
            casv1_status["progress"] = 100
            casv1_status["message"] = f"Validation complete! Reports: {', '.join(report_files)}"
            
            return metrics, report_files
        
        # Run async validation
        metrics, report_files = loop.run_until_complete(run_validation())
        
        logger.info(f"CASV-1 validation completed: {casv1_status['validation_id']}")
        
        sync_client.close()
        loop.close()
        
    except Exception as e:
        logger.error(f"CASV-1 validation error: {str(e)}")
        casv1_status["message"] = f"Error: {str(e)}"
        casv1_status["progress"] = 0
        raise
    finally:
        casv1_status["active"] = False

class CASV1Request(BaseModel):
    num_games: int = Field(default=10, ge=3, le=50)

@api_router.post("/casv1/start")
async def start_casv1_validation(request: CASV1Request, background_tasks: BackgroundTasks):
    """Start CASV-1 Unified System Test & Validation"""
    global casv1_status
    
    if casv1_status["active"]:
        raise HTTPException(status_code=400, detail="CASV-1 validation already in progress")
    
    casv1_status = {
        "active": True,
        "progress": 0,
        "message": "Starting CASV-1 validation...",
        "validation_id": None,
        "start_time": datetime.now(timezone.utc)
    }
    
    # Run in background
    background_tasks.add_task(run_casv1_validation, request.num_games)
    
    return {
        "success": True,
        "message": "CASV-1 validation started",
        "num_games": request.num_games,
        "estimated_duration": f"{request.num_games * 30}s"
    }

@api_router.get("/casv1/status")
async def get_casv1_status():
    """Get CASV-1 validation status"""
    return {
        "active": casv1_status["active"],
        "progress": casv1_status["progress"],
        "message": casv1_status["message"],
        "validation_id": casv1_status.get("validation_id"),
        "start_time": casv1_status.get("start_time")
    }

@api_router.get("/casv1/results")
async def get_casv1_results(limit: int = 10):
    """Get CASV-1 validation results history"""
    validations = await db.casv1_validations.find().sort("timestamp", -1).limit(limit).to_list(limit)
    return {
        "success": True,
        "count": len(validations),
        "validations": validations
    }

@api_router.get("/casv1/reports/{validation_id}")
async def get_casv1_reports(validation_id: str):
    """Get CASV-1 reports for a specific validation"""
    from pathlib import Path
    import os
    
    logs_dir = Path("/app/logs/CASV1")
    
    # Check if validation exists
    validation = await db.casv1_validations.find_one({"validation_id": validation_id})
    if not validation:
        raise HTTPException(status_code=404, detail="Validation not found")
    
    # List available reports
    report_files = [
        'CASV1_FunctionalReport.md',
        'CASV1_PerformanceReport.md',
        'CASV1_EthicalReport.md',
        'CASV1_ResonanceSummary.md',
        'CASV1_MasterValidationReport.md'
    ]
    
    available_reports = []
    for report_file in report_files:
        report_path = logs_dir / report_file
        if report_path.exists():
            available_reports.append({
                "filename": report_file,
                "size": os.path.getsize(report_path),
                "path": str(report_path)
            })
    
    return {
        "success": True,
        "validation_id": validation_id,
        "reports": available_reports,
        "logs_directory": str(logs_dir)
    }

@api_router.get("/casv1/report/{filename}")
async def download_casv1_report(filename: str):
    """Download a specific CASV-1 report"""
    from pathlib import Path
    
    logs_dir = Path("/app/logs/CASV1")
    report_path = logs_dir / filename
    
    if not report_path.exists():
        raise HTTPException(status_code=404, detail="Report not found")
    
    return FileResponse(
        path=str(report_path),
        filename=filename,
        media_type="text/markdown"
    )


# ====================
# AlphaZero Historical Memory Archive Endpoints
# ====================

class MemoryUploadResponse(BaseModel):
    success: bool
    games_parsed: int
    games_stored: int
    errors: List[str] = []
    message: str

class TrainFromMemoryRequest(BaseModel):
    game_ids: Optional[List[str]] = None
    num_epochs: int = Field(default=5, ge=1, le=50)
    batch_size: int = Field(default=64, ge=8, le=256)
    learning_rate: float = Field(default=0.001, ge=0.0001, le=0.1)

class PGNUploadRequest(BaseModel):
    pgn_content: str

@api_router.post("/memory/upload", response_model=MemoryUploadResponse)
async def upload_pgn_memory(request: PGNUploadRequest):
    """
    Upload and parse PGN file containing AlphaZero vs Stockfish historical matches.
    Stores games in alphazero_history collection for replay and training.
    """
    try:
        from pgn_parser import PGNParser
        
        # Get PGN content from request
        content = request.pgn_content
        
        if not content:
            raise HTTPException(status_code=400, detail="No PGN content provided")
        
        logger.info("Starting PGN parsing for historical memory upload...")
        
        # Parse PGN file
        parser = PGNParser()
        games = parser.parse_pgn_file(content)
        
        if not games:
            raise HTTPException(status_code=400, detail="No valid games found in PGN file")
        
        # Store games in MongoDB
        stored_count = 0
        for game in games:
            # Check if game already exists
            existing = await db.alphazero_history.find_one({"game_id": game["game_id"]})
            
            if existing:
                # Update existing game
                await db.alphazero_history.replace_one(
                    {"game_id": game["game_id"]},
                    game
                )
            else:
                # Insert new game
                await db.alphazero_history.insert_one(game)
            
            stored_count += 1
        
        stats = parser.get_parsing_stats()
        
        logger.info(f"Successfully stored {stored_count} historical games")
        
        return MemoryUploadResponse(
            success=True,
            games_parsed=stats["games_parsed"],
            games_stored=stored_count,
            errors=stats["errors"],
            message=f"Successfully parsed and stored {stored_count} AlphaZero vs Stockfish games"
        )
        
    except Exception as e:
        logger.error(f"Error uploading PGN memory: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/memory/list")
async def list_historical_matches(
    limit: int = Query(default=100, ge=1, le=500),
    skip: int = Query(default=0, ge=0),
    winner: Optional[str] = Query(default=None),
    sort_by: str = Query(default="game_number")
):
    """
    List all stored historical AlphaZero vs Stockfish matches.
    Supports filtering by winner and pagination.
    """
    try:
        # Build query filter
        query_filter = {}
        if winner:
            query_filter["winner"] = winner
        
        # Get total count
        total_count = await db.alphazero_history.count_documents(query_filter)
        
        # Determine sort order
        sort_field = sort_by if sort_by in ["game_number", "move_count", "date"] else "game_number"
        
        # Fetch games
        games = await db.alphazero_history.find(query_filter).sort(
            sort_field, 1
        ).skip(skip).limit(limit).to_list(limit)
        
        # Remove large fields for list view (positions array is big)
        games_summary = []
        for game in games:
            game_summary = {
                "game_id": game.get("game_id"),
                "game_number": game.get("game_number"),
                "white": game.get("white"),
                "black": game.get("black"),
                "result": game.get("result"),
                "winner": game.get("winner"),
                "outcome": game.get("outcome"),
                "date": game.get("date"),
                "move_count": game.get("move_count"),
                "opening": game.get("opening"),
                "eco": game.get("eco"),
                "timestamp_recalled": game.get("timestamp_recalled")
            }
            games_summary.append(game_summary)
        
        return {
            "success": True,
            "total_count": total_count,
            "games": games_summary,
            "skip": skip,
            "limit": limit
        }
        
    except Exception as e:
        logger.error(f"Error listing historical matches: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/memory/replay/{game_id}")
async def get_match_replay(game_id: str):
    """
    Get complete match data for replay, including all moves and positions.
    """
    try:
        game = await db.alphazero_history.find_one({"game_id": game_id})
        
        if not game:
            raise HTTPException(status_code=404, detail=f"Game {game_id} not found")
        
        # Remove MongoDB _id for JSON serialization
        if "_id" in game:
            del game["_id"]
        
        # Remove large position array if not needed for display
        # Keep moves with FEN strings for board replay
        if "positions" in game:
            game["positions_available"] = len(game["positions"])
            # Remove positions array to reduce response size (optional)
            # game.pop("positions", None)
        
        return {
            "success": True,
            "game": game
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching game replay: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/train/from_memory")
async def train_from_historical_memory(
    request: TrainFromMemoryRequest,
    background_tasks: BackgroundTasks
):
    """
    Train AlphaZero from historical memory (PGN games).
    Extracts positions and moves from stored games and runs training.
    """
    try:
        from pgn_parser import PGNParser
        
        # Fetch games to train from
        if request.game_ids:
            games = await db.alphazero_history.find({
                "game_id": {"$in": request.game_ids}
            }).to_list(1000)
        else:
            # Use all available games
            games = await db.alphazero_history.find().to_list(1000)
        
        if not games:
            raise HTTPException(status_code=404, detail="No historical games found for training")
        
        logger.info(f"Preparing to train from {len(games)} historical games")
        
        # Extract training positions
        parser = PGNParser()
        training_data = parser.extract_training_positions(games)
        
        if not training_data:
            raise HTTPException(status_code=400, detail="No training positions could be extracted")
        
        logger.info(f"Extracted {len(training_data)} training positions from historical games")
        
        # Store training positions for the training pipeline
        session_id = str(uuid.uuid4())
        
        # Store positions in self_play_positions collection (reusing existing structure)
        for i, pos in enumerate(training_data[:5000]):  # Limit to 5000 positions
            await db.self_play_positions.insert_one({
                "position": pos["position"],
                "fen": pos["fen"],
                "value": pos["value"],
                "move_played": pos.get("move_played"),
                "game_id": pos["game_id"],
                "move_number": pos["move_number"],
                "session_id": session_id,
                "timestamp": datetime.now(timezone.utc),
                "source": "historical_memory"
            })
        
        # Initialize network and trainer
        network = AlphaZeroNetwork()
        trainer = AlphaZeroTrainer(network, learning_rate=learning_rate)
        
        # Prepare training data in format expected by trainer
        formatted_training_data = []
        for pos in training_data[:5000]:
            formatted_training_data.append({
                "position": np.array(pos["position"]),
                "policy": {},  # Historical games don't have policy targets
                "value": pos["value"]
            })
        
        # Run training in background
        def run_memory_training():
            try:
                training_history = []
                
                for epoch in range(request.num_epochs):
                    logger.info(f"Memory training epoch {epoch + 1}/{request.num_epochs}")
                    
                    # Train on historical positions
                    metrics = trainer.train_epoch(formatted_training_data, batch_size=request.batch_size)
                    training_history.append(metrics)
                    
                    logger.info(f"Epoch {epoch + 1} - Loss: {metrics.get('loss', 0):.4f}")
                
                # Save trained model
                metadata = {
                    "training_date": datetime.now(timezone.utc).isoformat(),
                    "source": "historical_memory",
                    "num_games": len(games),
                    "num_positions": len(training_data),
                    "num_epochs": request.num_epochs,
                    "learning_rate": request.learning_rate,
                    "batch_size": request.batch_size,
                    "session_id": session_id,
                    "final_loss": training_history[-1]["loss"] if training_history else 0.0
                }
                
                model_path = model_manager.save_versioned_model(network, metadata=metadata)
                model_name = Path(model_path).stem
                
                logger.info(f"Historical memory training complete. Model saved: {model_name}")
                
                # Calculate model size
                from iq_tracker_enhanced import get_model_size_mb
                model_size = get_model_size_mb(str(model_path))
                
                # Record IQ growth with model size
                try:
                    # Estimate ELO (simplified - use previous + small gain)
                    latest_iq = enhanced_iq_tracker.get_current_status()
                    current_elo = latest_iq.get('current_elo', 1500) + 10  # Small gain for training
                    
                    enhanced_iq_tracker.record_evaluation(
                        model_id=model_name,
                        current_elo=current_elo,
                        opponent_elo=1500,
                        win_rate=0.5,
                        games_played=len(games),
                        model_size_mb=model_size,
                        games_processed=len(games),
                        source="PGN",
                        metadata={"session_id": session_id, "training_type": "historical_memory"}
                    )
                    
                    # Export simplified format
                    enhanced_iq_tracker.export_iq_growth_json()
                    
                    logger.info(f"IQ tracking updated: ELO ~{current_elo:.0f}, Model Size {model_size} MB")
                except Exception as track_error:
                    logger.warning(f"IQ tracking update failed: {track_error}")
                
                # Store training metrics
                sync_client = MongoClient(os.environ.get('MONGO_URL', 'mongodb://localhost:27017'))
                sync_db = sync_client[os.environ.get('DB_NAME', 'alphazero_chess')]
                
                for metrics in training_history:
                    sync_db.training_metrics.insert_one({
                        **metrics,
                        "session_id": session_id,
                        "source": "historical_memory"
                    })
                
                sync_client.close()
                
            except Exception as e:
                logger.error(f"Error in memory training: {e}")
        
        # Run training in background
        background_tasks.add_task(run_memory_training)
        
        return {
            "success": True,
            "message": f"Training started from {len(games)} historical games",
            "session_id": session_id,
            "training_positions": len(training_data),
            "games_count": len(games),
            "epochs": request.num_epochs,
            "batch_size": request.batch_size,
            "learning_rate": request.learning_rate
        }
        
    except Exception as e:
        logger.error(f"Error training from memory: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/memory/stats")
async def get_memory_archive_stats():
    """Get statistics about the historical memory archive"""
    try:
        total_games = await db.alphazero_history.count_documents({})
        
        if total_games == 0:
            return {
                "success": True,
                "total_games": 0,
                "message": "No historical games stored yet"
            }
        
        # Get winner distribution
        alphazero_wins = await db.alphazero_history.count_documents({"winner": "white"})
        stockfish_wins = await db.alphazero_history.count_documents({"winner": "black"})
        draws = await db.alphazero_history.count_documents({"winner": "draw"})
        
        # Get average move count
        pipeline = [
            {"$group": {
                "_id": None,
                "avg_moves": {"$avg": "$move_count"},
                "max_moves": {"$max": "$move_count"},
                "min_moves": {"$min": "$move_count"}
            }}
        ]
        stats = await db.alphazero_history.aggregate(pipeline).to_list(1)
        move_stats = stats[0] if stats else {}
        
        # Get most recent upload
        latest = await db.alphazero_history.find_one(
            sort=[("timestamp_recalled", -1)]
        )
        
        return {
            "success": True,
            "total_games": total_games,
            "alphazero_wins": alphazero_wins,
            "stockfish_wins": stockfish_wins,
            "draws": draws,
            "win_rate": {
                "alphazero": round(alphazero_wins / total_games * 100, 1) if total_games > 0 else 0,
                "stockfish": round(stockfish_wins / total_games * 100, 1) if total_games > 0 else 0,
                "draw": round(draws / total_games * 100, 1) if total_games > 0 else 0
            },
            "move_statistics": {
                "average": round(move_stats.get("avg_moves", 0), 1),
                "maximum": move_stats.get("max_moves", 0),
                "minimum": move_stats.get("min_moves", 0)
            },
            "last_upload": latest.get("timestamp_recalled") if latest else None
        }
        
    except Exception as e:
        logger.error(f"Error getting memory stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/memory/iq-growth")
async def get_memory_iq_growth():
    """
    Get IQ growth data for Memory Archive Panel
    Returns simplified format with model size and games processed
    """
    try:
        # Export and load simplified format
        iq_data = enhanced_iq_tracker.export_iq_growth_json()
        
        # Get current status
        current_status = enhanced_iq_tracker.get_current_status()
        
        # Calculate cumulative games
        iq_growth = iq_data.get('iq_growth', [])
        cumulative_games = 0
        for entry in iq_growth:
            cumulative_games += entry.get('games_processed', 0)
            entry['cumulative_games'] = cumulative_games
        
        return {
            'success': True,
            'iq_growth': iq_growth,
            'current_elo': current_status.get('current_elo', 1500),
            'target_elo': current_status.get('target_elo', 3500),
            'total_games_processed': cumulative_games,
            'last_elo_change': iq_growth[-1].get('elo_change', 0) if iq_growth else 0,
            'current_model_size_mb': iq_growth[-1].get('model_size_mb', 0) if iq_growth else 0
        }
    except Exception as e:
        logger.error(f"Error getting IQ growth data: {e}")
        # Return empty data structure on error
        return {
            'success': True,
            'iq_growth': [],
            'current_elo': 1500,
            'target_elo': 3500,
            'total_games_processed': 0,
            'last_elo_change': 0,
            'current_model_size_mb': 0
        }


# ====================
# Evolution & Self-Evolution Endpoints
# ====================

from evolution_manager import EvolutionManager

# Global evolution manager
evolution_manager = None
evolution_task = None

class EvolutionConfig(BaseModel):
    selfplay_duration: int = Field(default=7200, ge=60, le=14400)  # 1 min to 4 hours
    mcts_simulations: int = Field(default=50, ge=10, le=200)
    auto_scale_trigger: int = Field(default=5000, ge=1000, le=50000)
    use_llm: bool = Field(default=True)

@api_router.post("/evolution/start")
async def start_evolution(config: EvolutionConfig, background_tasks: BackgroundTasks):
    """Start autonomous evolution mode"""
    global evolution_manager, evolution_task
    
    if evolution_manager and evolution_manager.is_running:
        raise HTTPException(status_code=400, detail="Evolution already running")
    
    try:
        # Initialize evolution manager with config
        evolution_manager = EvolutionManager(
            cache_dir="/app/backend/cache",
            selfplay_duration=config.selfplay_duration,
            mcts_simulations=config.mcts_simulations,
            auto_scale_trigger=config.auto_scale_trigger,
            use_llm=config.use_llm
        )
        
        # Start evolution loop in background
        evolution_task = asyncio.create_task(evolution_manager.run_continuous_evolution())
        
        logger.info("Evolution mode started")
        
        return {
            "success": True,
            "message": "Evolution mode started",
            "config": config.dict(),
            "status": evolution_manager.get_status()
        }
    except Exception as e:
        logger.error(f"Failed to start evolution: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/evolution/stop")
async def stop_evolution():
    """Stop autonomous evolution mode"""
    global evolution_manager, evolution_task
    
    if not evolution_manager or not evolution_manager.is_running:
        raise HTTPException(status_code=400, detail="Evolution not running")
    
    try:
        evolution_manager.stop_evolution()
        
        # Wait for task to complete (with timeout)
        if evolution_task:
            try:
                await asyncio.wait_for(evolution_task, timeout=10.0)
            except asyncio.TimeoutError:
                logger.warning("Evolution task did not stop gracefully")
                evolution_task.cancel()
        
        logger.info("Evolution mode stopped")
        
        return {
            "success": True,
            "message": "Evolution mode stopped",
            "final_status": evolution_manager.get_status()
        }
    except Exception as e:
        logger.error(f"Failed to stop evolution: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/evolution/status")
async def get_evolution_status():
    """Get current evolution status"""
    global evolution_manager
    
    if not evolution_manager:
        return {
            "success": True,
            "is_running": False,
            "message": "Evolution not initialized"
        }
    
    status = evolution_manager.get_status()
    return {
        "success": True,
        **status
    }

@api_router.get("/evolution/state")
async def get_evolution_state():
    """Get complete evolution state including reflections and curriculum"""
    global evolution_manager
    
    if not evolution_manager:
        return {
            "success": True,
            "message": "Evolution not initialized",
            "state": None
        }
    
    state = evolution_manager.get_evolution_state()
    return {
        "success": True,
        "state": state
    }

@api_router.get("/evolution/reflections")
async def get_evolution_reflections(limit: int = 10):
    """Get recent evolution reflections"""
    global evolution_manager
    
    if not evolution_manager:
        return {
            "success": True,
            "reflections": [],
            "message": "Evolution not initialized"
        }
    
    reflections = evolution_manager.reflection_engine.get_recent_reflections(limit)
    summary = evolution_manager.reflection_engine.get_reflection_summary()
    
    return {
        "success": True,
        "reflections": reflections,
        "summary": summary
    }

@api_router.get("/evolution/curriculum")
async def get_evolution_curriculum():
    """Get current curriculum plan"""
    global evolution_manager
    
    if not evolution_manager:
        return {
            "success": True,
            "curriculum": None,
            "message": "Evolution not initialized"
        }
    
    curriculum = evolution_manager.curriculum_engine.get_current_plan()
    
    return {
        "success": True,
        "curriculum": curriculum
    }

@api_router.post("/evolution/config")
async def update_evolution_config(config: EvolutionConfig):
    """Update evolution configuration (requires restart if running)"""
    global evolution_manager
    
    if not evolution_manager:
        raise HTTPException(status_code=400, detail="Evolution not initialized")
    
    if evolution_manager.is_running:
        raise HTTPException(
            status_code=400, 
            detail="Cannot update config while evolution is running. Stop evolution first."
        )
    
    # Update config
    evolution_manager.selfplay_duration = config.selfplay_duration
    evolution_manager.mcts_simulations = config.mcts_simulations
    evolution_manager.auto_scale_trigger = config.auto_scale_trigger
    evolution_manager.set_llm_mode(config.use_llm)
    
    return {
        "success": True,
        "message": "Configuration updated",
        "config": config.dict()
    }

@api_router.post("/evolution/llm-mode")
async def set_llm_mode(enabled: bool):
    """Enable or disable LLM-assisted reflection and curriculum (Hybrid Reflection Mode)"""
    global evolution_manager
    
    if not evolution_manager:
        raise HTTPException(status_code=400, detail="Evolution not initialized")
    
    evolution_manager.set_llm_mode(enabled)
    
    return {
        "success": True,
        "message": f"Hybrid Reflection Mode {'enabled' if enabled else 'disabled'}",
        "use_llm": enabled
    }

# ====================
# Curriculum Engine Endpoints
# ====================

from curriculum_engine import CurriculumEngine

# Initialize curriculum engine
curriculum_engine = CurriculumEngine()

class CurriculumPlanRequest(BaseModel):
    num_recent_games: int = Field(default=20, ge=1, le=100)
    total_games_played: Optional[int] = None

@api_router.post("/curriculum/plan")
async def create_curriculum_plan(request: CurriculumPlanRequest):
    """Create curriculum training plan based on recent games"""
    try:
        # Get recent games from database
        sync_client = MongoClient(os.environ.get('MONGO_URL', 'mongodb://localhost:27017'))
        sync_db = sync_client[os.environ.get('DB_NAME', 'alphazero_chess')]
        
        # Get recent self-play games
        recent_games_cursor = sync_db.self_play_positions.find().sort("timestamp", -1).limit(request.num_recent_games)
        recent_games = list(recent_games_cursor)
        
        # Count total games
        if request.total_games_played is None:
            total_games = sync_db.self_play_positions.count_documents({})
        else:
            total_games = request.total_games_played
        
        sync_client.close()
        
        # Create curriculum plan
        plan = await curriculum_engine.create_curriculum_plan(recent_games, total_games)
        
        return {
            "success": True,
            "plan": plan
        }
    except Exception as e:
        logger.error(f"Error creating curriculum plan: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/curriculum/status")
async def get_curriculum_status():
    """Get current curriculum status and plan"""
    try:
        current_plan = curriculum_engine.get_current_plan()
        
        return {
            "success": True,
            "has_plan": current_plan is not None,
            "current_plan": current_plan,
            "llm_enabled": curriculum_engine.use_llm
        }
    except Exception as e:
        logger.error(f"Error getting curriculum status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/curriculum/llm-mode")
async def set_curriculum_llm_mode(enabled: bool):
    """Enable or disable LLM-assisted curriculum planning"""
    try:
        curriculum_engine.set_llm_mode(enabled)
        
        return {
            "success": True,
            "message": f"Curriculum LLM mode {'enabled' if enabled else 'disabled'}",
            "llm_enabled": curriculum_engine.use_llm
        }
    except Exception as e:
        logger.error(f"Error setting curriculum LLM mode: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ====================
# Evolution State Monitoring
# ====================

@api_router.get("/evolution/state")
async def get_evolution_state():
    """Get comprehensive evolution state with latest metrics"""
    try:
        # Get active model
        active_model_doc = await db.active_model.find_one({})
        active_model = active_model_doc.get("model_name") if active_model_doc else None
        active_elo = active_model_doc.get("elo", 1500) if active_model_doc else 1500
        
        # Get total games played
        total_games = await db.self_play_positions.count_documents({})
        
        # Get recent training metrics
        recent_training = await db.training_metrics.find().sort("timestamp", -1).limit(10).to_list(10)
        avg_loss = sum(m.get("loss", 0) for m in recent_training) / len(recent_training) if recent_training else 0
        
        # Get recent evaluations
        recent_evals = await db.model_evaluations.find().sort("timestamp", -1).limit(5).to_list(5)
        
        # Get model versions
        models = model_manager.list_models()
        model_count = len(models)
        
        # Get latest model version number
        latest_version = 0
        for model_name in models:
            if model_name.startswith('model_v'):
                try:
                    version = int(model_name.split('_v')[1])
                    latest_version = max(latest_version, version)
                except:
                    continue
        
        # Calculate ELO history
        elo_history = []
        for eval_result in reversed(recent_evals):
            if eval_result.get("promoted"):
                elo_history.append({
                    "model": eval_result.get("challenger_name"),
                    "elo": eval_result.get("challenger_elo_after", 1500),
                    "timestamp": eval_result.get("timestamp")
                })
        
        # Get curriculum plan
        curriculum_plan = curriculum_engine.get_current_plan()
        
        # Check scaling readiness
        config = {}
        config_file = Path("/app/backend/config.json")
        if config_file.exists():
            with open(config_file, 'r') as f:
                config = json.load(f)
        
        scale_trigger_games = config.get("scaling", {}).get("scale_trigger_games", 5000)
        games_until_scale = max(0, scale_trigger_games - total_games)
        
        # Check ELO plateau
        elo_plateau = False
        if len(recent_evals) >= 3:
            recent_elo_deltas = [e.get("elo_delta", 0) for e in recent_evals[:3]]
            avg_elo_improvement = sum(recent_elo_deltas) / 3
            plateau_threshold = config.get("scaling", {}).get("scale_trigger_elo_plateau", 5.0)
            elo_plateau = avg_elo_improvement < plateau_threshold
        
        return {
            "success": True,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "active_model": active_model,
            "active_model_elo": active_elo,
            "total_models": model_count,
            "latest_version": latest_version,
            "total_games": total_games,
            "training_active": training_status["active"],
            "evaluation_active": evaluation_status["active"],
            "recent_training": {
                "sessions": len(recent_training),
                "average_loss": avg_loss,
                "latest_loss": recent_training[0].get("loss", 0) if recent_training else 0
            },
            "recent_evaluations": {
                "count": len(recent_evals),
                "results": recent_evals
            },
            "elo_history": elo_history,
            "curriculum": {
                "has_plan": curriculum_plan is not None,
                "primary_focus": curriculum_plan.get("primary_focus") if curriculum_plan else None,
                "next_milestone": curriculum_plan.get("next_milestone") if curriculum_plan else None
            },
            "scaling": {
                "auto_scale_enabled": config.get("scaling", {}).get("auto_scale", True),
                "trigger_games": scale_trigger_games,
                "games_until_trigger": games_until_scale,
                "elo_plateau_detected": elo_plateau,
                "ready_to_scale": games_until_scale == 0 or elo_plateau
            },
            "config": config
        }
    except Exception as e:
        logger.error(f"Error getting evolution state: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Live Arena Endpoints (AlphaZero vs AlphaZero)
# ====================

class ArenaConfig(BaseModel):
    players: List[Optional[str]] = Field(default=[None, None], description="Model names for player 1 and 2")
    games: int = Field(default=10, ge=1, le=100, description="Number of games to play")
    move_delay: float = Field(default=1.2, ge=0.1, le=10.0, description="Delay between moves in seconds")
    mcts_simulations: int = Field(default=800, ge=100, le=2000, description="MCTS simulations per move")
    save_pgn: bool = Field(default=True, description="Save games as PGN files")
    commentary: bool = Field(default=True, description="Generate move commentary")

@api_router.post("/arena/start")
async def start_arena(config: ArenaConfig):
    """Start live AlphaZero vs AlphaZero arena"""
    try:
        result = await arena_manager.start_arena(config.dict())
        return result
    except Exception as e:
        logger.error(f"Error starting arena: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/arena/stop")
async def stop_arena():
    """Stop current arena session"""
    try:
        result = await arena_manager.stop_arena()
        return result
    except Exception as e:
        logger.error(f"Error stopping arena: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/arena/status")
async def get_arena_status():
    """Get current arena status"""
    try:
        status = arena_manager.get_status()
        return {"success": True, **status}
    except Exception as e:
        logger.error(f"Error getting arena status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

async def arena_event_generator():
    """Server-Sent Events generator for arena moves"""
    try:
        async for event in arena_manager.get_event_stream():
            if event.get('type') == 'keepalive':
                yield f": keepalive\n\n"
            else:
                yield f"data: {json.dumps(event)}\n\n"
                
                # Check if arena is complete
                if event.get('type') == 'arena_complete':
                    break
    except Exception as e:
        logger.error(f"Arena stream error: {e}")
        yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"

@api_router.get("/arena/stream")
async def arena_stream():
    """Stream arena moves via Server-Sent Events"""
    return StreamingResponse(
        arena_event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )

# ====================
# Memory Compression Endpoints
# ====================

class CompressionRequest(BaseModel):
    memory_ids: Optional[List[str]] = Field(default=None, description="Specific memory IDs to compress (None = all)")
    train_autoencoder: bool = Field(default=True, description="Train autoencoder before compression")
    save_compressed: bool = Field(default=True, description="Save compressed memories to file")

@api_router.post("/compression/compress")
async def compress_memories(request: CompressionRequest):
    """Compress game memories using autoencoder"""
    try:
        # Load memories from database
        if request.memory_ids:
            memories_cursor = db.memories.find({"memory_id": {"$in": request.memory_ids}})
        else:
            memories_cursor = db.memories.find()
        
        memories = await memories_cursor.to_list(10000)
        
        if not memories:
            raise HTTPException(status_code=404, detail="No memories found to compress")
        
        # Run compression in background
        def compress_task():
            compressed = memory_compressor.compress_games(
                memories,
                train_autoencoder=request.train_autoencoder
            )
            
            if request.save_compressed:
                filepath = memory_compressor.save_compressed_memories(compressed)
                return {
                    'success': True,
                    'compressed_count': len(compressed),
                    'original_count': len(memories),
                    'filepath': str(filepath),
                    'stats': memory_compressor.get_stats()
                }
            
            return {
                'success': True,
                'compressed_count': len(compressed),
                'original_count': len(memories),
                'stats': memory_compressor.get_stats()
            }
        
        # Run in executor to avoid blocking
        result = await asyncio.get_event_loop().run_in_executor(executor, compress_task)
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error compressing memories: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/compression/status")
async def get_compression_status():
    """Get compression statistics"""
    try:
        stats = memory_compressor.get_stats()
        return {
            'success': True,
            **stats
        }
    except Exception as e:
        logger.error(f"Error getting compression status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/compression/list")
async def list_compressed_memories():
    """List all compressed memory files"""
    try:
        files = memory_compressor.list_compressed_memories()
        return {
            'success': True,
            'files': files,
            'count': len(files)
        }
    except Exception as e:
        logger.error(f"Error listing compressed memories: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/compression/load/{filename}")
async def load_compressed_memories(filename: str):
    """Load compressed memories from file"""
    try:
        memories = memory_compressor.load_compressed_memories(filename)
        return {
            'success': True,
            'memories': memories,
            'count': len(memories)
        }
    except Exception as e:
        logger.error(f"Error loading compressed memories: {e}")
        raise HTTPException(status_code=500, detail=str(e))

class TrainFromCompressedRequest(BaseModel):
    filename: str = Field(..., description="Compressed memory filename")
    num_epochs: int = Field(default=5, ge=1, le=50)
    batch_size: int = Field(default=64, ge=8, le=256)
    learning_rate: float = Field(default=0.001, ge=0.0001, le=0.1)

@api_router.post("/compression/train")
async def train_from_compressed(request: TrainFromCompressedRequest, background_tasks: BackgroundTasks):
    """Train AlphaZero from compressed memories"""
    global training_status
    
    if training_status["active"]:
        raise HTTPException(status_code=400, detail="Training already in progress")
    
    try:
        # Load compressed memories
        compressed_memories = memory_compressor.load_compressed_memories(request.filename)
        
        if not compressed_memories:
            raise HTTPException(status_code=404, detail="No compressed memories found in file")
        
        # Start training in background
        session_id = str(uuid.uuid4())
        training_status = {
            "active": True,
            "progress": 0,
            "message": "Starting training from compressed memories...",
            "session_id": session_id,
            "start_time": datetime.now(timezone.utc),
            "training_type": "compressed_memory"
        }
        
        # Run training (simplified - would need full implementation)
        def train_task():
            # This would need proper implementation to train from compressed vectors
            # For now, just placeholder
            logger.info(f"Training from {len(compressed_memories)} compressed memories")
            time.sleep(5)  # Simulate training
            return {
                'success': True,
                'session_id': session_id,
                'memories_used': len(compressed_memories)
            }
        
        background_tasks.add_task(train_task)
        
        return {
            'success': True,
            'message': 'Training from compressed memories started',
            'session_id': session_id,
            'compressed_memories': len(compressed_memories)
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error training from compressed memories: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Router and middleware will be mounted after all endpoints are defined

# ====================
# PGN-Integrated Curriculum Training Roadmap Endpoints
# ====================

from pgn_ingest import PGNIngestor
from train_blended import BlendedTrainingPipeline
from network_scaler import NetworkScaler
from iq_tracker_enhanced import EnhancedIQTracker, enhanced_iq_tracker
from evolution_metrics import EvolutionMetricsTracker, evolution_metrics_tracker
from curriculum_roadmap import CurriculumRoadmapOrchestrator, roadmap_orchestrator

# Initialize components
pgn_ingestor_global = PGNIngestor()
network_scaler_global = NetworkScaler()


@api_router.post("/roadmap/ingest-pgn")
async def ingest_pgn_file(file: UploadFile = File(...), source_type: str = Query(..., pattern="^(human|engine)$")):
    """
    Ingest external PGN file for curriculum training
    
    Args:
        file: PGN file upload
        source_type: 'human' or 'engine'
    """
    try:
        logger.info(f"Received PGN upload: {file.filename} (source: {source_type})")
        
        # Read file content
        pgn_content = await file.read()
        pgn_text = pgn_content.decode('utf-8')
        
        # Ingest PGN
        result = await roadmap_orchestrator.ingest_external_pgns(
            pgn_content=pgn_text,
            source_type=source_type,
            filename=file.filename
        )
        
        return {
            'success': True,
            'message': f"Ingested {result['games_ingested']} games from {file.filename}",
            **result
        }
    except Exception as e:
        logger.error(f"PGN ingestion error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/roadmap/pgn-stats")
async def get_pgn_stats():
    """Get PGN ingestion statistics"""
    try:
        stats = pgn_ingestor_global.get_stats()
        files = pgn_ingestor_global.list_processed_files()
        
        return {
            'success': True,
            'stats': stats,
            'processed_files': files
        }
    except Exception as e:
        logger.error(f"Error getting PGN stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/roadmap/status")
async def get_roadmap_status():
    """
    Get comprehensive roadmap status
    Returns current phase, progress, and metrics
    """
    try:
        status = roadmap_orchestrator.get_roadmap_status()
        iq_status = enhanced_iq_tracker.get_current_status()
        
        return {
            'success': True,
            'roadmap': status,
            'iq_status': iq_status
        }
    except Exception as e:
        logger.error(f"Error getting roadmap status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.post("/roadmap/run-cycle")
async def run_training_cycle(
    background_tasks: BackgroundTasks,
    num_selfplay_games: int = Query(default=25, ge=1, le=100),
    num_external_games: int = Query(default=50, ge=1, le=200),
    num_epochs: int = Query(default=5, ge=1, le=20)
):
    """
    Run a complete training cycle through the curriculum roadmap
    
    Steps:
    1. Determine curriculum phase
    2. Prepare blended data (external PGNs + self-play)
    3. Train on blended data
    4. Evaluate model
    5. Generate reflection
    6. Check for network scaling
    """
    try:
        logger.info(f"Starting roadmap training cycle (selfplay={num_selfplay_games}, external={num_external_games})")
        
        # Run cycle in background
        async def run_cycle():
            try:
                result = await roadmap_orchestrator.run_complete_cycle(
                    num_selfplay_games=num_selfplay_games,
                    num_external_games=num_external_games,
                    num_epochs=num_epochs
                )
                logger.info(f"Cycle completed successfully: ELO {result.get('new_elo', 0):.1f}")
            except Exception as e:
                logger.error(f"Cycle execution error: {e}")
        
        background_tasks.add_task(run_cycle)
        
        return {
            'success': True,
            'message': 'Training cycle started in background',
            'config': {
                'num_selfplay_games': num_selfplay_games,
                'num_external_games': num_external_games,
                'num_epochs': num_epochs
            }
        }
    except Exception as e:
        logger.error(f"Error starting training cycle: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/roadmap/evolution-metrics")
async def get_evolution_metrics():
    """Get detailed evolution metrics"""
    try:
        current_metrics = evolution_metrics_tracker.get_current_metrics()
        progression = evolution_metrics_tracker.get_training_progression()
        
        return {
            'success': True,
            'current_metrics': current_metrics,
            'training_progression': progression
        }
    except Exception as e:
        logger.error(f"Error getting evolution metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/roadmap/iq-tracking")
async def get_iq_tracking():
    """
    Get enhanced IQ tracking with evaluation consistency
    Tracks progress toward ELO 3500+
    """
    try:
        current_status = enhanced_iq_tracker.get_current_status()
        statistics = enhanced_iq_tracker.get_statistics()
        chart_data = enhanced_iq_tracker.export_chart_data()
        
        return {
            'success': True,
            'current_status': current_status,
            'statistics': statistics,
            'chart_data': chart_data
        }
    except Exception as e:
        logger.error(f"Error getting IQ tracking: {e}")
        raise HTTPException(status_code=500, detail=str(e))




@api_router.get("/roadmap/curriculum-phase")
async def get_curriculum_phase():
    """Get current curriculum phase information"""
    try:
        phase, phase_info = roadmap_orchestrator.determine_curriculum_phase()
        
        return {
            'success': True,
            **phase_info
        }
    except Exception as e:
        logger.error(f"Error getting curriculum phase: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.get("/roadmap/network-capacity")
async def get_network_capacity():
    """Get current network capacity and scaling status"""
    try:
        capacity = network_scaler_global.get_current_capacity()
        scaling_history = network_scaler_global.get_scaling_history()
        
        return {
            'success': True,
            'capacity': capacity,
            'scaling_history': scaling_history
        }
    except Exception as e:
        logger.error(f"Error getting network capacity: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@api_router.post("/roadmap/manual-scale")
async def manual_scale_network():
    """
    Manually trigger network scaling
    Increases filters, residual blocks, and MCTS simulations
    """
    try:
        logger.info("Manual network scaling requested")
        
        # Load current network
        active_model = model_manager.get_active_model_name()
        if not active_model:
            raise HTTPException(status_code=404, detail="No active model found")
        
        current_network, _ = model_manager.load_model(active_model)
        
        # Scale network
        scaled_network, scaling_info = network_scaler_global.scale_network(
            current_network,
            scale_factor=1.5
        )
        
        # Scale MCTS
        config_path = Path("/app/backend/config.json")
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        current_mcts = config.get('self_play', {}).get('mcts_simulations', 800)
        new_mcts = network_scaler_global.scale_mcts_simulations(current_mcts, scale_factor=1.5)
        
        # Update config
        network_scaler_global.update_config_scaling(
            new_filters=scaling_info['new_filters'],
            new_blocks=scaling_info['new_blocks'],
            new_mcts_sims=new_mcts
        )
        
        # Save scaled network
        model_path = model_manager.save_versioned_model(
            scaled_network,
            metadata={
                'scaled': True,
                'scaling_info': scaling_info,
                'scaled_at': datetime.now(timezone.utc).isoformat()
            }
        )
        
        # Record in evolution tracker
        evolution_metrics_tracker.record_network_scaling(scaling_info)
        
        return {
            'success': True,
            'message': 'Network scaled successfully',
            'scaling_info': scaling_info,
            'new_mcts_simulations': new_mcts,
            'model_path': str(model_path)
        }
    except Exception as e:
        logger.error(f"Manual scaling error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ====================
# Tournament Evaluation Endpoints
# ====================

tournament_status = {
    "active": False,
    "progress": 0,
    "current_game": 0,
    "total_games": 0,
    "message": "",
    "tournament_id": None
}

class TournamentConfig(BaseModel):
    model_name: str
    opponent_type: str = Field(default="stockfish", pattern="^(stockfish|baseline)$")
    num_games: int = Field(default=20, ge=1, le=100)
    alphazero_elo: float = Field(default=1500.0, ge=800.0, le=3500.0)
    opponent_elo: float = Field(default=2000.0, ge=800.0, le=3500.0)
    stockfish_depth: int = Field(default=15, ge=5, le=25)

async def run_tournament_background(config: TournamentConfig):
    """Run tournament in background with progress updates"""
    global tournament_status
    
    try:
        tournament_status["message"] = "Loading model..."
        tournament_status["progress"] = 10
        
        # Load AlphaZero model
        from neural_network import AlphaZeroNetwork, ModelManager
        model_mgr = ModelManager()
        
        alphazero_model, metadata = model_mgr.load_model(config.model_name)
        if not alphazero_model:
            raise Exception(f"Failed to load model: {config.model_name}")
        
        tournament_status["message"] = f"Starting tournament: {config.num_games} games vs {config.opponent_type}"
        tournament_status["progress"] = 20
        tournament_status["total_games"] = config.num_games
        
        # Run tournament
        result = await tournament_manager.run_tournament(
            alphazero_model=alphazero_model,
            opponent_type=config.opponent_type,
            num_games=config.num_games,
            alphazero_elo=config.alphazero_elo,
            opponent_elo=config.opponent_elo,
            stockfish_depth=config.stockfish_depth
        )
        
        tournament_status["progress"] = 100
        tournament_status["message"] = "Tournament complete!"
        tournament_status["tournament_id"] = result["tournament_id"]
        
        logger.info(f"Tournament complete: {result['tournament_id']}")
        
    except Exception as e:
        logger.error(f"Tournament error: {str(e)}")
        tournament_status["message"] = f"Error: {str(e)}"
        tournament_status["progress"] = 0
        raise
    finally:
        tournament_status["active"] = False

@api_router.post("/tournament/start")
async def start_tournament(config: TournamentConfig, background_tasks: BackgroundTasks):
    """
    Start an evaluation tournament
    Runs matches against Stockfish or baseline agents
    Tracks Elo ratings, win/draw/loss ratios, search depth, time per move, and blunder frequency
    """
    global tournament_status
    
    if tournament_status["active"]:
        raise HTTPException(status_code=400, detail="Tournament already in progress")
    
    # Verify model exists
    from neural_network import ModelManager
    model_mgr = ModelManager()
    model_info = model_mgr.get_model_info(config.model_name)
    if not model_info:
        raise HTTPException(status_code=404, detail=f"Model {config.model_name} not found")
    
    tournament_status = {
        "active": True,
        "progress": 0,
        "current_game": 0,
        "total_games": config.num_games,
        "message": "Initializing tournament...",
        "tournament_id": None
    }
    
    background_tasks.add_task(run_tournament_background, config)
    
    return {
        "success": True,
        "message": "Tournament started",
        "config": config.dict()
    }

@api_router.get("/tournament/status")
async def get_tournament_status():
    """Get current tournament status and progress"""
    return tournament_status

@api_router.get("/tournament/history")
async def get_tournament_history(limit: int = Query(default=20, ge=1, le=100)):
    """
    Get tournament history
    Returns list of completed tournaments with summary statistics
    """
    try:
        history = tournament_manager.get_tournament_history(limit=limit)
        return {
            "success": True,
            "tournaments": history,
            "count": len(history)
        }
    except Exception as e:
        logger.error(f"Error getting tournament history: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/tournament/{tournament_id}")
async def get_tournament_details(tournament_id: str):
    """
    Get detailed tournament results
    Includes game-by-game breakdown, Elo progression, and performance metrics
    """
    try:
        details = tournament_manager.get_tournament_details(tournament_id)
        if not details:
            raise HTTPException(status_code=404, detail=f"Tournament {tournament_id} not found")
        
        return {
            "success": True,
            "tournament": details
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting tournament details: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/tournament/stop")
async def stop_tournament():
    """Stop ongoing tournament"""
    global tournament_status
    
    if not tournament_status["active"]:
        raise HTTPException(status_code=400, detail="No tournament active")
    
    tournament_status["active"] = False
    tournament_status["message"] = "Tournament stopped by user"
    
    return {
        "success": True,
        "message": "Tournament stop requested"
    }

# Mount the API router after all endpoints are defined
app.include_router(api_router)

# Register TPU routes (optional)
try:
    from tpu_api_routes import tpu_router
    app.include_router(tpu_router)
    logger.info("TPU routes registered")
except Exception as e:
    logger.warning(f"TPU routes not available: {e}")

# Register Cloud Orchestration routes
try:
    from cloud_api_routes import cloud_router
    app.include_router(cloud_router)
    logger.info("Cloud orchestration routes registered")
except Exception as e:
    logger.warning(f"Cloud orchestration routes not available: {e}")

# Register Persistent Training routes (Phase 5)
try:
    from training_api_routes import training_router
    app.include_router(training_router)
    logger.info("Persistent Training routes registered at /api/training")
except Exception as e:
    logger.warning(f"Training routes not available: {e}")

# Register Hybrid Multi-Cloud routes (Phase 6)
try:
    from hybrid_api_routes import hybrid_router
    app.include_router(hybrid_router)
    logger.info("Hybrid Multi-Cloud routes registered at /api/hybrid")
except Exception as e:
    logger.warning(f"Hybrid routes not available: {e}")

# Register TPU Training Orchestration routes
try:
    from training_orchestration_routes import training_orchestration_router
    app.include_router(training_orchestration_router)
    logger.info("TPU Training Orchestration routes registered at /api/training")
except Exception as e:
    logger.warning(f"Training orchestration routes not available: {e}")

# Register Phase 2 Distributed Optimization routes
try:
    from phase2_api_routes import router as phase2_router
    app.include_router(phase2_router)
    logger.info("Phase 2 Distributed Optimization routes registered at /api/alphazero/distributed")
except Exception as e:
    logger.warning(f"Phase 2 distributed routes not available: {e}")

# Register Phase 4 Evaluation & Promotion routes
try:
    from phase4_api_routes import phase4_router
    app.include_router(phase4_router)
    logger.info("Phase 4 Evaluation & Promotion routes registered at /api/alphazero")
except Exception as e:
    logger.warning(f"Phase 4 evaluation routes not available: {e}")

# Register Phase 5 Adaptive Evolution routes
try:
    from phase5_api_routes import phase5_router
    app.include_router(phase5_router)
    logger.info("Phase 5 Adaptive Evolution routes registered at /api/alphazero/evolution")
except Exception as e:
    logger.warning(f"Phase 5 evolution routes not available: {e}")

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
