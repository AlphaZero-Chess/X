#!/usr/bin/env python3
"""
Quick Phase 4 Validation - Reduced complexity for fast testing
"""

import asyncio
import logging
import time
from pathlib import Path

from evaluation_manager import EvaluationManager, reset_evaluation_manager
from model_registry import ModelRegistry, reset_model_registry
from neural_network import AlphaZeroNetwork
from tpu_cluster_manager import get_tpu_grid

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


async def run_validation():
    """Run quick Phase 4 validation"""
    
    print("="*80)
    print("PHASE 4 VALIDATION - Quick Test")
    print("Configuration: 2 pods × 10 games × 50 MCTS simulations")
    print("="*80)
    
    start_time = time.time()
    
    # Reset managers
    reset_evaluation_manager()
    reset_model_registry()
    
    # Initialize
    eval_manager = EvaluationManager()
    eval_manager.num_simulations = 50  # Reduced from 400 for speed
    registry = ModelRegistry()
    tpu_grid = get_tpu_grid()
    
    # Show status
    grid_status = tpu_grid.get_grid_status()
    print(f"\n📊 TPU Grid: {grid_status['grid']['total_pods']} pods, " + 
          f"{grid_status['grid']['total_tpus']:,} TPUs")
    
    # Create models
    print(f"\n🤖 Creating Models:")
    print(f"   Challenger: model_v2")
    print(f"   Champion: best_model")
    
    challenger = AlphaZeroNetwork()
    champion = AlphaZeroNetwork()
    
    # Run evaluation
    print(f"\n🎮 Starting Evaluation (10 games, 50 sims/move)...")
    
    job, results = await eval_manager.start_evaluation(
        challenger_model=challenger,
        champion_model=champion,
        challenger_name="model_v2",
        champion_name="best_model",
        challenger_elo=1500.0,
        champion_elo=1500.0,
        num_eval_games=10,
        pods_for_eval=2,
        use_tpu_pods=True,
        autoscale_eval=True,
        pod_warmup_seconds=2,
        aggregation_mode="weighted_by_games",
        elo_k_factor=32,
        async_mode=False
    )
    
    # Display results
    print(f"\n" + "="*80)
    print(f"📈 EVALUATION RESULTS")
    print("="*80)
    
    print(f"\n🎯 Overall:")
    print(f"   Job ID: {results['job_id']}")
    print(f"   Total Games: {results['total_games']}")
    print(f"   Results: {results['challenger_wins']}W-{results['champion_wins']}L-{results['draws']}D")
    print(f"   Win Rate: {results['challenger_win_rate']:.1%}")
    
    print(f"\n📊 Per-Pod Breakdown:")
    for pod_id, pod_results in results['per_pod_results'].items():
        print(f"   Pod {pod_id}:")
        print(f"      Games: {pod_results['games_completed']}")
        print(f"      Results: {pod_results['wins_challenger']}W-{pod_results['wins_champion']}L-{pod_results['draws']}D")
        print(f"      Win Rate: {pod_results['win_rate_challenger']:.1%}")
        print(f"      Avg Duration: {pod_results['avg_game_duration']:.2f}s/game")
    
    print(f"\n🎲 ELO Calculations:")
    elo = results['elo_calculations']
    print(f"   ELO Before: {elo['elo_before']:.0f}")
    print(f"   ELO After: {elo['elo_after']:.0f}")
    print(f"   ELO Delta: {elo['elo_delta']:+.0f}")
    print(f"   Expected Score: {elo['expected_score']:.3f}")
    print(f"   Actual Score: {elo['actual_score']:.3f}")
    
    print(f"\n🔍 Per-Pod ELO Contributions:")
    for pod_id, pod_elo in results['per_pod_elo'].items():
        print(f"   Pod {pod_id}: Δ {pod_elo['elo_delta']:+.0f} "
              f"({pod_elo['games']} games, {pod_elo['win_rate']:.1%} win rate)")
    
    # Check promotion
    print(f"\n🏆 Promotion Check:")
    should_promote, reason = registry.should_promote(
        challenger_win_rate=results['challenger_win_rate'],
        elo_delta=elo['elo_delta'],
        win_threshold=0.55,
        elo_threshold=50.0
    )
    
    print(f"   Should Promote: {should_promote}")
    print(f"   Reason: {reason}")
    
    # Timing
    elapsed = time.time() - start_time
    print(f"\n⏱️  Total Time: {elapsed:.1f}s ({elapsed/results['total_games']:.1f}s per game)")
    
    print(f"\n" + "="*80)
    print(f"✅ VALIDATION COMPLETE")
    print("="*80)
    
    # Return results for API testing
    return {
        'job_id': results['job_id'],
        'results': results,
        'should_promote': should_promote,
        'elapsed_time': elapsed
    }


if __name__ == "__main__":
    result = asyncio.run(run_validation())
    print(f"\n💾 Results saved. Job ID: {result['job_id']}")
