import numpy as np
from typing import List, Tuple
from chess_engine import ChessEngine
from mcts import MCTS
import chess
import chess.pgn
import time
import logging
from pathlib import Path
from datetime import datetime

logger = logging.getLogger(__name__)

# PGN storage directory
PGN_DIR = Path("/app/data/selfplay_pgns")
PGN_DIR.mkdir(parents=True, exist_ok=True)

# Global game counter for file naming
_game_counter = 0

def get_next_game_number():
    """Get next game number for PGN file naming"""
    global _game_counter
    _game_counter += 1
    return _game_counter

def export_game_to_pgn(board: chess.Board, result: str, game_number: int) -> str:
    """
    Export a chess game to PGN format
    
    Args:
        board: chess.Board object with move history
        result: Game result ("1-0", "0-1", "1/2-1/2", or "*")
        game_number: Game number for file naming
    
    Returns:
        Path to saved PGN file
    """
    # Create PGN game object
    game = chess.pgn.Game()
    
    # Set headers
    game.headers["Event"] = "AlphaZero Self-Play"
    game.headers["Site"] = "Training System"
    game.headers["Date"] = datetime.now().strftime("%Y.%m.%d")
    game.headers["Round"] = str(game_number)
    game.headers["White"] = "AlphaZero"
    game.headers["Black"] = "AlphaZero"
    game.headers["Result"] = result
    
    # Build move tree from board's move stack
    node = game
    temp_board = chess.Board()  # Start from initial position
    
    for move in board.move_stack:
        node = node.add_variation(move)
        temp_board.push(move)
    
    # Save to file with zero-padded numbering
    filename = f"game_{game_number:04d}.pgn"
    filepath = PGN_DIR / filename
    
    with open(filepath, "w") as f:
        exporter = chess.pgn.FileExporter(f)
        game.accept(exporter)
    
    logger.info(f"Saved PGN for game #{game_number} → {filepath}")
    
    return str(filepath)

class SelfPlayGame:
    """Generate self-play games for training"""
    
    def __init__(self, neural_network, num_simulations=800, c_puct=1.0):
        self.neural_network = neural_network
        self.mcts = MCTS(neural_network, num_simulations, c_puct)
        
    def play_game(self, temperature_threshold=15, store_fen=False, export_pgn=True, game_number=None):
        """
        Play one self-play game with performance tracking
        Returns: list of (position, policy, outcome) tuples, result, move_count, pgn_path
        """
        start_time = time.time()
        engine = ChessEngine()
        game_history = []
        move_count = 0
        
        while not engine.is_game_over():
            # Encode current position
            board_encoding = engine.encode_board()
            current_fen = engine.get_fen() if store_fen else None
            
            # Use MCTS to get move and policy
            temperature = 1.0 if move_count < temperature_threshold else 0.0
            move, move_probs, _ = self.mcts.search(engine, temperature=temperature)
            
            # Store position and policy
            game_history.append({
                'position': board_encoding,
                'policy': move_probs,
                'player': engine.board.turn,
                'fen': current_fen,
                'move_number': move_count
            })
            
            # Make move
            engine.make_move(move)
            move_count += 1
            
            # Safety limit
            if move_count > 500:
                break
        
        game_time = time.time() - start_time
        
        # Get game outcome
        result = engine.get_result()
        if result == "1-0":
            outcome = 1.0
        elif result == "0-1":
            outcome = -1.0
        else:
            outcome = 0.0
        
        # Export game as PGN
        pgn_path = None
        if export_pgn:
            if game_number is None:
                game_number = get_next_game_number()
            pgn_path = export_game_to_pgn(engine.board, result, game_number)
        
        # Assign outcomes from each player's perspective
        training_data = []
        for entry in game_history:
            # Outcome from perspective of player to move
            if entry['player'] == chess.WHITE:
                value = outcome
            else:
                value = -outcome
            
            training_data.append({
                'position': entry['position'],
                'policy': entry['policy'],
                'value': value,
                'fen': entry['fen'],
                'move_number': entry['move_number']
            })
        
        logger.info(f"Self-play game complete: {result}, {move_count} moves in {game_time:.2f}s")
        if pgn_path:
            logger.info(f"PGN saved: {pgn_path}")
        
        return training_data, result, move_count, pgn_path

class SelfPlayManager:
    """Manage self-play game generation"""
    
    def __init__(self, neural_network=None, num_simulations=800):
        """
        Initialize self-play manager
        
        Args:
            neural_network: Neural network for MCTS (can be None initially)
            num_simulations: Number of MCTS simulations per move
        """
        self.neural_network = neural_network
        self.num_simulations = num_simulations
        self.self_play = None
        
        if neural_network is not None:
            self.self_play = SelfPlayGame(neural_network, num_simulations=num_simulations)
    
    def update_network(self, neural_network):
        """
        Update the neural network used for self-play
        
        Args:
            neural_network: New neural network to use
        """
        if neural_network is None:
            logger.error("Cannot update self-play with None network")
            raise ValueError("Neural network cannot be None")
        
        self.neural_network = neural_network
        self.self_play = SelfPlayGame(neural_network, num_simulations=self.num_simulations)
        logger.info("Self-play network updated")
    
    def _ensure_network_initialized(self):
        """Ensure neural network is initialized before use"""
        if self.neural_network is None or self.self_play is None:
            logger.error("Self-play manager network not initialized. Call update_network() first.")
            raise RuntimeError("Neural network not initialized. Cannot generate games without a model.")
        
    def generate_single_game(self, store_fen=False, export_pgn=True):
        """Generate a single self-play game"""
        self._ensure_network_initialized()
        
        training_data, result, num_moves, pgn_path = self.self_play.play_game(
            store_fen=store_fen, 
            export_pgn=export_pgn
        )
        game_result = {
            'result': result,
            'num_moves': num_moves,
            'num_positions': len(training_data),
            'pgn_path': pgn_path
        }
        return training_data, game_result
    
    def generate_games(self, num_games=10, store_fen=False, export_pgn=True):
        """Generate multiple self-play games with performance tracking"""
        self._ensure_network_initialized()
        
        start_time = time.time()
        all_training_data = []
        game_results = []
        
        for i in range(num_games):
            logger.info(f"Starting self-play game {i + 1}/{num_games}")
            training_data, result, num_moves, pgn_path = self.self_play.play_game(
                store_fen=store_fen,
                export_pgn=export_pgn,
                game_number=get_next_game_number()
            )
            all_training_data.extend(training_data)
            game_results.append({
                'game_num': i + 1,
                'result': result,
                'num_moves': num_moves,
                'num_positions': len(training_data),
                'pgn_path': pgn_path
            })
        
        total_time = time.time() - start_time
        logger.info(f"Generated {num_games} games with {len(all_training_data)} positions in {total_time:.2f}s")
        
        return all_training_data, game_results