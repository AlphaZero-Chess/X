# AlphaZero Self-Play Training System

## Overview

This system implements the full-scale AlphaZero training pipeline capable of running 44 million self-play games over a 9-hour training session. It reproduces the learning behavior of the original AlphaZero Chess framework while maintaining compatibility with the PyTorch + FastAPI + React stack.

## Architecture

### Core Components

1. **selfplay_trainer.py** - Main orchestrator
   - Manages the complete 44M game / 9-hour training cycle
   - Implements distributed parallel self-play
   - Handles replay buffer management
   - Executes continuous training loop with cosine LR decay
   - Runs periodic evaluations and model promotions
   - Saves checkpoints every 30 minutes

2. **replay_buffer.py** - Ring buffer for training data
   - Stores up to 1M most recent positions
   - Thread-safe operations
   - Checkpoint save/load support

3. **distributed_selfplay.py** - Parallel game generation
   - Auto-detects hardware (Multi-GPU, Single GPU, CPU)
   - Spawns worker processes for parallel generation
   - Handles batched inference for efficiency

4. **Backend API Endpoints** (server.py)
   - `/api/train/start-alphazero` - Start training
   - `/api/train/status-alphazero` - Get real-time status
   - `/api/train/stop-alphazero` - Graceful stop
   - `/api/train/metrics-alphazero` - Detailed metrics

## Training Pipeline

### Self-Play Generation
- **800 MCTS simulations per move** (configurable)
- **Distributed across workers** based on available hardware
- **Parallel game generation** for maximum throughput
- Positions stored with (state, policy, value) tuples

### Training Loop
- **Replay buffer**: 1M positions (ring buffer)
- **Optimizer**: Adam with cosine annealing LR schedule
- **Batch size**: 256 (configurable)
- **Training frequency**: After each batch of games
- **Loss function**: Combined policy (cross-entropy) + value (MSE)

### Evaluation System
- **Periodic evaluation**: Every 1000 games (configurable)
- **Evaluation games**: 40 games (configurable)
- **Win threshold**: 55% for promotion
- **ELO tracking**: Simplified K=32 formula
- **Champion promotion**: Automatic when threshold met

### Checkpointing
- **Interval**: Every 30 minutes (configurable)
- **Saves**: Network weights, optimizer state, replay buffer
- **Resume support**: Full state restoration
- **Incremental saves**: Games completed, ELO, metadata

## Hardware Auto-Detection

The system automatically detects available hardware and optimizes accordingly:

### Multi-GPU Setup
- Spawns worker processes per GPU
- Each worker uses batched MCTS inference
- Optimal for maximum throughput

### Single GPU Setup
- Multiple worker processes share GPU
- Batched inference across workers
- Balanced CPU/GPU utilization

### CPU-Only Setup
- Multi-process parallel self-play
- Workers based on CPU core count
- Still efficient with good parallelization

## Usage

### Starting Training via API

```bash
# Start full-scale 44M game / 9-hour training
curl -X POST http://localhost:8001/api/train/start-alphazero \
  -H "Content-Type: application/json" \
  -d '{
    "max_games": 44000000,
    "max_hours": 9.0,
    "num_simulations": 800,
    "replay_buffer_size": 1000000,
    "batch_size": 256,
    "learning_rate": 0.001,
    "checkpoint_interval": 1800,
    "eval_interval": 1000,
    "win_threshold": 0.55,
    "num_eval_games": 40,
    "resume": false
  }'

# Check status
curl http://localhost:8001/api/train/status-alphazero

# Get detailed metrics
curl http://localhost:8001/api/train/metrics-alphazero

# Stop gracefully
curl -X POST http://localhost:8001/api/train/stop-alphazero
```

### Starting Training via CLI

```bash
# Full-scale training
cd /app/backend
python3 selfplay_trainer.py

# Resume from checkpoint
python3 selfplay_trainer.py --resume

# Small-scale test
python3 test_alphazero_training.py
```

### Configuration Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| max_games | 44,000,000 | Maximum number of self-play games |
| max_hours | 9.0 | Maximum training duration (hours) |
| num_simulations | 800 | MCTS simulations per move |
| replay_buffer_size | 1,000,000 | Replay buffer capacity |
| batch_size | 256 | Training batch size |
| learning_rate | 0.001 | Initial learning rate |
| checkpoint_interval | 1800 | Checkpoint save interval (seconds) |
| eval_interval | 1000 | Evaluation frequency (games) |
| win_threshold | 0.55 | Win rate threshold for promotion |
| num_eval_games | 40 | Number of evaluation games |

## Monitoring

### Real-Time Status

The status endpoint provides:
- Games completed / target
- Positions collected
- Elapsed time / max time
- Progress percentages
- Current ELO rating
- Models promoted count
- Games per second rate
- ETA estimation

### Training Metrics

Detailed metrics include:
- Loss curves (policy + value)
- Learning rate schedule
- ELO progression
- Throughput statistics
- Replay buffer utilization

### Logs

All logs are saved to `/data/training_logs/selfplay_44M/`:
- `training_metrics.json` - Full metrics history
- `checkpoints/` - Model checkpoints
- `replay_buffer_*.pkl` - Buffer snapshots

## Performance Expectations

### Throughput Estimates

Hardware configuration affects throughput significantly:

- **8x A100 GPUs**: ~50-100 games/sec → 44M games in 5-9 hours ✓
- **4x V100 GPUs**: ~20-40 games/sec → 44M games in 12-24 hours
- **1x V100 GPU**: ~5-10 games/sec → 44M games in 48-96 hours
- **CPU-only (32 cores)**: ~1-2 games/sec → 44M games in 250-500 hours

### Bottlenecks

1. **MCTS Simulations**: 800 sims per move is expensive
   - Can reduce to 400 for 2x speedup with minor quality loss
   
2. **Network Inference**: Batched inference helps significantly
   - Multi-GPU setup provides best parallelization
   
3. **Game Generation**: Parallel workers maximize throughput
   - Auto-scales based on available hardware

## Resumption Support

The system supports full checkpoint resumption:

```python
# Training will resume from last checkpoint
trainer.run(resume=True)
```

Checkpoint includes:
- Network weights (policy + value heads)
- Optimizer state (Adam momentum)
- LR scheduler state (cosine annealing position)
- Games completed counter
- Positions collected counter
- Current ELO rating
- Champion model reference
- Replay buffer contents

## Model Promotion

Models are promoted when they achieve ≥55% win rate against the current champion:

1. **Evaluation triggered** every 1000 games
2. **40 games played** between current and champion
3. **Win rate calculated** (wins + 0.5*draws) / total
4. **Promotion occurs** if win_rate ≥ 0.55
5. **New champion saved** with version number
6. **ELO updated** using K=32 formula

## Output Files

### Checkpoints
- `checkpoint_latest.pt` - Most recent checkpoint
- `checkpoint_{N}k_games.pt` - Periodic snapshots
- `checkpoint_final.pt` - Final checkpoint

### Models
- `champion_v{N}_{K}k.pt` - Promoted champions
- `checkpoint_{K}k_games.pt` - Training snapshots

### Replay Buffer
- `replay_buffer_latest.pkl` - Current buffer state
- `replay_buffer_{N}k_games.pkl` - Periodic snapshots

### Metrics
- `training_metrics.json` - Complete metrics history

## Troubleshooting

### Training Stops Early

Check:
1. Max games or max hours reached
2. Disk space for checkpoints
3. Memory for replay buffer
4. Logs for errors

### Low Throughput

Optimize:
1. Reduce MCTS simulations (400 instead of 800)
2. Increase batch size if memory allows
3. Enable GPU batching
4. Check worker count matches hardware

### Out of Memory

Solutions:
1. Reduce replay_buffer_size
2. Reduce batch_size
3. Reduce num_simulations
4. Use fewer parallel workers

### Can't Resume

Verify:
1. Checkpoint files exist in `/data/training_logs/selfplay_44M/checkpoints/`
2. Checkpoint is not corrupted
3. Network architecture matches

## Testing

### Small-Scale Test

Run a quick test to verify all components:

```bash
cd /app/backend
python3 test_alphazero_training.py
```

This runs:
- 100 games (instead of 44M)
- 5 minutes (instead of 9 hours)  
- 100 MCTS sims (instead of 800)
- Evaluation every 25 games

### Component Tests

Test individual components:

```python
# Test replay buffer
from replay_buffer import ReplayBuffer
buffer = ReplayBuffer(max_size=1000)
buffer.add([{'position': [...], 'policy': {...}, 'value': 0.5}])
print(f"Buffer size: {buffer.size()}")

# Test distributed self-play
from distributed_selfplay import DistributedSelfPlayManager
manager = DistributedSelfPlayManager("model_v1.pt", num_simulations=100)
data, results = manager.generate_games_parallel(10)
print(f"Generated {len(data)} positions from 10 games")
```

## Best Practices

1. **Start with small test** before full 44M run
2. **Monitor first hour** to verify throughput
3. **Save checkpoints frequently** for resumption
4. **Check disk space** before starting
5. **Use GPU** if available for best performance
6. **Tune batch size** based on memory
7. **Review metrics** periodically

## API Integration

Frontend can integrate via:

```javascript
// Start training
const response = await fetch('/api/train/start-alphazero', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    max_games: 44000000,
    max_hours: 9.0,
    num_simulations: 800
  })
});

// Poll status
setInterval(async () => {
  const status = await fetch('/api/train/status-alphazero').then(r => r.json());
  updateUI(status);
}, 5000);

// Get metrics
const metrics = await fetch('/api/train/metrics-alphazero').then(r => r.json());
plotCharts(metrics);
```

## Termination Conditions

Training stops when:
1. **Games target reached**: ≥44M games completed
2. **Time limit reached**: ≥9 hours elapsed
3. **Stop requested**: Via API or signal
4. **Error occurred**: Gracefully saves checkpoint

Whichever comes first triggers graceful shutdown with final checkpoint.
