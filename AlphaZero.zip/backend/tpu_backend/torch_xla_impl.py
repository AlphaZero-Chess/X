"""
PyTorch XLA TPU Backend Implementation.

Provides real TPU support using PyTorch XLA framework.
Requires: torch, torch_xla
"""

import numpy as np
from typing import Any, Dict, List, Optional, Tuple, TYPE_CHECKING
import logging
import time

try:
    import torch
    import torch_xla
    import torch_xla.core.xla_model as xm
    import torch_xla.distributed.parallel_loader as pl
    TORCH_XLA_AVAILABLE = True
except ImportError:
    TORCH_XLA_AVAILABLE = False
    # Keep torch available if only torch_xla is missing
    try:
        import torch
    except ImportError:
        torch = None
    torch_xla = None
    xm = None

from .core import TPUBackend, TPUConfig

logger = logging.getLogger(__name__)

# Use TYPE_CHECKING to avoid runtime issues
if TYPE_CHECKING or torch is not None:
    TorchTensor = torch.Tensor if torch else Any
else:
    TorchTensor = Any

# Define class - will raise error if torch_xla not available
class TorchXLATPUBackend(TPUBackend):
    """
    PyTorch XLA TPU backend for real TPU hardware.
    
    Uses PyTorch XLA's native TPU support.
    """
    
    def __init__(self, config: TPUConfig):
        if not TORCH_XLA_AVAILABLE:
            raise ImportError("PyTorch XLA not available. Install: pip install torch_xla")
        
        super().__init__(config)
        
        # Get TPU device
        try:
            self.device = xm.xla_device()
            self.num_cores = xm.xrt_world_size()
            self._initialized = True
            logger.info(f"PyTorch XLA TPU backend initialized with {self.num_cores} cores")
        except Exception as e:
            logger.warning(f"Failed to initialize TPU device: {e}")
            self.device = None
            self.num_cores = 0
            self._initialized = False
        
        # Performance tracking
        self._inference_times = []
        self._training_times = []
    
    def is_available(self) -> bool:
        """Check if TPU hardware is available."""
        return self._initialized and self.device is not None
    
    def get_device_info(self) -> Dict[str, Any]:
        """
        Get TPU device information.
        """
        if not self.is_available():
            return {'backend': 'torch_xla', 'available': False}
        
        info = {
            'backend': 'torch_xla',
            'device_type': 'tpu',
            'num_cores': self.num_cores,
            'device': str(self.device),
            'torch_xla_version': torch_xla.__version__,
            'is_simulation': False,
        }
        
        return info
    
    def to_device(self, tensor: Any) -> Any:
        """
        Move tensor to TPU device.
        """
        if isinstance(tensor, np.ndarray):
            tensor = torch.from_numpy(tensor)
        elif not isinstance(tensor, torch.Tensor):
            tensor = torch.tensor(tensor)
        
        return tensor.to(self.device)
    
    def from_device(self, tensor: Any) -> np.ndarray:
        """
        Move tensor from TPU to CPU as numpy array.
        """
        if isinstance(tensor, torch.Tensor):
            return tensor.cpu().numpy()
        elif isinstance(tensor, np.ndarray):
            return tensor
        else:
            return np.array(tensor)
    
    def inference(self, model: Any, inputs: Any) -> Any:
        """
        Run model inference on TPU.
        
        Args:
            model: PyTorch model
            inputs: Input tensor(s)
            
        Returns:
            Model outputs
        """
        start_time = time.time()
        
        # Move model to TPU
        if hasattr(model, 'to'):
            model = model.to(self.device)
            model.eval()
        
        # Move inputs to TPU
        if isinstance(inputs, (list, tuple)):
            inputs = [self.to_device(inp) for inp in inputs]
        else:
            inputs = self.to_device(inputs)
        
        # Run inference
        with torch.no_grad():
            if isinstance(inputs, list):
                outputs = model(*inputs)
            else:
                outputs = model(inputs)
        
        # Mark step for XLA
        xm.mark_step()
        
        elapsed = time.time() - start_time
        self._inference_times.append(elapsed)
        
        return outputs
    
    def train_step(self, model: Any, batch: Tuple[Any, Any], optimizer: Any) -> Dict[str, float]:
        """
        Execute one training step on TPU.
        
        Args:
            model: PyTorch model
            batch: (inputs, targets) tuple
            optimizer: PyTorch optimizer
            
        Returns:
            dict: Training metrics
        """
        start_time = time.time()
        
        # Move model to TPU
        if hasattr(model, 'to'):
            model = model.to(self.device)
            model.train()
        
        # Unpack batch
        inputs, targets = batch
        inputs = self.to_device(inputs)
        targets = self.to_device(targets)
        
        # Forward pass
        optimizer.zero_grad()
        outputs = model(inputs)
        
        # Compute loss
        if hasattr(model, 'compute_loss'):
            loss = model.compute_loss(outputs, targets)
        else:
            # Default: assume outputs is loss or use MSE
            if isinstance(outputs, torch.Tensor) and outputs.dim() == 0:
                loss = outputs
            else:
                loss = torch.nn.functional.mse_loss(outputs, targets)
        
        # Backward pass
        loss.backward()
        
        # XLA-specific: reduce gradients across cores if distributed
        if self.num_cores > 1:
            xm.optimizer_step(optimizer)
        else:
            optimizer.step()
        
        # Mark step for XLA
        xm.mark_step()
        
        elapsed = time.time() - start_time
        self._training_times.append(elapsed)
        
        return {
            'loss': loss.item(),
            'time': elapsed,
        }
    
    def compile_model(self, model: Any) -> Any:
        """
        'Compile' model for TPU (move to device).
        
        Args:
            model: PyTorch model
            
        Returns:
            Model on TPU device
        """
        if hasattr(model, 'to'):
            model = model.to(self.device)
            logger.info("Model moved to TPU device")
        
        # XLA will automatically compile operations
        logger.info("Model ready for XLA compilation (automatic on first forward pass)")
        
        return model
    
    def synchronize(self):
        """
        Synchronize TPU operations.
        """
        xm.mark_step()
        xm.wait_device_ops()
    
    def empty_cache(self):
        """
        Clear TPU memory cache.
        """
        # XLA manages memory automatically, but we can trigger GC
        import gc
        gc.collect()
        xm.mark_step()
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """
        Get TPU memory statistics.
        """
        # PyTorch XLA doesn't expose direct memory stats
        return {
            'backend': 'torch_xla',
            'device_type': 'tpu',
            'num_cores': self.num_cores,
            'note': 'PyTorch XLA manages TPU memory automatically',
        }
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """
        Get performance statistics.
        
        Returns:
            dict: Performance metrics
        """
        stats = {
            'backend': 'torch_xla',
            'num_inferences': len(self._inference_times),
            'num_training_steps': len(self._training_times),
        }
        
        if self._inference_times:
            stats.update({
                'avg_inference_time': np.mean(self._inference_times),
                'total_inference_time': np.sum(self._inference_times),
            })
        
        if self._training_times:
            stats.update({
                'avg_training_time': np.mean(self._training_times),
                'total_training_time': np.sum(self._training_times),
            })
        
        return stats
