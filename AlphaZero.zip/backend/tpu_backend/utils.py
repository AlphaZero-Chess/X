"""
Utility functions for TPU backend.
"""

import logging
from typing import Dict, Any
import json

logger = logging.getLogger(__name__)


def detect_hardware() -> Dict[str, Any]:
    """
    Detect available hardware (CPU, CUDA, TPU).
    
    Returns:
        dict: Hardware detection results
    """
    hardware = {
        'cpu': True,  # Always available
        'cuda': False,
        'tpu_jax': False,
        'tpu_torch_xla': False,
    }
    
    # Check CUDA
    try:
        import torch
        hardware['cuda'] = torch.cuda.is_available()
        if hardware['cuda']:
            hardware['cuda_devices'] = torch.cuda.device_count()
            hardware['cuda_device_name'] = torch.cuda.get_device_name(0)
    except ImportError:
        pass
    
    # Check JAX TPU
    try:
        import jax
        tpu_devices = jax.devices('tpu')
        hardware['tpu_jax'] = len(tpu_devices) > 0
        if hardware['tpu_jax']:
            hardware['tpu_jax_cores'] = len(tpu_devices)
    except:
        pass
    
    # Check PyTorch XLA TPU
    try:
        import torch_xla.core.xla_model as xm
        xm.xla_device()
        hardware['tpu_torch_xla'] = True
        hardware['tpu_torch_xla_cores'] = xm.xrt_world_size()
    except:
        pass
    
    return hardware


def print_hardware_info():
    """
    Print detected hardware information.
    """
    hardware = detect_hardware()
    
    print("\n" + "="*60)
    print("HARDWARE DETECTION")
    print("="*60)
    
    print(f"\nCPU: ✓ Available")
    
    if hardware['cuda']:
        print(f"\nCUDA GPU: ✓ Available")
        print(f"  - Devices: {hardware.get('cuda_devices', 0)}")
        print(f"  - Device Name: {hardware.get('cuda_device_name', 'Unknown')}")
    else:
        print(f"\nCUDA GPU: ✗ Not Available")
    
    if hardware['tpu_jax']:
        print(f"\nJAX TPU: ✓ Available")
        print(f"  - Cores: {hardware.get('tpu_jax_cores', 0)}")
    else:
        print(f"\nJAX TPU: ✗ Not Available")
    
    if hardware['tpu_torch_xla']:
        print(f"\nPyTorch XLA TPU: ✓ Available")
        print(f"  - Cores: {hardware.get('tpu_torch_xla_cores', 0)}")
    else:
        print(f"\nPyTorch XLA TPU: ✗ Not Available")
    
    print("\n" + "="*60)
    print()


def get_recommended_backend() -> str:
    """
    Get recommended TPU backend based on hardware.
    
    Returns:
        str: Recommended backend mode ('jax', 'torch_xla', or 'simulated')
    """
    hardware = detect_hardware()
    
    if hardware['tpu_jax']:
        return 'jax'
    elif hardware['tpu_torch_xla']:
        return 'torch_xla'
    else:
        return 'simulated'


def save_backend_config(backend, filepath: str):
    """
    Save backend configuration to file.
    
    Args:
        backend: TPUBackend instance
        filepath: Path to save config
    """
    config = {
        'backend_name': backend.backend_name,
        'device_info': backend.get_device_info(),
        'config': backend.config.to_dict(),
    }
    
    with open(filepath, 'w') as f:
        json.dump(config, f, indent=2)
    
    logger.info(f"Backend config saved to {filepath}")


def load_backend_config(filepath: str) -> Dict[str, Any]:
    """
    Load backend configuration from file.
    
    Args:
        filepath: Path to load config from
        
    Returns:
        dict: Backend configuration
    """
    with open(filepath, 'r') as f:
        config = json.load(f)
    
    logger.info(f"Backend config loaded from {filepath}")
    return config
