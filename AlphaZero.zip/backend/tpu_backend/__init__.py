"""
TPU Backend Abstraction Layer for AlphaZero Chess

Provides unified interface for:
- Simulated TPU (CPU/CUDA fallback)
- Real JAX TPU
- Real PyTorch XLA TPU

Usage:
    from tpu_backend import get_tpu_backend
    
    backend = get_tpu_backend(mode='auto')  # auto-detect
    # or backend = get_tpu_backend(mode='simulated')  # force simulation
    
    # Use for inference
    output = backend.inference(model, input_tensor)
    
    # Use for training
    loss = backend.train_step(model, batch, optimizer)
"""

from .core import TPUBackend, TPUConfig
from .simulated_impl import SimulatedTPUBackend

try:
    from .jax_impl import JAXTPUBackend, JAX_AVAILABLE
except (ImportError, RuntimeError, AttributeError):
    JAX_AVAILABLE = False
    JAXTPUBackend = None

try:
    from .torch_xla_impl import TorchXLATPUBackend, TORCH_XLA_AVAILABLE
except (ImportError, RuntimeError, AttributeError):
    TORCH_XLA_AVAILABLE = False
    TorchXLATPUBackend = None

import logging

logger = logging.getLogger(__name__)

__all__ = [
    'TPUBackend',
    'TPUConfig',
    'get_tpu_backend',
    'list_available_backends',
]


def list_available_backends():
    """
    List all available TPU backend implementations.
    
    Returns:
        dict: Available backends with their status
    """
    return {
        'simulated': {
            'available': True,
            'description': 'CPU/CUDA simulation of TPU operations',
            'priority': 3  # Lowest priority, always fallback
        },
        'jax': {
            'available': JAX_AVAILABLE,
            'description': 'Google JAX TPU backend',
            'priority': 1  # Highest priority for real TPUs
        },
        'torch_xla': {
            'available': TORCH_XLA_AVAILABLE,
            'description': 'PyTorch XLA TPU backend',
            'priority': 2  # Second priority
        }
    }


def get_tpu_backend(mode='auto', config=None):
    """
    Get TPU backend instance based on mode and availability.
    
    Args:
        mode (str): Backend mode - 'auto', 'simulated', 'jax', 'torch_xla'
        config (TPUConfig): Optional configuration
        
    Returns:
        TPUBackend: Initialized backend instance
        
    Raises:
        ValueError: If requested mode is not available
    """
    if config is None:
        config = TPUConfig()
    
    logger.info(f"Requesting TPU backend mode: {mode}")
    
    # Auto mode: try real TPUs first, fall back to simulation
    if mode == 'auto':
        backends_by_priority = sorted(
            list_available_backends().items(),
            key=lambda x: (x[1]['available'], -x[1]['priority']),
            reverse=True
        )
        
        for backend_name, backend_info in backends_by_priority:
            if backend_info['available']:
                try:
                    if backend_name == 'jax' and JAX_AVAILABLE:
                        backend = JAXTPUBackend(config)
                        if backend.is_available():
                            logger.info("✓ Using JAX TPU backend")
                            return backend
                    elif backend_name == 'torch_xla' and TORCH_XLA_AVAILABLE:
                        backend = TorchXLATPUBackend(config)
                        if backend.is_available():
                            logger.info("✓ Using PyTorch XLA TPU backend")
                            return backend
                    elif backend_name == 'simulated':
                        backend = SimulatedTPUBackend(config)
                        logger.info("✓ Using Simulated TPU backend (CPU/CUDA)")
                        return backend
                except Exception as e:
                    logger.warning(f"Failed to initialize {backend_name}: {e}")
                    continue
        
        # Fallback to simulated
        logger.info("✓ Falling back to Simulated TPU backend")
        return SimulatedTPUBackend(config)
    
    # Explicit mode selection
    elif mode == 'simulated':
        logger.info("✓ Using Simulated TPU backend")
        return SimulatedTPUBackend(config)
    
    elif mode == 'jax':
        if not JAX_AVAILABLE:
            raise ValueError("JAX backend requested but not available. Install: pip install jax jaxlib")
        backend = JAXTPUBackend(config)
        if not backend.is_available():
            raise ValueError("JAX installed but no TPU hardware detected")
        logger.info("✓ Using JAX TPU backend")
        return backend
    
    elif mode == 'torch_xla':
        if not TORCH_XLA_AVAILABLE:
            raise ValueError("PyTorch XLA backend requested but not available. Install: pip install torch_xla")
        backend = TorchXLATPUBackend(config)
        if not backend.is_available():
            raise ValueError("PyTorch XLA installed but no TPU hardware detected")
        logger.info("✓ Using PyTorch XLA TPU backend")
        return backend
    
    else:
        raise ValueError(f"Unknown TPU backend mode: {mode}. Use 'auto', 'simulated', 'jax', or 'torch_xla'")
