"""
Cloud Monitoring Service - Telemetry and Real-Time Streaming

Provides:
- Prometheus-style metrics endpoints
- WebSocket live feed for real-time updates
- Telemetry aggregation from cluster and job scheduler
- Performance metrics collection
"""

import asyncio
import time
import json
import logging
from typing import Dict, List, Optional, Set
from datetime import datetime, timezone
from collections import defaultdict, deque
import threading

logger = logging.getLogger(__name__)


class MetricsCollector:
    """
    Collects and aggregates metrics from cloud infrastructure
    """
    
    def __init__(self, cloud_controller, job_scheduler):
        self.cloud_controller = cloud_controller
        self.job_scheduler = job_scheduler
        
        # Metrics history (time-series data)
        self.metrics_history: deque = deque(maxlen=1000)  # Keep last 1000 data points
        
        # WebSocket connections
        self.ws_connections: Set = set()
        self.ws_lock = threading.Lock()
        
        # Collection state
        self.collection_thread = None
        self.collection_interval = 2  # seconds
        self.running = False
        
        logger.info("Metrics collector initialized")
    
    def start_collection(self):
        """Start background metrics collection"""
        if self.collection_thread and self.collection_thread.is_alive():
            return
        
        self.running = True
        self.collection_thread = threading.Thread(
            target=self._collection_loop,
            daemon=True
        )
        self.collection_thread.start()
        logger.info("Metrics collection started")
    
    def stop_collection(self):
        """Stop metrics collection"""
        self.running = False
        if self.collection_thread:
            self.collection_thread.join(timeout=5)
        logger.info("Metrics collection stopped")
    
    def _collection_loop(self):
        """Background collection loop"""
        while self.running:
            try:
                metrics = self.collect_metrics()
                self.metrics_history.append(metrics)
                
                # Broadcast to WebSocket connections
                self._broadcast_to_websockets(metrics)
                
                time.sleep(self.collection_interval)
            except Exception as e:
                logger.error(f"Metrics collection error: {e}")
    
    def collect_metrics(self) -> Dict:
        """
        Collect comprehensive metrics snapshot
        
        Returns Prometheus-style metrics plus custom telemetry
        """
        timestamp = datetime.now(timezone.utc)
        
        # Cluster metrics
        cluster_status = self.cloud_controller.get_cluster_status()
        
        # Job metrics
        queue_stats = self.job_scheduler.get_queue_stats()
        
        # Calculate derived metrics
        total_nodes = cluster_status['cluster']['total_nodes']
        total_tpus = cluster_status['cluster']['total_tpus']
        
        healthy_nodes = cluster_status['health'].get('healthy', 0)
        degraded_nodes = cluster_status['health'].get('degraded', 0)
        unhealthy_nodes = cluster_status['health'].get('unhealthy', 0)
        
        health_rate = (healthy_nodes / total_nodes * 100) if total_nodes > 0 else 0
        
        # Region metrics
        region_metrics = {}
        for region_name, region_data in cluster_status['regions'].items():
            region_metrics[region_name] = {
                'nodes': region_data['active_nodes'],
                'tpus': region_data['total_tpus'],
                'healthy': region_data['healthy_nodes'],
                'degraded': region_data['degraded_nodes'],
                'unhealthy': region_data['unhealthy_nodes'],
                'avg_latency_ms': region_data['avg_latency_ms']
            }
        
        # Job metrics
        active_jobs = queue_stats['active_jobs']
        queued_jobs = queue_stats['queue_length']
        
        # Throughput metrics
        jobs_completed = queue_stats['total_completed']
        jobs_failed = queue_stats['total_failed']
        
        success_rate = (
            (jobs_completed / (jobs_completed + jobs_failed) * 100)
            if (jobs_completed + jobs_failed) > 0 else 100.0
        )
        
        metrics = {
            'timestamp': timestamp.isoformat(),
            'timestamp_unix': time.time(),
            
            # Cluster metrics
            'cluster': {
                'total_nodes': total_nodes,
                'total_tpus': total_tpus,
                'healthy_nodes': healthy_nodes,
                'degraded_nodes': degraded_nodes,
                'unhealthy_nodes': unhealthy_nodes,
                'health_rate_percent': round(health_rate, 2)
            },
            
            # Region metrics
            'regions': region_metrics,
            
            # Job metrics
            'jobs': {
                'active': active_jobs,
                'queued': queued_jobs,
                'total_submitted': queue_stats['total_submitted'],
                'total_completed': jobs_completed,
                'total_failed': jobs_failed,
                'success_rate_percent': round(success_rate, 2),
                'priority_breakdown': queue_stats.get('priority_breakdown', {})
            },
            
            # Performance metrics
            'performance': {
                'avg_queue_time_sec': queue_stats['avg_queue_time_sec']
            }
        }
        
        return metrics
    
    def get_prometheus_metrics(self) -> str:
        """
        Generate Prometheus-compatible metrics format
        
        Returns metrics in Prometheus text exposition format
        """
        metrics = self.collect_metrics()
        
        lines = []
        
        # Cluster metrics
        lines.append('# HELP cloud_nodes_total Total number of cloud nodes')
        lines.append('# TYPE cloud_nodes_total gauge')
        lines.append(f'cloud_nodes_total {metrics["cluster"]["total_nodes"]}')
        
        lines.append('# HELP cloud_tpus_total Total number of TPUs')
        lines.append('# TYPE cloud_tpus_total gauge')
        lines.append(f'cloud_tpus_total {metrics["cluster"]["total_tpus"]}')
        
        lines.append('# HELP cloud_nodes_healthy Number of healthy nodes')
        lines.append('# TYPE cloud_nodes_healthy gauge')
        lines.append(f'cloud_nodes_healthy {metrics["cluster"]["healthy_nodes"]}')
        
        lines.append('# HELP cloud_health_rate_percent Node health rate percentage')
        lines.append('# TYPE cloud_health_rate_percent gauge')
        lines.append(f'cloud_health_rate_percent {metrics["cluster"]["health_rate_percent"]}')
        
        # Job metrics
        lines.append('# HELP jobs_active Number of active jobs')
        lines.append('# TYPE jobs_active gauge')
        lines.append(f'jobs_active {metrics["jobs"]["active"]}')
        
        lines.append('# HELP jobs_queued Number of queued jobs')
        lines.append('# TYPE jobs_queued gauge')
        lines.append(f'jobs_queued {metrics["jobs"]["queued"]}')
        
        lines.append('# HELP jobs_completed_total Total completed jobs')
        lines.append('# TYPE jobs_completed_total counter')
        lines.append(f'jobs_completed_total {metrics["jobs"]["total_completed"]}')
        
        lines.append('# HELP jobs_success_rate_percent Job success rate')
        lines.append('# TYPE jobs_success_rate_percent gauge')
        lines.append(f'jobs_success_rate_percent {metrics["jobs"]["success_rate_percent"]}')
        
        # Region metrics
        for region_name, region_data in metrics['regions'].items():
            lines.append(f'# HELP cloud_region_nodes_{{region="{region_name}"}} Nodes in region')
            lines.append(f'# TYPE cloud_region_nodes gauge')
            lines.append(f'cloud_region_nodes{{region="{region_name}"}} {region_data["nodes"]}')
            
            lines.append(f'# HELP cloud_region_latency_ms_{{region="{region_name}"}} Avg latency in region')
            lines.append(f'# TYPE cloud_region_latency_ms gauge')
            lines.append(f'cloud_region_latency_ms{{region="{region_name}"}} {region_data["avg_latency_ms"]}')
        
        return '\n'.join(lines)
    
    def get_metrics_history(self, limit: int = 100) -> List[Dict]:
        """Get recent metrics history"""
        return list(self.metrics_history)[-limit:]
    
    def register_websocket(self, websocket):
        """Register a WebSocket connection for live updates"""
        with self.ws_lock:
            self.ws_connections.add(websocket)
            logger.info(f"WebSocket registered: {len(self.ws_connections)} active connections")
    
    def unregister_websocket(self, websocket):
        """Unregister a WebSocket connection"""
        with self.ws_lock:
            self.ws_connections.discard(websocket)
            logger.info(f"WebSocket unregistered: {len(self.ws_connections)} active connections")
    
    def _broadcast_to_websockets(self, metrics: Dict):
        """Broadcast metrics to all connected WebSocket clients"""
        with self.ws_lock:
            if not self.ws_connections:
                return
            
            message = json.dumps({
                'type': 'metrics_update',
                'data': metrics
            })
            
            # Remove disconnected clients
            disconnected = set()
            
            for ws in self.ws_connections:
                try:
                    # This will be handled by the async WebSocket handler
                    # Store message in a queue for the websocket to send
                    if hasattr(ws, 'message_queue'):
                        ws.message_queue.append(message)
                except Exception as e:
                    logger.warning(f"Failed to queue message for WebSocket: {e}")
                    disconnected.add(ws)
            
            # Clean up disconnected clients
            for ws in disconnected:
                self.ws_connections.discard(ws)


class CloudMonitoringService:
    """
    Cloud Monitoring Service
    
    Provides:
    - Prometheus metrics endpoint
    - WebSocket live streaming
    - Metrics aggregation and history
    """
    
    def __init__(self, cloud_controller, job_scheduler):
        logger.info("="*80)
        logger.info("INITIALIZING CLOUD MONITORING SERVICE")
        logger.info("="*80)
        
        self.metrics_collector = MetricsCollector(cloud_controller, job_scheduler)
        
        # Start metrics collection
        self.metrics_collector.start_collection()
        
        logger.info("✅ Cloud Monitoring Service initialized")
    
    def get_metrics_json(self) -> Dict:
        """Get current metrics as JSON"""
        return self.metrics_collector.collect_metrics()
    
    def get_metrics_prometheus(self) -> str:
        """Get current metrics in Prometheus format"""
        return self.metrics_collector.get_prometheus_metrics()
    
    def get_metrics_history(self, limit: int = 100) -> List[Dict]:
        """Get metrics history"""
        return self.metrics_collector.get_metrics_history(limit)
    
    def register_websocket(self, websocket):
        """Register WebSocket connection"""
        self.metrics_collector.register_websocket(websocket)
    
    def unregister_websocket(self, websocket):
        """Unregister WebSocket connection"""
        self.metrics_collector.unregister_websocket(websocket)
    
    def stop(self):
        """Stop monitoring service"""
        self.metrics_collector.stop_collection()


# Global instance
_monitoring_service = None


def get_monitoring_service(
    cloud_controller=None,
    job_scheduler=None
) -> CloudMonitoringService:
    """Get or create global monitoring service"""
    global _monitoring_service
    
    if _monitoring_service is None:
        if cloud_controller is None:
            from cloud_cluster_controller import get_cloud_controller
            cloud_controller = get_cloud_controller()
        
        if job_scheduler is None:
            from cloud_job_scheduler import get_job_scheduler
            job_scheduler = get_job_scheduler(cloud_controller)
        
        _monitoring_service = CloudMonitoringService(
            cloud_controller,
            job_scheduler
        )
    
    return _monitoring_service


def reset_monitoring_service():
    """Reset global monitoring service (for testing)"""
    global _monitoring_service
    if _monitoring_service:
        _monitoring_service.stop()
    _monitoring_service = None
