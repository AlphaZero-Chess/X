"""
Test script to verify Unicode/Emoji logging works on Windows
Tests the fixes applied to distributed_selfplay_v2.py
"""

import sys
import io
import logging

# Apply the same fix as in distributed_selfplay_v2.py
if sys.platform == 'win32':
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding='utf-8', errors='replace')
    except Exception as e:
        print(f"Note: Could not wrap stdout/stderr: {e}")

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

# Test emoji logging
test_emojis = [
    "🚀 Worker starting",
    "📥 Task received",
    "✅ Model loaded",
    "❌ Error occurred",
    "📤 Batch complete",
    "🔄 Serializing samples",
    "⏹️  Worker exiting",
    "🚫 Fatal error",
    "📦 Collecting results",
    "📊 Progress update"
]

print("="*80)
print("UNICODE/EMOJI LOGGING TEST")
print("="*80)
print(f"Platform: {sys.platform}")
print(f"Python version: {sys.version}")
print(f"stdout encoding: {sys.stdout.encoding}")
print(f"stderr encoding: {sys.stderr.encoding}")
print("="*80)

print("\nTesting emoji output to console:")
for emoji_msg in test_emojis:
    try:
        print(f"  {emoji_msg}")
        logger.info(emoji_msg)
    except UnicodeEncodeError as e:
        print(f"  ❌ FAILED: {e}")
        logger.error(f"Failed to log: {emoji_msg[:10]}...")

print("\n" + "="*80)
print("TEST COMPLETE")
print("If you see all emojis above without errors, the fix is working!")
print("="*80)
