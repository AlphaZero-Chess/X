"""
Phase 4 Tests - TPU-Enhanced Evaluation & Promotion

Test Suites:
1. Unit Tests: ELO aggregation, promotion criteria, atomicity
2. Integration Tests: Pod-balanced evaluation, model registry
3. Smoke Tests: 4 pods × 10 games (quick validation)
4. Full Tests: Configurable pods × games (comprehensive validation)
"""

import asyncio
import unittest
import logging
from pathlib import Path
import shutil

from evaluation_manager import EvaluationManager, get_evaluation_manager, reset_evaluation_manager
from model_registry import ModelRegistry, get_model_registry, reset_model_registry
from neural_network import AlphaZeroNetwork, ModelManager
from evaluator import ELOCalculator
from tpu_cluster_manager import get_tpu_grid

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TestELOAggregation(unittest.TestCase):
    """Unit tests for ELO calculation and aggregation"""
    
    def test_basic_elo_calculation(self):
        """Test basic ELO calculation"""
        # Test case: 60% win rate
        result = ELOCalculator.calculate_elo_delta(
            wins=12,
            losses=8,
            draws=0,
            current_elo=1500.0,
            opponent_elo=1500.0,
            k_factor=32
        )
        
        self.assertGreater(result['elo_delta'], 0, "Should have positive ELO delta for winning record")
        self.assertEqual(result['total_games'], 20)
        self.assertAlmostEqual(result['actual_score'], 0.6, places=2)
    
    def test_weighted_aggregation(self):
        """Test weighted aggregation of per-pod results"""
        # Simulate 2 pods with different performance
        # Pod 0: 8/10 wins
        # Pod 1: 4/10 wins
        # Weighted avg should be (8+4)/(10+10) = 0.6
        
        pod0_wins = 8
        pod1_wins = 4
        total_wins = pod0_wins + pod1_wins
        total_games = 20
        
        weighted_win_rate = total_wins / total_games
        self.assertAlmostEqual(weighted_win_rate, 0.6, places=2)
    
    def test_promotion_criteria(self):
        """Test promotion criteria logic"""
        registry = ModelRegistry()
        
        # Test 1: Win rate passes, ELO doesn't
        should_promote, reason = registry.should_promote(
            challenger_win_rate=0.60,
            elo_delta=30.0,
            win_threshold=0.55,
            elo_threshold=50.0
        )
        self.assertTrue(should_promote, "Should promote based on win rate")
        
        # Test 2: ELO passes, win rate doesn't
        should_promote, reason = registry.should_promote(
            challenger_win_rate=0.50,
            elo_delta=60.0,
            win_threshold=0.55,
            elo_threshold=50.0
        )
        self.assertTrue(should_promote, "Should promote based on ELO")
        
        # Test 3: Neither passes
        should_promote, reason = registry.should_promote(
            challenger_win_rate=0.50,
            elo_delta=30.0,
            win_threshold=0.55,
            elo_threshold=50.0
        )
        self.assertFalse(should_promote, "Should not promote")


class TestModelRegistry(unittest.TestCase):
    """Integration tests for model registry"""
    
    def setUp(self):
        """Setup test environment"""
        self.test_dir = Path("/tmp/test_model_registry")
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
        self.test_dir.mkdir(parents=True)
        
        self.registry = ModelRegistry(
            models_dir=str(self.test_dir / "models"),
            registry_file=str(self.test_dir / "registry.json")
        )
    
    def tearDown(self):
        """Cleanup test environment"""
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
    
    def test_promotion_atomicity(self):
        """Test atomic promotion"""
        model = AlphaZeroNetwork()
        
        success, message = self.registry.promote_model(
            model=model,
            model_name="test_model_v1",
            elo=1550.0,
            promoted_by="test",
            reason="Test promotion"
        )
        
        self.assertTrue(success, f"Promotion should succeed: {message}")
        
        # Verify current best is updated
        current_best = self.registry.registry['current_best']
        self.assertEqual(current_best['name'], "test_model_v1")
        self.assertEqual(current_best['elo'], 1550.0)
    
    def test_rollback(self):
        """Test model rollback"""
        # Promote multiple versions
        for i in range(1, 4):
            model = AlphaZeroNetwork()
            self.registry.promote_model(
                model=model,
                model_name=f"test_model_v{i}",
                elo=1500.0 + i * 50,
                promoted_by="test",
                reason=f"Test promotion {i}"
            )
        
        # Current should be v3
        self.assertEqual(self.registry.registry['current_best']['name'], "test_model_v3")
        
        # Rollback to v2
        success, message = self.registry.rollback_to_version(1)
        self.assertTrue(success, f"Rollback should succeed: {message}")
        
        # Verify rollback
        current_best = self.registry.registry['current_best']
        self.assertEqual(current_best['version'], 1)
    
    def test_version_history(self):
        """Test version history tracking"""
        # Promote several versions
        for i in range(1, 5):
            model = AlphaZeroNetwork()
            self.registry.promote_model(
                model=model,
                model_name=f"test_model_v{i}",
                elo=1500.0 + i * 25,
                promoted_by="test",
                reason=f"Test {i}"
            )
        
        versions = self.registry.list_all_versions()
        self.assertGreaterEqual(len(versions), 4, "Should have at least 4 versions")
        
        # Check promotion history
        history = self.registry.get_promotion_history()
        self.assertEqual(len(history), 4, "Should have 4 promotions")


class TestPodBalancedEvaluation(unittest.TestCase):
    """Integration tests for pod-balanced evaluation"""
    
    def setUp(self):
        """Setup test environment"""
        reset_evaluation_manager()
        self.eval_manager = get_evaluation_manager()
    
    def test_game_distribution(self):
        """Test game distribution across pods"""
        # Create mock job
        from evaluation_manager import EvaluationJob, EvaluationStatus
        
        job = EvaluationJob(
            job_id="test_job",
            challenger_name="test_challenger",
            champion_name="test_champion",
            total_games=100,
            pods_allocated=4,
            status=EvaluationStatus.PENDING,
            use_tpu_pods=True
        )
        
        # Distribute games
        asyncio.run(self.eval_manager._distribute_games(job))
        
        # Verify distribution
        total_assigned = sum(task.games_assigned for task in job.pod_tasks.values())
        self.assertEqual(total_assigned, 100, "All games should be assigned")
        
        # Each pod should have ~25 games
        for task in job.pod_tasks.values():
            self.assertGreaterEqual(task.games_assigned, 24)
            self.assertLessEqual(task.games_assigned, 26)


class SmokeTest(unittest.TestCase):
    """Smoke test: 4 pods × 10 games (quick validation)"""
    
    def test_smoke_evaluation(self):
        """Run quick smoke test with 4 pods and 10 games"""
        logger.info("="*80)
        logger.info("SMOKE TEST: 4 pods × 10 games")
        logger.info("="*80)
        
        reset_evaluation_manager()
        eval_manager = get_evaluation_manager()
        
        # Create two models
        challenger = AlphaZeroNetwork()
        champion = AlphaZeroNetwork()
        
        # Run evaluation
        job, results = asyncio.run(eval_manager.start_evaluation(
            challenger_model=challenger,
            champion_model=champion,
            challenger_name="smoke_challenger",
            champion_name="smoke_champion",
            num_eval_games=10,
            pods_for_eval=4,
            use_tpu_pods=True,
            autoscale_eval=False,
            pod_warmup_seconds=2,
            aggregation_mode="weighted_by_games",
            async_mode=False
        ))
        
        # Verify results
        self.assertEqual(results['total_games'], 10)
        self.assertIn('challenger_win_rate', results)
        self.assertIn('elo_calculations', results)
        self.assertIn('per_pod_results', results)
        
        logger.info(f"✅ Smoke test passed!")
        logger.info(f"   Games: {results['total_games']}")
        logger.info(f"   Win rate: {results['challenger_win_rate']:.1%}")
        logger.info(f"   ELO delta: {results['elo_calculations']['elo_delta']:+.0f}")
        logger.info(f"   Per-pod results: {len(results['per_pod_results'])} pods")


class FullValidationTest(unittest.TestCase):
    """Full validation test: Configurable pods × games"""
    
    def test_full_evaluation(self):
        """Run full validation with default config"""
        logger.info("="*80)
        logger.info("FULL VALIDATION TEST: 2 pods × 20 games")
        logger.info("="*80)
        
        reset_evaluation_manager()
        reset_model_registry()
        
        eval_manager = get_evaluation_manager()
        registry = get_model_registry()
        
        # Create models
        challenger = AlphaZeroNetwork()
        champion = AlphaZeroNetwork()
        
        # Run evaluation
        job, results = asyncio.run(eval_manager.start_evaluation(
            challenger_model=challenger,
            champion_model=champion,
            challenger_name="full_challenger",
            champion_name="full_champion",
            challenger_elo=1500.0,
            champion_elo=1500.0,
            num_eval_games=20,
            pods_for_eval=2,
            use_tpu_pods=True,
            autoscale_eval=True,
            pod_warmup_seconds=5,
            aggregation_mode="weighted_by_games",
            elo_k_factor=32,
            async_mode=False
        ))
        
        # Verify results
        self.assertEqual(results['total_games'], 20)
        self.assertGreaterEqual(results['challenger_wins'] + results['champion_wins'] + results['draws'], 20)
        
        # Check per-pod breakdown
        self.assertEqual(len(results['per_pod_results']), 2)
        
        # Verify aggregation
        total_pod_games = sum(r['games_completed'] for r in results['per_pod_results'].values())
        self.assertEqual(total_pod_games, 20)
        
        logger.info(f"✅ Full validation passed!")
        logger.info(f"   Results: {results['challenger_wins']}W-{results['champion_wins']}L-{results['draws']}D")
        logger.info(f"   Win rate: {results['challenger_win_rate']:.1%}")
        logger.info(f"   ELO delta: {results['elo_calculations']['elo_delta']:+.0f}")
        logger.info(f"   Aggregation: {results['aggregation_mode']}")
        
        # Test promotion decision
        should_promote, reason = registry.should_promote(
            challenger_win_rate=results['challenger_win_rate'],
            elo_delta=results['elo_calculations']['elo_delta']
        )
        
        logger.info(f"   Promotion: {should_promote} - {reason}")
        
        # If should promote, test promotion
        if should_promote:
            success, message = registry.promote_model(
                model=challenger,
                model_name="promoted_test_model",
                elo=1500.0 + results['elo_calculations']['elo_delta'],
                promoted_by="full_test",
                reason=reason
            )
            
            self.assertTrue(success, f"Promotion should succeed: {message}")
            logger.info(f"   ✅ Promotion successful: {message}")


def run_smoke_test():
    """Run smoke test only"""
    suite = unittest.TestLoader().loadTestsFromTestCase(SmokeTest)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    return result.wasSuccessful()


def run_full_tests():
    """Run all tests"""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add test cases
    suite.addTests(loader.loadTestsFromTestCase(TestELOAggregation))
    suite.addTests(loader.loadTestsFromTestCase(TestModelRegistry))
    suite.addTests(loader.loadTestsFromTestCase(TestPodBalancedEvaluation))
    suite.addTests(loader.loadTestsFromTestCase(SmokeTest))
    suite.addTests(loader.loadTestsFromTestCase(FullValidationTest))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--smoke":
        success = run_smoke_test()
    elif len(sys.argv) > 1 and sys.argv[1] == "--full":
        success = run_full_tests()
    else:
        # Default: run smoke test first, then full if it passes
        logger.info("Running smoke test first...")
        smoke_success = run_smoke_test()
        
        if smoke_success:
            logger.info("\n" + "="*80)
            logger.info("Smoke test passed! Running full test suite...")
            logger.info("="*80 + "\n")
            success = run_full_tests()
        else:
            logger.error("Smoke test failed! Skipping full tests.")
            success = False
    
    sys.exit(0 if success else 1)
