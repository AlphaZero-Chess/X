# 🚀 Quick Start Guide: PGN-Integrated Curriculum Training Roadmap

## Overview
This guide will help you start using the PGN-Integrated Curriculum Training Roadmap to train your AlphaZero Chess model toward **ELO 3500+ superhuman performance**.

---

## Prerequisites

### 1. Verify Installation
```bash
# Check Python dependencies
pip freeze | grep -E "(chess|torch|numpy)"

# Should show:
# chess==1.11.2
# python-chess==1.999
# torch==2.8.0
# numpy>=1.26.0
```

### 2. Prepare Your PGN Files
You mentioned you have PGN files ready. Organize them as:
- **Human GM Games**: `human_games_*.pgn`
- **Engine Games**: `engine_games_*.pgn`

---

## Step-by-Step Usage

### Step 1: Start the Backend Server
```bash
cd /app/backend
python server.py
```

The server will start on `http://localhost:8001`

### Step 2: Upload Your First PGN File (Human GM Games)

**Via curl:**
```bash
curl -X POST "http://localhost:8001/api/roadmap/ingest-pgn?source_type=human" \
  -F "file=@your_human_games.pgn"
```

**Expected Response:**
```json
{
  "success": true,
  "message": "Ingested 50 games from your_human_games.pgn",
  "games_ingested": 50,
  "positions_extracted": 2500,
  "processed_file": "processed_20250810_120000_your_human_games.pgn.json",
  "source_type": "human"
}
```

### Step 3: Upload Engine Games
```bash
curl -X POST "http://localhost:8001/api/roadmap/ingest-pgn?source_type=engine" \
  -F "file=@your_engine_games.pgn"
```

### Step 4: Check Roadmap Status
```bash
curl http://localhost:8001/api/roadmap/status | jq
```

**Expected Response:**
```json
{
  "success": true,
  "roadmap": {
    "overall_progress": 0,
    "current_phase": 1,
    "phases": {
      "phase_1": {
        "description": "70% Human PGNs / 30% Self-Play - Foundation Building",
        "target_games": 1000,
        "status": "in_progress"
      }
    },
    "elo_status": {
      "current": 1500,
      "target": 3500,
      "progress_percent": 42.9
    }
  },
  "iq_status": {
    "current_elo": 1500,
    "target_elo": 3500
  }
}
```

### Step 5: Run Your First Training Cycle
```bash
curl -X POST "http://localhost:8001/api/roadmap/run-cycle?num_selfplay_games=25&num_external_games=50&num_epochs=5"
```

**What Happens:**
1. ✅ System determines you're in **Phase 1** (Foundation Building)
2. ✅ Loads 50 external PGN games (70% weight)
3. ✅ Generates 25 self-play games (30% weight)
4. ✅ Blends data with weighted sampling
5. ✅ Trains network for 5 epochs
6. ✅ Evaluates against previous model
7. ✅ Generates reflection on performance
8. ✅ Checks if network scaling is needed
9. ✅ Updates IQ tracking and evolution metrics

**Expected Duration:** 30-60 minutes (depends on hardware)

### Step 6: Monitor IQ Growth
```bash
curl http://localhost:8001/api/roadmap/iq-tracking | jq
```

**Response:**
```json
{
  "success": true,
  "current_status": {
    "current_elo": 1550,
    "target_elo": 3500,
    "elo_delta_recent": 50,
    "progress_percent": 44.3,
    "growth_rate_per_100_games": 25.0,
    "evaluation_consistency": 0.75,
    "evaluation_stability": 0.80,
    "status": "Beginner - Learning fundamentals"
  }
}
```

### Step 7: Check Network Capacity
```bash
curl http://localhost:8001/api/roadmap/network-capacity | jq
```

**Response:**
```json
{
  "success": true,
  "capacity": {
    "num_filters": 256,
    "num_residual_blocks": 19,
    "mcts_simulations": 800,
    "scaling_count": 0,
    "last_scaled": null
  }
}
```

---

## Training Loop Workflow

### Automated Training (Recommended)
Run multiple cycles in sequence:

```bash
#!/bin/bash
# run_training_loop.sh

for i in {1..10}; do
  echo "=== Training Cycle $i ==="
  
  curl -X POST "http://localhost:8001/api/roadmap/run-cycle?num_selfplay_games=25&num_external_games=50&num_epochs=5"
  
  echo "Waiting 60 minutes for cycle to complete..."
  sleep 3600
  
  echo "Checking status..."
  curl http://localhost:8001/api/roadmap/status | jq '.roadmap.elo_status'
  
  echo ""
done
```

### Manual Monitoring
Check progress regularly:

```bash
# Get complete roadmap status
curl http://localhost:8001/api/roadmap/status

# Get IQ tracking
curl http://localhost:8001/api/roadmap/iq-tracking

# Get evolution metrics
curl http://localhost:8001/api/roadmap/evolution-metrics

# Get PGN stats
curl http://localhost:8001/api/roadmap/pgn-stats

# Get network capacity
curl http://localhost:8001/api/roadmap/network-capacity
```

---

## Curriculum Phase Progression

### Phase 1: Foundation Building (0-1,000 games)
- **Data Ratio**: 70% Human PGNs / 30% Self-Play
- **Focus**: Learn fundamentals from GM games
- **Expected ELO**: 1500 → 2200
- **Duration**: ~100 hours

**What to Do:**
- Upload high-quality GM games
- Run 40 training cycles (25 games each = 1,000 total)
- Monitor evaluation consistency

### Phase 2: Pattern Integration (1,000-5,000 games)
- **Data Ratio**: 50% Human PGNs / 50% Self-Play
- **Focus**: Balance human knowledge with self-discoveries
- **Expected ELO**: 2200 → 2800
- **Duration**: ~400 hours

**System Automatically:**
- Transitions to Phase 2 at 1,000 games
- Adjusts data blending ratio
- Continues training cycles

### Phase 3: Self-Evolution (5,000+ games)
- **Data Ratio**: 20% Human PGNs / 80% Self-Play
- **Focus**: Prioritize self-discovered strategies
- **Expected ELO**: 2800 → 3500+
- **Duration**: ~1,000 hours

**System Automatically:**
- Transitions to Phase 3 at 5,000 games
- Triggers first network scaling
- Increases MCTS simulations
- Continues toward superhuman performance

---

## Network Scaling

### Automatic Scaling
The system will **automatically scale** when:
- ✅ Total games >= 5,000 (first scaling)
- ✅ ELO plateaus for 3+ cycles
- ✅ Each subsequent 5,000 games

**Scaling Effects:**
```
Before Scaling: 256 filters, 19 blocks, 800 MCTS sims
After Scaling:  384 filters, 21 blocks, 1200 MCTS sims
```

### Manual Scaling
Force scaling anytime:
```bash
curl -X POST http://localhost:8001/api/roadmap/manual-scale
```

---

## Monitoring Dashboards

### Key Metrics to Watch

**1. ELO Progression**
```bash
curl http://localhost:8001/api/roadmap/iq-tracking | jq '.current_status.current_elo'
```

**2. Evaluation Consistency** (Target: >0.9)
```bash
curl http://localhost:8001/api/roadmap/iq-tracking | jq '.current_status.evaluation_consistency'
```

**3. Current Phase**
```bash
curl http://localhost:8001/api/roadmap/curriculum-phase | jq '.phase'
```

**4. Games Processed**
```bash
curl http://localhost:8001/api/roadmap/evolution-metrics | jq '.current_metrics.total_games_processed'
```

**5. Network Scaling Count**
```bash
curl http://localhost:8001/api/roadmap/network-capacity | jq '.capacity.scaling_count'
```

---

## Expected Timeline to ELO 3500+

| Milestone | Games | ELO | Phase | Estimated Time |
|-----------|-------|-----|-------|----------------|
| Start | 0 | 1500 | 1 | 0 hours |
| Learning | 500 | 2000 | 1 | 50 hours |
| Phase 1 Complete | 1,000 | 2200 | 1→2 | 100 hours |
| Developing | 2,500 | 2500 | 2 | 250 hours |
| Phase 2 Complete | 5,000 | 2800 | 2→3 | 500 hours |
| First Scaling | 5,000 | 2800 | 3 | 500 hours |
| Elite | 7,500 | 3000 | 3 | 750 hours |
| Engine Level | 10,000 | 3200 | 3 | 1,000 hours |
| **Superhuman** | 15,000 | **3500+** | 3 | **1,500 hours** |

**With moderate GPU (8-12GB VRAM):** ~2 months continuous training

---

## Troubleshooting

### Issue: "No training data available"
**Solution:** Upload more PGN files
```bash
curl -X POST "http://localhost:8001/api/roadmap/ingest-pgn?source_type=human" \
  -F "file=@more_games.pgn"
```

### Issue: "Training too slow"
**Solutions:**
- Reduce `num_epochs` (from 5 to 3)
- Reduce `num_selfplay_games` (from 25 to 15)
- Check GPU utilization

### Issue: "ELO plateau"
**Solutions:**
- System will auto-scale network
- Or manually trigger scaling:
```bash
curl -X POST http://localhost:8001/api/roadmap/manual-scale
```

### Issue: "Evaluation consistency low (<0.7)"
**Solution:** Continue training - consistency improves with more games

---

## Best Practices

### 1. Upload Quality PGNs
- ✅ GM games (ELO 2600+)
- ✅ Engine games (Stockfish 15+, depth 25+)
- ✅ Mix of opening repertoires
- ✅ Varied game lengths (tactical + positional + endgames)

### 2. Monitor Regularly
- Check IQ growth daily
- Watch for phase transitions
- Verify evaluation consistency improving

### 3. Let System Auto-Evolve
- Don't interrupt training cycles
- Trust the curriculum phasing
- Allow auto-scaling to occur naturally

### 4. Backup Models
```bash
# List models
curl http://localhost:8001/api/model/list

# Export current model
curl -X POST http://localhost:8001/api/model/export/pytorch/ActiveModel_Offline
```

---

## Advanced Configuration

### Customize Training Cycle
```bash
# More aggressive training (faster, but may overfit)
curl -X POST "http://localhost:8001/api/roadmap/run-cycle?num_selfplay_games=50&num_external_games=100&num_epochs=10"

# Conservative training (slower, more stable)
curl -X POST "http://localhost:8001/api/roadmap/run-cycle?num_selfplay_games=15&num_external_games=30&num_epochs=3"
```

### Adjust Scaling Thresholds
Edit `/app/backend/config.json`:
```json
{
  "scaling": {
    "auto_scale": true,
    "scale_trigger_games": 5000,
    "scale_trigger_elo_plateau": 5.0,
    "plateau_check_cycles": 3
  }
}
```

---

## Success Indicators

You're on track when:
- ✅ ELO increasing steadily (20-30 per 100 games)
- ✅ Evaluation consistency > 0.80
- ✅ Evaluation stability > 0.75
- ✅ Training loss decreasing
- ✅ Phase transitions happening naturally

---

## Final Goal: ELO 3500+ 🏆

**When you reach ELO 3500+:**
- 🎯 AlphaZero is **superhuman**
- 🎯 Beats Stockfish at depth 30+
- 🎯 Discovers novel opening ideas
- 🎯 Optimal endgame play
- 🎯 Consistent evaluation (>0.90)

**Congratulations! You've built a chess AI that rivals the best engines in the world! 🚀♟️**

---

## Need Help?

Check the comprehensive documentation:
- 📖 **Full Roadmap**: `/app/backend/ROADMAP.md`
- 📊 **API Documentation**: See ROADMAP.md for all endpoints
- 🔧 **Module Details**: Each Python file has extensive docstrings

---

**Happy Training! May your AlphaZero reach peak chess intelligence! 🧠♟️**
