# AlphaZero Test Cycle - Complete Index

## 📋 Files Overview

This directory contains a complete standalone test script for validating the AlphaZero Chess training pipeline.

## 🚀 Start Here

| File | Purpose | Read This If... |
|------|---------|-----------------|
| **[QUICK_START.md](QUICK_START.md)** | Get started in 3 minutes | You want to run your first test right now |
| **[validate_installation.py](validate_installation.py)** | Check installation | You want to verify everything is set up correctly |
| **[test_cycle_quick.py](test_cycle_quick.py)** | Quick test script | You want fast validation (2-5 minutes) |

## 📚 Documentation

| File | Content | Read This If... |
|------|---------|-----------------|
| **[TEST_CYCLE_README.md](TEST_CYCLE_README.md)** | Complete usage guide | You want detailed documentation |
| **[TEST_CYCLE_SUMMARY.md](TEST_CYCLE_SUMMARY.md)** | Implementation overview | You want a high-level summary |
| **[EXAMPLE_OUTPUT.md](EXAMPLE_OUTPUT.md)** | Example outputs | You want to see what results look like |
| **[TEST_CYCLE_INDEX.md](TEST_CYCLE_INDEX.md)** | This file | You want to navigate all documentation |

## 🔧 Scripts

| File | Description | Usage |
|------|-------------|-------|
| **[test_cycle.py](test_cycle.py)** | Main test script | `python test_cycle.py --games 20` |
| **[test_cycle_quick.py](test_cycle_quick.py)** | Quick test (50 MCTS sims) | `python test_cycle_quick.py --games 2` |
| **[validate_installation.py](validate_installation.py)** | Installation validator | `python validate_installation.py` |

## 📖 Reading Order

### For First-Time Users

1. **[QUICK_START.md](QUICK_START.md)** - Get started immediately
2. **[validate_installation.py](validate_installation.py)** - Check setup
3. **[test_cycle_quick.py](test_cycle_quick.py)** - Run first test
4. **[EXAMPLE_OUTPUT.md](EXAMPLE_OUTPUT.md)** - See what to expect

### For Detailed Understanding

1. **[TEST_CYCLE_SUMMARY.md](TEST_CYCLE_SUMMARY.md)** - Overview
2. **[TEST_CYCLE_README.md](TEST_CYCLE_README.md)** - Complete guide
3. **[test_cycle.py](test_cycle.py)** - Source code
4. **[EXAMPLE_OUTPUT.md](EXAMPLE_OUTPUT.md)** - Examples

### For Troubleshooting

1. **[validate_installation.py](validate_installation.py)** - Check dependencies
2. **[TEST_CYCLE_README.md](TEST_CYCLE_README.md)** - See troubleshooting section
3. `/app/backend/cache/test_cycle.log` - Debug logs
4. `/app/backend/cache/test_cycle_results.json` - Results data

## 🎯 Quick Reference

### Run a Test

```bash
# Validate installation
python validate_installation.py

# Quick test (3-5 min)
python test_cycle_quick.py --games 2

# Full test (20-30 min)
python test_cycle.py --games 10

# Parallel test (faster)
python test_cycle.py --games 20 --parallel --threads 4
```

### Check Results

```bash
# View results JSON
cat /app/backend/cache/test_cycle_results.json

# View logs
tail -f /app/backend/cache/test_cycle.log

# List generated games
ls /app/backend/cache/selfplay/test_cycle_pgns/
```

### Get Help

```bash
# Show all options
python test_cycle.py --help
python test_cycle_quick.py --help

# Validate setup
python validate_installation.py
```

## 📊 What Each Script Does

### test_cycle.py (Main Script)

**Purpose:** Production-grade pipeline validation

**Features:**
- Full MCTS simulations (800 for self-play, 400 for eval)
- Comprehensive logging
- Complete ELO calculation
- PGN file generation

**When to use:** Real validation, performance testing

**Time:** 20-60 minutes for 20 games

### test_cycle_quick.py (Quick Test)

**Purpose:** Fast development validation

**Features:**
- Reduced MCTS simulations (50 for all phases)
- Same pipeline as main script
- 16x faster execution

**When to use:** Development, quick checks

**Time:** 2-5 minutes for 3 games

### validate_installation.py (Validator)

**Purpose:** Installation verification

**Features:**
- Checks Python version
- Verifies dependencies
- Tests module imports
- Checks directory structure

**When to use:** Before running tests, troubleshooting

**Time:** <5 seconds

## 📁 Output Structure

```
/app/backend/
├── models/                          # Saved models
│   ├── ActiveModel_Offline.pt       # Base model
│   └── ActiveModel_TestCycle.pt     # Trained model
│
├── cache/                           # Test outputs
│   ├── test_cycle_results.json      # JSON results
│   ├── test_cycle.log               # Debug logs
│   └── selfplay/
│       └── test_cycle_pgns/         # PGN files
│           ├── game_*_000001.pgn
│           ├── game_*_000002.pgn
│           └── ...
│
├── test_cycle.py                    # Main script ⭐
├── test_cycle_quick.py              # Quick script ⭐
├── validate_installation.py         # Validator ⭐
│
└── [Documentation]
    ├── QUICK_START.md               # Start here!
    ├── TEST_CYCLE_README.md         # Full guide
    ├── TEST_CYCLE_SUMMARY.md        # Overview
    ├── EXAMPLE_OUTPUT.md            # Examples
    └── TEST_CYCLE_INDEX.md          # This file
```

## 🔍 Key Features

### ✅ Complete Pipeline Test
- Self-Play → Training → Evaluation
- All phases validated in one run

### ✅ Flexible Configuration
- Configurable via CLI arguments
- Sequential or parallel self-play
- Quick or full test modes

### ✅ Comprehensive Output
- JSON results file
- Detailed logs
- PGN game files

### ✅ Error Handling
- Graceful failure recovery
- Automatic model creation
- First-run detection

### ✅ Offline Compatible
- No external dependencies
- Works on CPU or GPU
- Air-gap friendly

## 🎓 Learning Resources

### Beginner Path
1. Read [QUICK_START.md](QUICK_START.md)
2. Run `validate_installation.py`
3. Run `test_cycle_quick.py --games 2`
4. Check results in JSON file

### Intermediate Path
1. Read [TEST_CYCLE_README.md](TEST_CYCLE_README.md)
2. Run various test configurations
3. Analyze [EXAMPLE_OUTPUT.md](EXAMPLE_OUTPUT.md)
4. Customize parameters

### Advanced Path
1. Read [TEST_CYCLE_SUMMARY.md](TEST_CYCLE_SUMMARY.md)
2. Study source code in `test_cycle.py`
3. Modify MCTS parameters
4. Integrate into CI/CD

## 📞 Support

| Issue | Solution |
|-------|----------|
| Installation problems | Run `validate_installation.py` |
| Script errors | Check `/app/backend/cache/test_cycle.log` |
| Understanding output | Read [EXAMPLE_OUTPUT.md](EXAMPLE_OUTPUT.md) |
| Performance issues | See troubleshooting in [TEST_CYCLE_README.md](TEST_CYCLE_README.md) |
| General questions | Read [QUICK_START.md](QUICK_START.md) |

## 🏆 Success Checklist

- [ ] `validate_installation.py` shows all green checkmarks
- [ ] `test_cycle_quick.py --games 2` completes successfully
- [ ] `test_cycle_results.json` file is created
- [ ] PGN files are saved to `cache/selfplay/test_cycle_pgns/`
- [ ] Models are saved to `models/` directory
- [ ] Second run shows evaluation results

## 🎯 Next Steps

1. **Validate**: `python validate_installation.py`
2. **Quick Test**: `python test_cycle_quick.py --games 2`
3. **Full Test**: `python test_cycle.py --games 10`
4. **Review Results**: `cat cache/test_cycle_results.json`
5. **Read Docs**: Start with [QUICK_START.md](QUICK_START.md)

---

**Everything you need is here. Start with [QUICK_START.md](QUICK_START.md)!** 🚀
