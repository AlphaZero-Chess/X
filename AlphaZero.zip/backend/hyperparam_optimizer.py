"""
Hyperparameter Optimization & Meta-Learning Module for AlphaZero
Implements intelligent parameter tuning and adaptive meta-learning

Features:
- Bayesian Optimization using Optuna
- Multi-objective optimization (ELO gain, loss, training time)
- Meta-learning: Parameter-performance correlation tracking
- State persistence for resume capability
- Integration with distributed TPU trainer
- Real-time progress tracking and reporting
"""

import optuna
import torch
import numpy as np
import logging
import json
import time
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple
from threading import Thread, Lock
from sklearn.linear_model import LinearRegression
from collections import defaultdict

from neural_network import AlphaZeroNetwork, ModelManager
from distributed_tpu_trainer import DistributedTPUTrainer
from evaluator import ModelEvaluator
from config_loader import load_config

logger = logging.getLogger(__name__)


class MetaLearner:
    """
    Meta-learning component that learns parameter-performance correlations
    Predicts optimal parameters for future training cycles
    """
    
    def __init__(self):
        self.parameter_history = []
        self.performance_history = []
        self.correlations = {}
        self.regression_models = {}
    
    def record_trial(self, params: Dict, performance: Dict):
        """Record trial parameters and performance metrics"""
        self.parameter_history.append(params)
        self.performance_history.append(performance)
    
    def compute_correlations(self) -> Dict:
        """
        Compute correlations between parameters and performance metrics
        
        Returns:
            Dictionary of parameter -> metric correlations
        """
        if len(self.parameter_history) < 5:
            return {}
        
        correlations = {}
        
        # Extract parameter arrays
        param_names = list(self.parameter_history[0].keys())
        
        for param_name in param_names:
            param_values = [trial[param_name] for trial in self.parameter_history]
            
            # Correlate with each performance metric
            correlations[param_name] = {}
            
            for metric in ['elo_gain', 'loss', 'training_time']:
                if metric in self.performance_history[0]:
                    metric_values = [perf[metric] for perf in self.performance_history]
                    
                    # Compute Pearson correlation
                    if len(param_values) == len(metric_values):
                        corr = np.corrcoef(param_values, metric_values)[0, 1]
                        correlations[param_name][metric] = float(corr) if not np.isnan(corr) else 0.0
        
        self.correlations = correlations
        return correlations
    
    def train_regression_models(self):
        """Train regression models to predict performance from parameters"""
        if len(self.parameter_history) < 10:
            logger.info("Insufficient data for regression models (need >= 10 trials)")
            return
        
        try:
            # Prepare feature matrix (parameters)
            param_names = list(self.parameter_history[0].keys())
            X = np.array([[trial[name] for name in param_names] for trial in self.parameter_history])
            
            # Train models for each performance metric
            for metric in ['elo_gain', 'loss', 'training_time']:
                if metric in self.performance_history[0]:
                    y = np.array([perf[metric] for perf in self.performance_history])
                    
                    model = LinearRegression()
                    model.fit(X, y)
                    
                    self.regression_models[metric] = {
                        'model': model,
                        'param_names': param_names,
                        'score': model.score(X, y)
                    }
                    
                    logger.info(f"Trained regression model for {metric}: R² = {model.score(X, y):.3f}")
        
        except Exception as e:
            logger.error(f"Error training regression models: {e}")
    
    def predict_performance(self, params: Dict) -> Dict:
        """
        Predict performance metrics for given parameters using trained models
        
        Returns:
            Dictionary of predicted metrics
        """
        if not self.regression_models:
            return {}
        
        predictions = {}
        
        try:
            for metric, model_data in self.regression_models.items():
                model = model_data['model']
                param_names = model_data['param_names']
                
                # Prepare feature vector
                X = np.array([[params[name] for name in param_names]])
                
                # Predict
                pred = model.predict(X)[0]
                predictions[metric] = float(pred)
        
        except Exception as e:
            logger.error(f"Error predicting performance: {e}")
        
        return predictions
    
    def suggest_parameters(self) -> Optional[Dict]:
        """
        Suggest optimal parameters based on meta-learning
        
        Returns:
            Suggested parameter dictionary or None
        """
        if not self.regression_models or len(self.parameter_history) < 15:
            return None
        
        # Use best observed parameters as baseline
        best_idx = np.argmax([p.get('elo_gain', 0) for p in self.performance_history])
        best_params = self.parameter_history[best_idx].copy()
        
        # Adjust based on correlations
        for param_name, corr_dict in self.correlations.items():
            elo_corr = corr_dict.get('elo_gain', 0)
            
            # If strong positive correlation, increase parameter
            if elo_corr > 0.3:
                best_params[param_name] *= 1.1
            # If strong negative correlation, decrease parameter
            elif elo_corr < -0.3:
                best_params[param_name] *= 0.9
        
        logger.info(f"Meta-learner suggested parameters based on {len(self.parameter_history)} trials")
        
        return best_params


class HyperparameterOptimizer:
    """
    Main Hyperparameter Optimization Engine
    Uses Bayesian optimization (Optuna) to find optimal AlphaZero parameters
    """
    
    def __init__(
        self,
        max_trials: int = 25,
        evaluation_games: int = 10,
        num_workers: int = 4,
        checkpoint_dir: str = "/app/backend/checkpoints/hpo",
        data_dir: str = "/app/backend/data"
    ):
        """
        Initialize HPO Engine
        
        Args:
            max_trials: Maximum number of optimization trials
            evaluation_games: Games per trial for performance evaluation
            num_workers: Number of parallel workers for self-play
            checkpoint_dir: Directory for HPO checkpoints
            data_dir: Directory for results and reports
        """
        self.max_trials = max_trials
        self.evaluation_games = evaluation_games
        self.num_workers = num_workers
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Optimization state
        self.active = False
        self.study = None
        self.current_trial = 0
        self.best_params = None
        self.best_value = float('-inf')
        self.trial_results = []
        self.state_lock = Lock()
        
        # Meta-learning
        self.meta_learner = MetaLearner()
        
        # Model manager
        self.model_manager = ModelManager()
        
        # Optimization thread
        self.optimization_thread = None
        
        # State persistence
        self.state_file = self.data_dir / "hpo_state.json"
        self.results_file = self.data_dir / "hpo_results.json"
        self.report_file = Path("/app/backend/hpo_report.md")
        
        # Load previous state if exists
        self.load_state()
        
        logger.info(f"Hyperparameter Optimizer initialized: max_trials={max_trials}, "
                   f"eval_games={evaluation_games}, workers={num_workers}")
    
    def define_search_space(self, trial: optuna.Trial) -> Dict:
        """
        Define hyperparameter search space
        
        Args:
            trial: Optuna trial object
            
        Returns:
            Dictionary of sampled hyperparameters
        """
        params = {
            # Learning rate (log scale)
            'learning_rate': trial.suggest_float('learning_rate', 1e-5, 1e-2, log=True),
            
            # MCTS simulations
            'mcts_simulations': trial.suggest_int('mcts_simulations', 400, 1600, step=100),
            
            # Temperature (exploration)
            'temperature': trial.suggest_float('temperature', 0.5, 2.0),
            
            # Batch size
            'batch_size': trial.suggest_categorical('batch_size', [128, 256, 512]),
            
            # Retrain frequency (games before retraining)
            'retrain_frequency': trial.suggest_int('retrain_frequency', 10, 50, step=5),
            
            # Exploration noise
            'exploration_noise': trial.suggest_float('exploration_noise', 0.01, 0.25)
        }
        
        return params
    
    def objective(self, trial: optuna.Trial) -> float:
        """
        Objective function for optimization
        Runs distributed training with sampled parameters and returns performance metric
        
        Args:
            trial: Optuna trial
            
        Returns:
            Objective value (ELO gain per cycle)
        """
        try:
            with self.state_lock:
                self.current_trial = trial.number + 1
            
            logger.info("="*80)
            logger.info(f"HPO TRIAL #{trial.number + 1}/{self.max_trials}")
            logger.info("="*80)
            
            # Sample hyperparameters
            params = self.define_search_space(trial)
            
            logger.info(f"Trial parameters: {json.dumps(params, indent=2)}")
            
            # Record trial start
            trial_start_time = time.time()
            
            # Create distributed trainer with sampled parameters
            trainer = DistributedTPUTrainer(
                num_workers=self.num_workers,
                replay_buffer_size=100000,  # Smaller for faster trials
                batch_size=params['batch_size'],
                learning_rate=params['learning_rate'],
                num_simulations=params['mcts_simulations']
            )
            
            # Load current active model
            config = load_config()
            active_model_name = config.get('active_model', 'ActiveModel_Offline.pth')
            model_path = trainer.model_manager.get_model_path(Path(active_model_name).stem)
            
            if not model_path.exists():
                logger.error(f"Model not found: {active_model_name}")
                return 0.0
            
            # Phase 1: Distributed Self-Play (smaller dataset for trials)
            logger.info(f"Phase 1: Distributed self-play ({self.evaluation_games * 2} games)...")
            
            training_data, game_results = trainer.launch_parallel_selfplay(
                num_games_total=self.evaluation_games * 2,  # 20 games for 10 eval
                model_path=str(model_path)
            )
            
            # Phase 2: Training
            logger.info("Phase 2: Training on collected data...")
            
            network, metadata = trainer.model_manager.load_model(Path(active_model_name).stem)
            
            training_metrics = trainer.run_distributed_training_cycle(
                network=network,
                num_epochs=2  # Faster training for trials
            )
            
            training_loss = training_metrics.get('loss', 1.0)
            
            # Phase 3: Evaluation
            logger.info(f"Phase 3: Evaluating with {self.evaluation_games} games...")
            
            baseline_network, _ = trainer.model_manager.load_model(Path(active_model_name).stem)
            
            eval_results, should_promote = trainer.evaluate_and_promote(
                new_network=network,
                baseline_network=baseline_network,
                num_eval_games=self.evaluation_games
            )
            
            win_rate = eval_results.get('challenger_win_rate', 0.5)
            
            # Calculate metrics
            trial_time = time.time() - trial_start_time
            elo_gain = (win_rate - 0.5) * 200  # Simplified ELO calculation
            
            # Multi-objective: maximize ELO gain, minimize loss and time
            # Weighted combination
            objective_value = (
                elo_gain * 1.0 +                    # ELO gain (primary)
                -training_loss * 10.0 +             # Training loss (penalty)
                -(trial_time / 60) * 0.1            # Time penalty (minutes)
            )
            
            # Record trial results
            trial_result = {
                'trial_number': trial.number + 1,
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'parameters': params,
                'metrics': {
                    'elo_gain': float(elo_gain),
                    'win_rate': float(win_rate),
                    'loss': float(training_loss),
                    'training_time': float(trial_time),
                    'objective_value': float(objective_value)
                }
            }
            
            with self.state_lock:
                self.trial_results.append(trial_result)
                
                # Update best if improved
                if objective_value > self.best_value:
                    self.best_value = objective_value
                    self.best_params = params
                    logger.info(f"🎯 NEW BEST TRIAL: ELO gain {elo_gain:+.1f}, "
                               f"Loss {training_loss:.4f}, Time {trial_time/60:.1f}min")
            
            # Meta-learning: Record trial for correlation analysis
            self.meta_learner.record_trial(params, {
                'elo_gain': float(elo_gain),
                'loss': float(training_loss),
                'training_time': float(trial_time)
            })
            
            # Save state
            self.save_state()
            
            # Cleanup trainer
            trainer.cleanup()
            
            logger.info(f"Trial #{trial.number + 1} complete: Objective = {objective_value:.2f}")
            
            return objective_value
        
        except Exception as e:
            logger.error(f"Trial #{trial.number + 1} failed: {e}")
            import traceback
            traceback.print_exc()
            return 0.0
    
    def run_optimization(self, resume: bool = False):
        """
        Run Bayesian optimization
        
        Args:
            resume: Resume from previous optimization session
        """
        try:
            with self.state_lock:
                self.active = True
            
            logger.info("="*80)
            logger.info("HYPERPARAMETER OPTIMIZATION - STARTING")
            logger.info(f"Max trials: {self.max_trials}, Evaluation games: {self.evaluation_games}")
            logger.info("="*80)
            
            # Create or load Optuna study
            study_name = "alphazero_hpo"
            storage_path = f"sqlite:///{self.checkpoint_dir / 'optuna_study.db'}"
            
            if resume and self.study is not None:
                logger.info("Resuming from previous optimization session")
                study = self.study
            else:
                study = optuna.create_study(
                    study_name=study_name,
                    storage=storage_path,
                    direction='maximize',
                    load_if_exists=True,
                    sampler=optuna.samplers.TPESampler(seed=42)
                )
                self.study = study
            
            # Run optimization
            study.optimize(
                self.objective,
                n_trials=self.max_trials - len(study.trials),
                catch=(Exception,)
            )
            
            # Final analysis
            logger.info("="*80)
            logger.info("HYPERPARAMETER OPTIMIZATION - COMPLETE")
            logger.info("="*80)
            
            # Best trial
            if study.best_trial:
                best_trial = study.best_trial
                logger.info(f"Best trial: #{best_trial.number + 1}")
                logger.info(f"Best value: {best_trial.value:.2f}")
                logger.info(f"Best parameters: {json.dumps(best_trial.params, indent=2)}")
            
            # Meta-learning analysis
            logger.info("\nComputing parameter-performance correlations...")
            correlations = self.meta_learner.compute_correlations()
            
            for param, corr_dict in correlations.items():
                logger.info(f"  {param}:")
                for metric, corr_value in corr_dict.items():
                    logger.info(f"    - {metric}: {corr_value:+.3f}")
            
            # Train regression models
            logger.info("\nTraining meta-learning regression models...")
            self.meta_learner.train_regression_models()
            
            # Generate report
            self.generate_report()
            
            # Save final state
            self.save_state()
            
        except Exception as e:
            logger.error(f"Optimization error: {e}")
            import traceback
            traceback.print_exc()
        
        finally:
            with self.state_lock:
                self.active = False
    
    def start_optimization(self, resume: bool = False):
        """Start optimization in background thread"""
        if self.active:
            logger.warning("Optimization already active")
            return False
        
        self.optimization_thread = Thread(
            target=self.run_optimization,
            args=(resume,),
            daemon=True
        )
        self.optimization_thread.start()
        
        logger.info("Hyperparameter optimization started in background")
        return True
    
    def stop_optimization(self):
        """Stop optimization gracefully"""
        if not self.active:
            logger.warning("No optimization active")
            return False
        
        with self.state_lock:
            self.active = False
        
        if self.study:
            self.study.stop()
        
        logger.info("Optimization stop requested")
        return True
    
    def get_status(self) -> Dict:
        """Get current optimization status"""
        with self.state_lock:
            status = {
                'active': self.active,
                'current_trial': self.current_trial,
                'max_trials': self.max_trials,
                'progress_percent': int((self.current_trial / self.max_trials) * 100) if self.max_trials > 0 else 0,
                'best_params': self.best_params,
                'best_value': float(self.best_value) if self.best_value != float('-inf') else None,
                'total_trials_completed': len(self.trial_results),
                'evaluation_games': self.evaluation_games
            }
            
            # Add best trial metrics
            if self.trial_results:
                best_trial = max(self.trial_results, key=lambda x: x['metrics']['objective_value'])
                status['best_trial'] = {
                    'trial_number': best_trial['trial_number'],
                    'elo_gain': best_trial['metrics']['elo_gain'],
                    'win_rate': best_trial['metrics']['win_rate'],
                    'loss': best_trial['metrics']['loss'],
                    'training_time_min': best_trial['metrics']['training_time'] / 60
                }
        
        return status
    
    def get_trial_history(self, limit: int = 50) -> List[Dict]:
        """Get trial history"""
        with self.state_lock:
            return self.trial_results[-limit:]
    
    def get_best_parameters(self) -> Optional[Dict]:
        """Get best parameters found so far"""
        with self.state_lock:
            return self.best_params.copy() if self.best_params else None
    
    def get_meta_learning_insights(self) -> Dict:
        """Get meta-learning insights and correlations"""
        return {
            'correlations': self.meta_learner.correlations,
            'regression_models': {
                metric: {
                    'r2_score': model_data.get('score', 0),
                    'param_names': model_data.get('param_names', [])
                }
                for metric, model_data in self.meta_learner.regression_models.items()
            },
            'total_trials_analyzed': len(self.meta_learner.parameter_history)
        }
    
    def save_state(self):
        """Save optimization state to disk"""
        try:
            state = {
                'max_trials': self.max_trials,
                'current_trial': self.current_trial,
                'best_params': self.best_params,
                'best_value': float(self.best_value) if self.best_value != float('-inf') else None,
                'trial_results': self.trial_results,
                'timestamp': datetime.now(timezone.utc).isoformat()
            }
            
            with open(self.state_file, 'w') as f:
                json.dump(state, f, indent=2)
            
            # Also save to results file for API access
            with open(self.results_file, 'w') as f:
                json.dump({
                    'trials': self.trial_results,
                    'best_params': self.best_params,
                    'meta_learning': self.get_meta_learning_insights()
                }, f, indent=2)
            
            logger.info(f"HPO state saved: {len(self.trial_results)} trials")
        
        except Exception as e:
            logger.error(f"Error saving state: {e}")
    
    def load_state(self):
        """Load optimization state from disk"""
        if not self.state_file.exists():
            return
        
        try:
            with open(self.state_file, 'r') as f:
                state = json.load(f)
            
            self.max_trials = state.get('max_trials', self.max_trials)
            self.current_trial = state.get('current_trial', 0)
            self.best_params = state.get('best_params')
            self.best_value = state.get('best_value', float('-inf'))
            self.trial_results = state.get('trial_results', [])
            
            # Restore meta-learner
            for trial in self.trial_results:
                self.meta_learner.record_trial(
                    trial['parameters'],
                    trial['metrics']
                )
            
            logger.info(f"HPO state loaded: {len(self.trial_results)} trials, "
                       f"best value: {self.best_value:.2f}")
        
        except Exception as e:
            logger.error(f"Error loading state: {e}")
    
    def generate_report(self):
        """Generate comprehensive HPO report in Markdown format"""
        try:
            report_lines = [
                "# AlphaZero Hyperparameter Optimization Report",
                "",
                f"**Generated:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}",
                f"**Total Trials:** {len(self.trial_results)}",
                "",
                "---",
                "",
                "## Best Configuration",
                ""
            ]
            
            if self.best_params:
                report_lines.append("```json")
                report_lines.append(json.dumps(self.best_params, indent=2))
                report_lines.append("```")
                report_lines.append("")
                
                # Best trial metrics
                if self.trial_results:
                    best_trial = max(self.trial_results, key=lambda x: x['metrics']['objective_value'])
                    report_lines.extend([
                        "**Performance:**",
                        f"- ELO Gain: **{best_trial['metrics']['elo_gain']:+.1f}**",
                        f"- Win Rate: **{best_trial['metrics']['win_rate']:.1%}**",
                        f"- Training Loss: **{best_trial['metrics']['loss']:.4f}**",
                        f"- Training Time: **{best_trial['metrics']['training_time']/60:.1f} minutes**",
                        ""
                    ])
            
            # Trial summary
            report_lines.extend([
                "---",
                "",
                "## Trial Summary",
                "",
                "| Trial # | ELO Gain | Win Rate | Loss | Time (min) | Objective |",
                "|---------|----------|----------|------|------------|-----------|"
            ])
            
            for trial in self.trial_results[-20:]:  # Last 20 trials
                metrics = trial['metrics']
                report_lines.append(
                    f"| {trial['trial_number']} | "
                    f"{metrics['elo_gain']:+.1f} | "
                    f"{metrics['win_rate']:.1%} | "
                    f"{metrics['loss']:.4f} | "
                    f"{metrics['training_time']/60:.1f} | "
                    f"{metrics['objective_value']:.2f} |"
                )
            
            report_lines.append("")
            
            # Meta-learning insights
            if self.meta_learner.correlations:
                report_lines.extend([
                    "---",
                    "",
                    "## Meta-Learning Insights",
                    "",
                    "### Parameter-Performance Correlations",
                    "",
                    "| Parameter | ELO Gain | Loss | Time |",
                    "|-----------|----------|------|------|"
                ])
                
                for param, corr_dict in self.meta_learner.correlations.items():
                    report_lines.append(
                        f"| {param} | "
                        f"{corr_dict.get('elo_gain', 0):+.3f} | "
                        f"{corr_dict.get('loss', 0):+.3f} | "
                        f"{corr_dict.get('training_time', 0):+.3f} |"
                    )
                
                report_lines.append("")
            
            # Parameter trends
            report_lines.extend([
                "---",
                "",
                "## Parameter Trends",
                "",
                "Average values across all trials:",
                ""
            ])
            
            if self.trial_results:
                # Calculate averages
                param_names = list(self.trial_results[0]['parameters'].keys())
                for param in param_names:
                    values = [t['parameters'][param] for t in self.trial_results]
                    avg = np.mean(values)
                    std = np.std(values)
                    report_lines.append(f"- **{param}**: {avg:.4f} ± {std:.4f}")
                
                report_lines.append("")
            
            # Write report
            with open(self.report_file, 'w') as f:
                f.write('\n'.join(report_lines))
            
            logger.info(f"HPO report generated: {self.report_file}")
        
        except Exception as e:
            logger.error(f"Error generating report: {e}")


# Global optimizer instance for API access
hpo_optimizer = None

def get_hpo_optimizer(
    max_trials: int = 25,
    evaluation_games: int = 10,
    num_workers: int = 4
) -> HyperparameterOptimizer:
    """Get or create global HPO optimizer instance"""
    global hpo_optimizer
    
    if hpo_optimizer is None:
        hpo_optimizer = HyperparameterOptimizer(
            max_trials=max_trials,
            evaluation_games=evaluation_games,
            num_workers=num_workers
        )
    
    return hpo_optimizer
