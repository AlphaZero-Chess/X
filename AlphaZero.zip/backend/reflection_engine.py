"""
Reflection Engine for AlphaZero Self-Evolution
LLM-powered self-reflection and mistake analysis
"""
import logging
import json
import numpy as np
from pathlib import Path
from typing import List, Dict, Optional
from datetime import datetime, timezone
import uuid
import asyncio
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Import emergentintegrations
try:
    from emergentintegrations.llm.chat import LlmChat, UserMessage
    EMERGENT_AVAILABLE = True
except ImportError:
    EMERGENT_AVAILABLE = False
    logging.warning("emergentintegrations not available, LLM features disabled")

logger = logging.getLogger(__name__)


class ReflectionEngine:
    """LLM-assisted self-reflection for AlphaZero"""
    
    def __init__(self, cache_dir: str = "/app/backend/cache/reflections", use_llm: bool = True):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.use_llm = use_llm
        
        # Initialize LLM client if enabled
        self.llm_client = None
        if self.use_llm and EMERGENT_AVAILABLE:
            try:
                api_key = os.environ.get('EMERGENT_LLM_KEY')
                if api_key:
                    self.llm_client = LlmChat(
                        api_key=api_key,
                        session_id="reflection_engine",
                        system_message="You are AlphaZero Chess AI reflecting on your training performance to identify weaknesses and improvement areas."
                    ).with_model("anthropic", "claude-3-7-sonnet-20250219")
                    logger.info("Reflection Engine initialized with LLM (Claude 3.7 Sonnet)")
                else:
                    logger.warning("EMERGENT_LLM_KEY not found, using numerical-only mode")
                    self.use_llm = False
            except Exception as e:
                logger.warning(f"LLM initialization failed, using numerical-only mode: {e}")
                self.use_llm = False
        elif not EMERGENT_AVAILABLE:
            logger.warning("emergentintegrations not available, using numerical-only mode")
            self.use_llm = False
        
        # Reflection history
        self.reflections = []
        self.load_reflection_history()
    
    async def reflect_on_session(self, session_data: Dict) -> Dict[str, any]:
        """
        Generate reflection after a self-play session
        
        Args:
            session_data: {
                'session_id': str,
                'games_played': int,
                'win_rate': float,
                'draw_rate': float,
                'loss_rate': float,
                'average_moves': float,
                'total_positions': int,
                'game_results': List[str],  # ['1-0', '0-1', '1/2-1/2', ...]
                'pgns': List[str]  # Optional PGNs for deep analysis
            }
        
        Returns:
            Reflection dictionary with insights and training focus
        """
        logger.info(f"Generating reflection for session {session_data.get('session_id')}")
        
        # Generate reflection
        if self.use_llm and self.llm_client:
            reflection = await self._generate_llm_reflection(session_data)
        else:
            reflection = self._generate_numerical_reflection(session_data)
        
        # Add metadata
        reflection['reflection_id'] = str(uuid.uuid4())
        reflection['session_id'] = session_data.get('session_id')
        reflection['timestamp'] = datetime.now(timezone.utc).isoformat()
        reflection['games_analyzed'] = session_data.get('games_played', 0)
        
        # Save reflection
        self.reflections.append(reflection)
        self.save_reflection(reflection)
        
        logger.info(f"Reflection generated: {reflection.get('weakness_detected', 'N/A')}")
        
        return reflection
    
    async def _generate_llm_reflection(self, session_data: Dict) -> Dict[str, any]:
        """Generate reflection using LLM"""
        try:
            # Prepare session summary
            games_played = session_data.get('games_played', 0)
            win_rate = session_data.get('win_rate', 0.0)
            draw_rate = session_data.get('draw_rate', 0.0)
            loss_rate = session_data.get('loss_rate', 0.0)
            avg_moves = session_data.get('average_moves', 0)
            
            # Get sample games for analysis
            game_results = session_data.get('game_results', [])
            
            prompt = f"""You are AlphaZero Chess AI reflecting on your recent self-play training session.

**Session Statistics:**
- Games Played: {games_played}
- Win Rate: {win_rate:.1%}
- Draw Rate: {draw_rate:.1%}  
- Loss Rate: {loss_rate:.1%}
- Average Moves: {avg_moves:.1f}

**Sample Game Results:** {', '.join(game_results[:10])}

Analyze your performance and provide a JSON response with:
1. **weakness_detected**: Main weakness or area needing improvement (concise, e.g., "Endgame conversion errors")
2. **training_focus**: Specific training directive (e.g., "pawn structure optimization", "tactical awareness")
3. **strategic_insight**: Brief strategic observation about your play style (1-2 sentences)
4. **confidence_level**: Your confidence in current abilities: 'low', 'medium', or 'high'
5. **next_priority**: What to prioritize in next training cycle

Return ONLY valid JSON, no explanation."""

            user_message = UserMessage(text=prompt)
            response = await self.llm_client.send_message(user_message)
            
            # Parse JSON response
            reflection = json.loads(response)
            
            # Validate required fields
            required_fields = ['weakness_detected', 'training_focus', 'strategic_insight', 
                             'confidence_level', 'next_priority']
            if all(field in reflection for field in required_fields):
                reflection['method'] = 'llm'
                return reflection
            else:
                logger.warning("LLM reflection missing required fields, using fallback")
                return self._generate_numerical_reflection(session_data)
                
        except Exception as e:
            logger.error(f"LLM reflection failed: {e}")
            return self._generate_numerical_reflection(session_data)
    
    def _generate_numerical_reflection(self, session_data: Dict) -> Dict[str, any]:
        """Generate reflection using numerical analysis only (offline mode)"""
        win_rate = session_data.get('win_rate', 0.5)
        draw_rate = session_data.get('draw_rate', 0.0)
        avg_moves = session_data.get('average_moves', 0)
        games_played = session_data.get('games_played', 0)
        
        # Detect weakness based on stats
        weakness = "Unknown weakness"
        training_focus = "General improvement"
        confidence = "medium"
        
        if win_rate < 0.4:
            weakness = "Low win rate - strategic planning issues"
            training_focus = "Positional understanding and planning"
            confidence = "low"
        elif win_rate > 0.6:
            weakness = "Performance is strong"
            training_focus = "Maintain current strategy"
            confidence = "high"
        
        if draw_rate > 0.5:
            weakness = "High draw rate - conversion difficulties"
            training_focus = "Endgame conversion and winning technique"
        
        if avg_moves < 20:
            weakness = "Short games - tactical errors"
            training_focus = "Tactical awareness in opening/middlegame"
        elif avg_moves > 60:
            weakness = "Long games - endgame inefficiency"
            training_focus = "Endgame technique optimization"
        
        # Strategic insight based on game count
        if games_played < 100:
            insight = "Early learning phase - building foundational patterns."
        elif games_played < 1000:
            insight = "Developing strategic understanding through diverse positions."
        else:
            insight = "Refining advanced strategies and rare position handling."
        
        return {
            'weakness_detected': weakness,
            'training_focus': training_focus,
            'strategic_insight': insight,
            'confidence_level': confidence,
            'next_priority': training_focus,
            'method': 'numerical'
        }
    
    async def analyze_mistakes(self, lost_games: List[Dict]) -> Dict[str, any]:
        """
        Deep analysis of lost/drawn games to identify specific mistakes
        
        Args:
            lost_games: List of game dictionaries where AlphaZero lost or drew
        
        Returns:
            Mistake analysis with patterns and recommendations
        """
        if not lost_games:
            return {
                'mistakes_found': 0,
                'patterns': [],
                'recommendations': ["Continue current training approach"]
            }
        
        logger.info(f"Analyzing mistakes from {len(lost_games)} games")
        
        if self.use_llm and self.llm_client:
            return await self._llm_mistake_analysis(lost_games)
        else:
            return self._numerical_mistake_analysis(lost_games)
    
    async def _llm_mistake_analysis(self, lost_games: List[Dict]) -> Dict[str, any]:
        """Use LLM to identify mistake patterns"""
        try:
            # Sample up to 5 games for analysis
            sample_games = lost_games[:5]
            game_summaries = []
            
            for game in sample_games:
                result = game.get('result', '*')
                moves = game.get('move_count', 0)
                pgn = game.get('pgn', '')[:200]  # First 200 chars
                game_summaries.append(f"Result: {result}, Moves: {moves}, PGN snippet: {pgn}")
            
            prompt = f"""Analyze these lost/drawn chess games to identify common mistakes:

{chr(10).join(game_summaries)}

Provide JSON response with:
1. **mistakes_found**: Number of distinct mistake patterns identified
2. **patterns**: List of 3-5 common mistake patterns (e.g., "Premature king exposure", "Missed tactical opportunities")
3. **recommendations**: List of 3-5 specific training recommendations to address these mistakes

Return ONLY valid JSON."""

            user_message = UserMessage(text=prompt)
            response = await self.llm_client.send_message(user_message)
            
            analysis = json.loads(response)
            return analysis
            
        except Exception as e:
            logger.error(f"LLM mistake analysis failed: {e}")
            return self._numerical_mistake_analysis(lost_games)
    
    def _numerical_mistake_analysis(self, lost_games: List[Dict]) -> Dict[str, any]:
        """Numerical mistake analysis (offline mode)"""
        total_moves = [g.get('move_count', 0) for g in lost_games]
        avg_moves = np.mean(total_moves) if total_moves else 0
        
        patterns = []
        recommendations = []
        
        if avg_moves < 25:
            patterns.append("Early game losses - opening/tactical weaknesses")
            recommendations.append("Focus on opening principles and early tactical awareness")
        elif avg_moves > 60:
            patterns.append("Long game losses - endgame technique issues")
            recommendations.append("Practice endgame positions and conversion techniques")
        else:
            patterns.append("Middlegame losses - strategic planning gaps")
            recommendations.append("Improve positional evaluation and planning")
        
        return {
            'mistakes_found': len(patterns),
            'patterns': patterns,
            'recommendations': recommendations
        }
    
    def save_reflection(self, reflection: Dict):
        """Save reflection to cache"""
        try:
            reflection_id = reflection.get('reflection_id', str(uuid.uuid4()))
            reflection_file = self.cache_dir / f"reflection_{reflection_id}.json"
            
            with open(reflection_file, 'w') as f:
                json.dump(reflection, f, indent=2)
            
            logger.debug(f"Reflection saved: {reflection_file.name}")
        except Exception as e:
            logger.error(f"Failed to save reflection: {e}")
    
    def load_reflection_history(self, limit: int = 50):
        """Load recent reflections from cache"""
        try:
            reflection_files = sorted(
                self.cache_dir.glob("reflection_*.json"),
                key=lambda p: p.stat().st_mtime,
                reverse=True
            )[:limit]
            
            self.reflections = []
            for file_path in reflection_files:
                try:
                    with open(file_path, 'r') as f:
                        reflection = json.load(f)
                        self.reflections.append(reflection)
                except Exception as e:
                    logger.warning(f"Failed to load reflection {file_path}: {e}")
            
            logger.info(f"Loaded {len(self.reflections)} reflections from cache")
        except Exception as e:
            logger.warning(f"Failed to load reflection history: {e}")
    
    def get_recent_reflections(self, limit: int = 10) -> List[Dict]:
        """Get recent reflections"""
        return self.reflections[:limit]
    
    def get_reflection_summary(self) -> Dict[str, any]:
        """Get summary of all reflections"""
        if not self.reflections:
            return {
                'total_reflections': 0,
                'common_weaknesses': [],
                'training_priorities': []
            }
        
        # Extract common patterns
        weaknesses = [r.get('weakness_detected', '') for r in self.reflections]
        focuses = [r.get('training_focus', '') for r in self.reflections]
        
        # Count occurrences
        from collections import Counter
        weakness_counts = Counter(weaknesses)
        focus_counts = Counter(focuses)
        
        return {
            'total_reflections': len(self.reflections),
            'common_weaknesses': [{'weakness': w, 'count': c} 
                                 for w, c in weakness_counts.most_common(5)],
            'training_priorities': [{'priority': f, 'count': c} 
                                   for f, c in focus_counts.most_common(5)]
        }
    
    def set_llm_mode(self, enabled: bool):
        """Enable or disable LLM-assisted reflection (Hybrid Reflection Mode)"""
        self.use_llm = enabled
        if enabled and not self.llm_client and EMERGENT_AVAILABLE:
            try:
                api_key = os.environ.get('EMERGENT_LLM_KEY')
                if api_key:
                    self.llm_client = LlmChat(
                        api_key=api_key,
                        session_id="reflection_engine",
                        system_message="You are AlphaZero Chess AI reflecting on your training performance to identify weaknesses and improvement areas."
                    ).with_model("anthropic", "claude-3-7-sonnet-20250219")
                    logger.info("LLM reflection enabled")
                else:
                    logger.error("EMERGENT_LLM_KEY not found")
                    self.use_llm = False
            except Exception as e:
                logger.error(f"Failed to enable LLM mode: {e}")
                self.use_llm = False
        elif not enabled:
            logger.info("LLM reflection disabled (numerical-only)")
