# Quick Start Guide - AlphaZero Test Cycle

## 🚀 Get Started in 3 Minutes

### Step 1: Validate Installation

```bash
cd /app/backend
python validate_installation.py
```

Expected output: `✓ All checks passed!`

### Step 2: Run Your First Test

```bash
python test_cycle_quick.py --games 2
```

This will:
- ✅ Create a base model (first run)
- ✅ Generate 2 self-play games
- ✅ Train the model
- ⚠️  Skip evaluation (no previous model)

**Time:** ~3-5 minutes

### Step 3: Run Again to See Evaluation

```bash
python test_cycle_quick.py --games 2
```

Now you'll see:
- ✅ All 3 phases complete
- ✅ ELO calculation
- ✅ Win rate analysis

### Step 4: Check Results

```bash
# View JSON results
cat /app/backend/cache/test_cycle_results.json

# View generated games
ls /app/backend/cache/selfplay/test_cycle_pgns/

# View logs
tail -50 /app/backend/cache/test_cycle.log
```

## 📚 What to Run Next

### For Development: Quick Tests

```bash
# Minimal test (2 games, ~3 min)
python test_cycle_quick.py --games 2

# Quick test with parallel mode (~1.5 min)
python test_cycle_quick.py --games 3 --parallel --threads 4
```

### For Real Validation: Full Tests

```bash
# Standard test (10 games, ~20 min)
python test_cycle.py --games 10

# Full test with all features (20 games, ~30 min)
python test_cycle.py --games 20 --parallel --threads 4
```

## 🎯 Command Cheat Sheet

| Command | Games | Time | Purpose |
|---------|-------|------|---------|
| `python test_cycle_quick.py --games 2` | 2 | 3 min | Quick validation |
| `python test_cycle_quick.py --games 5 --parallel` | 5 | 2 min | Fast parallel test |
| `python test_cycle.py --games 5` | 5 | 15 min | Light full test |
| `python test_cycle.py --games 10` | 10 | 30 min | Standard test |
| `python test_cycle.py --games 20 --parallel` | 20 | 15 min | Production test |

## 📊 Understanding Output

### Console Output

```
INFO - ██████████████████████████████████████████████████████████
INFO -  AlphaZero Test Cycle - Session abc123
INFO - ██████████████████████████████████████████████████████████

[PHASE 1] Self-Play Generation
✓ Generated 2 games, 187 positions

[PHASE 2] Training
✓ Epoch 1 complete, loss: 0.342

[PHASE 3] Evaluation
✓ Win rate: 55%, ELO change: +24

✓ Pipeline validated successfully
```

### Result Files

```
/app/backend/
├── cache/
│   ├── test_cycle_results.json  ← Main results
│   ├── test_cycle.log           ← Debug logs
│   └── selfplay/
│       └── test_cycle_pgns/     ← Game files
└── models/
    ├── ActiveModel_Offline.pt   ← Base model
    └── ActiveModel_TestCycle.pt ← Trained model
```

## ⚡ Performance Tips

### Faster Testing
- Use `test_cycle_quick.py` (16x faster)
- Enable `--parallel` mode
- Reduce `--games` count

### Better Results
- Use `test_cycle.py` (full simulations)
- Increase `--games` count (20+)
- Run multiple `--epochs`

## 🐛 Common Issues

### "Process takes too long"
→ Use quick mode: `python test_cycle_quick.py --games 2`

### "Out of memory"
→ Reduce games: `python test_cycle.py --games 5`

### "Evaluation skipped"
→ Normal on first run! Run again to see evaluation.

### "No module named 'torch'"
→ Install dependencies: `pip install -r requirements.txt`

## 📖 More Documentation

- **Full Guide**: `TEST_CYCLE_README.md`
- **Examples**: `EXAMPLE_OUTPUT.md`
- **Summary**: `TEST_CYCLE_SUMMARY.md`

## ✅ Expected Behavior

### First Run
1. Creates `ActiveModel_Offline.pt` (base model)
2. Generates games and trains
3. **Skips evaluation** (nothing to compare)
4. Message: "Run again to see evaluation"

### Second Run  
1. Loads existing `ActiveModel_Offline.pt`
2. Generates games and trains
3. **Runs evaluation** (compares models)
4. Shows ELO delta and win rate

### Third+ Runs
1. Always evaluates (has previous model)
2. Overwrites `ActiveModel_TestCycle.pt`
3. Keeps `ActiveModel_Offline.pt` as baseline

## 🎓 Learning Path

1. **Day 1**: Run `validate_installation.py` and `test_cycle_quick.py --games 2`
2. **Day 2**: Run `test_cycle.py --games 10` to see full pipeline
3. **Day 3**: Try parallel mode with `--parallel --threads 4`
4. **Day 4**: Experiment with custom models and epochs
5. **Day 5**: Integrate into your workflow

## 🔗 Related Files

- `test_cycle.py` - Main script (production)
- `test_cycle_quick.py` - Quick test (development)
- `validate_installation.py` - Installation checker
- `config.json` - Default configuration
- `requirements.txt` - Python dependencies

## 💡 Pro Tips

1. **Always validate first**: Run `validate_installation.py` before testing
2. **Start small**: Use `--games 2` for first run
3. **Monitor logs**: Use `tail -f cache/test_cycle.log` in another terminal
4. **Check results**: Always review the JSON output file
5. **Use parallel mode**: Much faster on multi-core systems

## 🎉 Success Criteria

You know it's working when you see:

```
✓ Generated N games
✓ Training complete
✓ Evaluation complete (or skipped on first run)
✓ Pipeline validated successfully
```

And files exist at:
- `/app/backend/models/ActiveModel_TestCycle.pt`
- `/app/backend/cache/test_cycle_results.json`
- `/app/backend/cache/selfplay/test_cycle_pgns/game_*.pgn`

---

**Ready to start?**

```bash
python validate_installation.py  # Check setup
python test_cycle_quick.py --games 2  # Run first test
```

Good luck! 🚀
