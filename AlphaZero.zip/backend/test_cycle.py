#!/usr/bin/env python3
"""
AlphaZero Chess Test Cycle Script
Self-Play → Train → Evaluate Pipeline Test

Validates the complete AlphaZero training pipeline:
1. Generate self-play games (AlphaZero vs AlphaZero)
2. Train model on generated data
3. Evaluate model improvement

Usage:
    python test_cycle.py --games 20 --threads 4
    python test_cycle.py --games 10 --epochs 1 --parallel
"""
import argparse
import json
import logging
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

# Add backend to path
backend_dir = Path(__file__).parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

# Import AlphaZero modules
from neural_network import AlphaZeroNetwork, ModelManager
from self_play import SelfPlayManager
from parallel_selfplay import ParallelSelfPlayManager, AdaptiveSelfPlayManager
from trainer import AlphaZeroTrainer
from evaluator import ModelEvaluator
from chess_engine import ChessEngine
import chess


class TestCycleRunner:
    """Complete test cycle runner for AlphaZero pipeline"""
    
    def __init__(self,
                 num_games: int = 20,
                 num_threads: int = 1,
                 enable_parallel: bool = False,
                 num_epochs: int = 1,
                 base_model_name: str = "ActiveModel_Offline",
                 new_model_name: str = "ActiveModel_TestCycle",
                 cache_dir: str = "/app/backend/cache"):
        """
        Initialize test cycle runner
        
        Args:
            num_games: Number of self-play games to generate
            num_threads: Number of threads for parallel self-play
            enable_parallel: Enable parallel self-play
            num_epochs: Number of training epochs
            base_model_name: Base model to fine-tune (without .pth extension)
            new_model_name: New model to save after training (without .pth extension)
            cache_dir: Cache directory for outputs
        """
        self.num_games = num_games
        self.num_threads = num_threads if enable_parallel else 1
        self.enable_parallel = enable_parallel and num_threads > 1
        self.num_epochs = num_epochs
        self.base_model_name = base_model_name
        self.new_model_name = new_model_name
        
        # Setup directories
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.selfplay_dir = self.cache_dir / "selfplay"
        self.selfplay_dir.mkdir(parents=True, exist_ok=True)
        self.pgn_dir = self.selfplay_dir / "test_cycle_pgns"
        self.pgn_dir.mkdir(parents=True, exist_ok=True)
        self.log_file = self.cache_dir / "test_cycle.log"
        
        # Setup logging to both file and console
        self.setup_logging()
        
        # Model manager
        self.model_manager = ModelManager()
        
        # Session ID for tracking
        self.session_id = str(uuid.uuid4())[:8]
        
        # Results
        self.results = {
            'session_id': self.session_id,
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'config': {
                'num_games': num_games,
                'num_threads': self.num_threads,
                'enable_parallel': self.enable_parallel,
                'num_epochs': num_epochs,
                'base_model': base_model_name,
                'new_model': new_model_name
            },
            'phases': {}
        }
        
        self.logger = logging.getLogger(__name__)
    
    def setup_logging(self):
        """Setup logging to both file and console"""
        # Clear any existing handlers
        root_logger = logging.getLogger()
        root_logger.handlers = []
        
        # Create formatters
        detailed_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        simple_formatter = logging.Formatter(
            '%(levelname)s - %(message)s'
        )
        
        # File handler (detailed)
        file_handler = logging.FileHandler(self.log_file, mode='w')
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(detailed_formatter)
        
        # Console handler (simpler)
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(simple_formatter)
        
        # Configure root logger
        root_logger.setLevel(logging.DEBUG)
        root_logger.addHandler(file_handler)
        root_logger.addHandler(console_handler)
    
    def print_banner(self, text: str, char: str = "="):
        """Print a banner"""
        width = 70
        self.logger.info("")
        self.logger.info(char * width)
        self.logger.info(f" {text}")
        self.logger.info(char * width)
    
    def load_or_create_base_model(self) -> AlphaZeroNetwork:
        """Load base model or create fresh one if doesn't exist"""
        self.logger.info(f"Loading base model: {self.base_model_name}")
        
        # Try to load existing model
        model, metadata = self.model_manager.load_model(self.base_model_name)
        
        if model is not None:
            self.logger.info(f"✓ Loaded existing model: {self.base_model_name}")
            if metadata:
                self.logger.info(f"  Metadata: {metadata}")
            return model
        else:
            # Create fresh model
            self.logger.info(f"⚠ Model {self.base_model_name} not found, creating fresh untrained model")
            model = AlphaZeroNetwork()
            
            # Save it as base model for future runs
            self.model_manager.save_model(
                model, 
                name=self.base_model_name,
                metadata={
                    'created': datetime.now(timezone.utc).isoformat(),
                    'type': 'base_untrained',
                    'note': 'Fresh model created by test_cycle.py'
                }
            )
            self.logger.info(f"✓ Created and saved base model: {self.base_model_name}")
            return model
    
    def save_pgn(self, game_data: List[Dict], result: str, game_num: int):
        """Save game as PGN file"""
        # Create PGN content
        timestamp = datetime.now(timezone.utc).strftime('%Y.%m.%d')
        pgn_lines = [
            f'[Event "AlphaZero Test Cycle Self-Play"]',
            f'[Site "Local"]',
            f'[Date "{timestamp}"]',
            f'[Round "{game_num}"]',
            f'[White "AlphaZero"]',
            f'[Black "AlphaZero"]',
            f'[Result "{result}"]',
            ''
        ]
        
        # Reconstruct moves from positions
        engine = ChessEngine()
        moves = []
        
        # Get moves from game data (positions include FEN)
        for i, entry in enumerate(game_data):
            if 'fen' in entry and entry['fen']:
                # We can reconstruct moves by comparing consecutive FENs
                # For simplicity, we'll use the policy to get the move
                pass
        
        # Alternative: Just list the result (minimal PGN)
        move_text = result
        pgn_lines.append(move_text)
        
        # Save to file
        pgn_file = self.pgn_dir / f"game_{self.session_id}_{game_num:06d}.pgn"
        with open(pgn_file, 'w') as f:
            f.write('\n'.join(pgn_lines))
    
    def phase_1_selfplay(self) -> tuple:
        """Phase 1: Generate self-play games"""
        self.print_banner("PHASE 1: SELF-PLAY GENERATION", "=")
        
        phase_start = time.time()
        
        # Load base model
        model = self.load_or_create_base_model()
        
        # Create self-play manager
        if self.enable_parallel:
            self.logger.info(f"Using parallel self-play with {self.num_threads} threads")
            manager = ParallelSelfPlayManager(
                model,
                num_threads=self.num_threads,
                num_simulations=800
            )
            all_training_data, game_results = manager.generate_games_parallel(
                self.num_games,
                temperature_threshold=15
            )
        else:
            self.logger.info("Using sequential self-play")
            manager = SelfPlayManager(model, num_simulations=800)
            all_training_data, game_results = manager.generate_games(
                self.num_games,
                store_fen=True
            )
        
        # Save PGNs
        self.logger.info(f"Saving {len(game_results)} games as PGN files...")
        for i, game_result in enumerate(game_results):
            result = game_result.get('result', '1/2-1/2')
            self.save_pgn(all_training_data, result, i + 1)
        
        phase_time = time.time() - phase_start
        
        # Calculate statistics
        white_wins = sum(1 for g in game_results if g.get('result') == '1-0')
        black_wins = sum(1 for g in game_results if g.get('result') == '0-1')
        draws = sum(1 for g in game_results if g.get('result') == '1/2-1/2')
        
        phase_results = {
            'games_generated': len(game_results),
            'positions_generated': len(all_training_data),
            'white_wins': white_wins,
            'black_wins': black_wins,
            'draws': draws,
            'time_seconds': phase_time,
            'games_per_minute': (len(game_results) / phase_time) * 60 if phase_time > 0 else 0,
            'pgn_directory': str(self.pgn_dir),
            'parallel_mode': self.enable_parallel,
            'threads': self.num_threads
        }
        
        self.results['phases']['selfplay'] = phase_results
        
        self.logger.info("")
        self.logger.info(f"✓ Generated {len(game_results)} games")
        self.logger.info(f"  Total positions: {len(all_training_data)}")
        self.logger.info(f"  Results: W={white_wins}, B={black_wins}, D={draws}")
        self.logger.info(f"  Time: {phase_time:.2f}s ({phase_results['games_per_minute']:.1f} games/min)")
        self.logger.info(f"  PGNs saved to: {self.pgn_dir}")
        
        return all_training_data, model
    
    def phase_2_training(self, training_data: List[Dict], base_model: AlphaZeroNetwork) -> AlphaZeroNetwork:
        """Phase 2: Train model on generated data"""
        self.print_banner("PHASE 2: MODEL TRAINING", "=")
        
        phase_start = time.time()
        
        self.logger.info(f"Training on {len(training_data)} positions for {self.num_epochs} epoch(s)")
        
        # Create trainer
        trainer = AlphaZeroTrainer(
            base_model,
            learning_rate=0.001,
            use_mixed_precision=False  # Keep lightweight for testing
        )
        
        # Train
        training_history = trainer.train(
            training_data,
            num_epochs=self.num_epochs,
            batch_size=64
        )
        
        # Save new model
        self.logger.info(f"Saving trained model as: {self.new_model_name}")
        model_path = self.model_manager.save_model(
            base_model,  # Model was trained in-place
            name=self.new_model_name,
            metadata={
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'trained_on_games': self.num_games,
                'trained_on_positions': len(training_data),
                'epochs': self.num_epochs,
                'base_model': self.base_model_name,
                'session_id': self.session_id
            }
        )
        
        phase_time = time.time() - phase_start
        
        # Get final epoch metrics
        final_metrics = training_history[-1] if training_history else {}
        
        phase_results = {
            'epochs': self.num_epochs,
            'positions_trained': len(training_data),
            'batch_size': 64,
            'learning_rate': 0.001,
            'final_loss': final_metrics.get('loss', 0.0),
            'final_policy_loss': final_metrics.get('policy_loss', 0.0),
            'final_value_loss': final_metrics.get('value_loss', 0.0),
            'time_seconds': phase_time,
            'model_saved': model_path,
            'training_history': training_history
        }
        
        self.results['phases']['training'] = phase_results
        
        self.logger.info("")
        self.logger.info(f"✓ Training complete")
        self.logger.info(f"  Epochs: {self.num_epochs}")
        self.logger.info(f"  Final loss: {final_metrics.get('loss', 0.0):.4f}")
        self.logger.info(f"  Time: {phase_time:.2f}s")
        self.logger.info(f"  Model saved: {self.new_model_name}.pth")
        
        return base_model
    
    def phase_3_evaluation(self, new_model: AlphaZeroNetwork, base_model_name: str) -> Optional[Dict]:
        """Phase 3: Evaluate model improvement"""
        self.print_banner("PHASE 3: MODEL EVALUATION", "=")
        
        phase_start = time.time()
        
        # Check if base model exists for comparison
        old_model, old_metadata = self.model_manager.load_model(base_model_name)
        
        if old_model is None:
            self.logger.info("⚠ First run detected - no previous model to compare against")
            self.logger.info("  Skipping evaluation phase")
            self.logger.info("  Run test_cycle.py again to compare future improvements")
            
            phase_results = {
                'skipped': True,
                'reason': 'No previous model for comparison (first run)',
                'note': 'Run test_cycle.py again to evaluate improvements'
            }
            
            self.results['phases']['evaluation'] = phase_results
            return None
        
        # Load the newly saved model for fair comparison
        new_model_loaded, new_metadata = self.model_manager.load_model(self.new_model_name)
        
        if new_model_loaded is None:
            self.logger.error("Failed to load newly trained model for evaluation")
            return None
        
        self.logger.info(f"Evaluating: {self.new_model_name} vs {base_model_name}")
        self.logger.info(f"Playing 20 evaluation games (10 as White, 10 as Black)")
        
        # Create evaluator
        evaluator = ModelEvaluator(
            num_evaluation_games=20,
            num_simulations=400,
            win_threshold=0.55,
            elo_threshold=50.0
        )
        
        # Run evaluation
        eval_results, should_promote = evaluator.evaluate_models(
            challenger_model=new_model_loaded,
            champion_model=old_model,
            challenger_name=self.new_model_name,
            champion_name=base_model_name,
            challenger_elo=1500.0,
            champion_elo=1500.0
        )
        
        phase_time = time.time() - phase_start
        eval_results['time_seconds'] = phase_time
        
        self.results['phases']['evaluation'] = eval_results
        
        # Calculate average evaluation (score)
        avg_eval = eval_results.get('actual_score', 0.5)
        
        self.logger.info("")
        self.logger.info(f"✓ Evaluation complete")
        self.logger.info(f"  Games played: {eval_results.get('games_played', 0)}")
        self.logger.info(f"  Win rate: {eval_results.get('challenger_win_rate', 0):.1%}")
        self.logger.info(f"  ELO change: {eval_results.get('elo_delta', 0):+.0f}")
        self.logger.info(f"  Average eval: {avg_eval:+.2f}")
        self.logger.info(f"  Promoted: {'Yes' if should_promote else 'No'}")
        self.logger.info(f"  Time: {phase_time:.2f}s")
        
        return eval_results
    
    def save_results(self):
        """Save final results to JSON"""
        results_file = self.cache_dir / "test_cycle_results.json"
        
        # Add summary
        self.results['summary'] = {
            'success': True,
            'total_time_seconds': sum(
                phase.get('time_seconds', 0) 
                for phase in self.results['phases'].values()
            ),
            'completed_phases': list(self.results['phases'].keys())
        }
        
        with open(results_file, 'w') as f:
            json.dump(self.results, f, indent=2)
        
        self.logger.info(f"\n✓ Results saved to: {results_file}")
        return results_file
    
    def run(self):
        """Run complete test cycle"""
        self.print_banner(f"AlphaZero Test Cycle - Session {self.session_id}", "█")
        
        self.logger.info(f"Configuration:")
        self.logger.info(f"  Games: {self.num_games}")
        self.logger.info(f"  Parallel: {self.enable_parallel} (threads: {self.num_threads})")
        self.logger.info(f"  Epochs: {self.num_epochs}")
        self.logger.info(f"  Base model: {self.base_model_name}")
        self.logger.info(f"  New model: {self.new_model_name}")
        
        cycle_start = time.time()
        
        try:
            # Phase 1: Self-Play
            training_data, base_model = self.phase_1_selfplay()
            
            # Phase 2: Training
            trained_model = self.phase_2_training(training_data, base_model)
            
            # Phase 3: Evaluation
            eval_results = self.phase_3_evaluation(trained_model, self.base_model_name)
            
            # Save results
            results_file = self.save_results()
            
            cycle_time = time.time() - cycle_start
            
            # Final summary
            self.print_banner("TEST CYCLE COMPLETE", "█")
            self.logger.info(f"Session: {self.session_id}")
            self.logger.info(f"Total time: {cycle_time:.2f}s ({cycle_time/60:.1f}m)")
            self.logger.info(f"Results: {results_file}")
            self.logger.info(f"Logs: {self.log_file}")
            
            if eval_results and not eval_results.get('skipped', False):
                self.logger.info("")
                self.logger.info("Key Metrics:")
                self.logger.info(f"  Games played: {self.num_games}")
                self.logger.info(f"  New model: {self.new_model_name}.pth")
                self.logger.info(f"  Win rate: {eval_results.get('challenger_win_rate', 0):.1%}")
                self.logger.info(f"  ELO change: {eval_results.get('elo_delta', 0):+.0f}")
            else:
                self.logger.info("")
                self.logger.info("Note: First run completed successfully")
                self.logger.info("Run again to see evaluation metrics")
            
            self.logger.info("")
            self.logger.info("✓ Pipeline validated successfully")
            
        except Exception as e:
            self.logger.error(f"Test cycle failed: {e}", exc_info=True)
            self.results['error'] = str(e)
            self.results['summary'] = {
                'success': False,
                'error': str(e)
            }
            self.save_results()
            raise


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='AlphaZero Test Cycle - Self-Play → Train → Evaluate',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python test_cycle.py
  python test_cycle.py --games 20 --threads 4 --parallel
  python test_cycle.py --games 10 --epochs 2
        """
    )
    
    parser.add_argument('--games', type=int, default=20,
                       help='Number of self-play games to generate (default: 20)')
    parser.add_argument('--threads', type=int, default=4,
                       help='Number of threads for parallel self-play (default: 4)')
    parser.add_argument('--parallel', action='store_true',
                       help='Enable parallel self-play (default: disabled)')
    parser.add_argument('--epochs', type=int, default=1,
                       help='Number of training epochs (default: 1)')
    parser.add_argument('--base-model', type=str, default='ActiveModel_Offline',
                       help='Base model name (default: ActiveModel_Offline)')
    parser.add_argument('--new-model', type=str, default='ActiveModel_TestCycle',
                       help='New model name after training (default: ActiveModel_TestCycle)')
    parser.add_argument('--cache-dir', type=str, default='/app/backend/cache',
                       help='Cache directory for outputs (default: /app/backend/cache)')
    
    args = parser.parse_args()
    
    # Create and run test cycle
    runner = TestCycleRunner(
        num_games=args.games,
        num_threads=args.threads,
        enable_parallel=args.parallel,
        num_epochs=args.epochs,
        base_model_name=args.base_model,
        new_model_name=args.new_model,
        cache_dir=args.cache_dir
    )
    
    runner.run()


if __name__ == '__main__':
    main()
