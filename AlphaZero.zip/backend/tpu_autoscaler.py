"""
TPU Autoscaler - Policy-Based Dynamic Scaling Engine

Manages automatic scaling of TPU grid based on:
- CPU/GPU/TPU utilization
- Job queue depth
- Job priority signals
- Time-based policies

Features:
- Cool-down/warm-up windows to prevent thrashing
- Multiple scaling policies (utilization, queue-based, time-based)
- Integration with cloud_cluster_controller
- Configurable scaling intervals and thresholds
"""

import logging
import time
import threading
from typing import Dict, Optional, Tuple, List
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timezone
import math

logger = logging.getLogger(__name__)


class ScalingPolicy(Enum):
    """Autoscaling policy types"""
    UTILIZATION_BASED = "utilization_based"  # Scale based on resource utilization
    QUEUE_BASED = "queue_based"  # Scale based on job queue depth
    PRIORITY_BASED = "priority_based"  # Scale based on high-priority jobs
    TIME_BASED = "time_based"  # Scale based on time of day
    HYBRID = "hybrid"  # Combination of policies


class ScalingAction(Enum):
    """Scaling actions"""
    SCALE_UP = "scale_up"
    SCALE_DOWN = "scale_down"
    NO_ACTION = "no_action"


@dataclass
class ScalingConfig:
    """Autoscaling configuration"""
    # TPU limits
    min_tpus: int = 200
    max_tpus: int = 5000
    
    # Scaling behavior
    scaling_interval_seconds: int = 30
    scale_up_cooldown_seconds: int = 120  # Wait 2 min after scale-up
    scale_down_cooldown_seconds: int = 180  # Wait 3 min after scale-down
    
    # Utilization thresholds
    target_utilization: float = 0.75  # Target 75% utilization
    scale_up_threshold: float = 0.85  # Scale up at 85%
    scale_down_threshold: float = 0.50  # Scale down at 50%
    
    # Queue thresholds
    queue_scale_up_threshold: int = 10  # Scale up if 10+ jobs queued
    queue_scale_down_threshold: int = 2  # Scale down if <2 jobs queued
    
    # Scaling step sizes
    scale_up_increment_percent: float = 0.20  # Add 20% capacity
    scale_down_increment_percent: float = 0.15  # Remove 15% capacity
    
    # Policy weights (for hybrid mode)
    utilization_weight: float = 0.5
    queue_weight: float = 0.3
    priority_weight: float = 0.2
    
    # Active policies
    enabled_policies: List[ScalingPolicy] = field(default_factory=lambda: [
        ScalingPolicy.UTILIZATION_BASED,
        ScalingPolicy.QUEUE_BASED
    ])


@dataclass
class ScalingDecision:
    """Scaling decision with reasoning"""
    action: ScalingAction
    current_tpus: int
    target_tpus: int
    reason: str
    metrics: Dict
    timestamp: float = field(default_factory=time.time)


@dataclass
class ScalingMetrics:
    """Current system metrics for scaling decisions"""
    total_tpus: int
    active_tpus: int
    utilization: float
    queued_jobs: int
    running_jobs: int
    avg_queue_wait_time: float
    high_priority_jobs: int
    timestamp: float = field(default_factory=time.time)


class TPUAutoscaler:
    """
    TPU Autoscaler - Dynamic scaling engine for TPU grid
    
    Monitors system metrics and automatically scales TPU count
    based on configured policies and thresholds.
    
    Example:
        autoscaler = TPUAutoscaler(cloud_controller, job_scheduler)
        autoscaler.start()
        # Autoscaler runs in background
        autoscaler.stop()
    """
    
    def __init__(
        self,
        cloud_controller,
        job_scheduler=None,
        config: Optional[ScalingConfig] = None
    ):
        """
        Initialize TPU Autoscaler
        
        Args:
            cloud_controller: CloudClusterController instance
            job_scheduler: Optional job scheduler for queue metrics
            config: Scaling configuration
        """
        self.cloud_controller = cloud_controller
        self.job_scheduler = job_scheduler
        self.config = config or ScalingConfig()
        
        logger.info("="*80)
        logger.info("INITIALIZING TPU AUTOSCALER")
        logger.info(f"TPU Range: {self.config.min_tpus} - {self.config.max_tpus}")
        logger.info(f"Target Utilization: {self.config.target_utilization:.0%}")
        logger.info(f"Scaling Interval: {self.config.scaling_interval_seconds}s")
        logger.info(f"Policies: {[p.value for p in self.config.enabled_policies]}")
        logger.info("="*80)
        
        # State tracking
        self.last_scale_up_time = 0.0
        self.last_scale_down_time = 0.0
        self.scaling_history: List[ScalingDecision] = []
        self.total_scale_up_events = 0
        self.total_scale_down_events = 0
        
        # Control thread
        self.running = False
        self.autoscaler_thread = None
        self.lock = threading.RLock()
        
        logger.info("✅ TPU Autoscaler initialized")
    
    def start(self):
        """Start autoscaling loop"""
        if self.running:
            logger.warning("Autoscaler already running")
            return
        
        self.running = True
        self.autoscaler_thread = threading.Thread(
            target=self._autoscaling_loop,
            daemon=True
        )
        self.autoscaler_thread.start()
        logger.info("🚀 Autoscaler started")
    
    def stop(self):
        """Stop autoscaling loop"""
        self.running = False
        if self.autoscaler_thread:
            self.autoscaler_thread.join(timeout=5)
        logger.info("⏹️  Autoscaler stopped")
    
    def _autoscaling_loop(self):
        """Main autoscaling loop (runs in background thread)"""
        while self.running:
            try:
                # Collect metrics
                metrics = self._collect_metrics()
                
                # Make scaling decision
                decision = self._make_scaling_decision(metrics)
                
                # Execute scaling action
                if decision.action != ScalingAction.NO_ACTION:
                    self._execute_scaling_action(decision)
                
                # Sleep until next interval
                time.sleep(self.config.scaling_interval_seconds)
            
            except Exception as e:
                logger.error(f"Autoscaling loop error: {e}")
                import traceback
                traceback.print_exc()
                time.sleep(self.config.scaling_interval_seconds)
    
    def _collect_metrics(self) -> ScalingMetrics:
        """Collect current system metrics"""
        # Get cluster status
        status = self.cloud_controller.get_cluster_status()
        cluster_info = status['cluster']
        
        total_tpus = cluster_info['total_tpus']
        
        # Calculate utilization (simulate based on health status)
        health_status = status['health']
        active_tpus = sum(
            cluster_info['total_tpus'] * count / sum(health_status.values())
            for node_health, count in health_status.items()
            if node_health in ['healthy', 'degraded']
        )
        
        utilization = active_tpus / total_tpus if total_tpus > 0 else 0.0
        
        # Get job queue metrics (if scheduler available)
        queued_jobs = 0
        running_jobs = 0
        high_priority_jobs = 0
        avg_queue_wait_time = 0.0
        
        if self.job_scheduler:
            try:
                job_status = self.job_scheduler.get_queue_status()
                queued_jobs = job_status.get('queued_count', 0)
                running_jobs = job_status.get('running_count', 0)
                high_priority_jobs = job_status.get('high_priority_count', 0)
                avg_queue_wait_time = job_status.get('avg_wait_time', 0.0)
            except:
                pass
        
        return ScalingMetrics(
            total_tpus=int(total_tpus),
            active_tpus=int(active_tpus),
            utilization=utilization,
            queued_jobs=queued_jobs,
            running_jobs=running_jobs,
            avg_queue_wait_time=avg_queue_wait_time,
            high_priority_jobs=high_priority_jobs
        )
    
    def _make_scaling_decision(self, metrics: ScalingMetrics) -> ScalingDecision:
        """Make scaling decision based on metrics and policies"""
        current_time = time.time()
        
        # Check cooldown periods
        if current_time - self.last_scale_up_time < self.config.scale_up_cooldown_seconds:
            return ScalingDecision(
                action=ScalingAction.NO_ACTION,
                current_tpus=metrics.total_tpus,
                target_tpus=metrics.total_tpus,
                reason="Scale-up cooldown active",
                metrics=metrics.__dict__
            )
        
        if current_time - self.last_scale_down_time < self.config.scale_down_cooldown_seconds:
            return ScalingDecision(
                action=ScalingAction.NO_ACTION,
                current_tpus=metrics.total_tpus,
                target_tpus=metrics.total_tpus,
                reason="Scale-down cooldown active",
                metrics=metrics.__dict__
            )
        
        # Evaluate enabled policies
        scale_signals = []
        
        if ScalingPolicy.UTILIZATION_BASED in self.config.enabled_policies:
            signal = self._evaluate_utilization_policy(metrics)
            scale_signals.append((signal, "utilization", self.config.utilization_weight))
        
        if ScalingPolicy.QUEUE_BASED in self.config.enabled_policies:
            signal = self._evaluate_queue_policy(metrics)
            scale_signals.append((signal, "queue", self.config.queue_weight))
        
        if ScalingPolicy.PRIORITY_BASED in self.config.enabled_policies:
            signal = self._evaluate_priority_policy(metrics)
            scale_signals.append((signal, "priority", self.config.priority_weight))
        
        # Aggregate signals
        if not scale_signals:
            return ScalingDecision(
                action=ScalingAction.NO_ACTION,
                current_tpus=metrics.total_tpus,
                target_tpus=metrics.total_tpus,
                reason="No policies enabled",
                metrics=metrics.__dict__
            )
        
        # Weighted voting
        weighted_sum = sum(signal * weight for signal, _, weight in scale_signals)
        total_weight = sum(weight for _, _, weight in scale_signals)
        avg_signal = weighted_sum / total_weight if total_weight > 0 else 0
        
        # Determine action and target
        if avg_signal > 0.3:  # Strong scale-up signal
            action = ScalingAction.SCALE_UP
            increment = int(metrics.total_tpus * self.config.scale_up_increment_percent)
            target_tpus = min(metrics.total_tpus + increment, self.config.max_tpus)
            reason = f"Scale up triggered: {', '.join(name for _, name, _ in scale_signals)}"
        
        elif avg_signal < -0.3:  # Strong scale-down signal
            action = ScalingAction.SCALE_DOWN
            decrement = int(metrics.total_tpus * self.config.scale_down_increment_percent)
            target_tpus = max(metrics.total_tpus - decrement, self.config.min_tpus)
            reason = f"Scale down triggered: {', '.join(name for _, name, _ in scale_signals)}"
        
        else:
            action = ScalingAction.NO_ACTION
            target_tpus = metrics.total_tpus
            reason = "Metrics within acceptable range"
        
        return ScalingDecision(
            action=action,
            current_tpus=metrics.total_tpus,
            target_tpus=target_tpus,
            reason=reason,
            metrics=metrics.__dict__
        )
    
    def _evaluate_utilization_policy(self, metrics: ScalingMetrics) -> float:
        """Evaluate utilization-based scaling policy
        Returns: signal in [-1.0, 1.0] where positive = scale up, negative = scale down
        """
        if metrics.utilization > self.config.scale_up_threshold:
            # Strong scale-up signal
            excess = metrics.utilization - self.config.scale_up_threshold
            return min(1.0, excess / 0.15)  # Normalize to [0, 1]
        
        elif metrics.utilization < self.config.scale_down_threshold:
            # Scale-down signal
            deficit = self.config.scale_down_threshold - metrics.utilization
            return -min(1.0, deficit / 0.25)  # Normalize to [-1, 0]
        
        else:
            # Within acceptable range
            return 0.0
    
    def _evaluate_queue_policy(self, metrics: ScalingMetrics) -> float:
        """Evaluate queue-based scaling policy"""
        if metrics.queued_jobs > self.config.queue_scale_up_threshold:
            # Scale up based on queue depth
            excess = metrics.queued_jobs - self.config.queue_scale_up_threshold
            return min(1.0, excess / 20.0)  # Normalize
        
        elif metrics.queued_jobs < self.config.queue_scale_down_threshold:
            # Scale down if queue is empty
            return -0.5
        
        else:
            return 0.0
    
    def _evaluate_priority_policy(self, metrics: ScalingMetrics) -> float:
        """Evaluate priority-based scaling policy"""
        if metrics.high_priority_jobs > 3:
            # Scale up for high-priority jobs
            return min(1.0, metrics.high_priority_jobs / 10.0)
        else:
            return 0.0
    
    def _execute_scaling_action(self, decision: ScalingDecision):
        """Execute scaling action"""
        with self.lock:
            if decision.action == ScalingAction.NO_ACTION:
                return
            
            logger.info("="*80)
            logger.info(f"⚙️  SCALING ACTION: {decision.action.value.upper()}")
            logger.info(f"Current TPUs: {decision.current_tpus:,}")
            logger.info(f"Target TPUs: {decision.target_tpus:,}")
            logger.info(f"Reason: {decision.reason}")
            logger.info(f"Utilization: {decision.metrics['utilization']:.1%}")
            logger.info(f"Queued Jobs: {decision.metrics['queued_jobs']}")
            logger.info("="*80)
            
            # Execute scaling
            success = self.cloud_controller.scale_cluster(decision.target_tpus)
            
            if success:
                # Update cooldown timers
                if decision.action == ScalingAction.SCALE_UP:
                    self.last_scale_up_time = time.time()
                    self.total_scale_up_events += 1
                elif decision.action == ScalingAction.SCALE_DOWN:
                    self.last_scale_down_time = time.time()
                    self.total_scale_down_events += 1
                
                # Record in history
                self.scaling_history.append(decision)
                if len(self.scaling_history) > 100:
                    self.scaling_history = self.scaling_history[-100:]
                
                logger.info(f"✅ Scaling action completed successfully")
            else:
                logger.error(f"❌ Scaling action failed")
    
    def get_autoscaler_status(self) -> Dict:
        """Get autoscaler status and metrics"""
        with self.lock:
            current_metrics = self._collect_metrics()
            
            # Check cooldown status
            current_time = time.time()
            scale_up_cooldown_remaining = max(
                0,
                self.config.scale_up_cooldown_seconds - (current_time - self.last_scale_up_time)
            )
            scale_down_cooldown_remaining = max(
                0,
                self.config.scale_down_cooldown_seconds - (current_time - self.last_scale_down_time)
            )
            
            return {
                'enabled': self.running,
                'config': {
                    'min_tpus': self.config.min_tpus,
                    'max_tpus': self.config.max_tpus,
                    'target_utilization': self.config.target_utilization,
                    'scaling_interval_seconds': self.config.scaling_interval_seconds,
                    'enabled_policies': [p.value for p in self.config.enabled_policies]
                },
                'current_metrics': {
                    'total_tpus': current_metrics.total_tpus,
                    'utilization': round(current_metrics.utilization, 3),
                    'queued_jobs': current_metrics.queued_jobs,
                    'running_jobs': current_metrics.running_jobs
                },
                'cooldown_status': {
                    'scale_up_cooldown_remaining_seconds': round(scale_up_cooldown_remaining, 1),
                    'scale_down_cooldown_remaining_seconds': round(scale_down_cooldown_remaining, 1)
                },
                'statistics': {
                    'total_scale_up_events': self.total_scale_up_events,
                    'total_scale_down_events': self.total_scale_down_events,
                    'total_scaling_events': self.total_scale_up_events + self.total_scale_down_events
                },
                'recent_history': [
                    {
                        'action': d.action.value,
                        'current_tpus': d.current_tpus,
                        'target_tpus': d.target_tpus,
                        'reason': d.reason,
                        'timestamp': d.timestamp
                    }
                    for d in self.scaling_history[-10:]
                ],
                'timestamp': datetime.now(timezone.utc).isoformat()
            }
    
    def update_config(self, **kwargs):
        """Update autoscaler configuration"""
        with self.lock:
            for key, value in kwargs.items():
                if hasattr(self.config, key):
                    setattr(self.config, key, value)
                    logger.info(f"Updated config: {key} = {value}")


# Global instance
_autoscaler = None


def get_autoscaler(
    cloud_controller=None,
    job_scheduler=None,
    config: Optional[ScalingConfig] = None
) -> TPUAutoscaler:
    """Get or create global autoscaler instance"""
    global _autoscaler
    
    if _autoscaler is None:
        if cloud_controller is None:
            from cloud_cluster_controller import get_cloud_controller
            cloud_controller = get_cloud_controller(initial_size=200)
        
        _autoscaler = TPUAutoscaler(
            cloud_controller=cloud_controller,
            job_scheduler=job_scheduler,
            config=config
        )
    
    return _autoscaler


def reset_autoscaler():
    """Reset global autoscaler (for testing)"""
    global _autoscaler
    if _autoscaler:
        _autoscaler.stop()
    _autoscaler = None
