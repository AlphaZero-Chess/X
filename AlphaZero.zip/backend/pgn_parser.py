"""
PGN Parser for AlphaZero Memory System
Parses multiple PGN files and extracts games for memory storage and training
"""
import chess
import chess.pgn
import io
import logging
from typing import List, Dict, Any, Tuple, Optional
from datetime import datetime, timezone
import uuid

logger = logging.getLogger(__name__)

class PGNParser:
    """Parse PGN files and extract game data for AlphaZero memory system"""
    
    @staticmethod
    def parse_pgn_file(pgn_content: str, source_filename: str) -> List[Dict[str, Any]]:
        """
        Parse a PGN file and extract all games
        
        Args:
            pgn_content: String content of PGN file
            source_filename: Name of the source file
            
        Returns:
            List of game dictionaries with metadata
        """
        games = []
        pgn_io = io.StringIO(pgn_content)
        
        game_index = 0
        while True:
            try:
                game = chess.pgn.read_game(pgn_io)
                if game is None:
                    break
                
                # Extract game metadata
                headers = game.headers
                
                # Extract moves
                moves = []
                board = game.board()
                for move in game.mainline_moves():
                    moves.append(move.uci())
                    board.push(move)
                
                # Determine result and winner
                result = headers.get("Result", "*")
                winner = None
                if result == "1-0":
                    winner = headers.get("White", "Unknown")
                elif result == "0-1":
                    winner = headers.get("Black", "Unknown")
                elif result == "1/2-1/2":
                    winner = "Draw"
                
                game_data = {
                    "memory_id": str(uuid.uuid4()),
                    "source_file": source_filename,
                    "white_player": headers.get("White", "Unknown"),
                    "black_player": headers.get("Black", "Unknown"),
                    "result": result,
                    "winner": winner,
                    "date": headers.get("Date", "????.??.??"),
                    "event": headers.get("Event", "Unknown"),
                    "opening": headers.get("Opening", "Unknown"),
                    "moves": moves,
                    "move_count": len(moves),
                    "pgn_text": str(game),
                    "timestamp_recalled": datetime.now(timezone.utc),
                    "game_index": game_index
                }
                
                games.append(game_data)
                game_index += 1
                
            except Exception as e:
                logger.error(f"Error parsing game {game_index} from {source_filename}: {e}")
                continue
        
        logger.info(f"Parsed {len(games)} games from {source_filename}")
        return games
    
    @staticmethod
    def parse_multiple_files(files_data: List[Tuple[str, str]]) -> Tuple[List[Dict[str, Any]], List[str]]:
        """
        Parse multiple PGN files
        
        Args:
            files_data: List of (filename, content) tuples
            
        Returns:
            Tuple of (all_games, errors)
        """
        all_games = []
        errors = []
        
        for filename, content in files_data:
            try:
                games = PGNParser.parse_pgn_file(content, filename)
                all_games.extend(games)
            except Exception as e:
                error_msg = f"Failed to parse {filename}: {str(e)}"
                logger.error(error_msg)
                errors.append(error_msg)
        
        return all_games, errors
    
    @staticmethod
    def game_to_training_positions(game_data: Dict[str, Any], network) -> List[Dict[str, Any]]:
        """
        Convert a game from PGN memory to training positions
        
        Args:
            game_data: Game dictionary from memory
            network: AlphaZero network for evaluation
            
        Returns:
            List of training position dictionaries
        """
        from chess_engine import ChessEngine
        import numpy as np
        
        positions = []
        engine = ChessEngine()
        
        # Determine game outcome value
        result = game_data.get("result", "*")
        if result == "1-0":
            final_value = 1.0  # White wins
        elif result == "0-1":
            final_value = -1.0  # Black wins
        else:
            final_value = 0.0  # Draw
        
        # Play through the game and collect positions
        for move_idx, move_uci in enumerate(game_data.get("moves", [])):
            # Get current position
            position = engine.get_position()
            fen = engine.get_fen()
            
            # Get policy (we'll use uniform for recalled games, as we don't have MCTS data)
            legal_moves = engine.get_legal_moves()
            policy = {move: 1.0 / len(legal_moves) for move in legal_moves}
            
            # Value decays toward the end result
            # Flip value for black's perspective
            move_value = final_value if engine.board.turn == chess.WHITE else -final_value
            
            positions.append({
                "position": position,
                "policy": policy,
                "value": move_value,
                "fen": fen,
                "move_number": move_idx + 1,
                "source": "pgn_memory",
                "memory_id": game_data.get("memory_id")
            })
            
            # Make the move
            if not engine.make_move(move_uci):
                logger.error(f"Invalid move {move_uci} in game {game_data.get('memory_id')}")
                break
        
        return positions
