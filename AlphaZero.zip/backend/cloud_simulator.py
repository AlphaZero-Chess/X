"""
Cloud TPU Grid Simulator
Simulates a 5,000 TPU virtual grid across 4 regions with real-time metrics
"""
import asyncio
import random
import time
import uuid
from typing import Dict, List, Any
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import logging

logger = logging.getLogger(__name__)

# Region definitions
REGIONS = ['us-east', 'us-west', 'eu-west', 'asia']

@dataclass
class TPUNode:
    """Individual TPU node"""
    node_id: str
    region: str
    utilization: float  # 0.0 to 1.0
    status: str  # 'active', 'idle', 'fault', 'maintenance'
    job_id: str = None
    fault_type: str = None  # 'crash', 'latency', None
    last_updated: float = None
    
    def __post_init__(self):
        if self.last_updated is None:
            self.last_updated = time.time()

@dataclass
class Job:
    """Training job"""
    job_id: str
    name: str
    priority: int  # 1-5
    tpus_required: int
    status: str  # 'queued', 'running', 'completed', 'failed'
    region: str
    started_at: float = None
    completed_at: float = None
    progress: float = 0.0  # 0.0 to 1.0

class CloudTPUSimulator:
    """Simulates a cloud TPU grid with realistic metrics"""
    
    def __init__(self, initial_tpu_count: int = 5000):
        self.total_tpus = initial_tpu_count
        self.nodes: Dict[str, TPUNode] = {}
        self.jobs: Dict[str, Job] = {}
        self.job_queue: List[str] = []
        
        # Metrics history (last 100 data points)
        self.metrics_history = {
            'throughput': [],  # jobs/sec
            'utilization': [],  # average utilization
            'fault_rate': [],  # faults/sec
            'latency': {}  # region-to-region latency
        }
        
        # Performance counters
        self.total_jobs_completed = 0
        self.total_faults_injected = 0
        self.start_time = time.time()
        
        # Initialize grid
        self._initialize_grid()
        
        # Start background metrics update
        self.running = False
        
    def _initialize_grid(self):
        """Initialize TPU nodes across regions"""
        tpus_per_region = self.total_tpus // len(REGIONS)
        
        for region_idx, region in enumerate(REGIONS):
            # Distribute TPUs across regions
            num_tpus = tpus_per_region
            if region_idx == 0:
                num_tpus += (self.total_tpus % len(REGIONS))  # Add remainder to first region
            
            for i in range(num_tpus):
                node_id = f"{region}-tpu-{i:05d}"
                self.nodes[node_id] = TPUNode(
                    node_id=node_id,
                    region=region,
                    utilization=random.uniform(0.3, 0.8),  # Start with moderate load
                    status='active' if random.random() > 0.05 else 'idle'
                )
        
        # Initialize inter-region latency matrix
        for r1 in REGIONS:
            for r2 in REGIONS:
                key = f"{r1}->{r2}"
                if r1 == r2:
                    self.metrics_history['latency'][key] = 0.5  # Intra-region latency
                else:
                    # Inter-region latency (5-50ms)
                    self.metrics_history['latency'][key] = random.uniform(5, 50)
        
        logger.info(f"Initialized cloud grid: {self.total_tpus} TPUs across {len(REGIONS)} regions")
    
    def get_status(self) -> Dict[str, Any]:
        """Get current grid status"""
        region_stats = {}
        
        for region in REGIONS:
            region_nodes = [n for n in self.nodes.values() if n.region == region]
            active_nodes = [n for n in region_nodes if n.status == 'active']
            fault_nodes = [n for n in region_nodes if n.status == 'fault']
            
            avg_utilization = sum(n.utilization for n in active_nodes) / len(active_nodes) if active_nodes else 0
            
            region_stats[region] = {
                'total_tpus': len(region_nodes),
                'active_tpus': len(active_nodes),
                'fault_tpus': len(fault_nodes),
                'utilization': round(avg_utilization, 3),
                'jobs_running': len([j for j in self.jobs.values() if j.region == region and j.status == 'running'])
            }
        
        # Global stats
        all_active = [n for n in self.nodes.values() if n.status == 'active']
        global_utilization = sum(n.utilization for n in all_active) / len(all_active) if all_active else 0
        
        return {
            'total_tpus': self.total_tpus,
            'active_tpus': len(all_active),
            'global_utilization': round(global_utilization, 3),
            'regions': region_stats,
            'jobs_running': len([j for j in self.jobs.values() if j.status == 'running']),
            'jobs_queued': len(self.job_queue),
            'total_jobs_completed': self.total_jobs_completed,
            'uptime_seconds': int(time.time() - self.start_time),
            'timestamp': datetime.now(timezone.utc).isoformat()
        }
    
    def scale(self, target_tpus: int) -> Dict[str, Any]:
        """Scale TPU grid up or down"""
        if target_tpus < 100 or target_tpus > 10000:
            raise ValueError("Target TPUs must be between 100 and 10,000")
        
        current_tpus = self.total_tpus
        delta = target_tpus - current_tpus
        
        if delta > 0:
            # Scale up: add new nodes
            self._add_tpus(delta)
        elif delta < 0:
            # Scale down: remove idle nodes
            self._remove_tpus(abs(delta))
        
        logger.info(f"Scaled grid from {current_tpus} to {target_tpus} TPUs (delta: {delta:+d})")
        
        return {
            'success': True,
            'previous_tpus': current_tpus,
            'current_tpus': self.total_tpus,
            'delta': delta,
            'message': f"Scaled {'up' if delta > 0 else 'down'} by {abs(delta)} TPUs"
        }
    
    def _add_tpus(self, count: int):
        """Add new TPU nodes"""
        tpus_per_region = count // len(REGIONS)
        remainder = count % len(REGIONS)
        
        for region_idx, region in enumerate(REGIONS):
            num_to_add = tpus_per_region + (1 if region_idx < remainder else 0)
            
            for i in range(num_to_add):
                node_id = f"{region}-tpu-{len([n for n in self.nodes.values() if n.region == region]):05d}"
                self.nodes[node_id] = TPUNode(
                    node_id=node_id,
                    region=region,
                    utilization=random.uniform(0.1, 0.3),
                    status='active'
                )
        
        self.total_tpus += count
    
    def _remove_tpus(self, count: int):
        """Remove idle TPU nodes"""
        # Find idle nodes
        idle_nodes = [n for n in self.nodes.values() if n.status == 'idle' and n.job_id is None]
        
        if len(idle_nodes) < count:
            # Not enough idle nodes, also remove lightly loaded active nodes
            active_nodes = [n for n in self.nodes.values() if n.status == 'active' and n.utilization < 0.2]
            idle_nodes.extend(active_nodes)
        
        # Remove nodes
        nodes_to_remove = idle_nodes[:min(count, len(idle_nodes))]
        for node in nodes_to_remove:
            del self.nodes[node.node_id]
        
        self.total_tpus -= len(nodes_to_remove)
    
    def inject_fault(self, region: str, fault_type: str, num_nodes: int = 10) -> Dict[str, Any]:
        """Inject faults into the grid"""
        if region not in REGIONS and region != 'random':
            raise ValueError(f"Invalid region: {region}")
        
        if fault_type not in ['crash', 'latency', 'recovery']:
            raise ValueError(f"Invalid fault type: {fault_type}")
        
        # Select target nodes
        if region == 'random':
            target_nodes = list(self.nodes.values())
        else:
            target_nodes = [n for n in self.nodes.values() if n.region == region]
        
        # Apply fault
        affected_nodes = random.sample(target_nodes, min(num_nodes, len(target_nodes)))
        
        if fault_type == 'crash':
            for node in affected_nodes:
                node.status = 'fault'
                node.fault_type = 'crash'
                node.utilization = 0.0
        elif fault_type == 'latency':
            for node in affected_nodes:
                node.fault_type = 'latency'
                node.utilization = min(node.utilization * 0.5, 0.3)  # Reduce performance
        elif fault_type == 'recovery':
            # Recover all faulted nodes in region
            for node in target_nodes:
                if node.status == 'fault' or node.fault_type:
                    node.status = 'active'
                    node.fault_type = None
                    node.utilization = random.uniform(0.3, 0.7)
        
        self.total_faults_injected += len(affected_nodes)
        
        logger.info(f"Injected {fault_type} fault: {len(affected_nodes)} nodes in {region}")
        
        return {
            'success': True,
            'fault_type': fault_type,
            'region': region,
            'affected_nodes': len(affected_nodes),
            'node_ids': [n.node_id for n in affected_nodes[:5]]  # Sample
        }
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get detailed metrics"""
        # Calculate current metrics
        active_nodes = [n for n in self.nodes.values() if n.status == 'active']
        fault_nodes = [n for n in self.nodes.values() if n.status == 'fault']
        
        # Jobs throughput (jobs completed per second)
        elapsed = time.time() - self.start_time
        throughput = self.total_jobs_completed / elapsed if elapsed > 0 else 0
        
        # Fault rate
        fault_rate = len(fault_nodes) / self.total_tpus if self.total_tpus > 0 else 0
        
        # Average utilization
        avg_utilization = sum(n.utilization for n in active_nodes) / len(active_nodes) if active_nodes else 0
        
        # Update history (keep last 100 points)
        self.metrics_history['throughput'].append({
            'timestamp': time.time(),
            'value': round(throughput, 2)
        })
        self.metrics_history['utilization'].append({
            'timestamp': time.time(),
            'value': round(avg_utilization, 3)
        })
        self.metrics_history['fault_rate'].append({
            'timestamp': time.time(),
            'value': round(fault_rate, 4)
        })
        
        # Trim history
        for key in ['throughput', 'utilization', 'fault_rate']:
            if len(self.metrics_history[key]) > 100:
                self.metrics_history[key] = self.metrics_history[key][-100:]
        
        return {
            'throughput': round(throughput, 2),
            'utilization': round(avg_utilization, 3),
            'fault_rate': round(fault_rate, 4),
            'latency_matrix': self.metrics_history['latency'],
            'history': {
                'throughput': self.metrics_history['throughput'][-20:],  # Last 20 points
                'utilization': self.metrics_history['utilization'][-20:],
                'fault_rate': self.metrics_history['fault_rate'][-20:]
            },
            'timestamp': datetime.now(timezone.utc).isoformat()
        }
    
    def get_jobs(self) -> Dict[str, Any]:
        """Get job queue status"""
        return {
            'running': [asdict(j) for j in self.jobs.values() if j.status == 'running'][:10],
            'queued': [asdict(j) for j in self.jobs.values() if j.status == 'queued'][:10],
            'total_running': len([j for j in self.jobs.values() if j.status == 'running']),
            'total_queued': len(self.job_queue),
            'total_completed': self.total_jobs_completed
        }
    
    def submit_job(self, name: str, tpus_required: int, priority: int = 3, region: str = 'us-east') -> str:
        """Submit a new job to the queue"""
        job_id = str(uuid.uuid4())[:8]
        
        job = Job(
            job_id=job_id,
            name=name,
            priority=priority,
            tpus_required=tpus_required,
            status='queued',
            region=region
        )
        
        self.jobs[job_id] = job
        self.job_queue.append(job_id)
        
        return job_id
    
    def update_simulation(self):
        """Update simulation state (called periodically)"""
        # Randomly adjust node utilization
        for node in self.nodes.values():
            if node.status == 'active':
                # Add some noise to utilization
                delta = random.uniform(-0.05, 0.05)
                node.utilization = max(0.0, min(1.0, node.utilization + delta))
                node.last_updated = time.time()
        
        # Update inter-region latency (add noise)
        for key in self.metrics_history['latency'].keys():
            if '->' in key:
                r1, r2 = key.split('->')
                if r1 != r2:
                    base_latency = self.metrics_history['latency'][key]
                    noise = random.uniform(-2, 2)
                    self.metrics_history['latency'][key] = max(1.0, base_latency + noise)
        
        # Process job queue (simple scheduler)
        self._schedule_jobs()
        
        # Update running jobs
        for job in list(self.jobs.values()):
            if job.status == 'running':
                job.progress = min(1.0, job.progress + random.uniform(0.02, 0.05))
                
                if job.progress >= 1.0:
                    job.status = 'completed'
                    job.completed_at = time.time()
                    self.total_jobs_completed += 1
                    
                    # Release TPUs
                    for node in self.nodes.values():
                        if node.job_id == job.job_id:
                            node.job_id = None
                            node.utilization = random.uniform(0.1, 0.3)
    
    def _schedule_jobs(self):
        """Simple job scheduler"""
        if not self.job_queue:
            return
        
        # Count available TPUs per region
        available_tpus = {}
        for region in REGIONS:
            region_nodes = [n for n in self.nodes.values() 
                          if n.region == region and n.status == 'active' and n.job_id is None]
            available_tpus[region] = len(region_nodes)
        
        # Try to schedule queued jobs
        for job_id in list(self.job_queue):
            job = self.jobs[job_id]
            
            if available_tpus.get(job.region, 0) >= job.tpus_required:
                # Allocate TPUs to job
                region_nodes = [n for n in self.nodes.values() 
                              if n.region == job.region and n.status == 'active' and n.job_id is None]
                
                allocated_nodes = region_nodes[:job.tpus_required]
                for node in allocated_nodes:
                    node.job_id = job_id
                    node.utilization = random.uniform(0.7, 0.95)
                
                # Update job status
                job.status = 'running'
                job.started_at = time.time()
                self.job_queue.remove(job_id)
                
                available_tpus[job.region] -= job.tpus_required
                
                logger.info(f"Scheduled job {job_id} ({job.name}) on {job.tpus_required} TPUs in {job.region}")

# Global simulator instance
cloud_simulator = CloudTPUSimulator(initial_tpu_count=5000)
