#!/usr/bin/env python3
"""
Test Sequential Self-Play Implementation
Verifies the fixed training cycle works correctly
"""

import sys
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def test_sequential_selfplay():
    """Test sequential self-play batch generation"""
    logger.info("="*80)
    logger.info("TESTING SEQUENTIAL SELF-PLAY IMPLEMENTATION")
    logger.info("="*80)
    
    try:
        from selfplay_trainer import AlphaZeroSelfPlayTrainer
        
        # Create trainer with minimal settings for fast testing
        logger.info("Creating AlphaZeroSelfPlayTrainer...")
        trainer = AlphaZeroSelfPlayTrainer(
            max_games=100,  # Low for testing
            max_hours=1.0,
            num_simulations=50,  # Low for speed
            replay_buffer_size=10000,
            batch_size=32,
            learning_rate=0.001,
            checkpoint_interval=3600,
            eval_interval=10000,  # Disable eval during test
            log_dir="/app/backend/test_logs"
        )
        
        logger.info("Trainer initialized successfully")
        logger.info(f"  Device: {trainer.network.device if hasattr(trainer.network, 'device') else 'Unknown'}")
        logger.info(f"  Replay buffer capacity: {trainer.replay_buffer.max_size:,}")
        
        # Test batch generation
        num_test_games = 3
        logger.info(f"\n--- Testing batch generation with {num_test_games} games ---")
        
        training_data, batch_time = trainer.generate_selfplay_batch(num_test_games)
        
        logger.info("\n" + "="*80)
        logger.info("RESULTS:")
        logger.info(f"  Games generated: {num_test_games}")
        logger.info(f"  Positions collected: {len(training_data)}")
        logger.info(f"  Time taken: {batch_time:.1f}s")
        logger.info(f"  Rate: {num_test_games/batch_time:.2f} games/sec")
        
        if len(training_data) > 0:
            avg_positions = len(training_data) / num_test_games
            logger.info(f"  Average positions per game: {avg_positions:.1f}")
            
            # Verify data structure
            sample = training_data[0]
            logger.info(f"\n  Sample data structure:")
            logger.info(f"    Keys: {list(sample.keys())}")
            logger.info(f"    Position type: {type(sample.get('position'))}")
            logger.info(f"    Policy type: {type(sample.get('policy'))}")
            logger.info(f"    Value: {sample.get('value')}")
        
        # Test replay buffer integration
        logger.info(f"\n--- Testing replay buffer integration ---")
        logger.info(f"  Replay buffer size before: {trainer.replay_buffer.size()}")
        
        trainer.replay_buffer.add(training_data)
        
        logger.info(f"  Replay buffer size after: {trainer.replay_buffer.size()}")
        
        if trainer.replay_buffer.size() == len(training_data):
            logger.info("  ✅ All positions added successfully")
            
            # Test sampling
            sample_batch = trainer.replay_buffer.sample(5)
            logger.info(f"  ✅ Sampled {len(sample_batch)} positions from buffer")
            
            logger.info("\n" + "="*80)
            logger.info("✅ ALL TESTS PASSED")
            logger.info("Sequential self-play implementation is working correctly!")
            logger.info("Training can now proceed with data collection enabled.")
            logger.info("="*80)
            
            return True
        else:
            logger.error(f"  ❌ Replay buffer size mismatch!")
            logger.error(f"     Expected: {len(training_data)}, Got: {trainer.replay_buffer.size()}")
            return False
        
    except Exception as e:
        logger.error(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_sequential_selfplay()
    sys.exit(0 if success else 1)
