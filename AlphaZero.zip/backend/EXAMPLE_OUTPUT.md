# Example Test Cycle Output

## Complete Run Example

```bash
$ python test_cycle.py --games 20 --epochs 1
```

### Console Output

```
INFO - 
INFO - ██████████████████████████████████████████████████████████████████████
INFO -  AlphaZero Test Cycle - Session 2f00012e
INFO - ██████████████████████████████████████████████████████████████████████
INFO - Configuration:
INFO -   Games: 20
INFO -   Parallel: False (threads: 1)
INFO -   Epochs: 1
INFO -   Base model: ActiveModel_Offline
INFO -   New model: ActiveModel_TestCycle
INFO - 
INFO - ======================================================================
INFO -  PHASE 1: SELF-PLAY GENERATION
INFO - ======================================================================
INFO - Loading base model: ActiveModel_Offline
INFO - ✓ Loaded existing model: ActiveModel_Offline
INFO -   Metadata: {'version': 1, 'games_trained': 1000, 'elo': 1524}
INFO - Using sequential self-play
INFO - Starting self-play game 1/20
INFO - Self-play game complete: 1-0, 87 moves in 12.3s
INFO - Starting self-play game 2/20
INFO - Self-play game complete: 1/2-1/2, 114 moves in 15.8s
...
INFO - Starting self-play game 20/20
INFO - Self-play game complete: 0-1, 95 moves in 13.2s
INFO - Saving 20 games as PGN files...
INFO - 
INFO - ✓ Generated 20 games
INFO -   Total positions: 1847
INFO -   Results: W=8, B=7, D=5
INFO -   Time: 245.3s (4.9 games/min)
INFO -   PGNs saved to: /app/backend/cache/selfplay/test_cycle_pgns/
INFO - 
INFO - ======================================================================
INFO -  PHASE 2: MODEL TRAINING
INFO - ======================================================================
INFO - Training on 1847 positions for 1 epoch(s)
INFO - Trainer initialized on CPU
INFO - Epoch 1/1 - Loss: 0.3421, Policy: 0.2145, Value: 0.1276, Time: 18.2s
INFO - Saving trained model as: ActiveModel_TestCycle
INFO - 
INFO - ✓ Training complete
INFO -   Epochs: 1
INFO -   Final loss: 0.3421
INFO -   Time: 23.5s
INFO -   Model saved: ActiveModel_TestCycle.pth
INFO - 
INFO - ======================================================================
INFO -  PHASE 3: MODEL EVALUATION
INFO - ======================================================================
INFO - Evaluating: ActiveModel_TestCycle vs ActiveModel_Offline
INFO - Playing 20 evaluation games (10 as White, 10 as Black)
INFO - Playing evaluation game 1/20 (Model1=White)
INFO - Playing evaluation game 2/20 (Model1=Black)
...
INFO - Playing evaluation game 20/20 (Model1=Black)
INFO - Evaluation complete in 178.2s
INFO - Evaluation complete:
INFO -   Challenger win rate: 55.0%
INFO -   ELO: 1500 -> 1524 (Δ +24)
INFO -   Promoted: Yes
INFO - 
INFO - ✓ Evaluation complete
INFO -   Games played: 20
INFO -   Win rate: 55.0%
INFO -   ELO change: +24
INFO -   Average eval: +0.10
INFO -   Promoted: Yes
INFO -   Time: 178.2s
INFO - 
INFO - ✓ Results saved to: /app/backend/cache/test_cycle_results.json
INFO - 
INFO - ██████████████████████████████████████████████████████████████████████
INFO -  TEST CYCLE COMPLETE
INFO - ██████████████████████████████████████████████████████████████████████
INFO - Session: 2f00012e
INFO - Total time: 447.0s (7.5m)
INFO - Results: /app/backend/cache/test_cycle_results.json
INFO - Logs: /app/backend/cache/test_cycle.log
INFO - 
INFO - Key Metrics:
INFO -   Games played: 20
INFO -   New model: ActiveModel_TestCycle.pth
INFO -   Win rate: 55.0%
INFO -   ELO change: +24
INFO - 
INFO - ✓ Pipeline validated successfully
```

## First Run Example (No Previous Model)

```bash
$ python test_cycle.py --games 10
```

### Console Output

```
INFO - 
INFO - ██████████████████████████████████████████████████████████████████████
INFO -  AlphaZero Test Cycle - Session a3f5b2c1
INFO - ██████████████████████████████████████████████████████████████████████
INFO - Configuration:
INFO -   Games: 10
INFO -   Parallel: False (threads: 1)
INFO -   Epochs: 1
INFO -   Base model: ActiveModel_Offline
INFO -   New model: ActiveModel_TestCycle
INFO - 
INFO - ======================================================================
INFO -  PHASE 1: SELF-PLAY GENERATION
INFO - ======================================================================
INFO - Loading base model: ActiveModel_Offline
INFO - Neural network initialized on CPU
INFO - ⚠ Model ActiveModel_Offline not found, creating fresh untrained model
INFO - ✓ Created and saved base model: ActiveModel_Offline
INFO - Using sequential self-play
...
INFO - 
INFO - ✓ Generated 10 games
INFO -   Total positions: 923
INFO -   Results: W=4, B=3, D=3
INFO -   Time: 122.7s (4.9 games/min)
INFO -   PGNs saved to: /app/backend/cache/selfplay/test_cycle_pgns/
INFO - 
INFO - ======================================================================
INFO -  PHASE 2: MODEL TRAINING
INFO - ======================================================================
...
INFO - ✓ Training complete
INFO -   Epochs: 1
INFO -   Final loss: 0.4521
INFO -   Time: 11.8s
INFO -   Model saved: ActiveModel_TestCycle.pth
INFO - 
INFO - ======================================================================
INFO -  PHASE 3: MODEL EVALUATION
INFO - ======================================================================
INFO - ⚠ First run detected - no previous model to compare against
INFO -   Skipping evaluation phase
INFO -   Run test_cycle.py again to compare future improvements
INFO - 
INFO - ██████████████████████████████████████████████████████████████████████
INFO -  TEST CYCLE COMPLETE
INFO - ██████████████████████████████████████████████████████████████████████
INFO - Session: a3f5b2c1
INFO - Total time: 134.5s (2.2m)
INFO - Results: /app/backend/cache/test_cycle_results.json
INFO - Logs: /app/backend/cache/test_cycle.log
INFO - 
INFO - Note: First run completed successfully
INFO - Run again to see evaluation metrics
INFO - 
INFO - ✓ Pipeline validated successfully
```

## Parallel Mode Example

```bash
$ python test_cycle.py --games 20 --threads 4 --parallel
```

### Console Output (Selected Lines)

```
INFO - Configuration:
INFO -   Games: 20
INFO -   Parallel: True (threads: 4)
INFO -   Epochs: 1
...
INFO - Using parallel self-play with 4 threads
INFO - Starting parallel self-play: 20 games with 4 threads
INFO - Game 1/20 complete (1-0, 87 moves) - 0.0 games/min
INFO - Game 2/20 complete (1/2-1/2, 95 moves) - 12.5 games/min
INFO - Game 3/20 complete (0-1, 102 moves) - 14.3 games/min
INFO - Game 4/20 complete (1-0, 79 moves) - 15.8 games/min
...
INFO - Game 20/20 complete (1/2-1/2, 91 moves) - 13.2 games/min
INFO - Parallel self-play complete: 20 games, 1823 positions in 91.2s (13.2 games/min)
...
INFO - ✓ Generated 20 games
INFO -   Total positions: 1823
INFO -   Results: W=9, B=6, D=5
INFO -   Time: 91.2s (13.2 games/min)  <-- 2.7x faster than sequential!
```

## Quick Test Example

```bash
$ python test_cycle_quick.py --games 3
```

### Console Output

```
======================================================================
 QUICK TEST MODE - Reduced MCTS simulations for fast validation
 Self-play: 50 sims/move (normal: 800)
 Evaluation: 50 sims/move (normal: 400)
======================================================================

INFO - 
INFO - ██████████████████████████████████████████████████████████████████████
INFO -  AlphaZero Test Cycle - Session b7d2e4f3
INFO - ██████████████████████████████████████████████████████████████████████
INFO - Configuration:
INFO -   Games: 3
INFO -   Parallel: False (threads: 1)
INFO -   Epochs: 1
INFO -   Base model: ActiveModel_Offline
INFO -   New model: ActiveModel_TestCycle
...
INFO - ✓ Generated 3 games
INFO -   Total positions: 287
INFO -   Results: W=1, B=1, D=1
INFO -   Time: 18.3s (9.8 games/min)  <-- Much faster with 50 sims!
...
INFO - ✓ Pipeline validated successfully
```

## JSON Output Example

### `/app/backend/cache/test_cycle_results.json`

```json
{
  "session_id": "2f00012e",
  "timestamp": "2025-10-15T21:15:34.567890+00:00",
  "config": {
    "num_games": 20,
    "num_threads": 1,
    "enable_parallel": false,
    "num_epochs": 1,
    "base_model": "ActiveModel_Offline",
    "new_model": "ActiveModel_TestCycle"
  },
  "phases": {
    "selfplay": {
      "games_generated": 20,
      "positions_generated": 1847,
      "white_wins": 8,
      "black_wins": 7,
      "draws": 5,
      "time_seconds": 245.3,
      "games_per_minute": 4.9,
      "pgn_directory": "/app/backend/cache/selfplay/test_cycle_pgns",
      "parallel_mode": false,
      "threads": 1
    },
    "training": {
      "epochs": 1,
      "positions_trained": 1847,
      "batch_size": 64,
      "learning_rate": 0.001,
      "final_loss": 0.3421,
      "final_policy_loss": 0.2145,
      "final_value_loss": 0.1276,
      "time_seconds": 23.5,
      "model_saved": "/app/backend/models/ActiveModel_TestCycle.pt",
      "training_history": [
        {
          "loss": 0.3421,
          "policy_loss": 0.2145,
          "value_loss": 0.1276,
          "num_batches": 29,
          "epoch": 1,
          "total_steps": 29,
          "timestamp": "2025-10-15T21:19:58.123456+00:00",
          "epoch_time": 18.2,
          "device": "CPU",
          "mixed_precision": false
        }
      ]
    },
    "evaluation": {
      "games_played": 20,
      "model1_wins": 11,
      "model2_wins": 7,
      "draws": 2,
      "model1_as_white_wins": 6,
      "model1_as_black_wins": 5,
      "model2_as_white_wins": 3,
      "model2_as_black_wins": 4,
      "model1_win_rate": 0.55,
      "model2_win_rate": 0.35,
      "draw_rate": 0.1,
      "evaluation_time": 178.2,
      "challenger_name": "ActiveModel_TestCycle",
      "champion_name": "ActiveModel_Offline",
      "challenger_win_rate": 0.55,
      "champion_win_rate": 0.35,
      "challenger_elo_before": 1500.0,
      "challenger_elo_after": 1524.0,
      "elo_delta": 24.0,
      "expected_score": 0.5,
      "actual_score": 0.6,
      "champion_elo_after": 1476.0,
      "promoted": true,
      "promotion_reason": [
        "Win rate 55.0% >= 55.0%"
      ],
      "time_seconds": 178.2
    }
  },
  "summary": {
    "success": true,
    "total_time_seconds": 447.0,
    "completed_phases": [
      "selfplay",
      "training",
      "evaluation"
    ]
  }
}
```

## PGN File Example

### `/app/backend/cache/selfplay/test_cycle_pgns/game_2f00012e_000001.pgn`

```
[Event "AlphaZero Test Cycle Self-Play"]
[Site "Local"]
[Date "2025.10.15"]
[Round "1"]
[White "AlphaZero"]
[Black "AlphaZero"]
[Result "1-0"]

1-0
```

## Log File Example (Excerpt)

### `/app/backend/cache/test_cycle.log`

```
2025-10-15 21:15:00,123 - __main__ - INFO - 
2025-10-15 21:15:00,123 - __main__ - INFO - ██████████████████████████████████████████████████████████████████████
2025-10-15 21:15:00,124 - __main__ - INFO -  AlphaZero Test Cycle - Session 2f00012e
2025-10-15 21:15:00,124 - __main__ - INFO - ██████████████████████████████████████████████████████████████████████
2025-10-15 21:15:00,125 - __main__ - INFO - Configuration:
2025-10-15 21:15:00,125 - __main__ - INFO -   Games: 20
2025-10-15 21:15:00,125 - __main__ - INFO -   Parallel: False (threads: 1)
2025-10-15 21:15:00,125 - __main__ - INFO -   Epochs: 1
2025-10-15 21:15:00,125 - __main__ - INFO -   Base model: ActiveModel_Offline
2025-10-15 21:15:00,126 - __main__ - INFO -   New model: ActiveModel_TestCycle
...
2025-10-15 21:15:05,234 - neural_network - INFO - Neural network initialized on CPU
2025-10-15 21:15:12,456 - self_play - INFO - Self-play game complete: 1-0, 87 moves in 12.3s
...
2025-10-15 21:22:45,789 - __main__ - INFO - ✓ Pipeline validated successfully
```

## File Structure After Test

```
/app/backend/
├── models/
│   ├── ActiveModel_Offline.pt          # Base model
│   └── ActiveModel_TestCycle.pt        # Trained model
├── cache/
│   ├── test_cycle_results.json         # JSON results
│   ├── test_cycle.log                  # Detailed logs
│   └── selfplay/
│       └── test_cycle_pgns/
│           ├── game_2f00012e_000001.pgn
│           ├── game_2f00012e_000002.pgn
│           ...
│           └── game_2f00012e_000020.pgn
└── test_cycle.py                       # Main script
```
