"""
Hybrid Multi-Cloud Deployment API Routes (Phase 6)
Provides HTTP and WebSocket endpoints for hybrid cloud orchestration

Endpoints:
- GET  /api/hybrid/status - Get hybrid cloud status
- GET  /api/hybrid/jobs - Get hybrid job queue
- POST /api/hybrid/route-job - Submit job with intelligent routing
- POST /api/hybrid/pricing - Toggle cost simulation
- WebSocket /api/hybrid/live - Live hybrid metrics streaming
"""

from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect, BackgroundTasks
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import asyncio
import json
import logging
from datetime import datetime, timezone
import uuid
import random

logger = logging.getLogger(__name__)

# Create router with /api/hybrid prefix
hybrid_router = APIRouter(prefix="/api/hybrid", tags=["Hybrid Multi-Cloud"])

# WebSocket connection manager
class HybridConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"Hybrid WebSocket connected. Total: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        logger.info(f"Hybrid WebSocket disconnected. Total: {len(self.active_connections)}")

    async def broadcast(self, message: dict):
        """Broadcast hybrid update to all connected clients"""
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error sending hybrid message: {e}")
                disconnected.append(connection)
        
        # Remove disconnected clients
        for conn in disconnected:
            self.disconnect(conn)

hybrid_manager = HybridConnectionManager()

# Simulated hybrid cloud state
REGIONS = {
    "aws-us-east-1": {"provider": "aws", "tpus": 800, "active": 0, "latency": 15},
    "aws-us-west-2": {"provider": "aws", "tpus": 800, "active": 0, "latency": 45},
    "aws-eu-west-1": {"provider": "aws", "tpus": 600, "active": 0, "latency": 85},
    "gcp-us-central1": {"provider": "gcp", "tpus": 1000, "active": 0, "latency": 20},
    "gcp-us-west1": {"provider": "gcp", "tpus": 800, "active": 0, "latency": 40},
    "gcp-europe-west1": {"provider": "gcp", "tpus": 600, "active": 0, "latency": 90},
    "gcp-asia-southeast1": {"provider": "gcp", "tpus": 400, "active": 0, "latency": 150},
    "local-zone-a": {"provider": "local", "tpus": 300, "active": 0, "latency": 5},
    "local-zone-b": {"provider": "local", "tpus": 300, "active": 0, "latency": 5},
    "aws-ap-southeast-1": {"provider": "aws", "tpus": 400, "active": 0, "latency": 160},
    "gcp-us-east1": {"provider": "gcp", "tpus": 600, "active": 0, "latency": 18},
    "aws-eu-central-1": {"provider": "aws", "tpus": 500, "active": 0, "latency": 80},
}

hybrid_jobs = {
    "running": [],
    "queued": [],
    "completed": []
}

pricing_enabled = False
total_cost = 0.0

# Pricing per TPU-hour
PRICING = {
    "aws": 4.50,
    "gcp": 4.00,
    "local": 0.00  # Local cluster has no usage cost
}

# Data models
class RouteJobRequest(BaseModel):
    name: str = Field(..., description="Job name")
    tpus_required: int = Field(..., ge=1, le=1000, description="TPUs required")
    priority: int = Field(default=3, ge=1, le=10, description="Job priority (1=lowest, 10=highest)")
    routing_policy: str = Field(default="latency_first", description="Routing policy")

class PricingToggleRequest(BaseModel):
    enabled: bool = Field(..., description="Enable/disable pricing simulation")

# REST Endpoints
@hybrid_router.get("/status")
async def get_hybrid_status():
    """
    Get hybrid cloud federation status
    Returns overview of all regions and providers
    """
    try:
        # Calculate federation stats
        total_tpus = sum(r["tpus"] for r in REGIONS.values())
        active_tpus = sum(r["active"] for r in REGIONS.values())
        
        # Provider breakdown
        providers = {
            "aws": {"regions": 0, "total_tpus": 0, "active_tpus": 0, "utilization": 0.0, "jobs_running": 0, "avg_cost_per_tpu_hour": PRICING["aws"]},
            "gcp": {"regions": 0, "total_tpus": 0, "active_tpus": 0, "utilization": 0.0, "jobs_running": 0, "avg_cost_per_tpu_hour": PRICING["gcp"]},
            "local": {"regions": 0, "total_tpus": 0, "active_tpus": 0, "utilization": 0.0, "jobs_running": 0, "avg_cost_per_tpu_hour": PRICING["local"]},
        }
        
        for region_id, region in REGIONS.items():
            provider = region["provider"]
            providers[provider]["regions"] += 1
            providers[provider]["total_tpus"] += region["tpus"]
            providers[provider]["active_tpus"] += region["active"]
        
        # Calculate utilization per provider
        for provider in providers.values():
            if provider["total_tpus"] > 0:
                provider["utilization"] = provider["active_tpus"] / provider["total_tpus"]
        
        # Build region details
        regions_detail = {}
        for region_id, region in REGIONS.items():
            regions_detail[region_id] = {
                "region_name": region_id,
                "provider": region["provider"],
                "total_tpus": region["tpus"],
                "active_tpus": region["active"],
                "utilization": region["active"] / region["tpus"] if region["tpus"] > 0 else 0.0,
                "latency_ms": region["latency"],
                "jobs_running": len([j for j in hybrid_jobs["running"] if j.get("assigned_region") == region_id]),
                "health": "healthy" if region["active"] < region["tpus"] * 0.9 else "saturated"
            }
        
        return {
            "success": True,
            "federation": {
                "total_regions": len(REGIONS),
                "total_tpus": total_tpus,
                "active_tpus": active_tpus,
                "utilization": active_tpus / total_tpus if total_tpus > 0 else 0.0,
                "total_cost_incurred": total_cost
            },
            "providers": providers,
            "regions": regions_detail,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting hybrid status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@hybrid_router.get("/jobs")
async def get_hybrid_jobs():
    """
    Get hybrid job queue
    Returns running, queued, and completed jobs
    """
    try:
        return {
            "success": True,
            "running": hybrid_jobs["running"],
            "queued": hybrid_jobs["queued"],
            "completed": hybrid_jobs["completed"][-50:],  # Last 50 completed
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting hybrid jobs: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@hybrid_router.post("/route-job")
async def route_job(request: RouteJobRequest, background_tasks: BackgroundTasks):
    """
    Submit job with intelligent routing
    Routes to optimal region based on policy
    
    Routing policies:
    - latency_first: Minimize latency
    - throughput_first: Maximize throughput
    - cost_aware: Balance cost and performance
    - round_robin: Distribute evenly
    """
    try:
        job_id = str(uuid.uuid4())[:8]
        
        # Select region based on routing policy
        selected_region = select_region_by_policy(
            request.tpus_required,
            request.routing_policy
        )
        
        if not selected_region:
            raise HTTPException(
                status_code=503,
                detail="No available capacity in any region"
            )
        
        # Calculate cost
        provider = REGIONS[selected_region]["provider"]
        cost_per_hour = PRICING[provider] * request.tpus_required
        estimated_duration_hours = 1.0  # Simulate 1 hour job
        estimated_cost = cost_per_hour * estimated_duration_hours if pricing_enabled else 0.0
        
        # Create job
        job = {
            "job_id": job_id,
            "name": request.name,
            "tpus_required": request.tpus_required,
            "priority": request.priority,
            "routing_policy": request.routing_policy,
            "assigned_region": selected_region,
            "assigned_provider": provider,
            "status": "running",
            "progress": 0.0,
            "estimated_cost": estimated_cost,
            "actual_cost": 0.0,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        
        # Allocate TPUs
        REGIONS[selected_region]["active"] += request.tpus_required
        
        # Add to running jobs
        hybrid_jobs["running"].append(job)
        
        # Start job simulation in background
        background_tasks.add_task(simulate_job_execution, job_id)
        
        # Broadcast update
        await hybrid_manager.broadcast({
            "type": "job_routed",
            "job": job,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        logger.info(f"Job routed: {job_id} to {selected_region} ({provider})")
        
        return {
            "success": True,
            "job_id": job_id,
            "assigned_region": selected_region,
            "assigned_provider": provider,
            "estimated_cost": estimated_cost,
            "message": f"Job routed to {selected_region}"
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error routing job: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@hybrid_router.post("/pricing")
async def toggle_pricing(request: PricingToggleRequest):
    """
    Toggle cost simulation on/off
    """
    try:
        global pricing_enabled
        pricing_enabled = request.enabled
        
        message = "Cost simulation enabled" if request.enabled else "Cost simulation disabled"
        
        logger.info(message)
        
        return {
            "success": True,
            "enabled": pricing_enabled,
            "message": message
        }
    except Exception as e:
        logger.error(f"Error toggling pricing: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# WebSocket Endpoint
@hybrid_router.websocket("/live")
async def websocket_hybrid_live(websocket: WebSocket):
    """
    WebSocket endpoint for live hybrid cloud metrics
    Streams real-time status, latency, and job updates
    """
    await hybrid_manager.connect(websocket)
    
    try:
        # Send initial status
        status = await get_hybrid_status()
        await websocket.send_json({
            "type": "hybrid_initial_status",
            "data": status,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        # Stream updates every 2 seconds
        while True:
            try:
                # Update simulation state
                update_hybrid_simulation()
                
                # Get current status
                status = await get_hybrid_status()
                latency_matrix = generate_latency_matrix()
                
                # Send update
                await websocket.send_json({
                    "type": "hybrid_live_update",
                    "data": {
                        "status": status,
                        "latency_matrix": latency_matrix
                    },
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })
                
                # Wait 2 seconds
                await asyncio.sleep(2)
                
            except WebSocketDisconnect:
                break
            except Exception as e:
                logger.error(f"Error in hybrid WebSocket loop: {e}")
                break
    
    except Exception as e:
        logger.error(f"Hybrid WebSocket error: {e}")
    finally:
        hybrid_manager.disconnect(websocket)

# Helper functions
def select_region_by_policy(tpus_required: int, policy: str) -> Optional[str]:
    """Select optimal region based on routing policy"""
    available_regions = [
        (region_id, region)
        for region_id, region in REGIONS.items()
        if region["tpus"] - region["active"] >= tpus_required
    ]
    
    if not available_regions:
        return None
    
    if policy == "latency_first":
        # Choose region with lowest latency
        return min(available_regions, key=lambda x: x[1]["latency"])[0]
    
    elif policy == "throughput_first":
        # Choose region with most available TPUs
        return max(available_regions, key=lambda x: x[1]["tpus"] - x[1]["active"])[0]
    
    elif policy == "cost_aware":
        # Prefer local, then GCP, then AWS
        priority = {"local": 3, "gcp": 2, "aws": 1}
        return max(available_regions, key=lambda x: (priority[x[1]["provider"]], -(x[1]["latency"])))[0]
    
    else:  # round_robin or default
        return random.choice(available_regions)[0]

async def simulate_job_execution(job_id: str):
    """Simulate job execution with progress updates"""
    try:
        job = next((j for j in hybrid_jobs["running"] if j["job_id"] == job_id), None)
        if not job:
            return
        
        # Simulate 30 seconds of execution
        steps = 15
        for step in range(steps):
            job["progress"] = (step + 1) / steps
            
            # Calculate cost
            if pricing_enabled:
                provider = job["assigned_provider"]
                cost_increment = (PRICING[provider] * job["tpus_required"] / 3600) * 2  # 2 seconds
                job["actual_cost"] += cost_increment
                
                global total_cost
                total_cost += cost_increment
            
            # Broadcast update
            await hybrid_manager.broadcast({
                "type": "job_progress",
                "job_id": job_id,
                "progress": job["progress"],
                "actual_cost": job["actual_cost"],
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            
            await asyncio.sleep(2)
        
        # Complete job
        job["status"] = "completed"
        job["progress"] = 1.0
        job["completed_at"] = datetime.now(timezone.utc).isoformat()
        
        # Release TPUs
        REGIONS[job["assigned_region"]]["active"] -= job["tpus_required"]
        
        # Move to completed
        hybrid_jobs["running"].remove(job)
        hybrid_jobs["completed"].append(job)
        
        logger.info(f"Job completed: {job_id}")
        
    except Exception as e:
        logger.error(f"Error simulating job execution: {e}")

def update_hybrid_simulation():
    """Update simulation state (add random fluctuations)"""
    # Add small random changes to latency
    for region in REGIONS.values():
        region["latency"] = max(5, region["latency"] + random.uniform(-2, 2))

def generate_latency_matrix() -> Dict[str, Dict[str, float]]:
    """Generate inter-region latency matrix"""
    matrix = {}
    region_ids = list(REGIONS.keys())
    
    for region1 in region_ids:
        matrix[region1] = {}
        for region2 in region_ids:
            if region1 == region2:
                matrix[region1][region2] = 0.0
            else:
                # Calculate simulated latency based on region proximity
                base_latency = (REGIONS[region1]["latency"] + REGIONS[region2]["latency"]) / 2
                matrix[region1][region2] = base_latency + random.uniform(-5, 10)
    
    return matrix
