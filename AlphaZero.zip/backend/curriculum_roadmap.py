"""
Curriculum Roadmap Orchestrator
Manages the complete PGN-integrated training roadmap for AlphaZero
Coordinates all phases from external data ingestion to superhuman performance
"""
import logging
import asyncio
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timezone

from pgn_ingest import PGNIngestor
from train_blended import BlendedTrainingPipeline
from network_scaler import NetworkScaler
from iq_tracker_enhanced import EnhancedIQTracker
from evolution_metrics import EvolutionMetricsTracker
from neural_network import AlphaZeroNetwork, ModelManager
from evaluator import ModelEvaluator
from self_play import SelfPlayManager
from curriculum_engine import CurriculumEngine
from reflection_engine import ReflectionEngine

logger = logging.getLogger(__name__)


class CurriculumRoadmapOrchestrator:
    """
    Orchestrates the complete PGN-integrated curriculum training roadmap
    
    Training Flow:
    1. Ingest PGN → Tag by Complexity → Blend with Self-Play → Retrain → Evaluate → Reflect → Repeat
    
    Three-Phase Curriculum:
    - Phase 1 (0-1000 games): 70% Human PGNs, 30% Self-Play
    - Phase 2 (1000-5000 games): 50% Human PGNs, 50% Self-Play
    - Phase 3 (5000+ games): 20% Human PGNs, 80% Self-Play
    
    Target: ELO 3500+ superhuman performance
    """
    
    def __init__(self):
        # Initialize components
        self.pgn_ingestor = PGNIngestor()
        self.network_scaler = NetworkScaler()
        self.iq_tracker = EnhancedIQTracker(target_elo=3500)
        self.evolution_tracker = EvolutionMetricsTracker()
        self.model_manager = ModelManager()
        self.curriculum_engine = CurriculumEngine()
        self.reflection_engine = ReflectionEngine()
        
        # Current state
        self.current_network = None
        self.blended_pipeline = None
        
        logger.info("Curriculum Roadmap Orchestrator initialized")
    
    async def ingest_external_pgns(
        self,
        pgn_content: str,
        source_type: str,
        filename: str
    ) -> Dict:
        """
        Step 1: Ingest external PGN files
        
        Args:
            pgn_content: PGN file content
            source_type: 'human' or 'engine'
            filename: Original filename
            
        Returns:
            Ingestion summary
        """
        logger.info(f"[ROADMAP] Step 1: Ingesting PGN file '{filename}' (source: {source_type})")
        
        result = self.pgn_ingestor.ingest_pgn_file(
            pgn_content=pgn_content,
            source_type=source_type,
            filename=filename
        )
        
        logger.info(f"[ROADMAP] Ingested {result['games_ingested']} games, "
                   f"{result['positions_extracted']} positions")
        
        return result
    
    def determine_curriculum_phase(self) -> Tuple[int, Dict]:
        """
        Step 2: Determine current curriculum phase
        
        Returns:
            Tuple of (phase_number, phase_info)
        """
        current_metrics = self.evolution_tracker.get_current_metrics()
        total_games = current_metrics['total_games_processed']
        
        if total_games < 1000:
            phase = 1
            description = "Phase 1: Foundation Building (70% Human / 30% Self-Play)"
            target_games = 1000
        elif total_games < 5000:
            phase = 2
            description = "Phase 2: Pattern Integration (50% Human / 50% Self-Play)"
            target_games = 5000
        else:
            phase = 3
            description = "Phase 3: Self-Evolution (20% Human / 80% Self-Play)"
            target_games = total_games + 5000
        
        phase_info = {
            'phase': phase,
            'description': description,
            'total_games': total_games,
            'target_games': target_games,
            'games_remaining': target_games - total_games if total_games < target_games else 0
        }
        
        logger.info(f"[ROADMAP] Step 2: Current phase: {phase} - {description}")
        
        return phase, phase_info
    
    async def prepare_blended_training_data(
        self,
        num_selfplay_games: int = 25,
        num_external_games: int = 50,
        curriculum_phase: int = 1
    ) -> Tuple[List[Dict], List[Dict]]:
        """
        Step 3: Prepare blended training data
        
        Args:
            num_selfplay_games: Number of self-play games to generate
            num_external_games: Number of external PGN games to use
            curriculum_phase: Current curriculum phase
            
        Returns:
            Tuple of (external_positions, selfplay_positions)
        """
        logger.info(f"[ROADMAP] Step 3: Preparing blended training data (phase {curriculum_phase})")
        
        # Load current network
        if not self.current_network:
            active_model = self.model_manager.get_active_model_name()
            if active_model:
                self.current_network, _ = self.model_manager.load_model(active_model)
            else:
                self.current_network = AlphaZeroNetwork()
        
        # Initialize blended pipeline
        if not self.blended_pipeline:
            self.blended_pipeline = BlendedTrainingPipeline(self.current_network)
        
        # Get external PGN data
        logger.info("[ROADMAP] Loading external PGN data...")
        external_data = self.blended_pipeline.prepare_external_pgn_data(
            source_filter=None,  # Use all sources
            complexity_filter=None,  # Use all complexity levels
            max_games=num_external_games
        )
        
        # Generate self-play data
        logger.info(f"[ROADMAP] Generating {num_selfplay_games} self-play games...")
        selfplay_manager = SelfPlayManager(self.current_network, num_simulations=800)
        selfplay_data = []
        
        for i in range(num_selfplay_games):
            game_data, game_result = selfplay_manager.generate_single_game(store_fen=True)
            selfplay_data.extend(game_data)
            
            if (i + 1) % 5 == 0:
                logger.info(f"[ROADMAP] Self-play progress: {i+1}/{num_selfplay_games} games")
        
        logger.info(f"[ROADMAP] Data prepared: {len(external_data)} external positions, "
                   f"{len(selfplay_data)} self-play positions")
        
        return external_data, selfplay_data
    
    async def train_blended_model(
        self,
        external_data: List[Dict],
        selfplay_data: List[Dict],
        curriculum_phase: int,
        num_epochs: int = 5
    ) -> Dict:
        """
        Step 4: Train model on blended data
        
        Args:
            external_data: External PGN positions
            selfplay_data: Self-play positions
            curriculum_phase: Current phase
            num_epochs: Training epochs
            
        Returns:
            Training summary
        """
        logger.info(f"[ROADMAP] Step 4: Training on blended data (phase {curriculum_phase})")
        
        training_result = self.blended_pipeline.train_blended(
            external_data=external_data,
            selfplay_data=selfplay_data,
            num_epochs=num_epochs,
            batch_size=64,
            curriculum_phase=curriculum_phase,
            save_checkpoint=True
        )
        
        logger.info(f"[ROADMAP] Training complete - Loss: {training_result['avg_loss']:.4f}")
        
        return training_result
    
    async def evaluate_model(self) -> Dict:
        """
        Step 5: Evaluate model performance
        
        Returns:
            Evaluation results with ELO and consistency
        """
        logger.info("[ROADMAP] Step 5: Evaluating model...")
        
        # Get current and previous models
        models = self.model_manager.list_models()
        if len(models) < 2:
            logger.warning("[ROADMAP] Need at least 2 models for evaluation")
            return {'error': 'Not enough models for evaluation'}
        
        current_model_name = models[-1]
        previous_model_name = models[-2]
        
        # Load models
        current_model, _ = self.model_manager.load_model(current_model_name)
        previous_model, _ = self.model_manager.load_model(previous_model_name)
        
        # Run evaluation
        evaluator = ModelEvaluator(
            num_evaluation_games=10,
            num_simulations=400
        )
        
        eval_results, should_promote = evaluator.evaluate_models(
            current_model,
            previous_model,
            current_model_name,
            previous_model_name
        )
        
        # Calculate ELO (simplified)
        current_elo = self.iq_tracker.get_current_status()['current_elo']
        win_rate = eval_results.get('challenger_win_rate', 0.5)
        
        # ELO update (simplified K-factor)
        K = 32
        expected_score = 1.0 / (1.0 + 10 ** ((current_elo - current_elo) / 400))
        elo_delta = K * (win_rate - expected_score)
        new_elo = current_elo + elo_delta
        
        logger.info(f"[ROADMAP] Evaluation complete: Win rate {win_rate:.1%}, "
                   f"ELO {new_elo:.1f} (Δ{elo_delta:+.1f})")
        
        return {
            **eval_results,
            'new_elo': new_elo,
            'elo_delta': elo_delta,
            'should_promote': should_promote
        }
    
    async def reflect_on_performance(self, evaluation_results: Dict) -> Dict:
        """
        Step 6: Reflect on performance and generate insights
        
        Args:
            evaluation_results: Results from evaluation
            
        Returns:
            Reflection insights
        """
        logger.info("[ROADMAP] Step 6: Generating reflection...")
        
        session_data = {
            'session_id': 'roadmap_cycle',
            'games_played': evaluation_results.get('games_played', 10),
            'win_rate': evaluation_results.get('challenger_win_rate', 0.5),
            'draw_rate': evaluation_results.get('draws', 0) / max(1, evaluation_results.get('games_played', 10)),
            'loss_rate': 1.0 - evaluation_results.get('challenger_win_rate', 0.5),
            'average_moves': 40,  # Placeholder
            'total_positions': 0,
            'game_results': []
        }
        
        reflection = await self.reflection_engine.reflect_on_session(session_data)
        
        logger.info(f"[ROADMAP] Reflection: {reflection.get('weakness_detected', 'N/A')}")
        
        return reflection
    
    async def check_scaling_trigger(self) -> Optional[Dict]:
        """
        Step 7: Check if network should be scaled
        
        Returns:
            Scaling info if triggered, None otherwise
        """
        logger.info("[ROADMAP] Step 7: Checking scaling triggers...")
        
        current_metrics = self.evolution_tracker.get_current_metrics()
        total_games = current_metrics['total_games_processed']
        current_elo = current_metrics['current_elo']
        
        if self.network_scaler.should_scale(total_games, current_elo):
            logger.info("[ROADMAP] Scaling triggered!")
            
            # Scale network
            scaled_network, scaling_info = self.network_scaler.scale_network(
                self.current_network,
                scale_factor=1.5
            )
            
            # Scale MCTS simulations
            new_mcts_sims = self.network_scaler.scale_mcts_simulations(800, scale_factor=1.5)
            
            # Update config
            self.network_scaler.update_config_scaling(
                new_filters=scaling_info['new_filters'],
                new_blocks=scaling_info['new_blocks'],
                new_mcts_sims=new_mcts_sims
            )
            
            # Update current network
            self.current_network = scaled_network
            
            # Record in evolution tracker
            self.evolution_tracker.record_network_scaling(scaling_info)
            
            logger.info(f"[ROADMAP] Network scaled: {scaling_info['new_filters']} filters, "
                       f"{scaling_info['new_blocks']} blocks, {new_mcts_sims} MCTS sims")
            
            return scaling_info
        
        logger.info("[ROADMAP] No scaling triggered")
        return None
    
    async def run_complete_cycle(
        self,
        num_selfplay_games: int = 25,
        num_external_games: int = 50,
        num_epochs: int = 5
    ) -> Dict:
        """
        Run a complete training cycle through the roadmap
        
        Returns:
            Cycle summary
        """
        logger.info("=" * 80)
        logger.info("[ROADMAP] Starting complete training cycle")
        logger.info("=" * 80)
        
        cycle_start = datetime.now(timezone.utc)
        
        # Step 2: Determine phase
        current_phase, phase_info = self.determine_curriculum_phase()
        
        # Step 3: Prepare data
        external_data, selfplay_data = await self.prepare_blended_training_data(
            num_selfplay_games=num_selfplay_games,
            num_external_games=num_external_games,
            curriculum_phase=current_phase
        )
        
        # Step 4: Train
        training_result = await self.train_blended_model(
            external_data=external_data,
            selfplay_data=selfplay_data,
            curriculum_phase=current_phase,
            num_epochs=num_epochs
        )
        
        # Step 5: Evaluate
        eval_results = await self.evaluate_model()
        
        # Step 6: Reflect
        reflection = await self.reflect_on_performance(eval_results)
        
        # Step 7: Check scaling
        scaling_info = await self.check_scaling_trigger()
        
        # Record cycle in evolution tracker
        self.evolution_tracker.record_training_cycle({
            'curriculum_phase': current_phase,
            'external_games_used': len(external_data),
            'selfplay_games_used': num_selfplay_games,
            'blended_positions': training_result['total_positions'],
            'epochs': num_epochs,
            'avg_loss': training_result['avg_loss'],
            'elo_before': self.iq_tracker.get_current_status()['current_elo'],
            'elo_after': eval_results.get('new_elo', 0),
            'consistency_score': 0.8,  # Placeholder - should calculate from eval
            'reflection': reflection.get('weakness_detected'),
            'scaled': scaling_info is not None
        })
        
        # Update IQ tracker
        self.iq_tracker.record_evaluation(
            model_id='latest',
            current_elo=eval_results.get('new_elo', 1500),
            opponent_elo=self.iq_tracker.get_current_status()['current_elo'],
            win_rate=eval_results.get('challenger_win_rate', 0.5),
            games_played=eval_results.get('games_played', 10),
            position_evaluations=None,  # Would come from actual evaluation
            metadata={'phase': current_phase}
        )
        
        cycle_end = datetime.now(timezone.utc)
        duration = (cycle_end - cycle_start).total_seconds()
        
        summary = {
            'success': True,
            'phase': current_phase,
            'duration_seconds': duration,
            'training_loss': training_result['avg_loss'],
            'new_elo': eval_results.get('new_elo'),
            'elo_delta': eval_results.get('elo_delta'),
            'reflection': reflection.get('weakness_detected'),
            'scaled': scaling_info is not None,
            'progress_to_target': self.iq_tracker.get_current_status()['progress_percent']
        }
        
        logger.info("=" * 80)
        logger.info(f"[ROADMAP] Cycle complete in {duration:.1f}s")
        logger.info(f"[ROADMAP] ELO: {eval_results.get('new_elo', 0):.1f} "
                   f"(Δ{eval_results.get('elo_delta', 0):+.1f})")
        logger.info(f"[ROADMAP] Progress to target: {summary['progress_to_target']:.1f}%")
        logger.info("=" * 80)
        
        return summary
    
    def get_roadmap_status(self) -> Dict:
        """Get comprehensive roadmap status"""
        return self.evolution_tracker.get_roadmap_status()


# Global orchestrator instance
roadmap_orchestrator = CurriculumRoadmapOrchestrator()
