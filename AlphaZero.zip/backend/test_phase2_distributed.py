#!/usr/bin/env python3
"""
Phase 2 Distributed Optimization - Comprehensive Test Suite
===========================================================

Tests:
1. Sequential vs Distributed mode switching
2. Worker health monitoring and recovery
3. Replay buffer integrity with concurrent access
4. Performance metrics and throughput
5. Fault tolerance (simulated worker failures)
"""

import sys
import logging
import time
import numpy as np
from pathlib import Path

# Add backend to path
backend_dir = Path(__file__).parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


def test_sequential_mode():
    """Test sequential self-play mode"""
    logger.info("\n" + "="*80)
    logger.info("TEST 1: SEQUENTIAL MODE")
    logger.info("="*80)
    
    try:
        from selfplay_trainer import AlphaZeroSelfPlayTrainer, SelfPlayMode
        
        # Create trainer in sequential mode
        trainer = AlphaZeroSelfPlayTrainer(
            max_games=10,
            max_hours=1.0,
            num_simulations=50,
            mode=SelfPlayMode.SEQUENTIAL
        )
        
        assert trainer.mode == SelfPlayMode.SEQUENTIAL, "Mode should be SEQUENTIAL"
        logger.info("✅ Sequential mode initialized")
        
        # Generate small batch
        training_data, batch_time = trainer.generate_selfplay_batch(num_games=2)
        
        assert len(training_data) > 0, "Should generate training data"
        assert batch_time > 0, "Should have positive batch time"
        
        logger.info(f"✅ Generated {len(training_data)} positions in {batch_time:.1f}s")
        logger.info(f"   Rate: {len(training_data)/batch_time:.1f} positions/s")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Sequential mode test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_distributed_mode():
    """Test distributed self-play mode"""
    logger.info("\n" + "="*80)
    logger.info("TEST 2: DISTRIBUTED MODE")
    logger.info("="*80)
    
    try:
        from selfplay_trainer import AlphaZeroSelfPlayTrainer, SelfPlayMode
        
        # Create trainer in distributed mode with 2 workers
        trainer = AlphaZeroSelfPlayTrainer(
            max_games=10,
            max_hours=1.0,
            num_simulations=50,
            mode=SelfPlayMode.DISTRIBUTED,
            num_workers=2
        )
        
        assert trainer.mode == SelfPlayMode.DISTRIBUTED, "Mode should be DISTRIBUTED"
        assert trainer.num_workers == 2, "Should have 2 workers"
        logger.info("✅ Distributed mode initialized with 2 workers")
        
        # Generate small batch
        training_data, batch_time = trainer.generate_selfplay_batch(num_games=4)
        
        assert len(training_data) > 0, "Should generate training data"
        assert batch_time > 0, "Should have positive batch time"
        
        logger.info(f"✅ Generated {len(training_data)} positions in {batch_time:.1f}s")
        logger.info(f"   Rate: {len(training_data)/batch_time:.1f} positions/s")
        logger.info(f"   Workers: 2")
        
        # Check distributed stats
        stats = trainer.selfplay_manager.get_stats()
        logger.info(f"   Worker stats: {len(stats['worker_stats'])} workers reported")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Distributed mode test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_replay_buffer_integrity():
    """Test replay buffer integrity with distributed generation"""
    logger.info("\n" + "="*80)
    logger.info("TEST 3: REPLAY BUFFER INTEGRITY")
    logger.info("="*80)
    
    try:
        from selfplay_trainer import AlphaZeroSelfPlayTrainer, SelfPlayMode
        from replay_buffer_service import get_replay_buffer_service
        
        # Create trainer
        trainer = AlphaZeroSelfPlayTrainer(
            max_games=10,
            max_hours=1.0,
            num_simulations=50,
            mode=SelfPlayMode.DISTRIBUTED,
            num_workers=2,
            replay_buffer_size=10000
        )
        
        # Generate games
        training_data, _ = trainer.generate_selfplay_batch(num_games=3)
        
        # Add to replay buffer
        trainer.replay_buffer.add(training_data)
        
        buffer_size = trainer.replay_buffer.size()
        assert buffer_size == len(training_data), f"Buffer size mismatch: {buffer_size} vs {len(training_data)}"
        logger.info(f"✅ Replay buffer: {buffer_size} positions added correctly")
        
        # Test sampling
        sample_batch = trainer.replay_buffer.sample(min(50, buffer_size))
        assert len(sample_batch) > 0, "Should be able to sample from buffer"
        logger.info(f"✅ Sampled {len(sample_batch)} positions from buffer")
        
        # Validate sample structure
        if len(sample_batch) > 0:
            sample = sample_batch[0]
            assert 'position' in sample or 'state' in sample, "Sample should have position"
            assert 'policy' in sample, "Sample should have policy"
            assert 'value' in sample, "Sample should have value"
            logger.info(f"✅ Sample structure validated")
        
        # Test advanced replay buffer service
        replay_service = get_replay_buffer_service()
        replay_service.add_replay_tuples(training_data, game_id="test_game_1")
        
        service_stats = replay_service.get_buffer_stats()
        logger.info(f"✅ Advanced replay buffer service:")
        logger.info(f"   Total size: {service_stats['total_size']}")
        logger.info(f"   Validation failures: {service_stats['validation_failures']}")
        logger.info(f"   Validation warnings: {service_stats['validation_warnings']}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Replay buffer integrity test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_performance_comparison():
    """Test and compare sequential vs distributed performance"""
    logger.info("\n" + "="*80)
    logger.info("TEST 4: PERFORMANCE COMPARISON")
    logger.info("="*80)
    
    try:
        from selfplay_trainer import AlphaZeroSelfPlayTrainer, SelfPlayMode
        
        num_games = 3
        
        # Sequential mode
        logger.info("\n--- Testing Sequential Mode ---")
        trainer_seq = AlphaZeroSelfPlayTrainer(
            max_games=10,
            max_hours=1.0,
            num_simulations=50,
            mode=SelfPlayMode.SEQUENTIAL
        )
        
        data_seq, time_seq = trainer_seq.generate_selfplay_batch(num_games)
        rate_seq = len(data_seq) / time_seq if time_seq > 0 else 0
        
        logger.info(f"Sequential: {len(data_seq)} positions in {time_seq:.1f}s ({rate_seq:.1f} pos/s)")
        
        # Distributed mode
        logger.info("\n--- Testing Distributed Mode (2 workers) ---")
        trainer_dist = AlphaZeroSelfPlayTrainer(
            max_games=10,
            max_hours=1.0,
            num_simulations=50,
            mode=SelfPlayMode.DISTRIBUTED,
            num_workers=2
        )
        
        data_dist, time_dist = trainer_dist.generate_selfplay_batch(num_games)
        rate_dist = len(data_dist) / time_dist if time_dist > 0 else 0
        
        logger.info(f"Distributed: {len(data_dist)} positions in {time_dist:.1f}s ({rate_dist:.1f} pos/s)")
        
        # Calculate speedup
        if time_seq > 0 and time_dist > 0:
            speedup = time_seq / time_dist
            logger.info(f"\n✅ Speedup: {speedup:.2f}x")
            
            if speedup > 1.2:
                logger.info("   🚀 Distributed mode is faster!")
            elif speedup < 0.8:
                logger.warning("   ⚠️ Distributed mode is slower (overhead)")
            else:
                logger.info("   ⚖️ Similar performance (overhead ~= parallelism gain)")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Performance comparison test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_worker_monitoring():
    """Test worker health monitoring features"""
    logger.info("\n" + "="*80)
    logger.info("TEST 5: WORKER HEALTH MONITORING")
    logger.info("="*80)
    
    try:
        from selfplay_trainer import AlphaZeroSelfPlayTrainer, SelfPlayMode
        
        # Create trainer with monitoring enabled
        trainer = AlphaZeroSelfPlayTrainer(
            max_games=10,
            max_hours=1.0,
            num_simulations=50,
            mode=SelfPlayMode.DISTRIBUTED,
            num_workers=2,
            enable_fault_tolerance=True
        )
        
        logger.info("✅ Trainer initialized with fault tolerance")
        
        # Generate batch
        training_data, batch_time = trainer.generate_selfplay_batch(num_games=4)
        
        # Check distributed stats
        stats = trainer.selfplay_manager.get_stats()
        
        logger.info(f"✅ Worker statistics:")
        logger.info(f"   Workers: {stats['num_workers']}")
        logger.info(f"   Total games: {stats['total_games']}")
        logger.info(f"   Total positions: {stats['total_positions']}")
        logger.info(f"   Worker failures: {stats['fault_tolerance']['worker_failures']}")
        logger.info(f"   Worker recoveries: {stats['fault_tolerance']['worker_recoveries']}")
        
        # Check features
        features = stats.get('features', {})
        assert features.get('heartbeat_monitoring') is True, "Heartbeat should be enabled"
        assert features.get('auto_recovery') is True, "Auto recovery should be enabled"
        logger.info(f"✅ Fault tolerance features enabled")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Worker monitoring test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_auto_mode():
    """Test automatic mode selection"""
    logger.info("\n" + "="*80)
    logger.info("TEST 6: AUTO MODE SELECTION")
    logger.info("="*80)
    
    try:
        from selfplay_trainer import AlphaZeroSelfPlayTrainer, SelfPlayMode
        import multiprocessing as mp
        
        # Create trainer with auto mode
        trainer = AlphaZeroSelfPlayTrainer(
            max_games=10,
            max_hours=1.0,
            num_simulations=50,
            mode=SelfPlayMode.AUTO
        )
        
        cpu_count = mp.cpu_count()
        logger.info(f"System CPUs: {cpu_count}")
        logger.info(f"Selected mode: {trainer.mode.value}")
        
        if cpu_count >= 4:
            assert trainer.mode == SelfPlayMode.DISTRIBUTED, "Should select DISTRIBUTED for >= 4 CPUs"
            logger.info(f"✅ Auto selected DISTRIBUTED mode with {trainer.num_workers} workers")
        else:
            logger.info(f"✅ Auto selected {trainer.mode.value} mode")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Auto mode test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def run_all_tests():
    """Run all Phase 2 tests"""
    logger.info("\n" + "="*80)
    logger.info("PHASE 2: DISTRIBUTED OPTIMIZATION - TEST SUITE")
    logger.info("="*80)
    
    tests = [
        ("Sequential Mode", test_sequential_mode),
        ("Distributed Mode", test_distributed_mode),
        ("Replay Buffer Integrity", test_replay_buffer_integrity),
        ("Performance Comparison", test_performance_comparison),
        ("Worker Monitoring", test_worker_monitoring),
        ("Auto Mode Selection", test_auto_mode),
    ]
    
    results = {}
    
    for test_name, test_func in tests:
        try:
            logger.info(f"\nRunning: {test_name}")
            result = test_func()
            results[test_name] = result
            
            if result:
                logger.info(f"✅ {test_name}: PASSED")
            else:
                logger.error(f"❌ {test_name}: FAILED")
        except Exception as e:
            logger.error(f"❌ {test_name}: CRASHED - {e}")
            results[test_name] = False
    
    # Summary
    logger.info("\n" + "="*80)
    logger.info("TEST SUMMARY")
    logger.info("="*80)
    
    passed = sum(1 for r in results.values() if r)
    total = len(results)
    
    for test_name, result in results.items():
        status = "✅ PASSED" if result else "❌ FAILED"
        logger.info(f"{test_name}: {status}")
    
    logger.info("="*80)
    logger.info(f"TOTAL: {passed}/{total} tests passed")
    logger.info("="*80)
    
    return passed == total


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
