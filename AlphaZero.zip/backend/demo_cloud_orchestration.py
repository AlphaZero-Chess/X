#!/usr/bin/env python3
"""
Cloud Orchestration Demo Script

Demonstrates:
1. Boot 1K-TPU simulated cluster across 4 regions
2. Schedule 3 jobs (self-play HIGH, training MEDIUM, eval LOW)
3. Inject faults (node crash + latency spike)
4. Stream metrics via WebSocket simulation

Usage:
    python demo_cloud_orchestration.py
"""

import sys
import time
import logging
from pathlib import Path

# Add backend to path
backend_dir = Path(__file__).parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

from cloud_cluster_controller import (
    get_cloud_controller,
    reset_cloud_controller,
    Region,
    ScalingPolicy
)
from cloud_job_scheduler import (
    get_job_scheduler,
    reset_job_scheduler,
    JobType,
    JobPriority
)
from cloud_monitoring_service import (
    get_monitoring_service,
    reset_monitoring_service
)
from tpu_cluster_manager import get_tpu_grid, reset_tpu_grid

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def print_section(title: str):
    """Print section header"""
    print("\n" + "="*80)
    print(f"  {title}")
    print("="*80 + "\n")


def print_status(status: dict):
    """Print formatted status"""
    cluster = status['cluster']
    health = status['health']
    regions = status['regions']
    
    print(f"  Cluster: {cluster['total_nodes']:,} nodes, {cluster['total_tpus']:,} TPUs")
    print(f"  Health: {health.get('healthy', 0)} healthy, "
          f"{health.get('degraded', 0)} degraded, "
          f"{health.get('unhealthy', 0)} unhealthy")
    print(f"\n  Regions:")
    for region_name, region_data in regions.items():
        print(f"    {region_name}: {region_data['active_nodes']} nodes, "
              f"{region_data['total_tpus']} TPUs, "
              f"latency {region_data['avg_latency_ms']:.1f}ms")


def print_job(job: dict):
    """Print formatted job info"""
    print(f"    {job['job_id']}: {job['job_type']} "
          f"(priority={job['priority']}, status={job['status']}, "
          f"TPUs={job['resource_request']['num_tpus']})")


def print_metrics(metrics: dict):
    """Print formatted metrics"""
    cluster = metrics['cluster']
    jobs = metrics['jobs']
    
    print(f"  Cluster: {cluster['total_nodes']} nodes, "
          f"{cluster['healthy_nodes']} healthy, "
          f"health rate {cluster['health_rate_percent']:.1f}%")
    
    print(f"  Jobs: {jobs['active']} active, {jobs['queued']} queued, "
          f"{jobs['total_completed']} completed, "
          f"success rate {jobs['success_rate_percent']:.1f}%")
    
    print(f"  Regions:")
    for region_name, region_data in metrics['regions'].items():
        print(f"    {region_name}: {region_data['tpus']} TPUs, "
              f"latency {region_data['avg_latency_ms']:.1f}ms")


def main():
    """
    Main demo flow
    """
    print("\n" + "*"*80)
    print("  CLOUD ORCHESTRATION DEMO")
    print("  Virtual Cloud Control Layer for AlphaZero Training")
    print("*"*80)
    
    try:
        # ====================
        # Step 1: Initialize 1K-TPU Cluster
        # ====================
        print_section("STEP 1: Initialize 1K-TPU Cluster Across 4 Regions")
        
        # Reset previous instances
        reset_cloud_controller()
        reset_job_scheduler()
        reset_monitoring_service()
        reset_tpu_grid()
        
        # Create TPU grid (underlying infrastructure)
        tpu_grid = get_tpu_grid(num_tpus=1000)
        
        # Create cloud controller
        controller = get_cloud_controller(
            tpu_grid_manager=tpu_grid,
            initial_size=1000,
            scaling_policy=ScalingPolicy.AUTO_DEMAND
        )
        
        # Create job scheduler
        scheduler = get_job_scheduler(controller)
        
        # Create monitoring service
        monitoring = get_monitoring_service(controller, scheduler)
        
        # Get initial status
        status = controller.get_cluster_status()
        print_status(status)
        
        time.sleep(2)
        
        # ====================
        # Step 2: Submit Jobs
        # ====================
        print_section("STEP 2: Submit 3 Jobs (Different Priorities)")
        
        # Job 1: Self-play (HIGH priority)
        job1_id = scheduler.submit_job(
            job_type=JobType.SELFPLAY,
            priority=JobPriority.HIGH,
            num_tpus=100,
            job_name="AlphaZero Self-Play",
            preferred_regions=["us-east"],
            estimated_duration_sec=600
        )
        print(f"  ✅ Submitted HIGH priority job: {job1_id}")
        
        # Job 2: Training (MEDIUM priority)
        job2_id = scheduler.submit_job(
            job_type=JobType.TRAINING,
            priority=JobPriority.MEDIUM,
            num_tpus=200,
            job_name="Model Training",
            preferred_regions=["us-west"],
            estimated_duration_sec=1200
        )
        print(f"  ✅ Submitted MEDIUM priority job: {job2_id}")
        
        # Job 3: Evaluation (LOW priority)
        job3_id = scheduler.submit_job(
            job_type=JobType.EVALUATION,
            priority=JobPriority.LOW,
            num_tpus=50,
            job_name="Model Evaluation",
            preferred_regions=["eu-west"],
            estimated_duration_sec=300
        )
        print(f"  ✅ Submitted LOW priority job: {job3_id}")
        
        # Wait for scheduling
        print("\n  Waiting for scheduler to allocate resources...")
        time.sleep(5)
        
        # Check job statuses
        print("\n  Job Status:")
        for job_id in [job1_id, job2_id, job3_id]:
            job = scheduler.get_job_status(job_id)
            if job:
                print_job(job)
        
        # Queue stats
        queue_stats = scheduler.get_queue_stats()
        print(f"\n  Queue Stats: {queue_stats['active_jobs']} active, "
              f"{queue_stats['queue_length']} queued")
        
        time.sleep(2)
        
        # ====================
        # Step 3: Fault Injection
        # ====================
        print_section("STEP 3: Fault Injection")
        
        # Inject node crash in us-east
        print("  Injecting node crash in us-east...")
        crash_result = controller.inject_fault(
            fault_type='crash',
            region=Region.US_EAST
        )
        if crash_result['success']:
            print(f"    ✅ Crashed node: {crash_result['node_id']} "
                  f"in {crash_result['region']}")
        
        time.sleep(1)
        
        # Inject latency spike in eu-west
        print("\n  Injecting latency spike in eu-west...")
        latency_result = controller.inject_fault(
            fault_type='latency_spike',
            region=Region.EU_WEST
        )
        if latency_result['success']:
            print(f"    ✅ Latency spike on node: {latency_result['node_id']} "
                  f"in {latency_result['region']}")
        
        time.sleep(2)
        
        # Check health status
        status = controller.get_cluster_status()
        print("\n  Updated Cluster Health:")
        health = status['health']
        print(f"    Healthy: {health.get('healthy', 0)}")
        print(f"    Degraded: {health.get('degraded', 0)}")
        print(f"    Unhealthy: {health.get('unhealthy', 0)}")
        
        time.sleep(2)
        
        # ====================
        # Step 4: Stream Metrics
        # ====================
        print_section("STEP 4: Stream Metrics (Simulated WebSocket)")
        
        print("  Streaming metrics for 10 seconds (2s interval)...\n")
        
        for i in range(5):
            metrics = monitoring.get_metrics_json()
            print(f"  [{i+1}/5] Metrics Update @ {metrics['timestamp']}")
            print_metrics(metrics)
            print()
            
            if i < 4:
                time.sleep(2)
        
        # ====================
        # Step 5: Demonstrate Scaling
        # ====================
        print_section("STEP 5: Demonstrate Auto-Scaling")
        
        print("  Scaling cluster: 1,000 → 2,000 TPUs...")
        scale_success = controller.scale_cluster(2000)
        
        if scale_success:
            status = controller.get_cluster_status()
            print(f"\n  ✅ Scaling complete:")
            print(f"    Nodes: {status['cluster']['total_nodes']:,}")
            print(f"    TPUs: {status['cluster']['total_tpus']:,}")
        
        time.sleep(2)
        
        # ====================
        # Step 6: Summary
        # ====================
        print_section("DEMO SUMMARY")
        
        # Final status
        status = controller.get_cluster_status()
        queue_stats = scheduler.get_queue_stats()
        
        print(f"  Cluster:")
        print(f"    Total Nodes: {status['cluster']['total_nodes']:,}")
        print(f"    Total TPUs: {status['cluster']['total_tpus']:,}")
        print(f"    Healthy Nodes: {status['health'].get('healthy', 0)}")
        print(f"    Nodes Created: {status['lifecycle']['total_created']:,}")
        print(f"    Faults Injected: {status['lifecycle']['total_faults_injected']}")
        
        print(f"\n  Jobs:")
        print(f"    Total Submitted: {queue_stats['total_submitted']}")
        print(f"    Active: {queue_stats['active_jobs']}")
        print(f"    Completed: {queue_stats['total_completed']}")
        print(f"    Failed: {queue_stats['total_failed']}")
        
        print(f"\n  Regions:")
        for region_name, region_data in status['regions'].items():
            print(f"    {region_name}: {region_data['active_nodes']} nodes, "
                  f"{region_data['healthy_nodes']}/{region_data['degraded_nodes']}/"
                  f"{region_data['unhealthy_nodes']} (H/D/U)")
        
        print("\n" + "="*80)
        print("  DEMO COMPLETE")
        print("="*80 + "\n")
        
        # Cleanup
        controller.stop_health_monitoring()
        scheduler.stop_scheduler()
        monitoring.stop()
        
        print("  ✅ Services stopped cleanly")
        
    except KeyboardInterrupt:
        print("\n\nDemo interrupted by user")
    except Exception as e:
        print(f"\n\n❌ Demo error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
