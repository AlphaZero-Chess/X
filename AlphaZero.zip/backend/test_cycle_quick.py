#!/usr/bin/env python3
"""
Quick Test for AlphaZero Pipeline
Reduced MCTS simulations for faster validation (50 sims instead of 800)
Use this for rapid testing and development
"""
import sys
from pathlib import Path

# Add backend to path
backend_dir = Path(__file__).parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

# Import main test cycle
from test_cycle import TestCycleRunner
import argparse


class QuickTestCycleRunner(TestCycleRunner):
    """Quick test with reduced simulations"""
    
    def phase_1_selfplay(self):
        """Phase 1 with reduced simulations (50 instead of 800)"""
        self.print_banner("PHASE 1: SELF-PLAY GENERATION (QUICK MODE)", "=")
        
        import time
        from self_play import SelfPlayManager
        from parallel_selfplay import ParallelSelfPlayManager
        
        phase_start = time.time()
        
        # Load base model
        model = self.load_or_create_base_model()
        
        # Create self-play manager with REDUCED simulations
        if self.enable_parallel:
            self.logger.info(f"Using parallel self-play with {self.num_threads} threads (50 sims)")
            manager = ParallelSelfPlayManager(
                model,
                num_threads=self.num_threads,
                num_simulations=50  # REDUCED for quick test
            )
            all_training_data, game_results = manager.generate_games_parallel(
                self.num_games,
                temperature_threshold=15
            )
        else:
            self.logger.info("Using sequential self-play (50 sims)")
            manager = SelfPlayManager(model, num_simulations=50)  # REDUCED
            all_training_data, game_results = manager.generate_games(
                self.num_games,
                store_fen=True
            )
        
        # Save PGNs
        self.logger.info(f"Saving {len(game_results)} games as PGN files...")
        for i, game_result in enumerate(game_results):
            result = game_result.get('result', '1/2-1/2')
            self.save_pgn(all_training_data, result, i + 1)
        
        phase_time = time.time() - phase_start
        
        # Calculate statistics
        white_wins = sum(1 for g in game_results if g.get('result') == '1-0')
        black_wins = sum(1 for g in game_results if g.get('result') == '0-1')
        draws = sum(1 for g in game_results if g.get('result') == '1/2-1/2')
        
        phase_results = {
            'games_generated': len(game_results),
            'positions_generated': len(all_training_data),
            'white_wins': white_wins,
            'black_wins': black_wins,
            'draws': draws,
            'time_seconds': phase_time,
            'games_per_minute': (len(game_results) / phase_time) * 60 if phase_time > 0 else 0,
            'pgn_directory': str(self.pgn_dir),
            'parallel_mode': self.enable_parallel,
            'threads': self.num_threads,
            'mcts_simulations': 50
        }
        
        self.results['phases']['selfplay'] = phase_results
        
        self.logger.info("")
        self.logger.info(f"✓ Generated {len(game_results)} games")
        self.logger.info(f"  Total positions: {len(all_training_data)}")
        self.logger.info(f"  Results: W={white_wins}, B={black_wins}, D={draws}")
        self.logger.info(f"  Time: {phase_time:.2f}s ({phase_results['games_per_minute']:.1f} games/min)")
        self.logger.info(f"  PGNs saved to: {self.pgn_dir}")
        
        return all_training_data, model
    
    def phase_3_evaluation(self, new_model, base_model_name):
        """Phase 3 with reduced simulations (50 instead of 400)"""
        self.print_banner("PHASE 3: MODEL EVALUATION (QUICK MODE)", "=")
        
        import time
        from evaluator import ModelEvaluator
        
        phase_start = time.time()
        
        # Check if base model exists for comparison
        old_model, old_metadata = self.model_manager.load_model(base_model_name)
        
        if old_model is None:
            self.logger.info("⚠ First run detected - no previous model to compare against")
            self.logger.info("  Skipping evaluation phase")
            self.logger.info("  Run test_cycle_quick.py again to compare future improvements")
            
            phase_results = {
                'skipped': True,
                'reason': 'No previous model for comparison (first run)',
                'note': 'Run test_cycle_quick.py again to evaluate improvements'
            }
            
            self.results['phases']['evaluation'] = phase_results
            return None
        
        # Load the newly saved model
        new_model_loaded, new_metadata = self.model_manager.load_model(self.new_model_name)
        
        if new_model_loaded is None:
            self.logger.error("Failed to load newly trained model for evaluation")
            return None
        
        self.logger.info(f"Evaluating: {self.new_model_name} vs {base_model_name}")
        self.logger.info(f"Playing 10 evaluation games (5 as White, 5 as Black) with 50 sims")
        
        # Create evaluator with REDUCED games and simulations
        evaluator = ModelEvaluator(
            num_evaluation_games=10,  # REDUCED from 20
            num_simulations=50,        # REDUCED from 400
            win_threshold=0.55,
            elo_threshold=50.0
        )
        
        # Run evaluation
        eval_results, should_promote = evaluator.evaluate_models(
            challenger_model=new_model_loaded,
            champion_model=old_model,
            challenger_name=self.new_model_name,
            champion_name=base_model_name,
            challenger_elo=1500.0,
            champion_elo=1500.0
        )
        
        phase_time = time.time() - phase_start
        eval_results['time_seconds'] = phase_time
        eval_results['mcts_simulations'] = 50
        
        self.results['phases']['evaluation'] = eval_results
        
        # Calculate average evaluation (score)
        avg_eval = eval_results.get('actual_score', 0.5)
        
        self.logger.info("")
        self.logger.info(f"✓ Evaluation complete")
        self.logger.info(f"  Games played: {eval_results.get('games_played', 0)}")
        self.logger.info(f"  Win rate: {eval_results.get('challenger_win_rate', 0):.1%}")
        self.logger.info(f"  ELO change: {eval_results.get('elo_delta', 0):+.0f}")
        self.logger.info(f"  Average eval: {avg_eval:+.2f}")
        self.logger.info(f"  Promoted: {'Yes' if should_promote else 'No'}")
        self.logger.info(f"  Time: {phase_time:.2f}s")
        
        return eval_results


def main():
    """Main entry point for quick test"""
    parser = argparse.ArgumentParser(
        description='AlphaZero Quick Test Cycle (Reduced MCTS for speed)',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Quick test with 50 MCTS simulations (instead of 800) for faster validation.

Examples:
  python test_cycle_quick.py
  python test_cycle_quick.py --games 3
  python test_cycle_quick.py --games 5 --parallel --threads 4
        """
    )
    
    parser.add_argument('--games', type=int, default=3,
                       help='Number of self-play games (default: 3 for quick test)')
    parser.add_argument('--threads', type=int, default=4,
                       help='Number of threads for parallel self-play (default: 4)')
    parser.add_argument('--parallel', action='store_true',
                       help='Enable parallel self-play')
    parser.add_argument('--epochs', type=int, default=1,
                       help='Number of training epochs (default: 1)')
    
    args = parser.parse_args()
    
    print("=" * 70)
    print(" QUICK TEST MODE - Reduced MCTS simulations for fast validation")
    print(" Self-play: 50 sims/move (normal: 800)")
    print(" Evaluation: 50 sims/move (normal: 400)")
    print("=" * 70)
    print()
    
    # Create and run quick test
    runner = QuickTestCycleRunner(
        num_games=args.games,
        num_threads=args.threads,
        enable_parallel=args.parallel,
        num_epochs=args.epochs,
        base_model_name='ActiveModel_Offline',
        new_model_name='ActiveModel_TestCycle',
        cache_dir='/app/backend/cache'
    )
    
    runner.run()


if __name__ == '__main__':
    main()
