#!/usr/bin/env python3
"""
Test script for AlphaZero massive training system
Runs a small-scale version to verify all components work
"""

import logging
import time
from selfplay_trainer import AlphaZeroSelfPlayTrainer

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def test_small_scale_training():
    """
    Test with small-scale parameters to verify system works
    100 games / 5 minutes instead of 44M games / 9 hours
    """
    logger.info("="*80)
    logger.info("AlphaZero Training System - Small Scale Test")
    logger.info("="*80)
    
    trainer = AlphaZeroSelfPlayTrainer(
        max_games=100,  # Small test: 100 games
        max_hours=0.083,  # 5 minutes
        num_simulations=100,  # Faster MCTS for testing
        replay_buffer_size=10_000,  # Smaller buffer
        batch_size=32,
        learning_rate=0.001,
        checkpoint_interval=120,  # 2 minutes
        eval_interval=25,  # Every 25 games
        win_threshold=0.55,
        num_eval_games=6,  # Quick evaluation
        log_dir="/data/training_logs/test_run"
    )
    
    logger.info("\n✓ Trainer initialized successfully")
    logger.info(f"  Target: 100 games / 5 minutes")
    logger.info(f"  MCTS: 100 simulations per move")
    logger.info(f"  Evaluation: every 25 games")
    logger.info("")
    
    # Run training
    trainer.run(resume=False)
    
    logger.info("\n" + "="*80)
    logger.info("Test Complete!")
    logger.info("="*80)

if __name__ == "__main__":
    test_small_scale_training()
