"""
Enhanced Distributed Self-Play System
- Robust model initialization with retry logic
- Proper numpy array serialization via pickle
- Per-worker log files with enhanced diagnostics
- Graceful fault tolerance and worker health monitoring
- Queue management with timeouts
- Auto-detect hardware (GPU/TPU/CPU)
"""

import multiprocessing as mp
import torch
import numpy as np
import logging
import time
import os
import traceback
import math
import threading
from typing import List, Dict, Tuple, Optional
from pathlib import Path
import queue
import sys
import io

# Fix for Windows console encoding issues with emoji characters
# Force UTF-8 encoding for stdout/stderr to handle Unicode properly
if sys.platform == 'win32':
    try:
        # Wrap stdout and stderr with UTF-8 encoding
        sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding='utf-8', errors='replace')
    except Exception:
        # If wrapping fails (already wrapped or not supported), continue
        pass

logger = logging.getLogger(__name__)

def _setup_worker_logger(worker_id: int, base_dir: str = "/app/data/logs/selfplay"):
    """Setup dedicated logger for worker process with UTF-8 encoding support"""
    os.makedirs(base_dir, exist_ok=True)
    log_path = os.path.join(base_dir, f"worker_{worker_id}.log")
    
    worker_logger = logging.getLogger(f"selfplay.worker.{worker_id}")
    worker_logger.setLevel(logging.INFO)
    worker_logger.propagate = False
    
    # Clear existing handlers
    worker_logger.handlers.clear()
    
    # File handler with UTF-8 encoding to support emoji characters
    fh = logging.FileHandler(log_path, mode='a', encoding='utf-8')
    fmt = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    fh.setFormatter(fmt)
    worker_logger.addHandler(fh)
    
    # Console handler with UTF-8 stream wrapper for Windows compatibility
    if sys.platform == 'win32':
        # Create a UTF-8 stream for console output on Windows
        console_stream = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
        ch = logging.StreamHandler(console_stream)
    else:
        ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    worker_logger.addHandler(ch)
    
    return worker_logger


def safe_serialize_game_samples(game_samples: List[Dict]) -> List[Dict]:
    """
    Convert numpy arrays to lists for reliable pickle serialization through multiprocessing.Queue
    
    Args:
        game_samples: List of training samples with position, policy, value
    
    Returns:
        Serializable list of dicts
    """
    serialized = []
    
    for sample in game_samples:
        # Convert position (numpy array -> list)
        pos = sample.get("position")
        if isinstance(pos, np.ndarray):
            pos_serial = pos.tolist()
        else:
            pos_serial = pos
        
        # Convert policy dict (ensure all values are plain Python floats)
        policy = sample.get("policy", {})
        policy_serial = {}
        for move_uci, prob in policy.items():
            if isinstance(prob, np.ndarray):
                policy_serial[move_uci] = float(prob.item())
            else:
                policy_serial[move_uci] = float(prob)
        
        # Ensure value is plain float
        value = sample.get("value", 0.0)
        if isinstance(value, np.ndarray):
            value_serial = float(value.item())
        else:
            value_serial = float(value)
        
        serialized.append({
            "position": pos_serial,
            "policy": policy_serial,
            "value": value_serial,
            "fen": sample.get("fen"),
            "move_number": sample.get("move_number")
        })
    
    return serialized


def deserialize_game_samples(serialized_samples: List[Dict]) -> List[Dict]:
    """
    Convert serialized samples back to numpy arrays for training
    
    Args:
        serialized_samples: List of serialized samples (from queue)
    
    Returns:
        List of samples with numpy arrays restored
    """
    deserialized = []
    
    for sample in serialized_samples:
        pos = sample.get("position")
        if isinstance(pos, list):
            pos_array = np.array(pos, dtype=np.float32)
        else:
            pos_array = pos
        
        deserialized.append({
            "position": pos_array,
            "policy": sample.get("policy", {}),
            "value": float(sample.get("value", 0.0)),
            "fen": sample.get("fen"),
            "move_number": sample.get("move_number")
        })
    
    return deserialized


def worker_generate_games(
    worker_id: int,
    task_queue: mp.Queue,
    result_queue: mp.Queue,
    stop_event: mp.Event,
    model_path: Optional[str],
    device_type: str,
    num_simulations: int
):
    """
    Worker process for parallel self-play game generation
    
    Args:
        worker_id: Unique worker identifier
        task_queue: Queue for receiving tasks
        result_queue: Queue for sending results
        stop_event: Event to signal worker shutdown
        model_path: Path to model checkpoint
        device_type: 'cuda', 'cpu', or 'tpu'
        num_simulations: MCTS simulations per move
    """
    worker_logger = _setup_worker_logger(worker_id)
    worker_logger.info(f"🚀 Worker {worker_id} starting")
    worker_logger.info(f"   Model path: {model_path}")
    worker_logger.info(f"   Device: {device_type}")
    worker_logger.info(f"   MCTS simulations: {num_simulations}")
    
    # Initialize tracking variables
    games_generated = 0
    positions_generated = 0
    
    try:
        # Import heavy modules inside worker process
        from neural_network import AlphaZeroNetwork, ModelManager
        from self_play import SelfPlayManager
        
        # Set device for this worker
        if device_type == 'cuda' and torch.cuda.is_available():
            device = torch.device('cuda')
            worker_logger.info(f"   Using CUDA device")
        else:
            device = torch.device('cpu')
            worker_logger.info(f"   Using CPU device")
        
        # Robust model initialization with retry logic
        model = None
        max_retries = 3
        
        for attempt in range(max_retries):
            try:
                worker_logger.info(f"   Loading model (attempt {attempt + 1}/{max_retries})...")
                
                if model_path and Path(model_path).exists():
                    # Load from checkpoint
                    model_manager = ModelManager()
                    model_name = Path(model_path).stem
                    model, metadata = model_manager.load_model(model_name)
                    
                    if model is None:
                        raise ValueError(f"Model loading returned None for {model_name}")
                    
                    worker_logger.info(f"   ✅ Model loaded from checkpoint: {model_name}")
                else:
                    # Create fresh model
                    model = AlphaZeroNetwork()
                    worker_logger.info(f"   ✅ Fresh model initialized")
                
                model.to(device)
                model.eval()
                break
                
            except Exception as e:
                worker_logger.error(f"   ❌ Model load attempt {attempt + 1} failed: {e}")
                worker_logger.error(f"   {traceback.format_exc()}")
                time.sleep(1.0)
        
        if model is None:
            worker_logger.critical(f"   🚫 Failed to initialize model after {max_retries} attempts")
            result_queue.put({
                'worker_id': worker_id,
                'error': 'model_init_failed',
                'traceback': traceback.format_exc()
            })
            return
        
        # Create self-play manager
        selfplay_manager = SelfPlayManager(model, num_simulations=num_simulations)
        worker_logger.info(f"   ✅ Self-play manager initialized")
        
        # Worker loop tracking
        
        while not stop_event.is_set():
            try:
                # Get task from queue with timeout
                task = task_queue.get(timeout=5.0)
                
                num_games = task.get('num_games', 1)
                worker_logger.info(f"📥 Task received: generate {num_games} games")
                
                # Generate games
                batch_samples = []
                batch_start = time.time()
                
                for game_idx in range(num_games):
                    try:
                        game_start = time.time()
                        
                        # Generate single game
                        training_data, game_result = selfplay_manager.generate_single_game(
                            store_fen=False,
                            export_pgn=False  # Disable PGN export in workers to reduce overhead
                        )
                        
                        game_time = time.time() - game_start
                        
                        # Collect samples
                        batch_samples.extend(training_data)
                        games_generated += 1
                        positions_generated += len(training_data)
                        
                        worker_logger.info(
                            f"   Game {game_idx + 1}/{num_games}: "
                            f"{game_result['result']}, "
                            f"{game_result['num_moves']} moves, "
                            f"{len(training_data)} positions, "
                            f"{game_time:.1f}s"
                        )
                        
                    except Exception as e:
                        worker_logger.error(f"   ❌ Error generating game {game_idx + 1}: {e}")
                        worker_logger.error(f"   {traceback.format_exc()}")
                        continue
                
                batch_time = time.time() - batch_start
                
                # Serialize samples for queue transfer
                worker_logger.info(f"🔄 Serializing {len(batch_samples)} samples...")
                serialized_samples = safe_serialize_game_samples(batch_samples)
                
                # Send result
                result = {
                    'worker_id': worker_id,
                    'num_games': num_games,
                    'num_positions': len(serialized_samples),
                    'samples': serialized_samples,
                    'batch_time': batch_time,
                    'total_games': games_generated,
                    'total_positions': positions_generated
                }
                
                worker_logger.info(
                    f"📤 Batch complete: {num_games} games, "
                    f"{len(serialized_samples)} positions in {batch_time:.1f}s "
                    f"({num_games / batch_time:.2f} games/s)"
                )
                
                result_queue.put(result)
                
            except queue.Empty:
                # No tasks available, continue waiting
                continue
            
            except Exception as e:
                worker_logger.error(f"❌ Worker error: {e}")
                worker_logger.error(f"{traceback.format_exc()}")
                
                result_queue.put({
                    'worker_id': worker_id,
                    'error': str(e),
                    'traceback': traceback.format_exc()
                })
    
    except Exception as e:
        worker_logger.critical(f"🚫 Worker {worker_id} fatal error: {e}")
        worker_logger.critical(f"{traceback.format_exc()}")
        
        try:
            result_queue.put({
                'worker_id': worker_id,
                'error': f"fatal: {e}",
                'traceback': traceback.format_exc()
            })
        except:
            pass
    
    finally:
        worker_logger.info(f"⏹️  Worker {worker_id} exiting")
        worker_logger.info(f"   Total games: {games_generated}")
        worker_logger.info(f"   Total positions: {positions_generated}")


class DistributedSelfPlayManager:
    """
    Enhanced Distributed Self-Play Manager - Phase 2 Optimization
    
    Features:
    - Auto-detects hardware (GPU/TPU/CPU)
    - Robust worker management with fault tolerance
    - Per-worker logging
    - Queue health monitoring
    - Heartbeat-based worker health tracking
    - Automatic worker recovery
    - Async producer-consumer model
    """
    
    def __init__(
        self,
        model_path: Optional[str] = None,
        num_simulations: int = 800,
        num_workers: Optional[int] = None,
        enable_heartbeat: bool = True,
        heartbeat_timeout: float = 120.0,
        enable_auto_recovery: bool = True
    ):
        """
        Initialize distributed self-play manager
        
        Args:
            model_path: Path to model checkpoint (optional)
            num_simulations: MCTS simulations per move
            num_workers: Number of workers (None = auto-detect)
            enable_heartbeat: Enable worker heartbeat monitoring
            heartbeat_timeout: Timeout for worker heartbeat (seconds)
            enable_auto_recovery: Enable automatic worker recovery
        """
        self.model_path = model_path
        self.num_simulations = num_simulations
        self.enable_heartbeat = enable_heartbeat
        self.heartbeat_timeout = heartbeat_timeout
        self.enable_auto_recovery = enable_auto_recovery
        
        # Auto-detect hardware and configure workers
        self._detect_hardware()
        
        if num_workers is not None:
            self.num_workers = num_workers
            logger.info(f"Using manual worker count: {self.num_workers}")
        
        logger.info(f"Distributed Self-Play Manager initialized (Phase 2):")
        logger.info(f"  Device: {self.device_type}")
        logger.info(f"  Workers: {self.num_workers}")
        logger.info(f"  MCTS simulations: {self.num_simulations}")
        logger.info(f"  Heartbeat monitoring: {self.enable_heartbeat}")
        logger.info(f"  Auto recovery: {self.enable_auto_recovery}")
        
        # Process management
        self.task_queue = None
        self.result_queue = None
        self.heartbeat_queue = None
        self.stop_event = None
        self.workers = []
        
        # Worker health tracking
        self.worker_health = {}
        self.worker_failures = 0
        self.worker_recoveries = 0
        
        # Statistics
        self.total_games_generated = 0
        self.total_positions_collected = 0
        self.worker_stats = {}
        
        # Performance tracking
        self.batch_start_time = None
        self.throughput_history = []
    
    def _detect_hardware(self):
        """Auto-detect hardware and configure optimal worker count"""
        # Check for CUDA GPUs
        if torch.cuda.is_available():
            num_gpus = torch.cuda.device_count()
            self.device_type = 'cuda'
            self.num_gpus = num_gpus
            # GPU: workers = max(1, num_gpus * 2)
            self.num_workers = max(1, num_gpus * 2)
            logger.info(f"Detected {num_gpus} CUDA GPUs")
        
        # Check for TPUs (simplified check)
        elif os.environ.get('TPU_NAME') or os.path.exists('/dev/accel0'):
            self.device_type = 'tpu'
            self.num_gpus = 0
            self.num_workers = 16  # Conservative default for TPU
            logger.info(f"Detected TPU environment")
        
        # Fallback to CPU
        else:
            self.device_type = 'cpu'
            self.num_gpus = 0
            num_cpus = mp.cpu_count()
            # CPU: workers = min(ceil(cpu_count * 0.75), 16)
            self.num_workers = min(math.ceil(num_cpus * 0.75), 16)
            logger.info(f"Detected {num_cpus} CPU cores")
    
    def _monitor_worker_health(self):
        """Monitor worker health via heartbeat messages"""
        if not self.enable_heartbeat:
            return
        
        try:
            while not self.stop_event.is_set():
                try:
                    # Check for heartbeat messages
                    heartbeat = self.heartbeat_queue.get(timeout=5.0)
                    worker_id = heartbeat.get('worker_id')
                    
                    # Update worker health
                    if worker_id in self.worker_health:
                        self.worker_health[worker_id]['last_heartbeat'] = time.time()
                        self.worker_health[worker_id]['games_completed'] = heartbeat.get('games_completed', 0)
                    
                except queue.Empty:
                    pass
                
                # Check for unhealthy workers
                current_time = time.time()
                for worker_id, health in self.worker_health.items():
                    elapsed = current_time - health['last_heartbeat']
                    if elapsed > self.heartbeat_timeout and health['is_alive']:
                        logger.warning(f"⚠️ Worker {worker_id} missed heartbeat ({elapsed:.0f}s)")
                        health['is_alive'] = False
                        self.worker_failures += 1
                        
                        # Attempt recovery if enabled
                        if self.enable_auto_recovery:
                            logger.info(f"🔄 Attempting to recover worker {worker_id}...")
                            self._recover_worker(worker_id)
        
        except Exception as e:
            logger.error(f"Heartbeat monitor error: {e}")
    
    def _recover_worker(self, worker_id: int):
        """Attempt to recover a failed worker"""
        try:
            # Find and terminate the failed worker
            for idx, (wid, worker, games) in enumerate(self.workers):
                if wid == worker_id:
                    if worker.is_alive():
                        worker.terminate()
                        worker.join(timeout=2)
                    
                    # Spawn replacement worker
                    new_worker = mp.Process(
                        target=worker_generate_games,
                        args=(
                            worker_id,
                            self.task_queue,
                            self.result_queue,
                            self.stop_event,
                            self.model_path,
                            self.device_type,
                            self.num_simulations
                        ),
                        daemon=True
                    )
                    new_worker.start()
                    
                    # Update worker list
                    self.workers[idx] = (worker_id, new_worker, games)
                    
                    # Reset health
                    self.worker_health[worker_id]['is_alive'] = True
                    self.worker_health[worker_id]['last_heartbeat'] = time.time()
                    self.worker_recoveries += 1
                    
                    logger.info(f"✅ Worker {worker_id} recovered (PID: {new_worker.pid})")
                    break
        
        except Exception as e:
            logger.error(f"Worker recovery failed for worker {worker_id}: {e}")
    
    def _calculate_adaptive_timeout(self, games_per_worker: int) -> float:
        """Calculate adaptive timeout based on historical performance"""
        if len(self.throughput_history) > 0:
            avg_game_time = np.mean(self.throughput_history)
            # Timeout = 3x average time per game * games per worker
            return max(300, avg_game_time * games_per_worker * 3)
        else:
            # Default: 60 seconds per game with 2x buffer
            return games_per_worker * 60 * 2
    
    def generate_games_parallel(
        self,
        num_games: int,
        fallback_to_sequential: bool = True
    ) -> Tuple[List[Dict], List[Dict]]:
        """
        Generate games in parallel across workers with enhanced monitoring
        
        Phase 2 Enhancements:
        - Adaptive timeout based on performance history
        - Worker heartbeat monitoring
        - Automatic worker recovery
        - Detailed performance metrics
        - Graceful degradation on worker failures
        
        Args:
            num_games: Total number of games to generate
            fallback_to_sequential: If True, fallback to sequential on worker failure
        
        Returns:
            (all_training_data, game_results)
        """
        logger.info("="*80)
        logger.info(f"DISTRIBUTED SELF-PLAY (PHASE 2): {num_games} games across {self.num_workers} workers")
        logger.info("="*80)
        
        self.batch_start_time = time.time()
        start_time = self.batch_start_time
        
        # Calculate games per worker
        games_per_worker = num_games // self.num_workers
        remainder = num_games % self.num_workers
        
        logger.info(f"Distribution: {games_per_worker} games/worker (+ {remainder} remainder)")
        logger.info(f"Heartbeat monitoring: {self.enable_heartbeat}")
        logger.info(f"Auto recovery: {self.enable_auto_recovery}")
        
        # Create queues and event
        self.task_queue = mp.Queue(maxsize=self.num_workers * 2)
        self.result_queue = mp.Queue(maxsize=self.num_workers * 10)
        self.heartbeat_queue = mp.Queue(maxsize=self.num_workers * 100) if self.enable_heartbeat else None
        self.stop_event = mp.Event()
        
        # Start heartbeat monitor thread
        heartbeat_thread = None
        if self.enable_heartbeat:
            heartbeat_thread = threading.Thread(target=self._monitor_worker_health, daemon=True)
            heartbeat_thread.start()
            logger.info("✅ Heartbeat monitor started")
        
        # Spawn workers
        self.workers = []
        self.worker_health = {}
        
        for worker_id in range(self.num_workers):
            # Distribute remainder games
            worker_games = games_per_worker + (1 if worker_id < remainder else 0)
            
            if worker_games == 0:
                continue
            
            # Create worker process
            worker = mp.Process(
                target=worker_generate_games,
                args=(
                    worker_id,
                    self.task_queue,
                    self.result_queue,
                    self.stop_event,
                    self.model_path,
                    self.device_type,
                    self.num_simulations
                ),
                daemon=True
            )
            worker.start()
            self.workers.append((worker_id, worker, worker_games))
            
            # Initialize worker health
            self.worker_health[worker_id] = {
                'start_time': time.time(),
                'last_heartbeat': time.time(),
                'games_completed': 0,
                'is_alive': True
            }
            
            logger.info(f"✅ Started worker {worker_id} (PID: {worker.pid}) for {worker_games} games")
        
        # Enqueue tasks
        for worker_id, worker, worker_games in self.workers:
            try:
                self.task_queue.put({'num_games': worker_games}, timeout=5)
                logger.info(f"📥 Task queued for worker {worker_id}: {worker_games} games")
            except queue.Full:
                logger.error(f"❌ Task queue full, couldn't enqueue for worker {worker_id}")
        
        # Collect results with adaptive timeout
        all_training_data = []
        game_results = []
        results_collected = 0
        expected_results = len(self.workers)
        
        # Calculate adaptive timeout
        max_wait_time = self._calculate_adaptive_timeout(games_per_worker)
        collection_start = time.time()
        
        logger.info(f"📦 Collecting results (timeout: {max_wait_time:.0f}s)...")
        
        while results_collected < expected_results:
            try:
                elapsed = time.time() - collection_start
                remaining_timeout = max(30, max_wait_time - elapsed)
                
                result = self.result_queue.get(timeout=remaining_timeout)
                
                # Check for errors
                if 'error' in result:
                    worker_id = result.get('worker_id', 'unknown')
                    error_msg = result.get('error')
                    logger.error(f"❌ Worker {worker_id} reported error: {error_msg}")
                    
                    if 'traceback' in result:
                        logger.error(f"   Traceback:\n{result['traceback']}")
                    
                    results_collected += 1
                    
                    # Mark worker as failed
                    if worker_id in self.worker_health:
                        self.worker_health[worker_id]['is_alive'] = False
                    
                    continue
                
                # Process successful result
                worker_id = result['worker_id']
                num_positions = result['num_positions']
                batch_time = result['batch_time']
                
                logger.info(
                    f"📤 Worker {worker_id}: received {num_positions} positions "
                    f"({result['num_games']} games in {batch_time:.1f}s)"
                )
                
                # Deserialize samples
                serialized_samples = result.get('samples', [])
                deserialized_samples = deserialize_game_samples(serialized_samples)
                
                all_training_data.extend(deserialized_samples)
                
                # Track statistics
                self.worker_stats[worker_id] = {
                    'games': result.get('total_games', 0),
                    'positions': result.get('total_positions', 0),
                    'batch_time': batch_time,
                    'throughput_games_per_sec': result['num_games'] / batch_time if batch_time > 0 else 0
                }
                
                # Update throughput history
                game_time = batch_time / result['num_games'] if result['num_games'] > 0 else 0
                self.throughput_history.append(game_time)
                if len(self.throughput_history) > 100:
                    self.throughput_history.pop(0)
                
                results_collected += 1
                
                logger.info(
                    f"📊 Progress: {results_collected}/{expected_results} workers, "
                    f"{len(all_training_data)} total positions"
                )
                
            except queue.Empty:
                logger.warning(f"⏱️  Timeout waiting for results ({elapsed:.0f}s elapsed)")
                logger.warning(f"   Collected {results_collected}/{expected_results} workers")
                
                # Check worker health
                alive_workers = sum(1 for h in self.worker_health.values() if h['is_alive'])
                logger.warning(f"   Alive workers: {alive_workers}/{len(self.workers)}")
                
                # Decide whether to continue waiting or break
                if alive_workers == 0:
                    logger.error("All workers failed, breaking collection loop")
                    break
                elif results_collected >= expected_results * 0.7:  # Got 70%+ results
                    logger.info(f"Collected {results_collected}/{expected_results} results (70%+), proceeding")
                    break
                else:
                    logger.info("Continuing to wait for remaining workers...")
                    collection_start = time.time()  # Reset timeout
                    continue
            
            except Exception as e:
                logger.error(f"❌ Error collecting results: {e}")
                logger.error(f"{traceback.format_exc()}")
                break
        
        # Cleanup workers
        logger.info("🧹 Cleaning up workers...")
        self.stop_event.set()
        
        time.sleep(1)
        
        for worker_id, worker, _ in self.workers:
            if worker.is_alive():
                logger.warning(f"   Worker {worker_id} still alive, terminating...")
                worker.terminate()
                worker.join(timeout=2)
        
        # Stop heartbeat monitor
        if heartbeat_thread and heartbeat_thread.is_alive():
            heartbeat_thread.join(timeout=2)
        
        # Calculate metrics
        total_time = time.time() - start_time
        games_collected = results_collected * games_per_worker  # Approximate
        
        # Detailed statistics
        logger.info("="*80)
        logger.info("DISTRIBUTED SELF-PLAY COMPLETE (PHASE 2)")
        logger.info(f"  Workers completed: {results_collected}/{expected_results}")
        logger.info(f"  Worker failures: {self.worker_failures}")
        logger.info(f"  Worker recoveries: {self.worker_recoveries}")
        logger.info(f"  Total positions: {len(all_training_data)}")
        logger.info(f"  Time: {total_time:.1f}s")
        logger.info(f"  Throughput:")
        logger.info(f"    - {len(all_training_data) / total_time:.1f} positions/s")
        logger.info(f"    - {games_collected / total_time:.3f} games/s")
        logger.info(f"    - {games_collected / (total_time / 3600):.1f} games/hour")
        
        # Calculate speedup vs sequential estimate
        if len(self.throughput_history) > 0:
            avg_game_time = np.mean(self.throughput_history)
            sequential_estimate = avg_game_time * num_games
            speedup = sequential_estimate / total_time if total_time > 0 else 1.0
            logger.info(f"  Estimated speedup: {speedup:.1f}x vs sequential")
        
        logger.info("="*80)
        
        # Update statistics
        self.total_games_generated += games_collected
        self.total_positions_collected += len(all_training_data)
        
        return all_training_data, game_results
    
    def get_stats(self) -> Dict:
        """Get comprehensive distributed self-play statistics (Phase 2)"""
        return {
            'device_type': self.device_type,
            'num_workers': self.num_workers,
            'total_games': self.total_games_generated,
            'total_positions': self.total_positions_collected,
            'worker_stats': self.worker_stats,
            'worker_health': {
                wid: {
                    'is_alive': health['is_alive'],
                    'games_completed': health['games_completed'],
                    'uptime_seconds': time.time() - health['start_time']
                }
                for wid, health in self.worker_health.items()
            },
            'fault_tolerance': {
                'worker_failures': self.worker_failures,
                'worker_recoveries': self.worker_recoveries,
                'recovery_rate': self.worker_recoveries / self.worker_failures if self.worker_failures > 0 else 0
            },
            'performance': {
                'avg_game_time': np.mean(self.throughput_history) if self.throughput_history else 0,
                'throughput_history_size': len(self.throughput_history)
            },
            'features': {
                'heartbeat_monitoring': self.enable_heartbeat,
                'auto_recovery': self.enable_auto_recovery,
                'heartbeat_timeout': self.heartbeat_timeout
            }
        }


# CLI for testing
if __name__ == "__main__":
    import argparse
    
    # Configure logging with UTF-8 encoding support
    log_handler = logging.StreamHandler(sys.stdout)
    log_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[log_handler]
    )
    
    parser = argparse.ArgumentParser(description='Distributed Self-Play Test')
    parser.add_argument('--mode', choices=['smoke', 'scale'], default='smoke',
                       help='Test mode: smoke (10 games, 2 workers) or scale (1000 games, auto workers)')
    parser.add_argument('--workers', type=str, default='auto',
                       help='Number of workers (or "auto")')
    parser.add_argument('--num_games', type=int, default=10,
                       help='Number of games to generate')
    
    args = parser.parse_args()
    
    # Configure based on mode
    if args.mode == 'smoke':
        num_games = 10
        num_workers = 2
        logger.info("🧪 SMOKE TEST: 10 games, 2 workers")
    else:  # scale
        num_games = args.num_games
        num_workers = None if args.workers == 'auto' else int(args.workers)
        logger.info(f"🚀 SCALE TEST: {num_games} games, {num_workers or 'auto'} workers")
    
    # Initialize manager
    manager = DistributedSelfPlayManager(
        model_path=None,  # Will use fresh model
        num_simulations=100,  # Reduced for testing
        num_workers=num_workers
    )
    
    # Run test
    training_data, game_results = manager.generate_games_parallel(num_games)
    
    # Report results
    logger.info("\n" + "="*80)
    logger.info("TEST RESULTS")
    logger.info("="*80)
    logger.info(f"Games requested: {num_games}")
    logger.info(f"Positions collected: {len(training_data)}")
    logger.info(f"Average positions/game: {len(training_data) / num_games:.1f}")
    logger.info("="*80)
    
    # Print sample
    if len(training_data) > 0:
        sample = training_data[0]
        logger.info("\nSample position:")
        logger.info(f"  Type: {type(sample)}")
        logger.info(f"  Keys: {list(sample.keys())}")
        if isinstance(sample.get('position'), np.ndarray):
            logger.info(f"  Position shape: {sample['position'].shape}")
        logger.info(f"  Policy length: {len(sample.get('policy', {}))}")
        logger.info(f"  Value: {sample.get('value')}")
