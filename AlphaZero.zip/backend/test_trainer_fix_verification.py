"""
Test script to verify the trainer fix for empty replay buffer scenario
"""
import logging
import sys

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def test_empty_training_data():
    """Test that train_on_batch handles empty data correctly"""
    logger.info("="*80)
    logger.info("TEST 1: Empty Training Data Handling")
    logger.info("="*80)
    
    try:
        from selfplay_trainer import AlphaZeroSelfPlayTrainer
        
        # Create a minimal trainer instance
        trainer = AlphaZeroSelfPlayTrainer(
            max_games=100,
            max_hours=0.1,
            log_dir="/tmp/test_trainer"
        )
        
        # Test empty training data
        logger.info("\n📋 Testing train_on_batch with empty list...")
        result = trainer.train_on_batch([])
        
        # Check that all required keys are present
        required_keys = ['loss', 'policy_loss', 'value_loss', 'learning_rate', 'num_batches']
        missing_keys = [key for key in required_keys if key not in result]
        
        if missing_keys:
            logger.error(f"❌ FAILED: Missing keys in result: {missing_keys}")
            logger.error(f"   Result keys: {list(result.keys())}")
            return False
        
        logger.info(f"✅ SUCCESS: All required keys present")
        logger.info(f"   Result: {result}")
        
        # Test that values are reasonable
        assert result['loss'] == 0.0, "Loss should be 0.0 for empty data"
        assert result['num_batches'] == 0, "num_batches should be 0 for empty data"
        assert 'learning_rate' in result, "learning_rate must be present"
        
        logger.info(f"✅ All assertions passed")
        return True
        
    except Exception as e:
        logger.error(f"❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_logging_with_empty_metrics():
    """Test that logging handles missing keys gracefully"""
    logger.info("\n" + "="*80)
    logger.info("TEST 2: Defensive Logging")
    logger.info("="*80)
    
    try:
        # Simulate incomplete training_metrics (should not crash)
        training_metrics = {'loss': 0.5}  # Missing 'learning_rate'
        
        # This is how we now access metrics (defensive)
        loss = training_metrics.get('loss', 0.0)
        lr = training_metrics.get('learning_rate', 0.0)
        
        logger.info(f"📊 Metrics: Loss={loss:.4f}, LR={lr:.6f}")
        logger.info(f"✅ SUCCESS: Defensive logging works correctly")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_complete_scenario():
    """Test the complete empty replay buffer scenario"""
    logger.info("\n" + "="*80)
    logger.info("TEST 3: Complete Empty Replay Buffer Scenario")
    logger.info("="*80)
    
    try:
        # Simulate the exact scenario from the error log
        training_metrics = {
            'loss': 0.0,
            'policy_loss': 0.0,
            'value_loss': 0.0,
            'learning_rate': 0.001,
            'num_batches': 0
        }
        
        train_time = 0.1
        
        # This was the line that caused the error - now it should work
        loss = training_metrics.get('loss', 0.0)
        lr = training_metrics.get('learning_rate', 0.0)
        
        log_message = f"Training complete in {train_time:.1f}s: Loss={loss:.4f}, LR={lr:.6f}"
        logger.info(f"📝 Log output: {log_message}")
        logger.info(f"✅ SUCCESS: No KeyError thrown")
        
        return True
        
    except KeyError as e:
        logger.error(f"❌ TEST FAILED: KeyError still occurring: {e}")
        return False
    except Exception as e:
        logger.error(f"❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    logger.info("🚀 Starting Trainer Fix Verification Tests\n")
    
    results = []
    
    # Run all tests
    results.append(("Empty Training Data", test_empty_training_data()))
    results.append(("Defensive Logging", test_logging_with_empty_metrics()))
    results.append(("Complete Scenario", test_complete_scenario()))
    
    # Summary
    logger.info("\n" + "="*80)
    logger.info("TEST SUMMARY")
    logger.info("="*80)
    
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        logger.info(f"{status}: {test_name}")
    
    total_passed = sum(1 for _, passed in results if passed)
    total_tests = len(results)
    
    logger.info(f"\nTotal: {total_passed}/{total_tests} tests passed")
    
    if total_passed == total_tests:
        logger.info("\n🎉 ALL TESTS PASSED! The fix is working correctly.")
        sys.exit(0)
    else:
        logger.error("\n⚠️ SOME TESTS FAILED. Please review the output above.")
        sys.exit(1)
