"""
Training Orchestration API Routes
Provides HTTP endpoints for controlling AlphaZero training cycles on TPU infrastructure

Endpoints:
- POST /api/training/cycle/start        - Start new training cycle
- POST /api/training/cycle/stop         - Stop current training cycle
- GET  /api/training/cycle/status       - Get current cycle status
- GET  /api/training/cycle/history      - Get training history
- GET  /api/training/metrics            - Get comprehensive training metrics
- GET  /api/training/model/current      - Get current model info
- GET  /api/training/replay-buffer/stats - Get replay buffer statistics
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field
from typing import Optional, Dict, List
import logging
from datetime import datetime

from tpu_training_orchestrator import get_tpu_training_orchestrator, reset_tpu_training_orchestrator
from replay_buffer_service import get_replay_buffer_service
from tpu_cluster_manager import get_tpu_grid

logger = logging.getLogger(__name__)

# Create router
training_orchestration_router = APIRouter(prefix="/api/training", tags=["Training Orchestration"])


# ====================
# Request Models
# ====================

class StartTrainingCycleRequest(BaseModel):
    num_selfplay_games: int = Field(default=100, ge=10, le=10000, description="Number of self-play games to generate")
    num_tpus_selfplay: int = Field(default=100, ge=10, le=5000, description="TPUs to allocate for self-play")
    num_tpus_training: int = Field(default=50, ge=10, le=5000, description="TPUs to allocate for training")
    num_training_epochs: int = Field(default=3, ge=1, le=10, description="Number of training epochs")
    num_eval_games: int = Field(default=20, ge=10, le=100, description="Number of evaluation games")
    batch_size: int = Field(default=256, ge=32, le=512, description="Training batch size")
    learning_rate: float = Field(default=0.001, ge=0.0001, le=0.01, description="Learning rate")
    continuous: bool = Field(default=False, description="Continue to next cycle after completion")


# ====================
# Training Cycle Endpoints
# ====================

@training_orchestration_router.post("/cycle/start")
async def start_training_cycle(request: StartTrainingCycleRequest):
    """
    Start a new AlphaZero training cycle
    
    Executes the full cycle:
    1. Self-Play: Generate games using MCTS on TPU workers
    2. Training: Update network weights using replay buffer
    3. Evaluation: Compare new vs old model
    4. Promotion: Replace old model if improved
    
    Args:
        request: Training cycle configuration
    
    Returns:
        Training cycle status
    """
    try:
        orchestrator = get_tpu_training_orchestrator()
        
        # Check if already running
        if orchestrator.is_running:
            raise HTTPException(
                status_code=400,
                detail="Training cycle already in progress"
            )
        
        logger.info(f"Starting training cycle: {request.num_selfplay_games} games, "
                   f"{request.num_tpus_selfplay} TPUs self-play, "
                   f"{request.num_tpus_training} TPUs training")
        
        # Start cycle (runs in background)
        cycle = await orchestrator.start_training_cycle(
            num_selfplay_games=request.num_selfplay_games,
            num_tpus_selfplay=request.num_tpus_selfplay,
            num_tpus_training=request.num_tpus_training,
            num_training_epochs=request.num_training_epochs,
            num_eval_games=request.num_eval_games,
            batch_size=request.batch_size,
            learning_rate=request.learning_rate,
            continuous=request.continuous
        )
        
        return {
            "success": True,
            "message": "Training cycle started",
            "cycle_id": cycle.cycle_id,
            "cycle_number": cycle.cycle_number,
            "current_model": cycle.current_model_name,
            "configuration": {
                "selfplay_games": request.num_selfplay_games,
                "tpus_selfplay": request.num_tpus_selfplay,
                "tpus_training": request.num_tpus_training,
                "training_epochs": request.num_training_epochs,
                "eval_games": request.num_eval_games,
                "continuous": request.continuous
            }
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error starting training cycle: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@training_orchestration_router.post("/cycle/stop")
async def stop_training_cycle():
    """
    Stop the current training cycle
    
    Gracefully stops the cycle at the current phase.
    In-progress phases will complete before stopping.
    
    Returns:
        Stop status
    """
    try:
        orchestrator = get_tpu_training_orchestrator()
        
        if not orchestrator.is_running:
            raise HTTPException(
                status_code=400,
                detail="No training cycle is currently running"
            )
        
        success = orchestrator.stop_training()
        
        return {
            "success": success,
            "message": "Training cycle stop requested",
            "note": "Current phase will complete before stopping"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error stopping training cycle: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@training_orchestration_router.get("/cycle/status")
async def get_cycle_status():
    """
    Get current training cycle status
    
    Returns:
    - Current phase (self-play, training, evaluation, promotion)
    - Progress within each phase
    - TPU worker activity
    - Replay buffer status
    - Model information
    """
    try:
        orchestrator = get_tpu_training_orchestrator()
        status = orchestrator.get_cycle_status()
        
        if status is None:
            return {
                "success": True,
                "is_running": False,
                "message": "No active training cycle"
            }
        
        return {
            "success": True,
            "is_running": True,
            "timestamp": datetime.utcnow().isoformat(),
            **status
        }
    
    except Exception as e:
        logger.error(f"Error getting cycle status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@training_orchestration_router.get("/cycle/history")
async def get_training_history():
    """
    Get history of completed training cycles
    
    Returns:
    - List of all completed cycles
    - Performance metrics per cycle
    - Model progression over time
    - ELO evolution
    """
    try:
        orchestrator = get_tpu_training_orchestrator()
        history = orchestrator.get_training_history()
        
        return {
            "success": True,
            "total_cycles": len(history),
            "cycles": history
        }
    
    except Exception as e:
        logger.error(f"Error getting training history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@training_orchestration_router.get("/metrics")
async def get_training_metrics():
    """
    Get comprehensive training metrics
    
    Returns:
    - Current cycle status
    - TPU grid utilization
    - Replay buffer statistics
    - Model performance metrics
    - Training history summary
    """
    try:
        orchestrator = get_tpu_training_orchestrator()
        replay_buffer = get_replay_buffer_service()
        tpu_grid = get_tpu_grid()
        
        # Get current status
        cycle_status = orchestrator.get_cycle_status()
        
        # Get history
        history = orchestrator.get_training_history()
        
        # Calculate aggregate metrics
        total_positions = sum(c.get('positions_generated', 0) for c in history)
        total_promoted = sum(1 for c in history if c.get('model_promoted', False))
        avg_win_rate = sum(c.get('evaluation_win_rate', 0) for c in history) / max(len(history), 1)
        
        # Get buffer stats
        buffer_stats = replay_buffer.get_buffer_stats()
        
        # Get grid stats
        grid_stats = tpu_grid.get_grid_status()
        
        return {
            "success": True,
            "timestamp": datetime.utcnow().isoformat(),
            "current_cycle": cycle_status,
            "aggregate_metrics": {
                "total_cycles_completed": len(history),
                "total_positions_generated": total_positions,
                "total_models_promoted": total_promoted,
                "avg_evaluation_win_rate": avg_win_rate,
                "current_model_version": orchestrator.model_version,
                "current_model_elo": orchestrator.current_model_elo
            },
            "replay_buffer": {
                "total_size": buffer_stats['total_size'],
                "capacity": buffer_stats['total_capacity'],
                "utilization": buffer_stats['utilization'],
                "total_inserted": buffer_stats['total_inserted'],
                "total_sampled": buffer_stats['total_sampled']
            },
            "tpu_grid": {
                "total_tpus": grid_stats['grid']['total_tpus'],
                "busy_tpus": grid_stats['grid']['busy_tpus'],
                "utilization_percent": grid_stats['utilization']['current_percent'],
                "active_jobs": grid_stats['jobs']['active'],
                "total_compute_hours": grid_stats['performance']['total_compute_hours']
            }
        }
    
    except Exception as e:
        logger.error(f"Error getting training metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Model Information Endpoints
# ====================

@training_orchestration_router.get("/model/current")
async def get_current_model_info():
    """
    Get current model information
    
    Returns:
    - Model name and version
    - ELO rating
    - Training history
    - Architecture details
    """
    try:
        orchestrator = get_tpu_training_orchestrator()
        
        # Get architecture info
        arch_info = orchestrator.current_network.get_architecture_info()
        
        return {
            "success": True,
            "model": {
                "name": orchestrator.current_model_name,
                "version": orchestrator.model_version,
                "elo": orchestrator.current_model_elo
            },
            "architecture": arch_info,
            "training_state": {
                "total_cycles": len(orchestrator.cycle_history),
                "is_training": orchestrator.is_running,
                "continuous_mode": orchestrator.continuous_mode
            }
        }
    
    except Exception as e:
        logger.error(f"Error getting current model info: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Replay Buffer Endpoints
# ====================

@training_orchestration_router.get("/replay-buffer/stats")
async def get_replay_buffer_stats():
    """
    Get replay buffer statistics
    
    Returns:
    - Buffer size and capacity
    - Shard statistics
    - Sampling statistics
    - Validation metrics
    """
    try:
        replay_buffer = get_replay_buffer_service()
        stats = replay_buffer.get_buffer_stats()
        
        return {
            "success": True,
            "timestamp": datetime.utcnow().isoformat(),
            **stats
        }
    
    except Exception as e:
        logger.error(f"Error getting replay buffer stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@training_orchestration_router.get("/replay-buffer/sample")
async def get_replay_buffer_sample(count: int = 10):
    """
    Get sample replay tuples for preview
    
    Args:
        count: Number of samples to retrieve
    
    Returns:
        Sample of replay tuples with metadata
    """
    try:
        replay_buffer = get_replay_buffer_service()
        samples = replay_buffer.get_sample_replays(count=count)
        
        return {
            "success": True,
            "count": len(samples),
            "samples": samples
        }
    
    except Exception as e:
        logger.error(f"Error getting replay buffer sample: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@training_orchestration_router.post("/replay-buffer/clear")
async def clear_replay_buffer():
    """
    Clear replay buffer
    
    WARNING: This will delete all stored training data
    """
    try:
        replay_buffer = get_replay_buffer_service()
        replay_buffer.clear_buffer()
        
        return {
            "success": True,
            "message": "Replay buffer cleared"
        }
    
    except Exception as e:
        logger.error(f"Error clearing replay buffer: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Admin Endpoints
# ====================

@training_orchestration_router.post("/reset")
async def reset_orchestrator():
    """
    Reset training orchestrator
    
    WARNING: This will reset all training state
    Use only for testing/development
    """
    try:
        reset_tpu_training_orchestrator()
        
        return {
            "success": True,
            "message": "Training orchestrator reset successfully"
        }
    
    except Exception as e:
        logger.error(f"Error resetting orchestrator: {e}")
        raise HTTPException(status_code=500, detail=str(e))
