#!/usr/bin/env python3
"""
Training Monitor - Check AlphaZero Training Status
"""

import json
import sys
from pathlib import Path
from datetime import datetime

def format_duration(seconds):
    """Format seconds into readable duration"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    return f"{hours}h {minutes}m {secs}s"

def check_training_status():
    """Check current training status from logs"""
    
    log_dir = Path("/data/training_logs/selfplay_44M")
    
    print("="*80)
    print("ALPHAZERO TRAINING STATUS")
    print("="*80)
    
    # Check if training has started
    if not log_dir.exists():
        print("❌ Training not started - log directory doesn't exist")
        print(f"   Expected: {log_dir}")
        return
    
    # Check metrics file
    metrics_file = log_dir / "training_metrics.json"
    if not metrics_file.exists():
        print("⚠️  Training started but no metrics file yet")
        print(f"   Metrics file: {metrics_file}")
        return
    
    # Load metrics
    try:
        with open(metrics_file, 'r') as f:
            data = json.load(f)
            metrics = data.get('metrics', [])
        
        if not metrics:
            print("⚠️  No training metrics recorded yet")
            return
        
        latest = metrics[-1]
        
        # Display status
        print(f"\n📊 Latest Training Metrics (Updated: {latest.get('timestamp', 'Unknown')})")
        print(f"   Games Completed: {latest.get('games_completed', 0):,} / {44_000_000:,}")
        print(f"   Progress: {latest.get('progress_pct', 0):.2f}%")
        print(f"   Positions Collected: {latest.get('positions_collected', 0):,}")
        print(f"   Elapsed Time: {format_duration(latest.get('elapsed_hours', 0) * 3600)}")
        print(f"   ETA: {format_duration(latest.get('eta_hours', 0) * 3600)}")
        
        print(f"\n⚡ Performance:")
        print(f"   Games/sec: {latest.get('games_per_sec', 0):.4f}")
        print(f"   Positions/sec: {latest.get('positions_per_sec', 0):.2f}")
        
        print(f"\n🎯 Training Metrics:")
        print(f"   Current ELO: {latest.get('current_elo', 1500):.0f}")
        print(f"   Models Promoted: {latest.get('models_promoted', 0)}")
        print(f"   Training Loss: {latest.get('training_loss', 0):.4f}")
        print(f"   Learning Rate: {latest.get('learning_rate', 0):.6f}")
        
        print(f"\n💾 Replay Buffer:")
        print(f"   Size: {latest.get('replay_buffer_size', 0):,} positions")
        
        # Check if training is progressing
        if len(metrics) > 1:
            prev = metrics[-2]
            games_delta = latest.get('games_completed', 0) - prev.get('games_completed', 0)
            positions_delta = latest.get('positions_collected', 0) - prev.get('positions_collected', 0)
            
            print(f"\n📈 Recent Progress:")
            print(f"   Games in last batch: {games_delta}")
            print(f"   Positions in last batch: {positions_delta}")
            
            if positions_delta > 0:
                print(f"   ✅ Replay buffer is collecting data!")
            else:
                print(f"   ⚠️  No new positions in last batch")
        
        print("\n" + "="*80)
        
    except Exception as e:
        print(f"❌ Error reading metrics: {e}")
        import traceback
        traceback.print_exc()

def check_checkpoints():
    """Check available checkpoints"""
    checkpoint_dir = Path("/data/training_logs/selfplay_44M/checkpoints")
    
    if not checkpoint_dir.exists():
        print("No checkpoints directory found")
        return
    
    checkpoints = list(checkpoint_dir.glob("checkpoint_*.pt"))
    
    if not checkpoints:
        print("No checkpoints found")
        return
    
    print(f"\n📁 Checkpoints ({len(checkpoints)} found):")
    for cp in sorted(checkpoints)[-5:]:  # Show last 5
        stat = cp.stat()
        size_mb = stat.st_size / (1024 * 1024)
        mtime = datetime.fromtimestamp(stat.st_mtime)
        print(f"   {cp.name}: {size_mb:.1f} MB (Modified: {mtime.strftime('%Y-%m-%d %H:%M:%S')})")

def check_replay_buffer():
    """Check replay buffer files"""
    log_dir = Path("/data/training_logs/selfplay_44M")
    
    replay_files = list(log_dir.glob("replay_buffer_*.pkl"))
    
    if not replay_files:
        print("\nNo replay buffer files found")
        return
    
    print(f"\n💾 Replay Buffer Files ({len(replay_files)} found):")
    for rf in sorted(replay_files)[-3:]:  # Show last 3
        stat = rf.stat()
        size_mb = stat.st_size / (1024 * 1024)
        mtime = datetime.fromtimestamp(stat.st_mtime)
        print(f"   {rf.name}: {size_mb:.1f} MB (Modified: {mtime.strftime('%Y-%m-%d %H:%M:%S')})")

if __name__ == "__main__":
    check_training_status()
    check_checkpoints()
    check_replay_buffer()
    print()
