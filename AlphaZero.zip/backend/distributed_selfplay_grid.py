"""
Distributed Self-Play Orchestration for 5000-TPU Grid
Manages self-play game generation across virtual TPU cluster

AlphaZero Phase: Self-Play Data Generation
- Distributes game generation across TPU pods
- Collects (state, policy, value) tuples
- Aggregates to centralized replay buffer
- Load balancing and fault tolerance
"""

import logging
import time
import asyncio
import random
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from pathlib import Path
import multiprocessing as mp
from concurrent.futures import ThreadPoolExecutor, Future
import queue

from tpu_cluster_manager import (
    TPUGridManager,
    JobType,
    get_tpu_grid
)
from neural_network import AlphaZeroNetwork, ModelManager
from self_play import SelfPlayManager

logger = logging.getLogger(__name__)


@dataclass
class SelfPlayTask:
    """Self-play task specification"""
    task_id: str
    num_games: int
    num_simulations: int
    model_path: str
    assigned_tpus: List[int]
    priority: int = 5
    
    # Execution tracking
    games_completed: int = 0
    positions_generated: int = 0
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    status: str = "pending"  # pending, running, completed, failed


class DistributedSelfPlayManager:
    """
    Manages distributed self-play across 5000-TPU grid
    
    Architecture:
    - Splits self-play workload into tasks
    - Allocates TPU pods for each task
    - Physical workers execute on behalf of logical TPUs
    - Aggregates results to replay buffer
    
    Example:
        manager = DistributedSelfPlayManager(grid, num_workers=32)
        positions = await manager.generate_selfplay_games(
            num_games=10000,
            num_tpus=1000
        )
    """
    
    def __init__(
        self,
        tpu_grid: TPUGridManager,
        num_physical_workers: int = 32,
        games_per_task: int = 100
    ):
        """
        Initialize distributed self-play manager
        
        Args:
            tpu_grid: TPU grid manager instance
            num_physical_workers: Actual worker processes (8-64)
            games_per_task: Games per TPU allocation
        """
        self.tpu_grid = tpu_grid
        self.num_physical_workers = num_physical_workers
        self.games_per_task = games_per_task
        
        # Task management
        self.tasks: Dict[str, SelfPlayTask] = {}
        self.active_tasks: List[str] = []
        
        # Physical worker pool (executes tasks for logical TPUs)
        self.worker_pool = ThreadPoolExecutor(max_workers=num_physical_workers)
        self.result_queue = queue.Queue()
        
        # Model manager
        self.model_manager = ModelManager()
        
        # Metrics
        self.total_games_generated = 0
        self.total_positions_collected = 0
        self.total_tpu_hours = 0.0
        
        logger.info(f"Distributed Self-Play Manager initialized: "
                   f"{num_physical_workers} physical workers, "
                   f"{games_per_task} games/task")
    
    def generate_selfplay_games(
        self,
        num_games: int,
        num_tpus: int,
        num_simulations: int = 800,
        model_name: str = "ActiveModel",
        priority: int = 5
    ) -> Tuple[List[Dict], List[Dict]]:
        """
        Generate self-play games across TPU grid
        
        Args:
            num_games: Total games to generate
            num_tpus: Number of TPUs to allocate
            num_simulations: MCTS simulations per move
            model_name: Model to use for self-play
            priority: Job priority (1-10)
        
        Returns:
            (training_positions, game_results)
        """
        logger.info("="*80)
        logger.info(f"DISTRIBUTED SELF-PLAY GENERATION")
        logger.info(f"Total Games: {num_games:,}")
        logger.info(f"TPU Allocation: {num_tpus:,} cores")
        logger.info(f"Physical Workers: {self.num_physical_workers}")
        logger.info("="*80)
        
        start_time = time.time()
        
        # Load model path
        model_path = self.model_manager.get_model_path(model_name)
        if not model_path.exists():
            raise FileNotFoundError(f"Model not found: {model_name}")
        
        # Create tasks (distribute games across TPU allocation)
        tasks = self._create_selfplay_tasks(
            num_games=num_games,
            num_tpus=num_tpus,
            num_simulations=num_simulations,
            model_path=str(model_path),
            priority=priority
        )
        
        logger.info(f"Created {len(tasks)} self-play tasks")
        
        # Execute tasks using physical workers
        all_positions = []
        all_results = []
        
        futures = []
        for task in tasks:
            future = self.worker_pool.submit(
                self._execute_selfplay_task,
                task
            )
            futures.append((task.task_id, future))
        
        # Collect results
        completed = 0
        for task_id, future in futures:
            try:
                positions, results = future.result(timeout=3600)  # 1 hour timeout
                all_positions.extend(positions)
                all_results.extend(results)
                completed += 1
                
                # Release TPUs
                self.tpu_grid.release_tpus(task_id)
                
                if completed % 10 == 0:
                    logger.info(f"Progress: {completed}/{len(tasks)} tasks completed")
            
            except Exception as e:
                logger.error(f"Task {task_id} failed: {e}")
                # Release TPUs even on failure
                self.tpu_grid.release_tpus(task_id)
        
        total_time = time.time() - start_time
        
        # Update metrics
        self.total_games_generated += len(all_results)
        self.total_positions_collected += len(all_positions)
        self.total_tpu_hours += (total_time / 3600.0) * num_tpus
        
        logger.info("="*80)
        logger.info(f"✅ DISTRIBUTED SELF-PLAY COMPLETE")
        logger.info(f"Games: {len(all_results):,}")
        logger.info(f"Positions: {len(all_positions):,}")
        logger.info(f"Time: {total_time:.2f}s")
        logger.info(f"Throughput: {len(all_results)/total_time:.2f} games/sec")
        logger.info(f"TPU Hours: {self.total_tpu_hours:.2f}")
        logger.info("="*80)
        
        return all_positions, all_results
    
    def _create_selfplay_tasks(
        self,
        num_games: int,
        num_tpus: int,
        num_simulations: int,
        model_path: str,
        priority: int
    ) -> List[SelfPlayTask]:
        """
        Create self-play tasks and allocate TPUs
        
        Strategy: Divide games across TPU allocation
        Each task gets subset of TPUs and proportional games
        """
        tasks = []
        
        # Calculate tasks based on TPU allocation
        # Aim for ~8-16 TPUs per task for good locality
        tpus_per_task = min(16, max(8, num_tpus // 20))
        num_tasks = max(1, num_tpus // tpus_per_task)
        
        games_per_task = num_games // num_tasks
        tpus_per_task_actual = num_tpus // num_tasks
        
        for task_idx in range(num_tasks):
            task_id = f"selfplay_{int(time.time())}_{task_idx}"
            
            # Allocate TPUs for this task
            success, assigned_tpus = self.tpu_grid.allocate_tpus(
                job_id=task_id,
                job_type=JobType.SELFPLAY,
                num_tpus=tpus_per_task_actual,
                priority=priority
            )
            
            if not success:
                logger.warning(f"Task {task_id} queued - waiting for TPUs")
            
            # Create task
            task = SelfPlayTask(
                task_id=task_id,
                num_games=games_per_task,
                num_simulations=num_simulations,
                model_path=model_path,
                assigned_tpus=assigned_tpus,
                priority=priority
            )
            
            tasks.append(task)
            self.tasks[task_id] = task
        
        return tasks
    
    def _execute_selfplay_task(
        self,
        task: SelfPlayTask
    ) -> Tuple[List[Dict], List[Dict]]:
        """
        Execute self-play task on physical worker
        
        This function runs in worker thread pool.
        Simulates execution on behalf of assigned logical TPUs.
        
        Args:
            task: Self-play task specification
        
        Returns:
            (training_positions, game_results)
        """
        logger.info(f"[Task-{task.task_id}] Starting self-play: "
                   f"{task.num_games} games, {len(task.assigned_tpus)} TPUs")
        
        task.start_time = time.time()
        task.status = "running"
        
        try:
            # Load model
            model_name = Path(task.model_path).stem
            network, metadata = self.model_manager.load_model(model_name)
            
            if network is None:
                raise ValueError(f"Failed to load model: {model_name}")
            
            network.eval()
            
            # Create self-play manager
            selfplay_manager = SelfPlayManager(
                network,
                num_simulations=task.num_simulations
            )
            
            # Generate games
            all_positions = []
            all_results = []
            
            for game_idx in range(task.num_games):
                try:
                    positions, result = selfplay_manager.generate_single_game(store_fen=True)
                    
                    all_positions.extend(positions)
                    all_results.append(result)
                    
                    task.games_completed += 1
                    task.positions_generated += len(positions)
                    
                    # Log progress
                    if (game_idx + 1) % 25 == 0:
                        elapsed = time.time() - task.start_time
                        rate = task.games_completed / elapsed if elapsed > 0 else 0
                        logger.info(f"[Task-{task.task_id}] Progress: {game_idx+1}/{task.num_games} "
                                   f"({rate:.2f} games/sec)")
                
                except Exception as e:
                    logger.error(f"[Task-{task.task_id}] Game {game_idx} failed: {e}")
                    continue
            
            task.end_time = time.time()
            task.status = "completed"
            
            duration = task.end_time - task.start_time
            logger.info(f"[Task-{task.task_id}] Completed: {task.games_completed} games, "
                       f"{task.positions_generated} positions in {duration:.2f}s")
            
            return all_positions, all_results
        
        except Exception as e:
            task.status = "failed"
            logger.error(f"[Task-{task.task_id}] Fatal error: {e}")
            import traceback
            traceback.print_exc()
            return [], []
    
    def get_selfplay_status(self) -> Dict:
        """Get current self-play status across grid"""
        active_tasks = [t for t in self.tasks.values() if t.status == "running"]
        completed_tasks = [t for t in self.tasks.values() if t.status == "completed"]
        
        total_games = sum(t.games_completed for t in self.tasks.values())
        total_positions = sum(t.positions_generated for t in self.tasks.values())
        
        return {
            'active_tasks': len(active_tasks),
            'completed_tasks': len(completed_tasks),
            'total_tasks': len(self.tasks),
            'total_games': total_games,
            'total_positions': total_positions,
            'total_tpu_hours': round(self.total_tpu_hours, 2),
            'physical_workers': self.num_physical_workers
        }
    
    def get_task_details(self, task_id: str) -> Optional[Dict]:
        """Get details for specific task"""
        if task_id not in self.tasks:
            return None
        
        task = self.tasks[task_id]
        
        return {
            'task_id': task.task_id,
            'status': task.status,
            'num_games': task.num_games,
            'games_completed': task.games_completed,
            'positions_generated': task.positions_generated,
            'assigned_tpus': len(task.assigned_tpus),
            'start_time': task.start_time,
            'end_time': task.end_time,
            'duration_sec': (task.end_time - task.start_time) if task.end_time else None
        }
    
    def cleanup(self):
        """Cleanup resources"""
        self.worker_pool.shutdown(wait=True)
        logger.info("Distributed self-play manager cleaned up")


# Global instance
_distributed_selfplay_manager = None


def get_distributed_selfplay_manager(
    tpu_grid: Optional[TPUGridManager] = None,
    num_workers: int = 32
) -> DistributedSelfPlayManager:
    """Get or create distributed self-play manager"""
    global _distributed_selfplay_manager
    
    if _distributed_selfplay_manager is None:
        if tpu_grid is None:
            tpu_grid = get_tpu_grid()
        
        _distributed_selfplay_manager = DistributedSelfPlayManager(
            tpu_grid=tpu_grid,
            num_physical_workers=num_workers
        )
    
    return _distributed_selfplay_manager
