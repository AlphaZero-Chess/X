"""
Cloud Job Scheduler - Priority-Aware Job Orchestration

Features:
- Named priority levels (HIGH/MEDIUM/LOW)
- Region-aware resource allocation
- Job preemption support
- Queue management with priority sorting
- Integration with Cloud Cluster Controller
- Resource reservation and scheduling
"""

import time
import uuid
import logging
import threading
from collections import deque, defaultdict
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field, asdict
from enum import Enum
from datetime import datetime, timezone
import heapq

logger = logging.getLogger(__name__)


class JobPriority(Enum):
    """Named job priority levels with numeric weights"""
    HIGH = 10
    MEDIUM = 5
    LOW = 1
    
    @classmethod
    def from_string(cls, priority_str: str):
        """Convert string to priority enum"""
        mapping = {
            'high': cls.HIGH,
            'medium': cls.MEDIUM,
            'low': cls.LOW
        }
        return mapping.get(priority_str.lower(), cls.MEDIUM)


class JobStatus(Enum):
    """Job lifecycle status"""
    PENDING = "pending"
    QUEUED = "queued"
    SCHEDULED = "scheduled"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    PREEMPTED = "preempted"
    CANCELLED = "cancelled"


class JobType(Enum):
    """AlphaZero job types"""
    SELFPLAY = "selfplay"
    TRAINING = "training"
    EVALUATION = "evaluation"
    INFERENCE = "inference"


@dataclass
class ResourceRequest:
    """Resource requirements for a job"""
    num_tpus: int
    preferred_regions: List[str] = field(default_factory=list)  # Empty = any region
    min_memory_gb: float = 16.0
    max_latency_ms: float = 100.0
    require_healthy_nodes: bool = True


@dataclass
class JobSpec:
    """Complete job specification"""
    job_id: str
    job_type: JobType
    priority: JobPriority
    resource_request: ResourceRequest
    
    # Metadata
    job_name: str = ""
    owner: str = "system"
    created_at: float = field(default_factory=time.time)
    
    # Scheduling state
    status: JobStatus = JobStatus.PENDING
    scheduled_at: Optional[float] = None
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    
    # Resource allocation
    assigned_nodes: List[str] = field(default_factory=list)
    assigned_region: Optional[str] = None
    
    # Execution tracking
    attempts: int = 0
    max_attempts: int = 3
    preempted_count: int = 0
    error_message: Optional[str] = None
    
    # Estimated runtime (for scheduling)
    estimated_duration_sec: float = 0.0
    actual_duration_sec: float = 0.0
    
    def to_dict(self) -> Dict:
        return {
            'job_id': self.job_id,
            'job_name': self.job_name,
            'job_type': self.job_type.value,
            'priority': self.priority.name,
            'priority_weight': self.priority.value,
            'status': self.status.value,
            'owner': self.owner,
            'resource_request': {
                'num_tpus': self.resource_request.num_tpus,
                'preferred_regions': self.resource_request.preferred_regions,
                'max_latency_ms': self.resource_request.max_latency_ms
            },
            'assigned_nodes': self.assigned_nodes,
            'assigned_region': self.assigned_region,
            'created_at': self.created_at,
            'scheduled_at': self.scheduled_at,
            'started_at': self.started_at,
            'completed_at': self.completed_at,
            'attempts': self.attempts,
            'preempted_count': self.preempted_count,
            'estimated_duration_sec': self.estimated_duration_sec,
            'actual_duration_sec': self.actual_duration_sec,
            'error_message': self.error_message
        }
    
    def __lt__(self, other):
        """For heap-based priority queue (higher priority = lower value for min-heap)"""
        # Negate priority value so higher priority comes first
        return -self.priority.value < -other.priority.value


class CloudJobScheduler:
    """
    Priority-Aware Cloud Job Scheduler
    
    Manages job lifecycle:
    1. Job submission → PENDING
    2. Queue admission → QUEUED
    3. Resource allocation → SCHEDULED
    4. Execution → RUNNING
    5. Completion → COMPLETED/FAILED
    
    Features:
    - Priority-based scheduling (HIGH > MEDIUM > LOW)
    - Region-aware resource allocation
    - Job preemption for higher-priority jobs
    - Fair scheduling within same priority
    - Automatic retry on failure
    """
    
    def __init__(self, cloud_controller):
        """
        Initialize Cloud Job Scheduler
        
        Args:
            cloud_controller: CloudClusterController instance
        """
        self.cloud_controller = cloud_controller
        
        logger.info("="*80)
        logger.info("INITIALIZING CLOUD JOB SCHEDULER")
        logger.info("Priority Levels: HIGH (10) > MEDIUM (5) > LOW (1)")
        logger.info("="*80)
        
        # Job storage
        self.jobs: Dict[str, JobSpec] = {}
        
        # Priority queue (min-heap with negated priorities)
        self.job_queue: List[JobSpec] = []  # heapq
        
        # Active jobs
        self.active_jobs: Dict[str, JobSpec] = {}
        
        # Completed jobs history (limited)
        self.completed_jobs: deque = deque(maxlen=1000)
        
        # Statistics
        self.total_jobs_submitted = 0
        self.total_jobs_completed = 0
        self.total_jobs_failed = 0
        self.total_jobs_preempted = 0
        self.total_jobs_cancelled = 0
        
        # Scheduling metrics
        self.avg_queue_time_sec = 0.0
        self.avg_scheduling_time_sec = 0.0
        
        # Thread safety
        self.lock = threading.RLock()
        
        # Scheduler thread
        self.scheduler_thread = None
        self.scheduler_interval = 2  # seconds
        self.running = False
        
        # Start scheduler
        self.start_scheduler()
        
        logger.info("✅ Cloud Job Scheduler initialized")
    
    def submit_job(
        self,
        job_type: JobType,
        priority: JobPriority,
        num_tpus: int,
        job_name: str = "",
        owner: str = "system",
        preferred_regions: List[str] = None,
        estimated_duration_sec: float = 0.0
    ) -> str:
        """
        Submit a new job to the scheduler
        
        Args:
            job_type: Type of job (SELFPLAY, TRAINING, etc.)
            priority: Job priority (HIGH, MEDIUM, LOW)
            num_tpus: Number of TPUs required
            job_name: Human-readable job name
            owner: Job owner/submitter
            preferred_regions: List of preferred regions
            estimated_duration_sec: Estimated runtime
        
        Returns:
            job_id: Unique job identifier
        """
        with self.lock:
            job_id = f"{job_type.value}-{uuid.uuid4().hex[:8]}"
            
            resource_request = ResourceRequest(
                num_tpus=num_tpus,
                preferred_regions=preferred_regions or []
            )
            
            job = JobSpec(
                job_id=job_id,
                job_type=job_type,
                priority=priority,
                resource_request=resource_request,
                job_name=job_name or f"{job_type.value}-job",
                owner=owner,
                estimated_duration_sec=estimated_duration_sec,
                status=JobStatus.PENDING
            )
            
            self.jobs[job_id] = job
            
            # Add to priority queue
            heapq.heappush(self.job_queue, job)
            job.status = JobStatus.QUEUED
            
            self.total_jobs_submitted += 1
            
            logger.info(f"✅ Job submitted: {job_id} ({job_type.value}, priority={priority.name}, TPUs={num_tpus})")
            
            return job_id
    
    def cancel_job(self, job_id: str) -> bool:
        """Cancel a job"""
        with self.lock:
            if job_id not in self.jobs:
                return False
            
            job = self.jobs[job_id]
            
            if job.status in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED]:
                return False
            
            # Remove from queue if queued
            if job.status == JobStatus.QUEUED:
                self.job_queue = [j for j in self.job_queue if j.job_id != job_id]
                heapq.heapify(self.job_queue)
            
            # Release resources if running
            if job.status == JobStatus.RUNNING and job.assigned_nodes:
                self._release_resources(job)
            
            job.status = JobStatus.CANCELLED
            job.completed_at = time.time()
            
            self.total_jobs_cancelled += 1
            self.completed_jobs.append(job)
            
            logger.info(f"❌ Job cancelled: {job_id}")
            
            return True
    
    def get_job_status(self, job_id: str) -> Optional[Dict]:
        """Get job status"""
        with self.lock:
            if job_id not in self.jobs:
                # Check completed jobs
                for job in self.completed_jobs:
                    if job.job_id == job_id:
                        return job.to_dict()
                return None
            
            return self.jobs[job_id].to_dict()
    
    def list_jobs(
        self,
        status: Optional[JobStatus] = None,
        priority: Optional[JobPriority] = None
    ) -> List[Dict]:
        """List jobs with optional filters"""
        with self.lock:
            jobs = list(self.jobs.values()) + list(self.completed_jobs)
            
            if status:
                jobs = [j for j in jobs if j.status == status]
            
            if priority:
                jobs = [j for j in jobs if j.priority == priority]
            
            # Sort by creation time (newest first)
            jobs.sort(key=lambda j: j.created_at, reverse=True)
            
            return [j.to_dict() for j in jobs[:100]]  # Limit to 100
    
    def start_scheduler(self):
        """Start background scheduler thread"""
        if self.scheduler_thread and self.scheduler_thread.is_alive():
            return
        
        self.running = True
        self.scheduler_thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True
        )
        self.scheduler_thread.start()
        logger.info("Job scheduler started")
    
    def stop_scheduler(self):
        """Stop scheduler"""
        self.running = False
        if self.scheduler_thread:
            self.scheduler_thread.join(timeout=5)
        logger.info("Job scheduler stopped")
    
    def _scheduler_loop(self):
        """Background scheduling loop"""
        while self.running:
            try:
                self._schedule_jobs()
                time.sleep(self.scheduler_interval)
            except Exception as e:
                logger.error(f"Scheduler error: {e}")
                import traceback
                traceback.print_exc()
    
    def _schedule_jobs(self):
        """Attempt to schedule queued jobs"""
        with self.lock:
            if not self.job_queue:
                return
            
            # Process jobs in priority order
            scheduled_jobs = []
            
            while self.job_queue:
                # Peek at highest priority job
                job = heapq.heappop(self.job_queue)
                
                if job.status != JobStatus.QUEUED:
                    continue
                
                # Try to allocate resources
                allocated = self._try_allocate_resources(job)
                
                if allocated:
                    job.status = JobStatus.SCHEDULED
                    job.scheduled_at = time.time()
                    
                    # Start execution
                    self._start_job_execution(job)
                    
                    scheduled_jobs.append(job)
                else:
                    # Put back in queue
                    heapq.heappush(self.job_queue, job)
                    break  # Stop if we can't schedule highest priority job
            
            if scheduled_jobs:
                logger.info(f"📅 Scheduled {len(scheduled_jobs)} jobs")
    
    def _try_allocate_resources(self, job: JobSpec) -> bool:
        """
        Try to allocate resources for a job
        
        Args:
            job: Job to allocate resources for
        
        Returns:
            Success status
        """
        resource_req = job.resource_request
        
        # Find available nodes
        available_nodes = self._find_available_nodes(
            num_tpus=resource_req.num_tpus,
            preferred_regions=resource_req.preferred_regions,
            max_latency_ms=resource_req.max_latency_ms,
            require_healthy=resource_req.require_healthy_nodes
        )
        
        if len(available_nodes) >= resource_req.num_tpus:
            # Allocate nodes
            job.assigned_nodes = [node.node_id for node in available_nodes[:resource_req.num_tpus]]
            
            # Determine primary region
            region_counts = defaultdict(int)
            for node in available_nodes[:resource_req.num_tpus]:
                region_counts[node.region.value] += 1
            
            job.assigned_region = max(region_counts.items(), key=lambda x: x[1])[0]
            
            logger.info(f"  ✅ Allocated {len(job.assigned_nodes)} nodes to job {job.job_id} in region {job.assigned_region}")
            
            return True
        
        return False
    
    def _find_available_nodes(self, num_tpus: int, preferred_regions: List[str],
                              max_latency_ms: float, require_healthy: bool) -> List:
        """
        Find available nodes matching requirements
        
        Returns list of CloudNode objects
        """
        from cloud_cluster_controller import NodeHealth
        
        available = []
        
        # Get all nodes
        all_nodes = list(self.cloud_controller.nodes.values())
        
        # Filter by health
        if require_healthy:
            all_nodes = [n for n in all_nodes if n.health == NodeHealth.HEALTHY]
        
        # Filter by latency
        all_nodes = [n for n in all_nodes if n.current_latency_ms <= max_latency_ms]
        
        # Filter by region preference
        if preferred_regions:
            preferred = [n for n in all_nodes if n.region.value in preferred_regions]
            if len(preferred) >= num_tpus:
                all_nodes = preferred
        
        # Check if nodes are idle (not in active jobs)
        active_node_ids = set()
        for active_job in self.active_jobs.values():
            active_node_ids.update(active_job.assigned_nodes)
        
        for node in all_nodes:
            if node.node_id not in active_node_ids:
                available.append(node)
                
                if len(available) >= num_tpus:
                    break
        
        return available
    
    def _start_job_execution(self, job: JobSpec):
        """Start job execution"""
        job.status = JobStatus.RUNNING
        job.started_at = time.time()
        job.attempts += 1
        
        self.active_jobs[job.job_id] = job
        
        logger.info(f"▶️ Job started: {job.job_id} ({job.job_type.value}, priority={job.priority.name})")
    
    def complete_job(self, job_id: str, success: bool = True, error_message: str = None):
        """Mark job as completed"""
        with self.lock:
            if job_id not in self.jobs:
                return
            
            job = self.jobs[job_id]
            
            job.completed_at = time.time()
            
            if job.started_at:
                job.actual_duration_sec = job.completed_at - job.started_at
            
            if success:
                job.status = JobStatus.COMPLETED
                self.total_jobs_completed += 1
                logger.info(f"✅ Job completed: {job_id} (duration: {job.actual_duration_sec:.1f}s)")
            else:
                job.status = JobStatus.FAILED
                job.error_message = error_message
                self.total_jobs_failed += 1
                logger.error(f"❌ Job failed: {job_id} - {error_message}")
            
            # Release resources
            if job.assigned_nodes:
                self._release_resources(job)
            
            # Remove from active jobs
            if job_id in self.active_jobs:
                del self.active_jobs[job_id]
            
            # Add to completed history
            self.completed_jobs.append(job)
            
            # Remove from main jobs dict (keep in completed history)
            del self.jobs[job_id]
    
    def _release_resources(self, job: JobSpec):
        """Release resources allocated to job"""
        logger.info(f"  Released {len(job.assigned_nodes)} nodes from job {job.job_id}")
        job.assigned_nodes = []
        job.assigned_region = None
    
    def get_queue_stats(self) -> Dict:
        """Get queue statistics"""
        with self.lock:
            # Count by priority
            priority_counts = defaultdict(int)
            for job in self.job_queue:
                priority_counts[job.priority.name] += 1
            
            # Count by status
            status_counts = defaultdict(int)
            for job in self.jobs.values():
                status_counts[job.status.value] += 1
            
            return {
                'queue_length': len(self.job_queue),
                'active_jobs': len(self.active_jobs),
                'priority_breakdown': dict(priority_counts),
                'status_breakdown': dict(status_counts),
                'total_submitted': self.total_jobs_submitted,
                'total_completed': self.total_jobs_completed,
                'total_failed': self.total_jobs_failed,
                'total_preempted': self.total_jobs_preempted,
                'total_cancelled': self.total_jobs_cancelled,
                'avg_queue_time_sec': round(self.avg_queue_time_sec, 2),
                'timestamp': datetime.now(timezone.utc).isoformat()
            }


# Global instance
_job_scheduler = None


def get_job_scheduler(cloud_controller=None) -> CloudJobScheduler:
    """Get or create global job scheduler"""
    global _job_scheduler
    
    if _job_scheduler is None:
        if cloud_controller is None:
            from cloud_cluster_controller import get_cloud_controller
            cloud_controller = get_cloud_controller()
        
        _job_scheduler = CloudJobScheduler(cloud_controller)
    
    return _job_scheduler


def reset_job_scheduler():
    """Reset global scheduler (for testing)"""
    global _job_scheduler
    if _job_scheduler:
        _job_scheduler.stop_scheduler()
    _job_scheduler = None
