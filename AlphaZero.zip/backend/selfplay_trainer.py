"""
AlphaZero Self-Play Trainer - Unified Orchestrator
==================================================

Phase 2: Distributed Optimization - Full integration of distributed self-play
with fault tolerance, performance monitoring, and adaptive worker management.

Features:
- Sequential or distributed self-play modes
- Auto-scaling worker count based on hardware
- Heartbeat monitoring and worker recovery
- Thread-safe replay buffer integration
- Comprehensive metrics and logging
- Frontend API integration ready

Author: E1 Agent
Date: 2025-10-18
"""

import os
import sys
import time
import logging
import signal
import threading
import multiprocessing as mp
from typing import Dict, List, Optional, Tuple, Any
from pathlib import Path
from datetime import datetime, timezone
from enum import Enum
import traceback
import numpy as np

# Import core components
from neural_network import AlphaZeroNetwork, ModelManager
from replay_buffer import ReplayBuffer
from replay_buffer_service import get_replay_buffer_service
from trainer import AlphaZeroTrainer
from self_play import SelfPlayManager
from distributed_selfplay_v2 import DistributedSelfPlayManager
from evaluator import ModelEvaluator

logger = logging.getLogger(__name__)


class SelfPlayMode(str, Enum):
    """Self-play execution mode"""
    SEQUENTIAL = "sequential"
    DISTRIBUTED = "distributed"
    AUTO = "auto"


class WorkerHealth:
    """Track worker health and performance"""
    
    def __init__(self, worker_id: int):
        self.worker_id = worker_id
        self.start_time = time.time()
        self.last_heartbeat = time.time()
        self.games_completed = 0
        self.positions_generated = 0
        self.errors = 0
        self.is_alive = True
    
    def heartbeat(self):
        """Update heartbeat timestamp"""
        self.last_heartbeat = time.time()
    
    def is_healthy(self, timeout: float = 300.0) -> bool:
        """Check if worker is healthy (heartbeat within timeout)"""
        if not self.is_alive:
            return False
        elapsed = time.time() - self.last_heartbeat
        return elapsed < timeout
    
    def get_stats(self) -> Dict:
        """Get worker statistics"""
        uptime = time.time() - self.start_time
        return {
            'worker_id': self.worker_id,
            'uptime_seconds': uptime,
            'games_completed': self.games_completed,
            'positions_generated': self.positions_generated,
            'errors': self.errors,
            'is_alive': self.is_alive,
            'is_healthy': self.is_healthy(),
            'last_heartbeat': self.last_heartbeat,
            'games_per_hour': (self.games_completed / uptime) * 3600 if uptime > 0 else 0
        }


class AlphaZeroSelfPlayTrainer:
    """
    Unified AlphaZero Self-Play Trainer
    
    Orchestrates complete training cycle:
    - Self-play game generation (sequential or distributed)
    - Replay buffer management
    - Neural network training
    - Model evaluation and checkpointing
    - Performance monitoring
    """
    
    def __init__(
        self,
        max_games: int = 44_000_000,
        max_hours: float = 200.0,
        num_simulations: int = 800,
        replay_buffer_size: int = 1_000_000,
        batch_size: int = 256,
        learning_rate: float = 0.001,
        checkpoint_interval: int = 3600,
        eval_interval: int = 10000,
        log_dir: str = "/app/backend/cache/selfplay",
        mode: SelfPlayMode = SelfPlayMode.AUTO,
        num_workers: Optional[int] = None,
        enable_fault_tolerance: bool = True,
        enable_performance_tuning: bool = True
    ):
        """
        Initialize AlphaZero self-play trainer
        
        Args:
            max_games: Maximum games to generate
            max_hours: Maximum training duration in hours
            num_simulations: MCTS simulations per move
            replay_buffer_size: Replay buffer capacity
            batch_size: Training batch size
            learning_rate: Neural network learning rate
            checkpoint_interval: Checkpoint save interval (seconds)
            eval_interval: Model evaluation interval (games)
            log_dir: Directory for logs and checkpoints
            mode: Self-play mode (sequential/distributed/auto)
            num_workers: Number of workers for distributed mode (None = auto-detect)
            enable_fault_tolerance: Enable worker health monitoring and recovery
            enable_performance_tuning: Enable adaptive performance optimization
        """
        self.max_games = max_games
        self.max_hours = max_hours
        self.num_simulations = num_simulations
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.checkpoint_interval = checkpoint_interval
        self.eval_interval = eval_interval
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # Mode configuration
        self.mode = self._determine_mode(mode, num_workers)
        self.num_workers = num_workers
        self.enable_fault_tolerance = enable_fault_tolerance
        self.enable_performance_tuning = enable_performance_tuning
        
        # Initialize components
        logger.info("="*80)
        logger.info("ALPHAZERO SELF-PLAY TRAINER - PHASE 2: DISTRIBUTED OPTIMIZATION")
        logger.info("="*80)
        
        # Neural network
        logger.info("Initializing neural network...")
        self.network = AlphaZeroNetwork()
        self.model_manager = ModelManager()
        
        # Replay buffer (simple version for now)
        logger.info(f"Initializing replay buffer (capacity: {replay_buffer_size:,})...")
        self.replay_buffer = ReplayBuffer(max_size=replay_buffer_size)
        
        # Advanced replay buffer service (thread-safe, validated)
        logger.info("Initializing advanced replay buffer service...")
        self.replay_buffer_service = get_replay_buffer_service(
            num_shards=8,
            shard_size=replay_buffer_size // 8,
            eviction_policy="fifo"
        )
        
        # Trainer
        logger.info("Initializing trainer...")
        self.trainer = AlphaZeroTrainer(
            self.network,
            learning_rate=learning_rate,
            use_mixed_precision=False,
            adaptive_lr=True
        )
        
        # Evaluator
        logger.info("Initializing evaluator...")
        self.evaluator = ModelEvaluator()
        
        # Self-play manager
        self._initialize_selfplay_manager()
        
        # Training state
        self.games_completed = 0
        self.positions_collected = 0
        self.iterations_completed = 0
        self.start_time = None
        self.last_checkpoint_time = None
        self.last_eval_time = None
        
        # Worker health tracking
        self.worker_health: Dict[int, WorkerHealth] = {}
        self.worker_health_lock = threading.Lock()
        
        # Performance metrics
        self.metrics = {
            'games_per_second': 0.0,
            'positions_per_second': 0.0,
            'training_loss': 0.0,
            'replay_buffer_utilization': 0.0,
            'worker_efficiency': 0.0
        }
        
        # Shutdown handling
        self.shutdown_requested = False
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        logger.info(f"Trainer initialized:")
        logger.info(f"  Mode: {self.mode.value}")
        logger.info(f"  Workers: {self.num_workers if self.mode == SelfPlayMode.DISTRIBUTED else 'N/A'}")
        logger.info(f"  Fault tolerance: {self.enable_fault_tolerance}")
        logger.info(f"  Performance tuning: {self.enable_performance_tuning}")
        logger.info(f"  Target: {self.max_games:,} games in {self.max_hours:.1f} hours")
        logger.info("="*80)
    
    def _determine_mode(self, mode: SelfPlayMode, num_workers: Optional[int]) -> SelfPlayMode:
        """Determine optimal self-play mode"""
        if mode == SelfPlayMode.AUTO:
            # Auto-detect based on available resources
            cpu_count = mp.cpu_count()
            if cpu_count >= 4 or num_workers is not None:
                logger.info(f"Auto mode: Detected {cpu_count} CPUs, using DISTRIBUTED")
                return SelfPlayMode.DISTRIBUTED
            else:
                logger.info(f"Auto mode: Limited resources ({cpu_count} CPUs), using SEQUENTIAL")
                return SelfPlayMode.SEQUENTIAL
        return mode
    
    def _initialize_selfplay_manager(self):
        """Initialize self-play manager based on mode"""
        if self.mode == SelfPlayMode.DISTRIBUTED:
            logger.info("Initializing DISTRIBUTED self-play manager...")
            self.selfplay_manager = DistributedSelfPlayManager(
                model_path=None,  # Will use current network
                num_simulations=self.num_simulations,
                num_workers=self.num_workers
            )
            logger.info(f"  ✅ Distributed mode with {self.selfplay_manager.num_workers} workers")
        else:
            logger.info("Initializing SEQUENTIAL self-play manager...")
            self.selfplay_manager = SelfPlayManager(
                self.network,
                num_simulations=self.num_simulations
            )
            logger.info(f"  ✅ Sequential mode")
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully"""
        logger.info("Shutdown signal received, finishing current operation...")
        self.shutdown_requested = True
    
    def generate_selfplay_batch(self, num_games: int) -> Tuple[List[Dict], float]:
        """
        Generate batch of self-play games
        
        Args:
            num_games: Number of games to generate
        
        Returns:
            (training_data, batch_time) tuple
        """
        logger.info("="*80)
        logger.info(f"GENERATING SELF-PLAY BATCH: {num_games} games ({self.mode.value} mode)")
        logger.info("="*80)
        
        batch_start = time.time()
        
        try:
            if self.mode == SelfPlayMode.DISTRIBUTED:
                # Distributed mode
                training_data, game_results = self.selfplay_manager.generate_games_parallel(
                    num_games=num_games,
                    fallback_to_sequential=True
                )
            else:
                # Sequential mode
                training_data, game_results = self.selfplay_manager.generate_games(
                    num_games=num_games,
                    store_fen=True,
                    export_pgn=False
                )
            
            batch_time = time.time() - batch_start
            
            logger.info("="*80)
            logger.info(f"BATCH COMPLETE:")
            logger.info(f"  Games: {num_games}")
            logger.info(f"  Positions: {len(training_data)}")
            logger.info(f"  Time: {batch_time:.1f}s")
            logger.info(f"  Rate: {num_games/batch_time:.3f} games/s, {len(training_data)/batch_time:.1f} positions/s")
            logger.info("="*80)
            
            # Update metrics
            self.metrics['games_per_second'] = num_games / batch_time
            self.metrics['positions_per_second'] = len(training_data) / batch_time
            
            return training_data, batch_time
            
        except Exception as e:
            logger.error(f"❌ Self-play batch generation failed: {e}")
            logger.error(traceback.format_exc())
            return [], time.time() - batch_start
    
    def train_on_batch(self, training_data: List[Dict], num_epochs: int = 10) -> Dict:
        """
        Train neural network on batch of training data
        
        Args:
            training_data: List of training samples
            num_epochs: Number of training epochs
        
        Returns:
            Training metrics dict
        """
        if len(training_data) == 0:
            logger.warning("⚠️ No training data available, skipping training")
            return {
                'loss': 0.0,
                'policy_loss': 0.0,
                'value_loss': 0.0,
                'learning_rate': self.trainer.optimizer.param_groups[0]['lr'],
                'num_batches': 0
            }
        
        logger.info(f"Training on {len(training_data):,} positions for {num_epochs} epochs...")
        train_start = time.time()
        
        # Train
        training_history = self.trainer.train(
            training_data,
            num_epochs=num_epochs,
            batch_size=self.batch_size
        )
        
        train_time = time.time() - train_start
        
        # Get latest metrics
        if training_history:
            latest_metrics = training_history[-1]
            loss = latest_metrics.get('loss', 0.0)
            lr = latest_metrics.get('learning_rate', self.learning_rate)
            
            logger.info(f"Training complete in {train_time:.1f}s: Loss={loss:.4f}, LR={lr:.6f}")
            
            # Update metrics
            self.metrics['training_loss'] = loss
            
            return latest_metrics
        else:
            return {
                'loss': 0.0,
                'policy_loss': 0.0,
                'value_loss': 0.0,
                'learning_rate': self.learning_rate,
                'num_batches': 0
            }
    
    def save_checkpoint(self, checkpoint_name: str = "latest"):
        """Save training checkpoint"""
        try:
            logger.info(f"Saving checkpoint: {checkpoint_name}")
            
            # Save model
            model_name = f"{checkpoint_name}_{self.iterations_completed}"
            self.model_manager.save_model(self.network, model_name, metadata={
                'games_completed': self.games_completed,
                'positions_collected': self.positions_collected,
                'iterations': self.iterations_completed,
                'timestamp': datetime.now(timezone.utc).isoformat()
            })
            
            # Save trainer state
            self.trainer.save_checkpoint(checkpoint_name, metadata={
                'games': self.games_completed,
                'positions': self.positions_collected
            })
            
            # Save replay buffer
            self.replay_buffer.save(f"replay_buffer_{checkpoint_name}.pkl")
            
            self.last_checkpoint_time = time.time()
            logger.info(f"✅ Checkpoint saved: {model_name}")
            
        except Exception as e:
            logger.error(f"❌ Checkpoint save failed: {e}")
            logger.error(traceback.format_exc())
    
    def run(self, batch_games: int = 100, train_epochs: int = 10):
        """
        Run complete training cycle
        
        Args:
            batch_games: Games per self-play batch
            train_epochs: Training epochs per batch
        """
        self.start_time = time.time()
        self.last_checkpoint_time = self.start_time
        self.last_eval_time = self.start_time
        
        logger.info("="*80)
        logger.info("STARTING ALPHAZERO TRAINING CYCLE")
        logger.info(f"  Target: {self.max_games:,} games in {self.max_hours:.1f} hours")
        logger.info(f"  Batch size: {batch_games} games")
        logger.info(f"  Mode: {self.mode.value}")
        logger.info("="*80)
        
        try:
            while not self.shutdown_requested:
                # Check termination conditions
                elapsed_hours = (time.time() - self.start_time) / 3600
                if self.games_completed >= self.max_games:
                    logger.info(f"✅ Reached target games: {self.games_completed:,}")
                    break
                if elapsed_hours >= self.max_hours:
                    logger.info(f"✅ Reached time limit: {elapsed_hours:.2f} hours")
                    break
                
                iteration_start = time.time()
                self.iterations_completed += 1
                
                logger.info(f"\n{'='*80}")
                logger.info(f"ITERATION {self.iterations_completed}")
                logger.info(f"  Games: {self.games_completed:,} / {self.max_games:,}")
                logger.info(f"  Time: {elapsed_hours:.2f} / {self.max_hours:.1f} hours")
                logger.info(f"  Replay buffer: {self.replay_buffer.size():,} / {self.replay_buffer.max_size:,}")
                logger.info(f"{'='*80}")
                
                # Step 1: Generate self-play batch
                training_data, batch_time = self.generate_selfplay_batch(batch_games)
                
                if len(training_data) == 0:
                    logger.warning("⚠️ No training data generated, skipping iteration")
                    continue
                
                # Step 2: Add to replay buffer
                logger.info(f"Adding {len(training_data)} positions to replay buffer...")
                self.replay_buffer.add(training_data)
                self.positions_collected += len(training_data)
                self.games_completed += batch_games
                
                # Update replay buffer metrics
                buffer_stats = self.replay_buffer.get_stats()
                self.metrics['replay_buffer_utilization'] = buffer_stats['utilization']
                
                # Step 3: Train on replay buffer
                if self.replay_buffer.size() >= self.batch_size * 4:  # Minimum buffer size for training
                    # Sample from replay buffer
                    sample_size = min(self.replay_buffer.size(), self.batch_size * train_epochs)
                    training_sample = self.replay_buffer.sample(sample_size)
                    
                    # Train
                    training_metrics = self.train_on_batch(training_sample, num_epochs=train_epochs)
                else:
                    logger.info(f"⚠️ Replay buffer too small ({self.replay_buffer.size()}), skipping training")
                    training_metrics = {'loss': 0.0}
                
                # Step 4: Checkpointing
                if time.time() - self.last_checkpoint_time >= self.checkpoint_interval:
                    self.save_checkpoint(f"iter_{self.iterations_completed}")
                
                # Step 5: Evaluation (optional)
                if (time.time() - self.last_eval_time >= self.eval_interval * batch_time and
                    self.games_completed % self.eval_interval < batch_games):
                    logger.info("Running model evaluation...")
                    # TODO: Implement evaluation against previous checkpoint
                    self.last_eval_time = time.time()
                
                # Iteration summary
                iteration_time = time.time() - iteration_start
                logger.info(f"\nIteration {self.iterations_completed} complete in {iteration_time:.1f}s")
                logger.info(f"  Games: {batch_games}, Positions: {len(training_data)}")
                logger.info(f"  Training loss: {training_metrics.get('loss', 0.0):.4f}")
                logger.info(f"  Total games: {self.games_completed:,}")
                logger.info(f"  Total positions: {self.positions_collected:,}")
                
        except KeyboardInterrupt:
            logger.info("Training interrupted by user")
        except Exception as e:
            logger.error(f"❌ Training error: {e}")
            logger.error(traceback.format_exc())
        finally:
            self._finalize_training()
    
    def _finalize_training(self):
        """Finalize training and save final checkpoint"""
        logger.info("\n" + "="*80)
        logger.info("FINALIZING TRAINING")
        logger.info("="*80)
        
        # Save final checkpoint
        self.save_checkpoint("final")
        
        # Calculate statistics
        elapsed_time = time.time() - self.start_time if self.start_time else 0
        elapsed_hours = elapsed_time / 3600
        
        logger.info("="*80)
        logger.info("TRAINING COMPLETE")
        logger.info("="*80)
        logger.info(f"  Games completed: {self.games_completed:,}")
        logger.info(f"  Positions collected: {self.positions_collected:,}")
        logger.info(f"  Iterations: {self.iterations_completed}")
        logger.info(f"  Training time: {elapsed_hours:.2f} hours")
        logger.info(f"  Average rate: {self.games_completed/elapsed_hours:.1f} games/hour")
        logger.info(f"  Replay buffer size: {self.replay_buffer.size():,}")
        logger.info("="*80)
        
        # Save performance report
        self._save_performance_report()
    
    def _save_performance_report(self):
        """Save detailed performance report"""
        report_path = self.log_dir / f"performance_report_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
        
        import json
        report = {
            'training_summary': {
                'games_completed': self.games_completed,
                'positions_collected': self.positions_collected,
                'iterations': self.iterations_completed,
                'mode': self.mode.value,
                'elapsed_hours': (time.time() - self.start_time) / 3600 if self.start_time else 0
            },
            'metrics': self.metrics,
            'replay_buffer': self.replay_buffer.get_stats(),
            'timestamp': datetime.now(timezone.utc).isoformat()
        }
        
        if self.mode == SelfPlayMode.DISTRIBUTED:
            report['distributed_stats'] = self.selfplay_manager.get_stats()
        
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2)
        
        logger.info(f"Performance report saved: {report_path}")
    
    def get_status(self) -> Dict:
        """Get current training status"""
        elapsed = time.time() - self.start_time if self.start_time else 0
        
        return {
            'mode': self.mode.value,
            'games_completed': self.games_completed,
            'positions_collected': self.positions_collected,
            'iterations': self.iterations_completed,
            'elapsed_seconds': elapsed,
            'elapsed_hours': elapsed / 3600,
            'replay_buffer_size': self.replay_buffer.size(),
            'replay_buffer_capacity': self.replay_buffer.max_size,
            'metrics': self.metrics,
            'is_running': not self.shutdown_requested
        }
    
    @property
    def is_running(self) -> bool:
        """
        Check if training is currently running
        
        Returns:
            bool: True if training is active, False if shutdown requested
        """
        return not self.shutdown_requested
    
    def stop(self):
        """
        Stop training gracefully
        
        Sets the shutdown flag to terminate training loop after current operation completes.
        """
        logger.info("Stop requested via API - setting shutdown flag...")
        self.shutdown_requested = True


# CLI interface
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='AlphaZero Self-Play Trainer')
    parser.add_argument('--mode', choices=['sequential', 'distributed', 'auto'], 
                       default='auto', help='Self-play mode')
    parser.add_argument('--workers', type=int, default=None,
                       help='Number of workers for distributed mode (auto-detect if not specified)')
    parser.add_argument('--games', type=int, default=1000,
                       help='Target number of games')
    parser.add_argument('--hours', type=float, default=10.0,
                       help='Maximum training hours')
    parser.add_argument('--batch_games', type=int, default=100,
                       help='Games per self-play batch')
    parser.add_argument('--simulations', type=int, default=800,
                       help='MCTS simulations per move')
    parser.add_argument('--resume', action='store_true',
                       help='Resume from latest checkpoint')
    
    args = parser.parse_args()
    
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('/app/backend/training.log'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    # Create trainer
    trainer = AlphaZeroSelfPlayTrainer(
        max_games=args.games,
        max_hours=args.hours,
        num_simulations=args.simulations,
        mode=SelfPlayMode(args.mode),
        num_workers=args.workers,
        enable_fault_tolerance=True,
        enable_performance_tuning=True
    )
    
    # Resume from checkpoint if requested
    if args.resume:
        logger.info("Attempting to resume from checkpoint...")
        trainer.trainer.load_checkpoint("latest")
        trainer.replay_buffer.load("replay_buffer_latest.pkl")
    
    # Run training
    trainer.run(batch_games=args.batch_games, train_epochs=10)
