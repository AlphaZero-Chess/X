"""
AlphaZero Self-Play Training System
Implements full-scale 44M game / 9-hour training cycle with:
- Distributed parallel self-play
- Replay buffer (1M positions)
- Continuous training loop
- Periodic evaluation and model promotion
- Checkpoint system (every 30 minutes)
- Comprehensive logging
"""

import torch
import torch.optim as optim
import numpy as np
import logging
import time
import json
import signal
import sys
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Tuple
import math

from neural_network import AlphaZeroNetwork, ModelManager
from trainer import AlphaZeroTrainer
from evaluator import ModelEvaluator
from replay_buffer import ReplayBuffer
from distributed_selfplay import DistributedSelfPlayManager
from device_manager import device_manager

logger = logging.getLogger(__name__)

class AlphaZeroSelfPlayTrainer:
    """
    Main orchestrator for massive-scale AlphaZero training
    Handles 44M games / 9 hours continuous training cycle
    """
    
    def __init__(self,
                 max_games: int = 44_000_000,
                 max_hours: float = 9.0,
                 num_simulations: int = 800,
                 replay_buffer_size: int = 1_000_000,
                 batch_size: int = 256,
                 learning_rate: float = 0.001,
                 checkpoint_interval: int = 1800,  # 30 minutes
                 eval_interval: int = 1000,  # Every 1000 games
                 win_threshold: float = 0.55,
                 num_eval_games: int = 40,
                 log_dir: str = "/data/training_logs/selfplay_44M"):
        """
        Initialize AlphaZero self-play trainer
        
        Args:
            max_games: Maximum number of self-play games (44M)
            max_hours: Maximum training duration in hours (9)
            num_simulations: MCTS simulations per move (800)
            replay_buffer_size: Replay buffer capacity (1M positions)
            batch_size: Training batch size
            learning_rate: Initial learning rate
            checkpoint_interval: Checkpoint save interval in seconds (1800 = 30 min)
            eval_interval: Model evaluation interval in games
            win_threshold: Win rate threshold for model promotion (0.55)
            num_eval_games: Number of evaluation games
            log_dir: Directory for logs and checkpoints
        """
        self.max_games = max_games
        self.max_hours = max_hours
        self.max_seconds = int(max_hours * 3600)
        self.num_simulations = num_simulations
        self.batch_size = batch_size
        self.initial_lr = learning_rate
        self.checkpoint_interval = checkpoint_interval
        self.eval_interval = eval_interval
        self.win_threshold = win_threshold
        self.num_eval_games = num_eval_games
        
        # Setup logging directory
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_dir = self.log_dir / "checkpoints"
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize components
        self.network = AlphaZeroNetwork()
        self.model_manager = ModelManager()
        self.replay_buffer = ReplayBuffer(max_size=replay_buffer_size, checkpoint_dir=str(self.log_dir))
        
        # Optimizer with cosine annealing learning rate schedule
        self.optimizer = optim.Adam(self.network.parameters(), lr=self.initial_lr)
        
        # Calculate total training steps for cosine annealing
        # Estimate: ~40 positions per game, train every 100 games
        estimated_positions_per_game = 40
        estimated_training_cycles = max_games // 100
        estimated_batches_per_cycle = (estimated_positions_per_game * 100) // batch_size
        total_steps = estimated_training_cycles * estimated_batches_per_cycle
        
        self.scheduler = optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer, 
            T_max=total_steps,
            eta_min=learning_rate * 0.01
        )
        
        # Training state
        self.games_completed = 0
        self.positions_collected = 0
        self.training_steps = 0
        self.models_promoted = 0
        self.current_elo = 1500
        self.start_time = None
        self.last_checkpoint_time = None
        self.last_eval_game = 0
        self.running = False
        self.stop_requested = False
        
        # Current champion model
        self.champion_model = None
        self.champion_name = "model_v1"
        
        # Performance metrics
        self.metrics_history = []
        
        # Latest training metrics (for status polling)
        self.latest_training_metrics = {
            'loss': 0.0,
            'learning_rate': self.initial_lr
        }
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        logger.info(f"AlphaZero Trainer initialized:")
        logger.info(f"  Max games: {self.max_games:,}")
        logger.info(f"  Max duration: {self.max_hours} hours")
        logger.info(f"  MCTS simulations: {self.num_simulations}")
        logger.info(f"  Replay buffer: {replay_buffer_size:,} positions")
        logger.info(f"  Device: {device_manager.device_name}")
        logger.info(f"  Log directory: {self.log_dir}")
    
    def _signal_handler(self, signum, frame):
        """Handle graceful shutdown on SIGINT/SIGTERM"""
        logger.info(f"Received signal {signum}, initiating graceful shutdown...")
        self.stop_requested = True
    
    def save_checkpoint(self, checkpoint_name: str = "latest"):
        """Save complete training checkpoint"""
        try:
            checkpoint_path = self.checkpoint_dir / f"checkpoint_{checkpoint_name}.pt"
            
            checkpoint = {
                'network_state': self.network.state_dict(),
                'optimizer_state': self.optimizer.state_dict(),
                'scheduler_state': self.scheduler.state_dict(),
                'games_completed': self.games_completed,
                'positions_collected': self.positions_collected,
                'training_steps': self.training_steps,
                'models_promoted': self.models_promoted,
                'current_elo': self.current_elo,
                'champion_name': self.champion_name,
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'elapsed_time': time.time() - self.start_time if self.start_time else 0
            }
            
            torch.save(checkpoint, checkpoint_path)
            
            # Also save the network as a standalone model
            model_name = f"checkpoint_{self.games_completed//1000}k_games"
            self.model_manager.save_model(self.network, name=model_name, metadata={
                'games': self.games_completed,
                'elo': self.current_elo,
                'checkpoint': True
            })
            
            # Save replay buffer
            self.replay_buffer.save(f"replay_buffer_{checkpoint_name}.pkl")
            
            logger.info(f"Checkpoint saved: {checkpoint_path} (Games: {self.games_completed:,}, ELO: {self.current_elo:.0f})")
            
        except Exception as e:
            logger.error(f"Failed to save checkpoint: {e}")
    
    def load_checkpoint(self, checkpoint_name: str = "latest") -> bool:
        """Load training checkpoint to resume"""
        try:
            checkpoint_path = self.checkpoint_dir / f"checkpoint_{checkpoint_name}.pt"
            
            if not checkpoint_path.exists():
                logger.warning(f"Checkpoint not found: {checkpoint_path}")
                return False
            
            checkpoint = torch.load(checkpoint_path, map_location=device_manager.device, weights_only=False)
            
            self.network.load_state_dict(checkpoint['network_state'])
            self.optimizer.load_state_dict(checkpoint['optimizer_state'])
            self.scheduler.load_state_dict(checkpoint['scheduler_state'])
            self.games_completed = checkpoint['games_completed']
            self.positions_collected = checkpoint['positions_collected']
            self.training_steps = checkpoint['training_steps']
            self.models_promoted = checkpoint['models_promoted']
            self.current_elo = checkpoint['current_elo']
            self.champion_name = checkpoint['champion_name']
            
            # Load replay buffer
            self.replay_buffer.load(f"replay_buffer_{checkpoint_name}.pkl")
            
            logger.info(f"Checkpoint loaded: {checkpoint_path}")
            logger.info(f"  Resuming from game {self.games_completed:,}")
            logger.info(f"  Current ELO: {self.current_elo:.0f}")
            logger.info(f"  Replay buffer: {self.replay_buffer.size():,} positions")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to load checkpoint: {e}")
            return False
    
    def generate_selfplay_batch(self, num_games: int) -> Tuple[List[Dict], float]:
        """Generate a batch of self-play games using distributed workers"""
        start_time = time.time()
        
        # Save current model for workers to load
        temp_model_name = f"temp_selfplay_model_{int(time.time())}"
        temp_model_path = self.model_manager.save_model(self.network, name=temp_model_name)
        
        try:
            # Create distributed self-play manager
            distributed_manager = DistributedSelfPlayManager(
                model_path=temp_model_path,
                num_simulations=self.num_simulations
            )
            
            # Generate games in parallel
            training_data, game_results = distributed_manager.generate_games_parallel(num_games)
            
            # Cleanup workers
            distributed_manager.cleanup()
            
            elapsed = time.time() - start_time
            
            logger.info(f"Self-play batch complete: {num_games} games, {len(training_data)} positions in {elapsed:.1f}s")
            
            return training_data, elapsed
            
        finally:
            # Clean up temporary model
            try:
                self.model_manager.delete_model(temp_model_name)
            except:
                pass
    
    def train_on_batch(self, training_data: List[Dict], num_epochs: int = 1) -> Dict:
        """Train network on batch of positions"""
        if len(training_data) == 0:
            return {
                'loss': 0.0,
                'policy_loss': 0.0,
                'value_loss': 0.0,
                'learning_rate': self.scheduler.get_last_lr()[0] if self.scheduler else self.initial_lr,
                'num_batches': 0
            }
        
        self.network.train()
        
        total_loss = 0.0
        total_policy_loss = 0.0
        total_value_loss = 0.0
        num_batches = 0
        
        for epoch in range(num_epochs):
            # Shuffle data
            shuffled_data = training_data.copy()
            np.random.shuffle(shuffled_data)
            
            # Process in batches
            for i in range(0, len(shuffled_data), self.batch_size):
                batch = shuffled_data[i:i + self.batch_size]
                
                # Prepare batch tensors
                positions = []
                target_policies = []
                target_values = []
                
                for entry in batch:
                    try:
                        position = np.array(entry['position'], dtype=np.float32)
                        if position.shape != (8, 8, 14):
                            continue
                        
                        # Convert policy dict to array
                        policy_array = np.zeros(4096, dtype=np.float32)
                        if isinstance(entry.get('policy'), dict):
                            from chess_engine import ChessEngine
                            engine = ChessEngine()
                            for move, prob in entry['policy'].items():
                                idx = engine.move_to_index(move)
                                if idx < 4096:
                                    policy_array[idx] = prob
                        
                        positions.append(position)
                        target_policies.append(policy_array)
                        target_values.append(float(entry['value']))
                        
                    except Exception as e:
                        logger.debug(f"Skipping invalid training sample: {e}")
                        continue
                
                if len(positions) == 0:
                    continue
                
                # Convert to tensors
                positions_tensor = torch.FloatTensor(np.stack(positions)).permute(0, 3, 1, 2).to(device_manager.device)
                policies_tensor = torch.FloatTensor(np.array(target_policies)).to(device_manager.device)
                values_tensor = torch.FloatTensor(np.array(target_values)).unsqueeze(1).to(device_manager.device)
                
                # Forward pass
                pred_log_policies, pred_values = self.network(positions_tensor)
                
                # Calculate losses
                policy_loss = -torch.sum(policies_tensor * pred_log_policies) / positions_tensor.size(0)
                value_loss = torch.nn.MSELoss()(pred_values, values_tensor)
                loss = policy_loss + value_loss
                
                # Backward pass
                self.optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.network.parameters(), max_norm=1.0)
                self.optimizer.step()
                self.scheduler.step()
                
                total_loss += loss.item()
                total_policy_loss += policy_loss.item()
                total_value_loss += value_loss.item()
                num_batches += 1
                self.training_steps += 1
        
        return {
            'loss': total_loss / max(num_batches, 1),
            'policy_loss': total_policy_loss / max(num_batches, 1),
            'value_loss': total_value_loss / max(num_batches, 1),
            'num_batches': num_batches,
            'learning_rate': self.scheduler.get_last_lr()[0]
        }
    
    def evaluate_model(self) -> Tuple[float, bool]:
        """Evaluate current model against champion"""
        logger.info(f"Starting evaluation: current model vs {self.champion_name}")
        
        try:
            # Load champion model
            if self.champion_model is None:
                self.champion_model, _ = self.model_manager.load_model(self.champion_name)
            
            # Create evaluator
            evaluator = ModelEvaluator(
                num_evaluation_games=self.num_eval_games,
                num_simulations=self.num_simulations // 2,  # Use fewer sims for faster eval
                win_threshold=self.win_threshold
            )
            
            # Run evaluation
            results, should_promote = evaluator.evaluate_models(
                self.network,
                self.champion_model,
                "current_model",
                self.champion_name
            )
            
            win_rate = results.get('challenger_win_rate', 0.0)
            
            logger.info(f"Evaluation complete: win rate {win_rate:.1%} (threshold: {self.win_threshold:.1%})")
            
            if should_promote:
                # Promote new champion
                self.models_promoted += 1
                new_champion_name = f"champion_v{self.models_promoted}_{self.games_completed//1000}k"
                self.model_manager.save_model(self.network, name=new_champion_name, metadata={
                    'games': self.games_completed,
                    'elo': self.current_elo,
                    'win_rate': win_rate,
                    'promoted_from': self.champion_name
                })
                
                self.champion_name = new_champion_name
                self.champion_model = None  # Will reload on next eval
                
                # Update ELO (simplified K=32 formula)
                expected_score = 1.0 / (1.0 + 10 ** ((self.current_elo - self.current_elo) / 400))
                self.current_elo += 32 * (win_rate - expected_score)
                
                logger.info(f"🏆 Model promoted! New champion: {new_champion_name}, ELO: {self.current_elo:.0f}")
            
            return win_rate, should_promote
            
        except Exception as e:
            logger.error(f"Evaluation failed: {e}")
            return 0.0, False
    
    def log_progress(self, batch_games: int, batch_time: float, training_metrics: Dict):
        """Log training progress"""
        elapsed = time.time() - self.start_time
        games_per_sec = self.games_completed / elapsed if elapsed > 0 else 0
        positions_per_sec = self.positions_collected / elapsed if elapsed > 0 else 0
        
        # Calculate ETA
        remaining_games = self.max_games - self.games_completed
        remaining_seconds = self.max_seconds - elapsed
        
        if games_per_sec > 0:
            eta_by_games = remaining_games / games_per_sec
            eta = min(eta_by_games, remaining_seconds)
        else:
            eta = remaining_seconds
        
        progress_pct = (self.games_completed / self.max_games) * 100
        time_progress_pct = (elapsed / self.max_seconds) * 100
        
        metrics = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'games_completed': self.games_completed,
            'positions_collected': self.positions_collected,
            'elapsed_hours': elapsed / 3600,
            'games_per_sec': games_per_sec,
            'positions_per_sec': positions_per_sec,
            'progress_pct': progress_pct,
            'time_progress_pct': time_progress_pct,
            'eta_hours': eta / 3600,
            'current_elo': self.current_elo,
            'models_promoted': self.models_promoted,
            'replay_buffer_size': self.replay_buffer.size(),
            'training_loss': training_metrics.get('loss', 0.0),
            'learning_rate': training_metrics.get('learning_rate', self.initial_lr),
            'batch_games': batch_games,
            'batch_time': batch_time
        }
        
        self.metrics_history.append(metrics)
        
        # Save metrics to JSON
        metrics_file = self.log_dir / "training_metrics.json"
        with open(metrics_file, 'w') as f:
            json.dump({'metrics': self.metrics_history}, f, indent=2)
        
        logger.info(f"Progress: {self.games_completed:,}/{self.max_games:,} games ({progress_pct:.2f}%), "
                   f"{elapsed/3600:.2f}h/{self.max_hours:.2f}h ({time_progress_pct:.2f}%), "
                   f"ETA: {eta/3600:.2f}h, "
                   f"Rate: {games_per_sec:.2f} games/s, "
                   f"ELO: {self.current_elo:.0f}, "
                   f"Loss: {training_metrics.get('loss', 0.0):.4f}, "
                   f"LR: {training_metrics.get('learning_rate', self.initial_lr):.6f}")
    
    def run(self, resume: bool = False):
        """
        Run the full 44M game / 9-hour training cycle
        
        Args:
            resume: If True, attempt to resume from checkpoint
        """
        logger.info("="*80)
        logger.info("ALPHAZERO SELF-PLAY TRAINING - STARTING")
        logger.info("="*80)
        
        # Try to resume if requested
        if resume:
            self.load_checkpoint("latest")
        
        self.start_time = time.time()
        self.last_checkpoint_time = self.start_time
        self.running = True
        
        # Save initial model as champion if starting fresh
        if self.games_completed == 0:
            self.model_manager.save_model(self.network, name=self.champion_name, metadata={
                'initial': True,
                'elo': self.current_elo
            })
        
        try:
            # Main training loop
            while self.running and not self.stop_requested:
                # Check termination conditions
                elapsed = time.time() - self.start_time
                if self.games_completed >= self.max_games:
                    logger.info(f"Reached max games: {self.games_completed:,}")
                    break
                
                if elapsed >= self.max_seconds:
                    logger.info(f"Reached max time: {elapsed/3600:.2f} hours")
                    break
                
                # Calculate batch size (dynamic: more games early, fewer later for more training)
                if self.games_completed < 10000:
                    batch_games = 100
                elif self.games_completed < 100000:
                    batch_games = 50
                else:
                    batch_games = 25
                
                # Generate self-play batch
                logger.info(f"\n--- Batch {self.games_completed // batch_games + 1}: Generating {batch_games} games ---")
                training_data, batch_time = self.generate_selfplay_batch(batch_games)
                
                # Update counters
                self.games_completed += batch_games
                self.positions_collected += len(training_data)
                
                # Add to replay buffer
                self.replay_buffer.add(training_data)
                
                # Train on replay buffer
                train_start = time.time()
                
                # Check if replay buffer has data
                if self.replay_buffer.size() == 0:
                    logger.warning("⚠️ Replay buffer is empty — skipping training step.")
                    training_metrics = {
                        'loss': 0.0,
                        'policy_loss': 0.0,
                        'value_loss': 0.0,
                        'learning_rate': self.scheduler.get_last_lr()[0] if self.scheduler else self.initial_lr,
                        'num_batches': 0
                    }
                else:
                    logger.info(f"Training on replay buffer ({self.replay_buffer.size():,} positions)...")
                    
                    # Sample from replay buffer for training
                    train_sample_size = min(self.replay_buffer.size(), self.batch_size * 50)
                    train_data = self.replay_buffer.sample(train_sample_size)
                    
                    training_metrics = self.train_on_batch(train_data, num_epochs=1)
                
                train_time = time.time() - train_start
                
                # Store latest metrics for status polling
                self.latest_training_metrics = {
                    'loss': training_metrics.get('loss', 0.0),
                    'learning_rate': training_metrics.get('learning_rate', self.initial_lr)
                }
                
                # Defensive logging with .get() to handle missing keys
                loss = training_metrics.get('loss', 0.0)
                lr = training_metrics.get('learning_rate', 0.0)
                logger.info(f"Training complete in {train_time:.1f}s: Loss={loss:.4f}, LR={lr:.6f}")
                
                # Log progress
                self.log_progress(batch_games, batch_time, training_metrics)
                
                # Periodic checkpoint
                if time.time() - self.last_checkpoint_time >= self.checkpoint_interval:
                    logger.info("Saving checkpoint...")
                    self.save_checkpoint("latest")
                    self.save_checkpoint(f"{self.games_completed//1000}k_games")
                    self.last_checkpoint_time = time.time()
                
                # Periodic evaluation
                if self.games_completed - self.last_eval_game >= self.eval_interval:
                    logger.info("\n--- Running model evaluation ---")
                    win_rate, promoted = self.evaluate_model()
                    self.last_eval_game = self.games_completed
        
        except KeyboardInterrupt:
            logger.info("\nTraining interrupted by user")
        
        except Exception as e:
            logger.error(f"Training error: {e}")
            import traceback
            traceback.print_exc()
        
        finally:
            # Final checkpoint
            logger.info("\nSaving final checkpoint...")
            self.save_checkpoint("final")
            
            # Summary
            total_time = time.time() - self.start_time
            logger.info("="*80)
            logger.info("ALPHAZERO SELF-PLAY TRAINING - COMPLETE")
            logger.info("="*80)
            logger.info(f"Games completed: {self.games_completed:,}")
            logger.info(f"Positions collected: {self.positions_collected:,}")
            logger.info(f"Training time: {total_time/3600:.2f} hours")
            logger.info(f"Average rate: {self.games_completed/total_time:.2f} games/sec")
            logger.info(f"Models promoted: {self.models_promoted}")
            logger.info(f"Final ELO: {self.current_elo:.0f}")
            logger.info(f"Logs saved to: {self.log_dir}")
            logger.info("="*80)
            
            self.running = False
    
    def stop(self):
        """Request graceful stop"""
        logger.info("Stop requested...")
        self.stop_requested = True
    
    def get_status(self) -> Dict:
        """Get current training status"""
        if not self.running or self.start_time is None:
            return {
                'active': False,
                'message': 'Not running'
            }
        
        elapsed = time.time() - self.start_time
        progress_pct = (self.games_completed / self.max_games) * 100
        time_progress_pct = (elapsed / self.max_seconds) * 100
        
        return {
            'active': True,
            'games_completed': self.games_completed,
            'max_games': self.max_games,
            'positions_collected': self.positions_collected,
            'elapsed_seconds': int(elapsed),
            'elapsed_hours': elapsed / 3600,
            'max_hours': self.max_hours,
            'progress_pct': progress_pct,
            'time_progress_pct': time_progress_pct,
            'current_elo': self.current_elo,
            'models_promoted': self.models_promoted,
            'training_steps': self.training_steps,
            'replay_buffer_size': self.replay_buffer.size(),
            'games_per_sec': self.games_completed / elapsed if elapsed > 0 else 0,
            'champion_name': self.champion_name,
            'loss': self.latest_training_metrics.get('loss', 0.0),
            'learning_rate': self.latest_training_metrics.get('learning_rate', self.initial_lr)
        }


# CLI interface for standalone execution
if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    trainer = AlphaZeroSelfPlayTrainer(
        max_games=44_000_000,
        max_hours=9.0,
        num_simulations=800,
        replay_buffer_size=1_000_000,
        batch_size=256,
        learning_rate=0.001,
        checkpoint_interval=1800,
        eval_interval=1000,
        win_threshold=0.55,
        num_eval_games=40
    )
    
    # Check for resume flag
    resume = "--resume" in sys.argv
    
    trainer.run(resume=resume)
