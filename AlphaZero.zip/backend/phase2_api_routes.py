"""
Phase 2 API Routes - Distributed Self-Play Monitoring
======================================================

API endpoints for AlphaZeroControlPanel integration:
- Real-time training status
- Worker health monitoring
- Performance metrics
- Training control (start/pause/stop)
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional, Dict, List, Any
import logging
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/api/alphazero/distributed", tags=["alphazero-distributed"])

# Global trainer instance (will be initialized on startup)
_global_trainer = None
_training_task_running = False


class TrainingConfig(BaseModel):
    """Training configuration"""
    max_games: int = 1000
    max_hours: float = 10.0
    num_simulations: int = 800
    mode: str = "auto"  # sequential, distributed, auto
    num_workers: Optional[int] = None
    batch_games: int = 100
    train_epochs: int = 10


class TrainingControlRequest(BaseModel):
    """Training control request"""
    action: str  # start, pause, resume, stop


@router.get("/status")
async def get_training_status():
    """
    Get current training status
    
    Returns training progress, worker health, and performance metrics
    """
    try:
        if _global_trainer is None:
            return {
                "status": "not_initialized",
                "is_running": False,
                "message": "Trainer not initialized"
            }
        
        status = _global_trainer.get_status()
        status["is_running"] = _training_task_running
        status["timestamp"] = datetime.now(timezone.utc).isoformat()
        
        # Add distributed-specific stats if in distributed mode
        if hasattr(_global_trainer, 'selfplay_manager') and hasattr(_global_trainer.selfplay_manager, 'get_stats'):
            status["distributed_stats"] = _global_trainer.selfplay_manager.get_stats()
        
        return status
        
    except Exception as e:
        logger.error(f"Error getting training status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/workers")
async def get_worker_health():
    """
    Get worker health and performance metrics
    
    Returns detailed statistics for each worker
    """
    try:
        if _global_trainer is None:
            return {"workers": [], "summary": {"total": 0, "alive": 0, "failed": 0}}
        
        if not hasattr(_global_trainer, 'selfplay_manager'):
            return {"workers": [], "summary": {"total": 0, "alive": 0, "failed": 0}}
        
        stats = _global_trainer.selfplay_manager.get_stats()
        
        # Extract worker information
        workers = []
        total_alive = 0
        total_failed = 0
        
        worker_health = stats.get('worker_health', {})
        worker_stats = stats.get('worker_stats', {})
        
        for worker_id, health in worker_health.items():
            worker_info = {
                'worker_id': worker_id,
                'is_alive': health.get('is_alive', False),
                'games_completed': health.get('games_completed', 0),
                'uptime_seconds': health.get('uptime_seconds', 0),
            }
            
            # Add performance stats if available
            if worker_id in worker_stats:
                perf = worker_stats[worker_id]
                worker_info['positions'] = perf.get('positions', 0)
                worker_info['batch_time'] = perf.get('batch_time', 0)
                worker_info['throughput'] = perf.get('throughput_games_per_sec', 0)
            
            workers.append(worker_info)
            
            if health.get('is_alive'):
                total_alive += 1
            else:
                total_failed += 1
        
        # Summary
        fault_tolerance = stats.get('fault_tolerance', {})
        summary = {
            'total': len(workers),
            'alive': total_alive,
            'failed': total_failed,
            'total_failures': fault_tolerance.get('worker_failures', 0),
            'total_recoveries': fault_tolerance.get('worker_recoveries', 0),
            'recovery_rate': fault_tolerance.get('recovery_rate', 0)
        }
        
        return {
            'workers': workers,
            'summary': summary,
            'timestamp': datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error getting worker health: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/metrics")
async def get_performance_metrics():
    """
    Get detailed performance metrics
    
    Returns throughput, efficiency, and resource utilization metrics
    """
    try:
        if _global_trainer is None:
            return {"metrics": {}, "message": "Trainer not initialized"}
        
        metrics = _global_trainer.metrics.copy()
        
        # Add replay buffer metrics
        if hasattr(_global_trainer, 'replay_buffer'):
            buffer_stats = _global_trainer.replay_buffer.get_stats()
            metrics['replay_buffer'] = buffer_stats
        
        # Add distributed metrics if available
        if hasattr(_global_trainer, 'selfplay_manager') and hasattr(_global_trainer.selfplay_manager, 'get_stats'):
            dist_stats = _global_trainer.selfplay_manager.get_stats()
            metrics['distributed'] = {
                'num_workers': dist_stats.get('num_workers', 0),
                'total_games': dist_stats.get('total_games', 0),
                'total_positions': dist_stats.get('total_positions', 0),
                'avg_game_time': dist_stats.get('performance', {}).get('avg_game_time', 0)
            }
        
        metrics['timestamp'] = datetime.now(timezone.utc).isoformat()
        
        return metrics
        
    except Exception as e:
        logger.error(f"Error getting performance metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/control")
async def control_training(request: TrainingControlRequest, background_tasks: BackgroundTasks):
    """
    Control training execution
    
    Actions: start, pause, resume, stop
    """
    global _training_task_running
    
    try:
        action = request.action.lower()
        
        if action == "stop":
            if _global_trainer is not None:
                _global_trainer.shutdown_requested = True
                _training_task_running = False
                return {"status": "success", "message": "Training stop requested"}
            else:
                return {"status": "error", "message": "No active trainer"}
        
        elif action == "pause":
            # TODO: Implement pause functionality
            return {"status": "not_implemented", "message": "Pause not yet implemented"}
        
        elif action == "resume":
            # TODO: Implement resume functionality
            return {"status": "not_implemented", "message": "Resume not yet implemented"}
        
        else:
            raise HTTPException(status_code=400, detail=f"Unknown action: {action}")
        
    except Exception as e:
        logger.error(f"Error controlling training: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/start")
async def start_training(config: TrainingConfig, background_tasks: BackgroundTasks):
    """
    Start new training session
    
    Initializes trainer and starts training in background
    """
    global _global_trainer, _training_task_running
    
    try:
        if _training_task_running:
            return {"status": "error", "message": "Training already running"}
        
        from selfplay_trainer import AlphaZeroSelfPlayTrainer, SelfPlayMode
        
        # Create trainer
        logger.info(f"Initializing trainer with config: {config.dict()}")
        
        _global_trainer = AlphaZeroSelfPlayTrainer(
            max_games=config.max_games,
            max_hours=config.max_hours,
            num_simulations=config.num_simulations,
            mode=SelfPlayMode(config.mode),
            num_workers=config.num_workers,
            enable_fault_tolerance=True,
            enable_performance_tuning=True
        )
        
        # Start training in background
        def run_training():
            global _training_task_running
            _training_task_running = True
            try:
                _global_trainer.run(
                    batch_games=config.batch_games,
                    train_epochs=config.train_epochs
                )
            finally:
                _training_task_running = False
        
        background_tasks.add_task(run_training)
        
        return {
            "status": "success",
            "message": "Training started",
            "config": config.dict()
        }
        
    except Exception as e:
        logger.error(f"Error starting training: {e}")
        _training_task_running = False
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/replay-buffer")
async def get_replay_buffer_stats():
    """
    Get replay buffer statistics
    
    Returns buffer size, utilization, and sample data
    """
    try:
        if _global_trainer is None:
            return {"status": "not_initialized", "stats": {}}
        
        buffer_stats = _global_trainer.replay_buffer.get_stats()
        
        # Add advanced buffer service stats if available
        if hasattr(_global_trainer, 'replay_buffer_service'):
            service_stats = _global_trainer.replay_buffer_service.get_buffer_stats()
            buffer_stats['service'] = service_stats
        
        return {
            "status": "success",
            "stats": buffer_stats,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error getting replay buffer stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/throughput-history")
async def get_throughput_history():
    """
    Get throughput history for visualization
    
    Returns time-series data of game generation performance
    """
    try:
        if _global_trainer is None or not hasattr(_global_trainer, 'selfplay_manager'):
            return {"history": [], "message": "No throughput data available"}
        
        stats = _global_trainer.selfplay_manager.get_stats()
        performance = stats.get('performance', {})
        
        # Get throughput history
        history = []
        if hasattr(_global_trainer.selfplay_manager, 'throughput_history'):
            throughput_data = _global_trainer.selfplay_manager.throughput_history
            
            for idx, game_time in enumerate(throughput_data):
                history.append({
                    'index': idx,
                    'game_time_seconds': game_time,
                    'games_per_hour': 3600 / game_time if game_time > 0 else 0
                })
        
        return {
            "history": history,
            "summary": {
                "avg_game_time": performance.get('avg_game_time', 0),
                "sample_count": len(history)
            },
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error getting throughput history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


def get_router():
    """Get the API router for Phase 2 distributed training"""
    return router
