"""
TPU Training Orchestrator - Real AlphaZero Self-Play Training Cycles
Coordinates the full AlphaZero training pipeline on simulated TPU infrastructure

Architecture:
    Self-Play → Replay Buffer → Training → Evaluation → Promotion → Repeat

Features:
- Execute real MCTS-based self-play on TPU workers
- Collect training data (positions, policies, values) into replay buffer
- Train neural network on aggregated data
- Evaluate new vs old model with ELO calculation
- Automatically promote improved models
- Continuous improvement loop

This orchestrator transforms passive TPU simulation into an active training cluster
that performs actual AlphaZero-style iterative model improvement.
"""

import asyncio
import time
import logging
import uuid
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timezone
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path
import json
import numpy as np

from tpu_cluster_manager import get_tpu_grid, JobType
from self_play import SelfPlayManager
from replay_buffer_service import get_replay_buffer_service
from trainer import AlphaZeroTrainer
from evaluator import ModelEvaluator
from neural_network import AlphaZeroNetwork, ModelManager
from device_manager import device_manager

logger = logging.getLogger(__name__)


class CyclePhase(str, Enum):
    """Training cycle phases"""
    IDLE = "idle"
    SELF_PLAY = "self_play"
    TRAINING = "training"
    EVALUATION = "evaluation"
    PROMOTION = "promotion"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class TPUWorkerTask:
    """Task assigned to a TPU worker"""
    worker_id: int
    task_type: str  # 'selfplay', 'training', 'evaluation'
    num_games: int = 0
    positions_generated: int = 0
    games_completed: int = 0
    status: str = "pending"
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class TrainingCycle:
    """Complete AlphaZero training cycle"""
    cycle_id: str
    cycle_number: int
    phase: CyclePhase
    
    # Configuration
    num_selfplay_games: int = 1000
    num_tpus_selfplay: int = 500
    num_tpus_training: int = 100
    num_training_epochs: int = 3
    num_eval_games: int = 20
    batch_size: int = 256
    learning_rate: float = 0.001
    
    # Current model info
    current_model_name: str = "model_v0"
    current_model_elo: float = 1500.0
    current_model_version: int = 0
    
    # Progress tracking
    selfplay_progress: int = 0
    training_progress: int = 0
    evaluation_progress: int = 0
    
    # Metrics
    positions_generated: int = 0
    positions_in_buffer: int = 0
    training_loss: float = 0.0
    best_training_loss: float = float('inf')
    evaluation_win_rate: float = 0.0
    elo_delta: float = 0.0
    model_promoted: bool = False
    
    # Timing
    created_at: str = ""
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    phase_start_time: Optional[float] = None
    
    # TPU worker tracking
    active_workers: List[int] = None
    worker_tasks: Dict[int, TPUWorkerTask] = None
    
    def __post_init__(self):
        if self.active_workers is None:
            self.active_workers = []
        if self.worker_tasks is None:
            self.worker_tasks = {}
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()
    
    def to_dict(self) -> Dict:
        result = asdict(self)
        result['phase'] = self.phase.value
        result['worker_tasks'] = {k: v.to_dict() for k, v in self.worker_tasks.items()}
        return result
    
    def calculate_overall_progress(self) -> float:
        """Calculate overall cycle progress (0-100%)"""
        # Each phase contributes 25% to total progress
        phase_weights = {
            CyclePhase.IDLE: 0,
            CyclePhase.SELF_PLAY: 0.25,
            CyclePhase.TRAINING: 0.50,
            CyclePhase.EVALUATION: 0.75,
            CyclePhase.PROMOTION: 0.90,
            CyclePhase.COMPLETED: 1.0,
            CyclePhase.FAILED: 0.0
        }
        
        base_progress = phase_weights.get(self.phase, 0.0) * 100
        
        # Add sub-progress within current phase
        if self.phase == CyclePhase.SELF_PLAY:
            base_progress += (self.selfplay_progress / 100.0) * 25
        elif self.phase == CyclePhase.TRAINING:
            base_progress += (self.training_progress / 100.0) * 25
        elif self.phase == CyclePhase.EVALUATION:
            base_progress += (self.evaluation_progress / 100.0) * 25
        
        return min(100.0, base_progress)


class TPUTrainingOrchestrator:
    """
    Orchestrates complete AlphaZero training cycles on TPU infrastructure
    
    Coordinates:
    1. Self-Play: Execute real games on TPU workers using MCTS
    2. Data Collection: Push positions to replay buffer
    3. Training: Update network weights using replay buffer samples
    4. Evaluation: Compare new vs old model
    5. Promotion: Replace old model if new one is better
    6. Repeat: Continuous improvement loop
    """
    
    def __init__(
        self,
        tpu_grid_manager=None,
        replay_buffer_service=None,
        model_manager=None,
        initial_model_name: str = "model_v0",
        work_dir: str = "/app/backend/cache/tpu_training"
    ):
        """Initialize TPU training orchestrator"""
        
        # Services
        self.tpu_grid = tpu_grid_manager or get_tpu_grid()
        self.replay_buffer = replay_buffer_service or get_replay_buffer_service()
        self.model_manager = model_manager or ModelManager()
        
        # Initialize neural network
        self.current_network = AlphaZeroNetwork()
        self.current_model_name = initial_model_name
        self.current_model_elo = 1500.0
        self.model_version = 0
        
        # Save initial model
        self.model_manager.save_model(
            self.current_network,
            name=initial_model_name,
            metadata={'version': 0, 'elo': self.current_model_elo, 'initial': True}
        )
        logger.info(f"Initial model saved: {initial_model_name}")
        
        # Self-play manager (will be updated with current network)
        self.selfplay_manager = SelfPlayManager(
            neural_network=self.current_network,
            num_simulations=800
        )
        
        # Trainer and evaluator
        self.trainer = None  # Created per cycle
        self.evaluator = ModelEvaluator(
            num_evaluation_games=20,
            num_simulations=400,
            win_threshold=0.55,
            elo_threshold=50.0
        )
        
        # Cycle management
        self.current_cycle: Optional[TrainingCycle] = None
        self.cycle_history: List[TrainingCycle] = []
        self.cycle_count = 0
        
        # Work directory for logs
        self.work_dir = Path(work_dir)
        self.work_dir.mkdir(parents=True, exist_ok=True)
        
        # State
        self.is_running = False
        self.continuous_mode = False
        
        logger.info(f"TPUTrainingOrchestrator initialized with {self.tpu_grid.num_tpus:,} TPUs")
    
    async def start_training_cycle(
        self,
        num_selfplay_games: int = 1000,
        num_tpus_selfplay: int = 500,
        num_tpus_training: int = 100,
        num_training_epochs: int = 3,
        num_eval_games: int = 20,
        batch_size: int = 256,
        learning_rate: float = 0.001,
        continuous: bool = False
    ) -> TrainingCycle:
        """
        Start a complete AlphaZero training cycle
        
        Args:
            num_selfplay_games: Number of games to generate
            num_tpus_selfplay: TPUs to allocate for self-play
            num_tpus_training: TPUs to allocate for training
            num_training_epochs: Training epochs per cycle
            num_eval_games: Evaluation games to play
            batch_size: Training batch size
            learning_rate: Learning rate
            continuous: Continue to next cycle after completion
        
        Returns:
            TrainingCycle object
        """
        if self.is_running:
            raise RuntimeError("Training cycle already running")
        
        self.cycle_count += 1
        cycle_id = f"cycle_{uuid.uuid4().hex[:8]}"
        
        # Create cycle object
        cycle = TrainingCycle(
            cycle_id=cycle_id,
            cycle_number=self.cycle_count,
            phase=CyclePhase.IDLE,
            num_selfplay_games=num_selfplay_games,
            num_tpus_selfplay=num_tpus_selfplay,
            num_tpus_training=num_tpus_training,
            num_training_epochs=num_training_epochs,
            num_eval_games=num_eval_games,
            batch_size=batch_size,
            learning_rate=learning_rate,
            current_model_name=self.current_model_name,
            current_model_elo=self.current_model_elo,
            current_model_version=self.model_version
        )
        
        self.current_cycle = cycle
        self.continuous_mode = continuous
        self.is_running = True
        
        logger.info("="*80)
        logger.info(f"STARTING TRAINING CYCLE {cycle.cycle_number}")
        logger.info(f"Cycle ID: {cycle_id}")
        logger.info(f"Current Model: {self.current_model_name} (ELO {self.current_model_elo:.0f})")
        logger.info(f"Config: {num_selfplay_games} games, {num_tpus_selfplay} TPUs self-play, "
                   f"{num_tpus_training} TPUs training, {num_training_epochs} epochs")
        logger.info("="*80)
        
        # Run cycle in background
        asyncio.create_task(self._execute_training_cycle(cycle))
        
        return cycle
    
    async def _execute_training_cycle(self, cycle: TrainingCycle):
        """Execute complete training cycle"""
        try:
            cycle.started_at = datetime.now(timezone.utc).isoformat()
            
            # Phase 1: Self-Play
            await self._phase_self_play(cycle)
            
            # Phase 2: Training
            await self._phase_training(cycle)
            
            # Phase 3: Evaluation
            await self._phase_evaluation(cycle)
            
            # Phase 4: Promotion
            await self._phase_promotion(cycle)
            
            # Complete cycle
            cycle.phase = CyclePhase.COMPLETED
            cycle.completed_at = datetime.now(timezone.utc).isoformat()
            
            # Save cycle history
            self.cycle_history.append(cycle)
            self._save_cycle_log(cycle)
            
            logger.info("="*80)
            logger.info(f"TRAINING CYCLE {cycle.cycle_number} COMPLETED")
            logger.info(f"Positions Generated: {cycle.positions_generated:,}")
            logger.info(f"Training Loss: {cycle.training_loss:.4f}")
            logger.info(f"Evaluation Win Rate: {cycle.evaluation_win_rate:.1%}")
            logger.info(f"Model Promoted: {cycle.model_promoted}")
            if cycle.model_promoted:
                logger.info(f"ELO Change: {cycle.current_model_elo:.0f} → {cycle.current_model_elo + cycle.elo_delta:.0f} (Δ {cycle.elo_delta:+.0f})")
            logger.info("="*80)
            
            self.is_running = False
            
            # Start next cycle if continuous mode
            if self.continuous_mode:
                logger.info("Continuous mode: Starting next cycle...")
                await asyncio.sleep(5)  # Brief pause
                await self.start_training_cycle(
                    num_selfplay_games=cycle.num_selfplay_games,
                    num_tpus_selfplay=cycle.num_tpus_selfplay,
                    num_tpus_training=cycle.num_tpus_training,
                    num_training_epochs=cycle.num_training_epochs,
                    num_eval_games=cycle.num_eval_games,
                    batch_size=cycle.batch_size,
                    learning_rate=cycle.learning_rate,
                    continuous=True
                )
        
        except Exception as e:
            logger.error(f"Training cycle failed: {e}")
            import traceback
            traceback.print_exc()
            
            cycle.phase = CyclePhase.FAILED
            cycle.completed_at = datetime.now(timezone.utc).isoformat()
            self.is_running = False
    
    async def _phase_self_play(self, cycle: TrainingCycle):
        """Phase 1: Execute self-play on TPU workers"""
        logger.info(f"[Cycle {cycle.cycle_number}] Phase 1: Self-Play - Generating {cycle.num_selfplay_games} games")
        
        cycle.phase = CyclePhase.SELF_PLAY
        cycle.phase_start_time = time.time()
        cycle.selfplay_progress = 0
        
        # Update self-play manager with current network
        self.selfplay_manager.update_network(self.current_network)
        
        # Allocate TPUs for self-play
        job_id = f"selfplay_{cycle.cycle_id}"
        success, allocated_tpus = self.tpu_grid.allocate_tpus(
            job_id=job_id,
            job_type=JobType.SELFPLAY,
            num_tpus=cycle.num_tpus_selfplay,
            priority=7
        )
        
        if not success:
            logger.warning(f"Could not allocate {cycle.num_tpus_selfplay} TPUs, job queued")
            # Wait for allocation
            await asyncio.sleep(10)
        
        cycle.active_workers = allocated_tpus if success else []
        
        # Execute self-play games
        # In real system, these would run in parallel on TPU workers
        # For simulation, we run sequentially but track as if parallel
        
        all_training_data = []
        games_per_worker = cycle.num_selfplay_games // max(len(cycle.active_workers), 1)
        
        for game_idx in range(cycle.num_selfplay_games):
            # Assign to worker (round-robin simulation)
            worker_idx = game_idx % max(len(cycle.active_workers), 1)
            
            # Create worker task if doesn't exist
            if worker_idx not in cycle.worker_tasks:
                cycle.worker_tasks[worker_idx] = TPUWorkerTask(
                    worker_id=worker_idx,
                    task_type='selfplay',
                    num_games=games_per_worker,
                    status='running',
                    start_time=time.time()
                )
            
            # Generate game using real MCTS self-play
            try:
                training_data, game_result = self.selfplay_manager.generate_single_game(
                    store_fen=False,
                    export_pgn=True
                )
                
                all_training_data.extend(training_data)
                
                # Update worker task
                task = cycle.worker_tasks[worker_idx]
                task.games_completed += 1
                task.positions_generated += len(training_data)
                
                # Update cycle progress
                cycle.selfplay_progress = int((game_idx + 1) / cycle.num_selfplay_games * 100)
                cycle.positions_generated = len(all_training_data)
                
                if (game_idx + 1) % 10 == 0:
                    logger.info(f"[Cycle {cycle.cycle_number}] Self-play progress: {game_idx + 1}/{cycle.num_selfplay_games} games "
                               f"({len(all_training_data):,} positions)")
            
            except Exception as e:
                logger.error(f"[Cycle {cycle.cycle_number}] Game {game_idx} failed: {e}")
                continue
        
        # Add to replay buffer
        logger.info(f"[Cycle {cycle.cycle_number}] Adding {len(all_training_data):,} positions to replay buffer")
        self.replay_buffer.add_replay_tuples(
            all_training_data,
            game_id=f"selfplay_cycle_{cycle.cycle_number}_{int(time.time())}"
        )
        
        cycle.positions_in_buffer = self.replay_buffer.get_buffer_stats()['total_size']
        
        # Mark worker tasks complete
        for task in cycle.worker_tasks.values():
            task.status = 'completed'
            task.end_time = time.time()
        
        # Release TPUs
        if success:
            self.tpu_grid.release_tpus(job_id)
        
        phase_time = time.time() - cycle.phase_start_time
        logger.info(f"[Cycle {cycle.cycle_number}] Self-play complete: {len(all_training_data):,} positions in {phase_time:.1f}s")
        
        cycle.selfplay_progress = 100
    
    async def _phase_training(self, cycle: TrainingCycle):
        """Phase 2: Train neural network on replay buffer data"""
        logger.info(f"[Cycle {cycle.cycle_number}] Phase 2: Training - {cycle.num_training_epochs} epochs")
        
        cycle.phase = CyclePhase.TRAINING
        cycle.phase_start_time = time.time()
        cycle.training_progress = 0
        
        # Allocate TPUs for training
        job_id = f"training_{cycle.cycle_id}"
        success, allocated_tpus = self.tpu_grid.allocate_tpus(
            job_id=job_id,
            job_type=JobType.TRAINING,
            num_tpus=cycle.num_tpus_training,
            priority=8
        )
        
        # Sample training data from replay buffer
        buffer_stats = self.replay_buffer.get_buffer_stats()
        buffer_size = buffer_stats['total_size']
        
        if buffer_size == 0:
            logger.warning(f"[Cycle {cycle.cycle_number}] Replay buffer is empty, skipping training")
            cycle.training_progress = 100
            return
        
        logger.info(f"[Cycle {cycle.cycle_number}] Sampling from replay buffer ({buffer_size:,} positions)")
        
        # Sample larger batch for training
        training_batch = self.replay_buffer.sample_batch(
            batch_size=min(10000, buffer_size),
            use_priority=False
        )
        
        logger.info(f"[Cycle {cycle.cycle_number}] Training on {len(training_batch):,} positions")
        
        # Create trainer
        self.trainer = AlphaZeroTrainer(
            neural_network=self.current_network,
            learning_rate=cycle.learning_rate,
            use_mixed_precision=False,
            adaptive_lr=True
        )
        
        # Train for specified epochs
        for epoch in range(cycle.num_training_epochs):
            logger.info(f"[Cycle {cycle.cycle_number}] Training epoch {epoch + 1}/{cycle.num_training_epochs}")
            
            metrics = self.trainer.train_epoch(
                training_data=training_batch,
                batch_size=cycle.batch_size
            )
            
            cycle.training_loss = metrics['loss']
            cycle.best_training_loss = min(cycle.best_training_loss, cycle.training_loss)
            cycle.training_progress = int((epoch + 1) / cycle.num_training_epochs * 100)
            
            logger.info(f"[Cycle {cycle.cycle_number}] Epoch {epoch + 1} Loss: {cycle.training_loss:.4f} "
                       f"(Best: {cycle.best_training_loss:.4f})")
        
        # Release TPUs
        if success:
            self.tpu_grid.release_tpus(job_id)
        
        phase_time = time.time() - cycle.phase_start_time
        logger.info(f"[Cycle {cycle.cycle_number}] Training complete: Loss {cycle.training_loss:.4f} in {phase_time:.1f}s")
        
        cycle.training_progress = 100
    
    async def _phase_evaluation(self, cycle: TrainingCycle):
        """Phase 3: Evaluate new model vs old model"""
        logger.info(f"[Cycle {cycle.cycle_number}] Phase 3: Evaluation - Playing {cycle.num_eval_games} games")
        
        cycle.phase = CyclePhase.EVALUATION
        cycle.phase_start_time = time.time()
        cycle.evaluation_progress = 0
        
        # Create candidate model (clone current network with trained weights)
        candidate_model = AlphaZeroNetwork()
        candidate_model.load_state_dict(self.current_network.state_dict())
        candidate_name = f"model_v{self.model_version + 1}_candidate"
        
        # Load champion model
        champion_model, champion_metadata = self.model_manager.load_model(self.current_model_name)
        if champion_model is None:
            logger.warning(f"[Cycle {cycle.cycle_number}] Could not load champion model, using current network")
            champion_model = self.current_network
        
        logger.info(f"[Cycle {cycle.cycle_number}] Evaluating: {candidate_name} vs {self.current_model_name}")
        
        # Run evaluation
        try:
            results, should_promote = self.evaluator.evaluate_models(
                challenger_model=candidate_model,
                champion_model=champion_model,
                challenger_name=candidate_name,
                champion_name=self.current_model_name,
                challenger_elo=self.current_model_elo,
                champion_elo=self.current_model_elo
            )
            
            cycle.evaluation_win_rate = results['challenger_win_rate']
            cycle.elo_delta = results['elo_delta']
            cycle.model_promoted = should_promote
            
            logger.info(f"[Cycle {cycle.cycle_number}] Evaluation results:")
            logger.info(f"  Win rate: {cycle.evaluation_win_rate:.1%}")
            logger.info(f"  ELO delta: {cycle.elo_delta:+.0f}")
            logger.info(f"  Should promote: {should_promote}")
            
            # Store candidate model for potential promotion
            self._candidate_model = candidate_model
            self._candidate_name = candidate_name
            self._evaluation_results = results
        
        except Exception as e:
            logger.error(f"[Cycle {cycle.cycle_number}] Evaluation failed: {e}")
            import traceback
            traceback.print_exc()
            cycle.evaluation_win_rate = 0.0
            cycle.elo_delta = 0.0
            cycle.model_promoted = False
        
        phase_time = time.time() - cycle.phase_start_time
        logger.info(f"[Cycle {cycle.cycle_number}] Evaluation complete in {phase_time:.1f}s")
        
        cycle.evaluation_progress = 100
    
    async def _phase_promotion(self, cycle: TrainingCycle):
        """Phase 4: Promote new model if it's better"""
        logger.info(f"[Cycle {cycle.cycle_number}] Phase 4: Promotion")
        
        cycle.phase = CyclePhase.PROMOTION
        cycle.phase_start_time = time.time()
        
        if not cycle.model_promoted:
            logger.info(f"[Cycle {cycle.cycle_number}] Model not promoted - insufficient improvement")
            return
        
        # Promote model
        self.model_version += 1
        new_model_name = f"model_v{self.model_version}"
        self.current_model_elo += cycle.elo_delta
        
        # Save new model
        self.model_manager.save_model(
            self._candidate_model,
            name=new_model_name,
            metadata={
                'version': self.model_version,
                'elo': self.current_model_elo,
                'cycle': cycle.cycle_number,
                'win_rate': cycle.evaluation_win_rate,
                'elo_delta': cycle.elo_delta,
                'training_loss': cycle.training_loss
            }
        )
        
        # Update current network
        self.current_network.load_state_dict(self._candidate_model.state_dict())
        self.current_model_name = new_model_name
        
        # Sync model across TPU grid
        self.tpu_grid.sync_model(
            model_version=new_model_name,
            tpu_ids=None  # Sync to all TPUs
        )
        
        logger.info(f"[Cycle {cycle.cycle_number}] ✅ MODEL PROMOTED: {new_model_name}")
        logger.info(f"[Cycle {cycle.cycle_number}] New ELO: {self.current_model_elo:.0f}")
        
        # Update cycle state
        cycle.current_model_name = new_model_name
        cycle.current_model_elo = self.current_model_elo
        cycle.current_model_version = self.model_version
        
        phase_time = time.time() - cycle.phase_start_time
        logger.info(f"[Cycle {cycle.cycle_number}] Promotion complete in {phase_time:.1f}s")
    
    def stop_training(self):
        """Stop current training cycle"""
        if self.current_cycle:
            logger.info(f"Stopping training cycle {self.current_cycle.cycle_number}")
            self.continuous_mode = False
            self.is_running = False
            return True
        return False
    
    def get_cycle_status(self) -> Optional[Dict]:
        """Get current cycle status"""
        if not self.current_cycle:
            return None
        
        cycle = self.current_cycle
        buffer_stats = self.replay_buffer.get_buffer_stats()
        grid_status = self.tpu_grid.get_grid_status()
        
        return {
            'cycle': cycle.to_dict(),
            'overall_progress': cycle.calculate_overall_progress(),
            'current_model': {
                'name': self.current_model_name,
                'version': self.model_version,
                'elo': self.current_model_elo
            },
            'replay_buffer': {
                'total_positions': buffer_stats['total_size'],
                'capacity': buffer_stats['total_capacity'],
                'utilization': buffer_stats['utilization']
            },
            'tpu_grid': {
                'total_tpus': grid_status['grid']['total_tpus'],
                'busy_tpus': grid_status['grid']['busy_tpus'],
                'active_workers': len(cycle.active_workers),
                'utilization': grid_status['utilization']['current_percent']
            },
            'is_running': self.is_running,
            'continuous_mode': self.continuous_mode
        }
    
    def get_training_history(self) -> List[Dict]:
        """Get history of completed cycles"""
        return [
            {
                'cycle_number': c.cycle_number,
                'cycle_id': c.cycle_id,
                'positions_generated': c.positions_generated,
                'training_loss': c.training_loss,
                'evaluation_win_rate': c.evaluation_win_rate,
                'elo_delta': c.elo_delta,
                'model_promoted': c.model_promoted,
                'model_name': c.current_model_name,
                'completed_at': c.completed_at
            }
            for c in self.cycle_history
        ]
    
    def _save_cycle_log(self, cycle: TrainingCycle):
        """Save cycle log to disk"""
        try:
            log_file = self.work_dir / f"cycle_{cycle.cycle_number}_{cycle.cycle_id}.json"
            with open(log_file, 'w') as f:
                json.dump(cycle.to_dict(), f, indent=2)
            logger.info(f"Cycle log saved: {log_file}")
        except Exception as e:
            logger.error(f"Failed to save cycle log: {e}")


# Global instance
_tpu_training_orchestrator = None


def get_tpu_training_orchestrator() -> TPUTrainingOrchestrator:
    """Get or create global TPU training orchestrator"""
    global _tpu_training_orchestrator
    
    if _tpu_training_orchestrator is None:
        _tpu_training_orchestrator = TPUTrainingOrchestrator()
    
    return _tpu_training_orchestrator


def reset_tpu_training_orchestrator():
    """Reset global orchestrator (for testing)"""
    global _tpu_training_orchestrator
    _tpu_training_orchestrator = None
