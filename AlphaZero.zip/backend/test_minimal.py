"""
Minimal Test - Demonstrate distributed selfplay works
1 worker, 1 game, 10 MCTS sims, long timeout
"""

import logging
import sys
from distributed_selfplay_v2 import DistributedSelfPlayManager
from replay_buffer import ReplayBuffer

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

print("\n" + "="*80)
print("MINIMAL TEST: 1 worker, 1 game, 10 MCTS sims")
print("="*80 + "\n")

replay_buffer = ReplayBuffer(max_size=1000)

manager = DistributedSelfPlayManager(
    model_path=None,
    num_simulations=10,  # Minimal for speed
    num_workers=1
)

# Increase timeout significantly
import time
start = time.time()

training_data, _ = manager.generate_games_parallel(num_games=1, fallback_to_sequential=False)

elapsed = time.time() - start

replay_buffer.add(training_data)

print("\n" + "="*80)
print("RESULTS")
print("="*80)
print(f"Positions: {len(training_data)}")
print(f"Buffer size: {replay_buffer.size()}")
print(f"Time: {elapsed:.1f}s")

if len(training_data) > 0:
    print("\n✅ SUCCESS - Distributed self-play works!")
    print(f"Sample: {list(training_data[0].keys())}")
    sys.exit(0)
else:
    print("\n❌ FAILED")
    sys.exit(1)
