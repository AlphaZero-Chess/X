"""
Enhanced IQ Growth Tracker for AlphaZero
Tracks ELO progression and evaluation consistency toward superhuman performance (3500+)
"""
import json
import logging
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timezone
from collections import deque

logger = logging.getLogger(__name__)


class EnhancedIQTracker:
    """
    Track AlphaZero's chess IQ growth with evaluation consistency metrics
    Target: ELO 3500+ superhuman performance
    """
    
    def __init__(
        self,
        cache_dir: str = "/app/backend/cache/iq_tracking",
        target_elo: int = 3500
    ):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        self.target_elo = target_elo
        self.history_file = self.cache_dir / "iq_growth_history.json"
        
        # IQ tracking data
        self.elo_history = []
        self.consistency_history = []
        self.evaluation_samples = deque(maxlen=100)  # Recent position evaluations
        
        self.load_history()
        
        logger.info(f"Enhanced IQ Tracker initialized (target: {target_elo} ELO)")
    
    def record_evaluation(
        self,
        model_id: str,
        current_elo: float,
        opponent_elo: float,
        win_rate: float,
        games_played: int,
        position_evaluations: Optional[List[float]] = None,
        metadata: Optional[Dict] = None
    ):
        """
        Record evaluation results with consistency tracking
        
        Args:
            model_id: Model identifier
            current_elo: Current ELO rating
            opponent_elo: Opponent's ELO
            win_rate: Win rate in evaluation
            games_played: Number of games played
            position_evaluations: List of position evaluation scores (for consistency)
            metadata: Additional metadata
        """
        timestamp = datetime.now(timezone.utc).isoformat()
        
        # Calculate ELO delta
        elo_delta = current_elo - (self.elo_history[-1]['elo'] if self.elo_history else 1500)
        
        # Calculate evaluation consistency
        consistency_score = 0.0
        if position_evaluations:
            # Store evaluations
            self.evaluation_samples.extend(position_evaluations)
            
            # Calculate consistency (lower variance = higher consistency)
            if len(position_evaluations) > 1:
                eval_std = np.std(position_evaluations)
                eval_mean = np.abs(np.mean(position_evaluations))
                
                # Consistency score: 0.0 (chaotic) to 1.0 (perfectly consistent)
                # High std relative to mean = low consistency
                if eval_mean > 0:
                    consistency_score = 1.0 / (1.0 + (eval_std / eval_mean))
                else:
                    consistency_score = 1.0 / (1.0 + eval_std)
                
                consistency_score = max(0.0, min(1.0, consistency_score))
        
        # Calculate overall evaluation stability (recent trend)
        stability_score = self._calculate_stability()
        
        # Progress toward target
        progress_to_target = (current_elo / self.target_elo) * 100
        progress_to_target = min(100.0, progress_to_target)
        
        # Create entry
        entry = {
            'timestamp': timestamp,
            'model_id': model_id,
            'elo': current_elo,
            'elo_delta': elo_delta,
            'opponent_elo': opponent_elo,
            'win_rate': win_rate,
            'games_played': games_played,
            'evaluation_consistency': consistency_score,
            'evaluation_stability': stability_score,
            'progress_to_target': progress_to_target,
            'target_elo': self.target_elo,
            'metadata': metadata or {}
        }
        
        self.elo_history.append(entry)
        
        # Store consistency separately
        if consistency_score > 0:
            self.consistency_history.append({
                'timestamp': timestamp,
                'consistency': consistency_score,
                'stability': stability_score,
                'elo': current_elo
            })
        
        # Save to disk
        self.save_history()
        
        logger.info(f"IQ recorded: ELO {current_elo:.1f} (Δ{elo_delta:+.1f}), "
                   f"Consistency: {consistency_score:.3f}, Progress: {progress_to_target:.1f}%")
    
    def _calculate_stability(self) -> float:
        """
        Calculate evaluation stability from recent samples
        Measures how stable position evaluations are over time
        """
        if len(self.evaluation_samples) < 10:
            return 0.5  # Neutral stability
        
        # Calculate variance of recent evaluations
        recent_evals = list(self.evaluation_samples)[-50:]
        
        # Split into two halves and compare
        mid = len(recent_evals) // 2
        first_half = recent_evals[:mid]
        second_half = recent_evals[mid:]
        
        mean_first = np.mean(first_half)
        mean_second = np.mean(second_half)
        
        # Stability = how similar the two halves are
        diff = abs(mean_second - mean_first)
        stability = 1.0 / (1.0 + diff)
        
        return max(0.0, min(1.0, stability))
    
    def get_elo_progression(self) -> List[Dict]:
        """Get ELO progression over time"""
        return self.elo_history
    
    def get_consistency_progression(self) -> List[Dict]:
        """Get evaluation consistency progression"""
        return self.consistency_history
    
    def get_current_status(self) -> Dict[str, any]:
        """Get current IQ status"""
        if not self.elo_history:
            return {
                'current_elo': 1500,
                'target_elo': self.target_elo,
                'progress': 0.0,
                'status': 'No evaluations recorded yet'
            }
        
        latest = self.elo_history[-1]
        current_elo = latest['elo']
        
        # Calculate growth rate (ELO per 100 games)
        if len(self.elo_history) >= 2:
            recent_entries = self.elo_history[-10:]
            total_games = sum(e.get('games_played', 0) for e in recent_entries)
            elo_gain = recent_entries[-1]['elo'] - recent_entries[0]['elo']
            growth_rate = (elo_gain / total_games) * 100 if total_games > 0 else 0
        else:
            growth_rate = 0
        
        # Estimate games to target ELO
        if growth_rate > 0:
            elo_remaining = self.target_elo - current_elo
            games_to_target = int(elo_remaining / growth_rate * 100)
        else:
            games_to_target = None
        
        # Get average consistency
        if self.consistency_history:
            avg_consistency = np.mean([c['consistency'] for c in self.consistency_history[-10:]])
            avg_stability = np.mean([c['stability'] for c in self.consistency_history[-10:]])
        else:
            avg_consistency = 0.0
            avg_stability = 0.0
        
        return {
            'current_elo': current_elo,
            'target_elo': self.target_elo,
            'elo_delta_recent': latest.get('elo_delta', 0),
            'progress_percent': latest.get('progress_to_target', 0),
            'growth_rate_per_100_games': growth_rate,
            'estimated_games_to_target': games_to_target,
            'evaluation_consistency': avg_consistency,
            'evaluation_stability': avg_stability,
            'total_evaluations': len(self.elo_history),
            'last_evaluation': latest.get('timestamp'),
            'status': self._get_status_message(current_elo, avg_consistency)
        }
    
    def _get_status_message(self, elo: float, consistency: float) -> str:
        """Generate status message based on current metrics"""
        if elo < 1600:
            return "Beginner - Learning fundamentals"
        elif elo < 2000:
            return "Intermediate - Developing tactical skills"
        elif elo < 2400:
            return "Advanced - Strong club player level"
        elif elo < 2800:
            return "Expert - Master level performance"
        elif elo < 3200:
            return "Elite - Super GM level"
        elif elo < 3500:
            return "Superhuman - Approaching engine level"
        else:
            return f"Godlike - Beyond Stockfish ({elo:.0f} ELO)"
    
    def get_statistics(self) -> Dict[str, any]:
        """Get comprehensive IQ statistics"""
        if not self.elo_history:
            return {'error': 'No data available'}
        
        elos = [e['elo'] for e in self.elo_history]
        deltas = [e['elo_delta'] for e in self.elo_history if e['elo_delta'] != 0]
        
        stats = {
            'total_evaluations': len(self.elo_history),
            'starting_elo': elos[0] if elos else 1500,
            'current_elo': elos[-1] if elos else 1500,
            'peak_elo': max(elos) if elos else 1500,
            'total_elo_gain': elos[-1] - elos[0] if len(elos) > 1 else 0,
            'average_elo_delta': np.mean(deltas) if deltas else 0,
            'max_single_gain': max(deltas) if deltas else 0,
            'max_single_loss': min(deltas) if deltas else 0,
            'progress_to_target': (elos[-1] / self.target_elo) * 100 if elos else 0,
            'target_elo': self.target_elo
        }
        
        # Add consistency stats
        if self.consistency_history:
            consistencies = [c['consistency'] for c in self.consistency_history]
            stabilities = [c['stability'] for c in self.consistency_history]
            
            stats['avg_consistency'] = np.mean(consistencies)
            stats['avg_stability'] = np.mean(stabilities)
            stats['consistency_trend'] = self._calculate_trend(consistencies)
        
        return stats
    
    def _calculate_trend(self, values: List[float]) -> str:
        """Calculate trend direction"""
        if len(values) < 2:
            return "stable"
        
        recent = values[-5:]
        if len(recent) < 2:
            return "stable"
        
        # Simple linear regression slope
        x = np.arange(len(recent))
        slope = np.polyfit(x, recent, 1)[0]
        
        if slope > 0.01:
            return "improving"
        elif slope < -0.01:
            return "declining"
        else:
            return "stable"
    
    def save_history(self):
        """Save IQ history to disk"""
        try:
            data = {
                'elo_history': self.elo_history,
                'consistency_history': self.consistency_history,
                'target_elo': self.target_elo,
                'last_updated': datetime.now(timezone.utc).isoformat()
            }
            
            with open(self.history_file, 'w') as f:
                json.dump(data, f, indent=2)
                
        except Exception as e:
            logger.error(f"Failed to save IQ history: {e}")
    
    def load_history(self):
        """Load IQ history from disk"""
        try:
            if self.history_file.exists():
                with open(self.history_file, 'r') as f:
                    data = json.load(f)
                
                self.elo_history = data.get('elo_history', [])
                self.consistency_history = data.get('consistency_history', [])
                self.target_elo = data.get('target_elo', 3500)
                
                logger.info(f"Loaded {len(self.elo_history)} IQ records")
        except Exception as e:
            logger.warning(f"Failed to load IQ history: {e}")
    
    def reset(self):
        """Reset IQ tracking"""
        self.elo_history = []
        self.consistency_history = []
        self.evaluation_samples.clear()
        self.save_history()
        logger.info("IQ tracking reset")
    
    def export_chart_data(self) -> Dict[str, any]:
        """Export data formatted for frontend charts"""
        return {
            'elo_progression': {
                'labels': [e['timestamp'][:10] for e in self.elo_history],
                'values': [e['elo'] for e in self.elo_history],
                'deltas': [e['elo_delta'] for e in self.elo_history]
            },
            'consistency_progression': {
                'labels': [c['timestamp'][:10] for c in self.consistency_history],
                'consistency': [c['consistency'] for c in self.consistency_history],
                'stability': [c['stability'] for c in self.consistency_history]
            },
            'target_line': {
                'target_elo': self.target_elo,
                'current_elo': self.elo_history[-1]['elo'] if self.elo_history else 1500
            }
        }


# Global instance
enhanced_iq_tracker = EnhancedIQTracker()
