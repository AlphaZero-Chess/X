"""
Grid Monitor Service - Metrics Aggregation & Visualization

Collects and aggregates metrics from TPU grid:
- CPU, GPU, TPU utilization
- Node health status
- Task execution metrics
- Network latency and bandwidth

Exports metrics for:
- Prometheus scraping
- WebSocket streaming to frontend
- Historical analysis

Features:
- Real-time metrics collection
- Time-series data storage
- Aggregation by region/zone
- Alert generation
"""

import logging
import time
import threading
import random
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime, timezone
from collections import deque, defaultdict
import json

logger = logging.getLogger(__name__)


@dataclass
class NodeMetrics:
    """Metrics for a single TPU node"""
    node_id: str
    region: str
    zone: str
    
    # Resource utilization
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    tpu_utilization: float = 0.0
    
    # Network metrics
    network_latency_ms: float = 0.0
    network_bandwidth_gbps: float = 100.0
    
    # Health metrics
    health_status: str = "healthy"
    uptime_seconds: float = 0.0
    
    # Task metrics
    active_tasks: int = 0
    completed_tasks: int = 0
    
    # Timestamp
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict:
        return {
            'node_id': self.node_id,
            'region': self.region,
            'zone': self.zone,
            'cpu_percent': round(self.cpu_percent, 2),
            'memory_percent': round(self.memory_percent, 2),
            'tpu_utilization': round(self.tpu_utilization, 2),
            'network_latency_ms': round(self.network_latency_ms, 2),
            'network_bandwidth_gbps': round(self.network_bandwidth_gbps, 2),
            'health_status': self.health_status,
            'uptime_seconds': round(self.uptime_seconds, 2),
            'active_tasks': self.active_tasks,
            'completed_tasks': self.completed_tasks,
            'timestamp': self.timestamp
        }


@dataclass
class AggregatedMetrics:
    """Aggregated metrics across grid"""
    # Resource utilization
    avg_cpu_percent: float = 0.0
    avg_memory_percent: float = 0.0
    avg_tpu_utilization: float = 0.0
    
    # Capacity
    total_nodes: int = 0
    healthy_nodes: int = 0
    unhealthy_nodes: int = 0
    total_tpus: int = 0
    
    # Task metrics
    total_active_tasks: int = 0
    total_completed_tasks: int = 0
    tasks_per_second: float = 0.0
    
    # Network metrics
    avg_network_latency_ms: float = 0.0
    
    # Regional breakdown
    by_region: Dict[str, Dict] = field(default_factory=dict)
    
    # Timestamp
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict:
        return {
            'avg_cpu_percent': round(self.avg_cpu_percent, 2),
            'avg_memory_percent': round(self.avg_memory_percent, 2),
            'avg_tpu_utilization': round(self.avg_tpu_utilization, 2),
            'total_nodes': self.total_nodes,
            'healthy_nodes': self.healthy_nodes,
            'unhealthy_nodes': self.unhealthy_nodes,
            'total_tpus': self.total_tpus,
            'total_active_tasks': self.total_active_tasks,
            'total_completed_tasks': self.total_completed_tasks,
            'tasks_per_second': round(self.tasks_per_second, 3),
            'avg_network_latency_ms': round(self.avg_network_latency_ms, 2),
            'by_region': self.by_region,
            'timestamp': self.timestamp
        }


class GridMonitorService:
    """
    Grid Monitor Service - Centralized metrics collection and aggregation
    
    Collects metrics from:
    - Cloud cluster controller (node health, capacity)
    - Elastic scheduler (task metrics)
    - TPU autoscaler (scaling events)
    
    Provides metrics via:
    - Real-time access (get_current_metrics)
    - Historical time-series (get_historical_metrics)
    - Prometheus-compatible export (get_prometheus_metrics)
    - WebSocket streaming (for frontend)
    
    Example:
        monitor = GridMonitorService(cloud_controller, scheduler)
        monitor.start()
        
        metrics = monitor.get_current_metrics()
        print(f"TPU Utilization: {metrics.avg_tpu_utilization:.1%}")
        
        monitor.stop()
    """
    
    def __init__(
        self,
        cloud_controller,
        scheduler=None,
        autoscaler=None,
        collection_interval_seconds: int = 5,
        history_size: int = 720  # 1 hour at 5s intervals
    ):
        """
        Initialize Grid Monitor Service
        
        Args:
            cloud_controller: CloudClusterController instance
            scheduler: ElasticScheduler instance (optional)
            autoscaler: TPUAutoscaler instance (optional)
            collection_interval_seconds: Metrics collection interval
            history_size: Number of historical data points to keep
        """
        self.cloud_controller = cloud_controller
        self.scheduler = scheduler
        self.autoscaler = autoscaler
        self.collection_interval = collection_interval_seconds
        self.history_size = history_size
        
        logger.info("="*80)
        logger.info("INITIALIZING GRID MONITOR SERVICE")
        logger.info(f"Collection Interval: {collection_interval_seconds}s")
        logger.info(f"History Size: {history_size} samples")
        logger.info("="*80)
        
        # Current metrics
        self.current_node_metrics: Dict[str, NodeMetrics] = {}
        self.current_aggregated: Optional[AggregatedMetrics] = None
        
        # Historical metrics (time-series)
        self.historical_aggregated: deque = deque(maxlen=history_size)
        self.historical_by_region: Dict[str, deque] = defaultdict(lambda: deque(maxlen=history_size))
        
        # Statistics
        self.total_samples_collected = 0
        self.last_collection_time = 0.0
        
        # Control
        self.running = False
        self.monitor_thread = None
        self.lock = threading.RLock()
        
        logger.info("✅ Grid Monitor Service initialized")
    
    def start(self):
        """Start metrics collection"""
        if self.running:
            logger.warning("Monitor already running")
            return
        
        self.running = True
        self.monitor_thread = threading.Thread(
            target=self._monitoring_loop,
            daemon=True
        )
        self.monitor_thread.start()
        logger.info("📊 Grid Monitor Service started")
    
    def stop(self):
        """Stop metrics collection"""
        self.running = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        logger.info("⏹️  Grid Monitor Service stopped")
    
    def _monitoring_loop(self):
        """Main monitoring loop"""
        while self.running:
            try:
                self._collect_metrics()
                time.sleep(self.collection_interval)
            except Exception as e:
                logger.error(f"Monitoring loop error: {e}")
                import traceback
                traceback.print_exc()
    
    def _collect_metrics(self):
        """Collect metrics from all sources"""
        with self.lock:
            collection_start = time.time()
            
            # Collect node metrics
            node_metrics = self._collect_node_metrics()
            
            # Aggregate metrics
            aggregated = self._aggregate_metrics(node_metrics)
            
            # Store current metrics
            self.current_node_metrics = node_metrics
            self.current_aggregated = aggregated
            
            # Store in history
            self.historical_aggregated.append(aggregated)
            for region, metrics in aggregated.by_region.items():
                self.historical_by_region[region].append(metrics)
            
            # Update statistics
            self.total_samples_collected += 1
            self.last_collection_time = time.time()
            
            collection_duration = time.time() - collection_start
            
            if self.total_samples_collected % 20 == 0:  # Log every 100 seconds
                logger.info(f"📊 Collected sample #{self.total_samples_collected} "
                          f"({collection_duration*1000:.1f}ms) - "
                          f"TPU Util: {aggregated.avg_tpu_utilization:.1%}, "
                          f"Tasks: {aggregated.total_active_tasks}")
    
    def _collect_node_metrics(self) -> Dict[str, NodeMetrics]:
        """Collect metrics from all nodes"""
        node_metrics = {}
        
        # Get cluster status
        cluster_status = self.cloud_controller.get_cluster_status()
        
        # Get scheduler task info (if available)
        task_info = {}
        if self.scheduler:
            try:
                scheduler_status = self.scheduler.get_scheduler_status()
                node_util = scheduler_status.get('node_utilization', {})
                task_info = node_util
            except:
                pass
        
        # Collect per-node metrics
        for region_name, region_stats in cluster_status['regions'].items():
            region_nodes = self.cloud_controller.list_nodes(
                region=self._parse_region(region_name)
            )
            
            for node in region_nodes:
                node_id = node['node_id']
                
                # Simulate resource utilization (in real system, would get from agents)
                cpu_percent = random.uniform(30, 95) if node['health'] == 'healthy' else 0.0
                memory_percent = random.uniform(40, 85) if node['health'] == 'healthy' else 0.0
                tpu_utilization = random.uniform(60, 95) if node['health'] == 'healthy' else 0.0
                
                # Get task counts
                node_task_info = task_info.get(node_id, {})
                active_tasks = node_task_info.get('tasks', 0)
                
                metrics = NodeMetrics(
                    node_id=node_id,
                    region=node['region'],
                    zone=node['zone'],
                    cpu_percent=cpu_percent,
                    memory_percent=memory_percent,
                    tpu_utilization=tpu_utilization,
                    network_latency_ms=node['latency_ms'],
                    network_bandwidth_gbps=node['bandwidth_gbps'],
                    health_status=node['health'],
                    uptime_seconds=node['uptime_hours'] * 3600,
                    active_tasks=active_tasks,
                    completed_tasks=node['jobs_executed']
                )
                
                node_metrics[node_id] = metrics
        
        return node_metrics
    
    def _aggregate_metrics(self, node_metrics: Dict[str, NodeMetrics]) -> AggregatedMetrics:
        """Aggregate node metrics into grid-level metrics"""
        if not node_metrics:
            return AggregatedMetrics()
        
        # Calculate grid-level aggregates
        nodes = list(node_metrics.values())
        
        avg_cpu = sum(n.cpu_percent for n in nodes) / len(nodes)
        avg_memory = sum(n.memory_percent for n in nodes) / len(nodes)
        avg_tpu = sum(n.tpu_utilization for n in nodes) / len(nodes)
        avg_latency = sum(n.network_latency_ms for n in nodes) / len(nodes)
        
        healthy_nodes = sum(1 for n in nodes if n.health_status == 'healthy')
        unhealthy_nodes = len(nodes) - healthy_nodes
        
        total_active_tasks = sum(n.active_tasks for n in nodes)
        total_completed_tasks = sum(n.completed_tasks for n in nodes)
        
        # Calculate tasks per second (from historical data)
        tasks_per_second = 0.0
        if len(self.historical_aggregated) >= 2:
            prev_completed = self.historical_aggregated[-1].total_completed_tasks
            time_delta = time.time() - self.historical_aggregated[-1].timestamp
            if time_delta > 0:
                tasks_per_second = (total_completed_tasks - prev_completed) / time_delta
        
        # Get total TPUs from cluster
        cluster_status = self.cloud_controller.get_cluster_status()
        total_tpus = cluster_status['cluster']['total_tpus']
        
        # Regional breakdown
        by_region = {}
        regional_nodes = defaultdict(list)
        
        for node in nodes:
            regional_nodes[node.region].append(node)
        
        for region, region_nodes in regional_nodes.items():
            by_region[region] = {
                'node_count': len(region_nodes),
                'avg_cpu_percent': round(sum(n.cpu_percent for n in region_nodes) / len(region_nodes), 2),
                'avg_tpu_utilization': round(sum(n.tpu_utilization for n in region_nodes) / len(region_nodes), 2),
                'healthy_nodes': sum(1 for n in region_nodes if n.health_status == 'healthy'),
                'active_tasks': sum(n.active_tasks for n in region_nodes)
            }
        
        return AggregatedMetrics(
            avg_cpu_percent=avg_cpu,
            avg_memory_percent=avg_memory,
            avg_tpu_utilization=avg_tpu,
            total_nodes=len(nodes),
            healthy_nodes=healthy_nodes,
            unhealthy_nodes=unhealthy_nodes,
            total_tpus=total_tpus,
            total_active_tasks=total_active_tasks,
            total_completed_tasks=total_completed_tasks,
            tasks_per_second=tasks_per_second,
            avg_network_latency_ms=avg_latency,
            by_region=by_region
        )
    
    def _parse_region(self, region_name: str):
        """Parse region name to Region enum"""
        from cloud_cluster_controller import Region
        region_map = {
            'us-east': Region.US_EAST,
            'us-west': Region.US_WEST,
            'eu-west': Region.EU_WEST,
            'asia': Region.ASIA
        }
        return region_map.get(region_name)
    
    def get_current_metrics(self) -> Optional[AggregatedMetrics]:
        """Get current aggregated metrics"""
        with self.lock:
            return self.current_aggregated
    
    def get_node_metrics(self, node_id: str) -> Optional[NodeMetrics]:
        """Get metrics for specific node"""
        with self.lock:
            return self.current_node_metrics.get(node_id)
    
    def get_historical_metrics(self, samples: int = 60) -> List[Dict]:
        """Get historical aggregated metrics"""
        with self.lock:
            history = list(self.historical_aggregated)[-samples:]
            return [m.to_dict() for m in history]
    
    def get_prometheus_metrics(self) -> str:
        """Get metrics in Prometheus text format"""
        with self.lock:
            if not self.current_aggregated:
                return ""
            
            metrics = self.current_aggregated
            timestamp_ms = int(metrics.timestamp * 1000)
            
            lines = [
                "# HELP tpu_grid_utilization Average TPU utilization across grid",
                "# TYPE tpu_grid_utilization gauge",
                f"tpu_grid_utilization {metrics.avg_tpu_utilization} {timestamp_ms}",
                "",
                "# HELP tpu_grid_nodes_total Total number of TPU nodes",
                "# TYPE tpu_grid_nodes_total gauge",
                f"tpu_grid_nodes_total {metrics.total_nodes} {timestamp_ms}",
                "",
                "# HELP tpu_grid_nodes_healthy Number of healthy TPU nodes",
                "# TYPE tpu_grid_nodes_healthy gauge",
                f"tpu_grid_nodes_healthy {metrics.healthy_nodes} {timestamp_ms}",
                "",
                "# HELP tpu_grid_tasks_active Number of active tasks",
                "# TYPE tpu_grid_tasks_active gauge",
                f"tpu_grid_tasks_active {metrics.total_active_tasks} {timestamp_ms}",
                "",
                "# HELP tpu_grid_tasks_completed_total Total completed tasks",
                "# TYPE tpu_grid_tasks_completed_total counter",
                f"tpu_grid_tasks_completed_total {metrics.total_completed_tasks} {timestamp_ms}",
                "",
                "# HELP tpu_grid_cpu_percent Average CPU utilization",
                "# TYPE tpu_grid_cpu_percent gauge",
                f"tpu_grid_cpu_percent {metrics.avg_cpu_percent} {timestamp_ms}",
                "",
            ]
            
            # Regional metrics
            for region, region_metrics in metrics.by_region.items():
                lines.extend([
                    f'tpu_grid_utilization{{region="{region}"}} {region_metrics["avg_tpu_utilization"]} {timestamp_ms}',
                    f'tpu_grid_nodes_total{{region="{region}"}} {region_metrics["node_count"]} {timestamp_ms}',
                ])
            
            return "\n".join(lines)
    
    def get_monitor_status(self) -> Dict:
        """Get monitor service status"""
        with self.lock:
            return {
                'enabled': self.running,
                'collection_interval_seconds': self.collection_interval,
                'total_samples_collected': self.total_samples_collected,
                'last_collection_time': self.last_collection_time,
                'history_size': len(self.historical_aggregated),
                'history_max_size': self.history_size,
                'current_metrics': self.current_aggregated.to_dict() if self.current_aggregated else None,
                'timestamp': datetime.now(timezone.utc).isoformat()
            }


# Global instance
_monitor = None


def get_grid_monitor(
    cloud_controller=None,
    scheduler=None,
    autoscaler=None,
    collection_interval: int = 5
) -> GridMonitorService:
    """Get or create global monitor instance"""
    global _monitor
    
    if _monitor is None:
        if cloud_controller is None:
            from cloud_cluster_controller import get_cloud_controller
            cloud_controller = get_cloud_controller(initial_size=200)
        
        _monitor = GridMonitorService(
            cloud_controller=cloud_controller,
            scheduler=scheduler,
            autoscaler=autoscaler,
            collection_interval_seconds=collection_interval
        )
    
    return _monitor


def reset_grid_monitor():
    """Reset global monitor (for testing)"""
    global _monitor
    if _monitor:
        _monitor.stop()
    _monitor = None
