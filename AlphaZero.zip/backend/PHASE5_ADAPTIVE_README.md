# Phase 5: Adaptive Evolution & Long-Cycle Automation

## 🎯 Overview

Phase 5 implements **autonomous evolutionary training** for AlphaZero, transforming the training system from manual cycles into a self-improving, adaptive learning engine.

### Key Features
- ✅ **Continuous Long-Cycle Training** - Runs indefinitely until manually stopped
- ✅ **Stagnation Detection** - Automatically detects performance plateaus (ΔELO < 25 over 5 cycles)
- ✅ **Auto-Optimization** - Triggers HPO (Hyperparameter Optimization) or NAS (Neural Architecture Search) when stagnated
- ✅ **Model Evolution Tracking** - Complete lineage tree with parent-child relationships
- ✅ **IQ Growth Metrics** - Tracks model intelligence evolution over time
- ✅ **Adaptive Mutation** - Hyperparameters evolve based on performance feedback
- ✅ **Rollback Protection** - Automatic rollback on negative performance

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                  Phase 5 Adaptive Orchestrator              │
└───────────────────┬─────────────────────────────────────────┘
                    │
        ┌───────────┴───────────┐
        │                       │
        ▼                       ▼
┌──────────────┐       ┌──────────────┐
│  TPU Training│       │  Evolution   │
│ Orchestrator │───────│   Tracker    │
└──────┬───────┘       └──────────────┘
       │
       ├─────► Self-Play → Train → Evaluate → Promote
       │                   │
       │        (Stagnation Detected?)
       │                   │
       │         ┌─────────┴─────────┐
       │         │                   │
       │         ▼                   ▼
       │  ┌─────────────┐    ┌─────────────┐
       └─►│     HPO     │    │     NAS     │
          │ Optimizer   │    │ Controller  │
          └─────────────┘    └─────────────┘
                 │                   │
                 └─────────┬─────────┘
                           │
                    Resume Training
```

---

## 🔄 Evolution Cycle Flow

### 1. Training Cycle
```python
Self-Play (1000 games)
    ↓
Training (3 epochs on replay buffer)
    ↓
Evaluation (20 games: new vs champion)
    ↓
Promotion (if win rate > 55%)
```

### 2. Stagnation Analysis
```python
Analyze last 5 cycles:
- Total ΔELO < 25? → STAGNATED
- Loss not decreasing? → LOSS_PLATEAU
- Win rate < 52%? → WIN_RATE_PLATEAU
- Otherwise → ELO_PLATEAU
```

### 3. Auto-Optimization
```python
if LOSS_PLATEAU:
    Trigger HPO (optimize learning rate, batch size)
elif ELO_PLATEAU:
    Trigger NAS (explore new architectures)
elif WIN_RATE_PLATEAU:
    Try HPO, fallback to NAS
```

### 4. Resume
```python
Apply optimized hyperparameters or new architecture
    ↓
Resume training cycles
    ↓
Monitor for next stagnation
```

---

## 📊 Evolution Tracker

### Model Lineage Tree
Tracks parent-child relationships and model evolution:

```
model_v0 (Gen 0, ELO 1500) [initial_model]
    │
    ├── model_v1 (Gen 1, ELO 1520) [training_cycle]
    │       │
    │       ├── model_v2 (Gen 2, ELO 1545) [training_cycle]
    │       │
    │       └── NAS_Model_v3 (Gen 2, ELO 1565) [nas]
    │
    └── HPO_Model_v4 (Gen 1, ELO 1530) [hpo]
```

### IQ Growth Metrics
Composite intelligence score combining:
- **ELO Gain** - Raw performance improvement
- **Architecture Complexity** - Model efficiency (params, depth)
- **Training Efficiency** - ELO gain per million positions per hour

```python
IQ_Score = (ELO_gain / 10) + (1 / complexity) * 100 + efficiency * 50
```

---

## 🚀 Quick Start

### 1. Start Evolution

```bash
curl -X POST http://localhost:8001/api/alphazero/evolution/start \
  -H "Content-Type: application/json" \
  -d '{
    "num_selfplay_games": 1000,
    "stagnation_window": 5,
    "elo_threshold": 25.0,
    "enable_hpo": true,
    "enable_nas": true,
    "max_cycles": null
  }'
```

**Response:**
```json
{
  "success": true,
  "message": "Phase 5 Evolution started",
  "session_id": "evolution_a7b3c9d2",
  "mode": "indefinite"
}
```

### 2. Monitor Status

```bash
curl http://localhost:8001/api/alphazero/evolution/status
```

**Response:**
```json
{
  "success": true,
  "is_running": true,
  "current_phase": "training_cycle",
  "total_cycles": 12,
  "best_elo": 1575.3,
  "stagnation_streak": 0,
  "elapsed_hours": 2.5,
  "current_cycle_metrics": {
    "cycle_number": 12,
    "elo_delta": 8.2,
    "training_loss": 0.324,
    "promoted": true
  }
}
```

### 3. Check Evolution Summary

```bash
curl http://localhost:8001/api/alphazero/evolution/summary
```

**Response:**
```json
{
  "success": true,
  "total_models": 15,
  "total_cycles": 12,
  "total_promotions": 8,
  "promotion_rate": 0.667,
  "generations": 3,
  "root_elo": 1500.0,
  "current_elo": 1575.3,
  "total_elo_gain": 75.3,
  "current_iq_score": 127.5,
  "creation_methods": {
    "training_cycle": 10,
    "hpo": 3,
    "nas": 2
  }
}
```

### 4. Stop Evolution

```bash
curl -X POST http://localhost:8001/api/alphazero/evolution/stop
```

---

## 📡 API Endpoints

### Core Operations
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/alphazero/evolution/start` | POST | Start autonomous evolution |
| `/api/alphazero/evolution/status` | GET | Get real-time status |
| `/api/alphazero/evolution/stop` | POST | Stop evolution gracefully |

### Evolution Insights
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/alphazero/evolution/history` | GET | Complete evolution history |
| `/api/alphazero/evolution/lineage` | GET | Model lineage tree |
| `/api/alphazero/evolution/iq-growth` | GET | IQ growth timeline |
| `/api/alphazero/evolution/summary` | GET | High-level statistics |
| `/api/alphazero/evolution/stagnation-check` | GET | Check current stagnation |

### Live Updates
| Endpoint | Protocol | Description |
|----------|----------|-------------|
| `/ws/alphazero/evolution/live` | WebSocket | Real-time evolution updates |

---

## 🧪 Testing

### Run Test Suite

```bash
cd /app/backend
python test_phase5_adaptive.py
```

**Tests included:**
1. ✅ Evolution Tracker initialization
2. ✅ Model registration and lineage
3. ✅ Stagnation detection algorithm
4. ✅ IQ growth metrics calculation
5. ✅ API endpoint responses
6. ✅ Mini adaptive cycle (smoke test)

### Expected Output

```
🧬 PHASE 5 ADAPTIVE EVOLUTION - TEST SUITE
======================================================================

TEST 1: Evolution Tracker Initialization
======================================================================
✅ Evolution tracker initialized
   Models tracked: 0
   Cycles recorded: 0

TEST 2: Model Registration & Lineage
======================================================================
✅ Root model registered: model_1234567890_0
✅ Child model registered: model_1234567891_1
✅ Lineage tree constructed: 1 nodes

... (more tests)

📊 TEST RESULTS SUMMARY
======================================================================
✅ PASS - Evolution Tracker
✅ PASS - Model Registration
✅ PASS - Stagnation Detection
✅ PASS - IQ Metrics
✅ PASS - API Endpoints
✅ PASS - Mini Adaptive Cycle

Passed: 6/6
Failed: 0/6

✨ All tests passed! Phase 5 is ready.
```

---

## ⚙️ Configuration

### Evolution Config Parameters

```python
EvolutionConfig(
    # Cycle parameters
    num_selfplay_games=1000,        # Games per training cycle
    num_tpus_selfplay=500,          # TPUs for self-play
    num_tpus_training=100,          # TPUs for training
    num_training_epochs=3,          # Epochs per cycle
    num_eval_games=20,              # Evaluation games
    batch_size=256,                 # Training batch size
    learning_rate=0.001,            # Initial learning rate
    
    # Stagnation detection
    stagnation_window=5,            # Cycles to analyze (default: 5)
    elo_threshold=25.0,             # Min ΔELO required (default: 25)
    
    # Optimization triggers
    enable_hpo=True,                # Enable HPO (default: True)
    enable_nas=True,                # Enable NAS (default: True)
    auto_decide_optimization=True,  # Auto-decide HPO vs NAS
    
    # HPO configuration
    hpo_max_trials=10,              # HPO optimization trials
    hpo_evaluation_games=10,        # Games per HPO trial
    
    # NAS configuration
    nas_population_size=8,          # NAS population size
    nas_max_generations=5,          # NAS evolution generations
    
    # Limits
    max_cycles=None,                # Max cycles (None=indefinite)
    max_hours=None                  # Max hours (None=indefinite)
)
```

---

## 🔍 Stagnation Detection Logic

### Criteria
Evolution is considered **stagnated** if:
1. Total ΔELO over `stagnation_window` cycles < `elo_threshold`
2. Promotions < 50% of cycles in window

### Example
```python
Last 5 cycles:
- Cycle 8: ΔELO = +5.2
- Cycle 9: ΔELO = +3.1
- Cycle 10: ΔELO = +4.8
- Cycle 11: ΔELO = +6.5
- Cycle 12: ΔELO = +2.3
----------------------------
Total ΔELO = 21.9 < 25.0 ✗
Promotions = 2/5 < 50% ✗
→ STAGNATION DETECTED
```

### Stagnation Types
| Type | Condition | Optimization |
|------|-----------|--------------|
| `LOSS_PLATEAU` | Loss not decreasing | HPO (learning rate) |
| `ELO_PLATEAU` | ELO flat, normal loss | NAS (architecture) |
| `WIN_RATE_PLATEAU` | Very low win rate | HPO → NAS fallback |

---

## 📈 Evolution Phases

| Phase | Description | Duration |
|-------|-------------|----------|
| `IDLE` | Waiting to start | - |
| `TRAINING_CYCLE` | Self-play → Train → Eval | ~10-30 min |
| `STAGNATION_ANALYSIS` | Checking for plateaus | <1 min |
| `HPO_OPTIMIZATION` | Hyperparameter tuning | ~20-60 min |
| `NAS_EVOLUTION` | Architecture search | ~30-90 min |
| `ROLLBACK` | Reverting bad optimization | <5 min |
| `COMPLETED` | Evolution finished | - |
| `FAILED` | Error occurred | - |

---

## 🎨 WebSocket Live Updates

### Connect
```javascript
const ws = new WebSocket('ws://localhost:8001/ws/alphazero/evolution/live');

ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    
    if (data.type === 'status_update') {
        console.log('Current phase:', data.current_phase);
        console.log('Total cycles:', data.total_cycles);
        console.log('Best ELO:', data.best_elo);
    }
};
```

### Message Types
- `initial_status` - Sent on connection
- `status_update` - Periodic status (every 5s)
- `heartbeat` - Connection keepalive

---

## 🐛 Troubleshooting

### Evolution not starting
**Problem:** "Evolution already running" error

**Solution:**
```bash
# Stop any running evolution
curl -X POST http://localhost:8001/api/alphazero/evolution/stop

# Reset orchestrator (if stuck)
curl -X POST http://localhost:8001/api/alphazero/evolution/admin/reset-orchestrator
```

### Stagnation not triggering
**Problem:** HPO/NAS never triggered despite plateau

**Causes:**
1. Not enough cycles (need ≥ `stagnation_window`)
2. Total ΔELO still above threshold
3. Recent optimization (waits `stagnation_window` cycles)

**Check:**
```bash
curl 'http://localhost:8001/api/alphazero/evolution/stagnation-check?window=5&elo_threshold=25'
```

### High memory usage
**Problem:** Memory grows over time

**Solution:**
- Reduce `num_selfplay_games` per cycle
- Lower `replay_buffer_size` in orchestrator
- Increase `checkpoint_interval` to clean old data

---

## 📚 Files Structure

```
/app/backend/
├── phase5_adaptive_orchestrator.py  # Core evolution engine
├── evolution_tracker.py             # Model lineage & IQ tracking
├── phase5_api_routes.py             # API endpoints
├── test_phase5_adaptive.py          # Test suite
├── PHASE5_ADAPTIVE_README.md        # This file
└── data/evolution/                  # Evolution data storage
    ├── model_lineage.json           # Model family tree
    ├── evolution_cycles.json        # Cycle history
    ├── iq_metrics.json              # IQ growth timeline
    └── evolution_summary.json       # High-level stats
```

---

## 🚦 Status Indicators

### Phase Indicators
- 🟢 **TRAINING_CYCLE** - Active training
- 🟡 **HPO_OPTIMIZATION** - Optimizing hyperparameters
- 🔵 **NAS_EVOLUTION** - Evolving architecture
- 🟠 **STAGNATION_ANALYSIS** - Checking performance
- ⚪ **IDLE** - Waiting
- ✅ **COMPLETED** - Finished
- ❌ **FAILED** - Error

### Stagnation Status
- ✅ **None** - Evolution progressing normally
- ⚠️ **LOSS_PLATEAU** - Loss not improving
- ⚠️ **ELO_PLATEAU** - ELO flat
- ⚠️ **WIN_RATE_PLATEAU** - Low win rates

---

## 🎯 Best Practices

### For Production
1. **Set reasonable limits:**
   - `max_cycles` or `max_hours` to prevent runaway evolution
   - Monitor disk space for evolution data

2. **Tune stagnation thresholds:**
   - Start conservative (`elo_threshold=25`, `window=5`)
   - Adjust based on your training data quality

3. **Enable both HPO and NAS:**
   - System auto-decides which to use
   - Provides maximum adaptation capability

4. **Monitor regularly:**
   - Check `/status` every 5 minutes
   - Watch for phase changes
   - Track `stagnation_streak`

### For Development/Testing
1. **Use smaller configs:**
   ```python
   num_selfplay_games=100
   num_eval_games=5
   hpo_max_trials=5
   nas_max_generations=3
   max_cycles=3
   ```

2. **Disable optimizations for quick tests:**
   ```python
   enable_hpo=False
   enable_nas=False
   ```

3. **Reset between tests:**
   ```bash
   curl -X POST .../evolution/admin/reset-orchestrator
   curl -X POST .../evolution/admin/reset-tracker
   ```

---

## 📊 Performance Metrics

### Expected Throughput
- **Training Cycle:** 10-30 minutes (1000 games, 800 MCTS sims)
- **HPO Optimization:** 20-60 minutes (10 trials)
- **NAS Evolution:** 30-90 minutes (8 population, 5 generations)

### Resource Usage
- **CPU:** ~80-90% during self-play
- **Memory:** ~4-8 GB base + replay buffer
- **Disk:** ~100 MB per 10 cycles (logs + models)

---

## 🔮 Future Enhancements (Phase 6+)

- **Multi-objective optimization** - Balance ELO, speed, model size
- **Transfer learning** - Bootstrap from external models
- **Curriculum learning** - Progressive difficulty increase
- **Ensemble models** - Combine multiple architectures
- **Cloud-native scaling** - Distribute across cloud providers

---

## ✅ Validation Checklist

Before deploying Phase 5 to production:

- [ ] Run full test suite (`test_phase5_adaptive.py`)
- [ ] Verify all API endpoints return 200
- [ ] Test WebSocket connection stays alive
- [ ] Confirm stagnation detection works (forced test)
- [ ] Run mini 3-cycle evolution successfully
- [ ] Check model lineage tree renders correctly
- [ ] Validate IQ growth metrics calculate properly
- [ ] Test HPO integration (if enabled)
- [ ] Test NAS integration (if enabled)
- [ ] Verify graceful stop works mid-cycle
- [ ] Confirm evolution data persists across restarts

---

## 📞 Support

For issues or questions:
1. Check logs: `/var/log/supervisor/backend.*.log`
2. Review evolution data: `/app/backend/data/evolution/`
3. Run diagnostics: `test_phase5_adaptive.py`
4. Check API health: `GET /api/alphazero/evolution/status`

---

**Phase 5 Status:** ✅ **FULLY OPERATIONAL**

*Last Updated: 2025-10-19*
