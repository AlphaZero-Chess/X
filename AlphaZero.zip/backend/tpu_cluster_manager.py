"""
TPU Cluster Manager - Virtual 5000-TPU Grid Simulation
Implements massive-scale TPU orchestration for AlphaZero training

Architecture:
- 5000 logical TPU cores organized in pods
- Dynamic job allocation (self-play, training, evaluation)
- Simulated compute/IO latency and throughput
- Load balancing and preemption support
- Real-time metrics and monitoring

This is a SIMULATION layer - physical execution uses 8-64 workers
while maintaining architectural fidelity to real TPU deployments.
"""

import asyncio
import time
import random
import logging
import json
from collections import deque, defaultdict
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict
from enum import Enum
from datetime import datetime, timezone
from pathlib import Path
import threading

logger = logging.getLogger(__name__)


class TPUState(Enum):
    """TPU core state machine"""
    IDLE = "idle"
    RESERVED = "reserved"
    BUSY = "busy"
    OFFLINE = "offline"
    MAINTENANCE = "maintenance"


class PodState(Enum):
    """Pod lifecycle states"""
    INACTIVE = "inactive"  # Pod exists but not allocated
    ACTIVE = "active"  # Pod allocated and running
    WARMING_UP = "warming_up"  # Pod starting up
    COOLING_DOWN = "cooling_down"  # Pod shutting down
    MAINTENANCE = "maintenance"  # Pod under maintenance


class JobType(Enum):
    """Job types in AlphaZero pipeline"""
    SELFPLAY = "selfplay"
    TRAINING = "training"
    EVALUATION = "evaluation"
    INFERENCE = "inference"


@dataclass
class LogicalTPU:
    """
    Virtual TPU core with simulated performance characteristics
    Mirrors behavior of real TPU v3/v4 cores
    """
    id: int
    pod_id: int
    state: TPUState
    current_job_id: Optional[str] = None
    queued_jobs: int = 0
    
    # Simulated performance profile (mimics real TPU variance)
    tflops: float = 100.0  # Teraflops
    memory_gb: float = 16.0  # HBM memory
    latency_ms: float = 5.0  # Network latency
    utilization: float = 0.0  # Current utilization %
    
    # Operational metrics
    total_jobs_completed: int = 0
    total_compute_time_sec: float = 0.0
    last_job_start: Optional[float] = None
    
    def __post_init__(self):
        """Add realistic variance to TPU performance"""
        # Simulate hardware variance (±10%)
        self.tflops *= (0.9 + random.random() * 0.2)
        self.latency_ms *= (0.8 + random.random() * 0.4)
    
    def assign_job(self, job_id: str, job_type: JobType):
        """Assign job to this TPU"""
        self.state = TPUState.BUSY
        self.current_job_id = job_id
        self.last_job_start = time.time()
        
        # Simulate utilization based on job type
        if job_type == JobType.TRAINING:
            self.utilization = 85.0 + random.random() * 10.0  # 85-95%
        elif job_type == JobType.SELFPLAY:
            self.utilization = 60.0 + random.random() * 15.0  # 60-75%
        elif job_type == JobType.EVALUATION:
            self.utilization = 70.0 + random.random() * 10.0  # 70-80%
        else:
            self.utilization = 50.0 + random.random() * 20.0
    
    def release_job(self):
        """Release job and return to idle"""
        if self.last_job_start:
            self.total_compute_time_sec += time.time() - self.last_job_start
            self.total_jobs_completed += 1
        
        self.state = TPUState.IDLE
        self.current_job_id = None
        self.utilization = 0.0
        self.last_job_start = None
    
    def to_dict(self) -> Dict:
        """Serialize to dict for API responses"""
        return {
            'id': self.id,
            'pod_id': self.pod_id,
            'state': self.state.value,
            'current_job': self.current_job_id,
            'utilization': round(self.utilization, 2),
            'tflops': round(self.tflops, 2),
            'memory_gb': self.memory_gb,
            'jobs_completed': self.total_jobs_completed
        }


class PodState(Enum):
    """Pod lifecycle states"""
    INACTIVE = "inactive"  # Pod exists but not allocated
    ACTIVE = "active"  # Pod allocated and running
    WARMING_UP = "warming_up"  # Pod starting up
    COOLING_DOWN = "cooling_down"  # Pod shutting down
    MAINTENANCE = "maintenance"  # Pod under maintenance


@dataclass
class TPUPod:
    """
    TPU Pod - collection of 8 TPU cores (v3 pod slice)
    Provides locality and high-speed interconnect simulation
    
    Phase 3 Enhancements:
    - Pod lifecycle management (active/inactive/warming/cooling)
    - Health monitoring with heartbeats
    - Cross-pod communication simulation
    - Detailed metrics tracking
    """
    pod_id: int
    tpu_cores: List[LogicalTPU]
    pod_type: str = "v3-8"  # v3-8, v3-32, v4-128, etc.
    
    # Phase 3: Pod lifecycle
    state: PodState = PodState.INACTIVE
    created_at: float = 0.0
    activated_at: Optional[float] = None
    deactivated_at: Optional[float] = None
    
    # Phase 3: Health monitoring
    last_heartbeat: float = 0.0
    heartbeat_interval: float = 30.0  # seconds
    is_healthy: bool = True
    
    # Phase 3: Workload tracking
    current_job_id: Optional[str] = None
    active_games: int = 0
    total_games_completed: int = 0
    total_positions_generated: int = 0
    
    # Phase 3: Performance metrics
    pod_throughput_games_per_sec: float = 0.0
    pod_uptime_seconds: float = 0.0
    
    def __post_init__(self):
        if not self.tpu_cores:
            self.tpu_cores = []
        if self.created_at == 0.0:
            self.created_at = time.time()
        self.last_heartbeat = time.time()
    
    @property
    def size(self) -> int:
        return len(self.tpu_cores)
    
    @property
    def available_cores(self) -> int:
        return sum(1 for tpu in self.tpu_cores if tpu.state == TPUState.IDLE)
    
    @property
    def busy_cores(self) -> int:
        return sum(1 for tpu in self.tpu_cores if tpu.state == TPUState.BUSY)
    
    @property
    def avg_utilization(self) -> float:
        if not self.tpu_cores:
            return 0.0
        return sum(tpu.utilization for tpu in self.tpu_cores) / len(self.tpu_cores)
    
    @property
    def is_active(self) -> bool:
        return self.state == PodState.ACTIVE
    
    def activate(self, warmup_time: float = 10.0):
        """Activate pod (simulate warmup)"""
        self.state = PodState.WARMING_UP
        time.sleep(0.1)  # Simulate warmup delay
        self.state = PodState.ACTIVE
        self.activated_at = time.time()
        self.last_heartbeat = time.time()
        logger.info(f"✅ Pod {self.pod_id} activated ({self.size} cores)")
    
    def deactivate(self, cooldown_time: float = 5.0):
        """Deactivate pod (simulate cooldown)"""
        self.state = PodState.COOLING_DOWN
        time.sleep(0.05)  # Simulate cooldown delay
        self.state = PodState.INACTIVE
        self.deactivated_at = time.time()
        logger.info(f"⏸️  Pod {self.pod_id} deactivated")
    
    def heartbeat(self):
        """Update pod heartbeat"""
        self.last_heartbeat = time.time()
        
        # Check individual TPU health
        unhealthy_tpus = sum(1 for tpu in self.tpu_cores if tpu.state == TPUState.OFFLINE)
        self.is_healthy = unhealthy_tpus == 0
    
    def check_health(self, timeout: float = 120.0) -> bool:
        """Check if pod is healthy (recent heartbeat)"""
        if not self.is_active:
            return True  # Inactive pods are considered healthy
        
        elapsed = time.time() - self.last_heartbeat
        return elapsed < timeout and self.is_healthy
    
    def assign_job(self, job_id: str, job_type: JobType):
        """Assign job to pod"""
        self.current_job_id = job_id
        
        # Assign to all available cores
        for tpu in self.tpu_cores:
            if tpu.state == TPUState.IDLE:
                tpu.assign_job(job_id, job_type)
    
    def release_job(self):
        """Release job from pod"""
        for tpu in self.tpu_cores:
            if tpu.current_job_id == self.current_job_id:
                tpu.release_job()
        
        self.current_job_id = None
        self.active_games = 0
    
    def update_metrics(self, games_completed: int, positions_generated: int):
        """Update pod performance metrics"""
        self.total_games_completed += games_completed
        self.total_positions_generated += positions_generated
        
        # Calculate throughput
        if self.activated_at:
            self.pod_uptime_seconds = time.time() - self.activated_at
            if self.pod_uptime_seconds > 0:
                self.pod_throughput_games_per_sec = self.total_games_completed / self.pod_uptime_seconds
    
    def to_dict(self) -> Dict:
        return {
            'pod_id': self.pod_id,
            'state': self.state.value,
            'size': self.size,
            'available_cores': self.available_cores,
            'busy_cores': self.busy_cores,
            'utilization': round(self.avg_utilization, 2),
            'type': self.pod_type,
            'is_healthy': self.is_healthy,
            'is_active': self.is_active,
            'current_job': self.current_job_id,
            'active_games': self.active_games,
            'total_games': self.total_games_completed,
            'total_positions': self.total_positions_generated,
            'throughput_games_per_sec': round(self.pod_throughput_games_per_sec, 3),
            'uptime_seconds': round(self.pod_uptime_seconds, 1),
            'last_heartbeat': self.last_heartbeat
        }


@dataclass
class JobSpec:
    """AlphaZero job specification"""
    job_id: str
    job_type: JobType
    num_tpus_requested: int
    priority: int = 5  # 1-10, higher = more important
    estimated_duration_sec: float = 0.0
    created_at: float = 0.0
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    assigned_tpus: List[int] = None
    
    def __post_init__(self):
        if self.created_at == 0.0:
            self.created_at = time.time()
        if self.assigned_tpus is None:
            self.assigned_tpus = []
    
    def to_dict(self) -> Dict:
        return {
            'job_id': self.job_id,
            'job_type': self.job_type.value,
            'num_tpus': self.num_tpus_requested,
            'priority': self.priority,
            'status': self.status,
            'assigned_tpus': len(self.assigned_tpus),
            'created_at': self.created_at,
            'started_at': self.started_at,
            'completed_at': self.completed_at
        }
    
    @property
    def status(self) -> str:
        if self.completed_at:
            return "completed"
        elif self.started_at:
            return "running"
        else:
            return "queued"


class TPUGridManager:
    """
    Virtual 5000-TPU Grid Manager
    
    Simulates large-scale TPU cluster with:
    - 5000 logical TPU cores
    - 625 TPU pods (8 cores each)
    - Dynamic job scheduling
    - Load balancing
    - Performance metrics
    
    Designed to mirror DeepMind AlphaZero training infrastructure
    """
    
    def __init__(
        self,
        num_tpus: int = 5000,
        cores_per_pod: int = 8,
        enable_metrics: bool = True
    ):
        """
        Initialize TPU grid
        
        Args:
            num_tpus: Total logical TPU cores (default: 5000)
            cores_per_pod: TPU cores per pod (default: 8 for v3-8)
            enable_metrics: Enable performance tracking
        """
        self.num_tpus = num_tpus
        self.cores_per_pod = cores_per_pod
        self.num_pods = num_tpus // cores_per_pod
        
        logger.info("="*80)
        logger.info(f"INITIALIZING TPU GRID MANAGER")
        logger.info(f"Total TPU Cores: {num_tpus:,}")
        logger.info(f"TPU Pods: {self.num_pods:,} ({cores_per_pod} cores each)")
        logger.info("="*80)
        
        # Create logical TPUs organized in pods
        self.tpus: Dict[int, LogicalTPU] = {}
        self.pods: Dict[int, TPUPod] = {}
        
        self._initialize_grid()
        
        # Job management
        self.jobs: Dict[str, JobSpec] = {}
        self.job_queue: deque = deque()  # Priority queue
        self.lock = threading.RLock()
        
        # Metrics
        self.enable_metrics = enable_metrics
        self.metrics = {
            'total_jobs_scheduled': 0,
            'total_jobs_completed': 0,
            'total_jobs_failed': 0,
            'total_compute_hours': 0.0,
            'current_utilization': 0.0,
            'avg_queue_time_sec': 0.0,
            'peak_utilization': 0.0
        }
        
        # Model synchronization state
        self.current_model_version = "model_v0"
        self.model_sync_status = {}  # {tpu_id: version}
        
        logger.info(f"✅ TPU Grid Manager initialized: {num_tpus:,} cores across {self.num_pods:,} pods")
    
    def _initialize_grid(self):
        """Create logical TPU grid organized in pods"""
        tpu_id = 0
        
        for pod_id in range(self.num_pods):
            pod_cores = []
            
            for core_idx in range(self.cores_per_pod):
                tpu = LogicalTPU(
                    id=tpu_id,
                    pod_id=pod_id,
                    state=TPUState.IDLE
                )
                self.tpus[tpu_id] = tpu
                pod_cores.append(tpu)
                tpu_id += 1
            
            self.pods[pod_id] = TPUPod(
                pod_id=pod_id,
                tpu_cores=pod_cores,
                state=PodState.INACTIVE  # Start inactive
            )
        
        logger.info(f"Initialized {len(self.tpus):,} TPU cores in {len(self.pods):,} pods")
    
    # Phase 3: Pod Management Methods
    
    def activate_pod(self, pod_id: int) -> bool:
        """
        Activate a pod for workload assignment
        
        Args:
            pod_id: Pod to activate
            
        Returns:
            Success status
        """
        with self.lock:
            if pod_id not in self.pods:
                logger.error(f"Pod {pod_id} not found")
                return False
            
            pod = self.pods[pod_id]
            if pod.is_active:
                logger.warning(f"Pod {pod_id} already active")
                return True
            
            pod.activate()
            return True
    
    def deactivate_pod(self, pod_id: int) -> bool:
        """
        Deactivate a pod (release resources)
        
        Args:
            pod_id: Pod to deactivate
            
        Returns:
            Success status
        """
        with self.lock:
            if pod_id not in self.pods:
                logger.error(f"Pod {pod_id} not found")
                return False
            
            pod = self.pods[pod_id]
            
            # Can't deactivate if busy
            if pod.busy_cores > 0:
                logger.warning(f"Pod {pod_id} has {pod.busy_cores} busy cores, cannot deactivate")
                return False
            
            pod.deactivate()
            return True
    
    def get_active_pods(self) -> List[int]:
        """Get list of active pod IDs"""
        with self.lock:
            return [pod_id for pod_id, pod in self.pods.items() if pod.is_active]
    
    def get_pod_status(self, pod_id: int) -> Optional[Dict]:
        """Get detailed status for specific pod"""
        with self.lock:
            if pod_id not in self.pods:
                return None
            return self.pods[pod_id].to_dict()
    
    def allocate_pods(
        self,
        job_id: str,
        job_type: JobType,
        num_pods: int,
        priority: int = 5,
        auto_activate: bool = True
    ) -> Tuple[bool, List[int]]:
        """
        Allocate entire pods for a job (better locality)
        
        Args:
            job_id: Unique job identifier
            job_type: Type of job
            num_pods: Number of pods requested
            priority: Job priority
            auto_activate: Automatically activate inactive pods
            
        Returns:
            (success, allocated_pod_ids)
        """
        with self.lock:
            allocated_pod_ids = []
            
            # Find available pods
            for pod_id, pod in self.pods.items():
                if len(allocated_pod_ids) >= num_pods:
                    break
                
                # Check if pod is available
                if pod.is_active and pod.available_cores == pod.size:
                    allocated_pod_ids.append(pod_id)
                elif not pod.is_active and auto_activate:
                    # Activate and allocate
                    pod.activate()
                    allocated_pod_ids.append(pod_id)
            
            if len(allocated_pod_ids) < num_pods:
                logger.warning(f"Could only allocate {len(allocated_pod_ids)}/{num_pods} pods for job {job_id}")
                return False, allocated_pod_ids
            
            # Create job spec with pods
            num_tpus = num_pods * self.cores_per_pod
            job = JobSpec(
                job_id=job_id,
                job_type=job_type,
                num_tpus_requested=num_tpus,
                priority=priority
            )
            
            # Assign job to allocated pods
            for pod_id in allocated_pod_ids:
                pod = self.pods[pod_id]
                pod.assign_job(job_id, job_type)
                job.assigned_tpus.extend([tpu.id for tpu in pod.tpu_cores])
            
            job.started_at = time.time()
            self.jobs[job_id] = job
            self.metrics['total_jobs_scheduled'] += 1
            
            logger.info(f"✅ Allocated {num_pods} pods ({num_tpus} TPUs) for job {job_id} ({job_type.value})")
            return True, allocated_pod_ids
    
    def release_pods(self, job_id: str) -> bool:
        """
        Release pods from completed job
        
        Args:
            job_id: Job to release
            
        Returns:
            Success status
        """
        with self.lock:
            if job_id not in self.jobs:
                logger.warning(f"Job {job_id} not found")
                return False
            
            job = self.jobs[job_id]
            
            # Find and release pods
            released_pods = []
            for pod_id, pod in self.pods.items():
                if pod.current_job_id == job_id:
                    pod.release_job()
                    released_pods.append(pod_id)
            
            job.completed_at = time.time()
            self.metrics['total_jobs_completed'] += 1
            
            # Calculate compute hours
            if job.started_at:
                duration_hours = (job.completed_at - job.started_at) / 3600.0
                compute_hours = duration_hours * len(job.assigned_tpus)
                self.metrics['total_compute_hours'] += compute_hours
            
            logger.info(f"✅ Released {len(released_pods)} pods from job {job_id}")
            
            # Try to schedule queued jobs
            self._process_job_queue()
            
            return True
    
    def update_pod_heartbeats(self):
        """Update heartbeats for all active pods"""
        with self.lock:
            for pod in self.pods.values():
                if pod.is_active:
                    pod.heartbeat()
    
    def check_pod_health(self) -> Dict[str, int]:
        """Check health of all pods and return summary"""
        with self.lock:
            healthy = 0
            unhealthy = 0
            inactive = 0
            
            for pod in self.pods.values():
                if not pod.is_active:
                    inactive += 1
                elif pod.check_health():
                    healthy += 1
                else:
                    unhealthy += 1
            
            return {
                'healthy_pods': healthy,
                'unhealthy_pods': unhealthy,
                'inactive_pods': inactive,
                'total_pods': len(self.pods)
            }
    
    def allocate_tpus(
        self,
        job_id: str,
        job_type: JobType,
        num_tpus: int,
        priority: int = 5
    ) -> Tuple[bool, List[int]]:
        """
        Allocate TPUs for a job
        
        Args:
            job_id: Unique job identifier
            job_type: Type of job (selfplay, training, eval)
            num_tpus: Number of TPU cores requested
            priority: Job priority (1-10)
        
        Returns:
            (success, assigned_tpu_ids)
        """
        with self.lock:
            # Create job spec
            job = JobSpec(
                job_id=job_id,
                job_type=job_type,
                num_tpus_requested=num_tpus,
                priority=priority
            )
            
            # Try to allocate immediately
            allocated_tpus = self._find_available_tpus(num_tpus, job_type)
            
            if len(allocated_tpus) >= num_tpus:
                # Allocation successful
                for tpu_id in allocated_tpus[:num_tpus]:
                    self.tpus[tpu_id].assign_job(job_id, job_type)
                
                job.assigned_tpus = allocated_tpus[:num_tpus]
                job.started_at = time.time()
                self.jobs[job_id] = job
                self.metrics['total_jobs_scheduled'] += 1
                
                logger.info(f"✅ Allocated {num_tpus} TPUs for job {job_id} ({job_type.value})")
                return True, job.assigned_tpus
            else:
                # Queue job for later
                self.jobs[job_id] = job
                self.job_queue.append(job)
                
                logger.info(f"⏳ Queued job {job_id} ({job_type.value}) - waiting for {num_tpus} TPUs")
                return False, []
    
    def _find_available_tpus(self, num_tpus: int, job_type: JobType) -> List[int]:
        """
        Find available TPUs with locality awareness
        Prefer allocating from same pod for better interconnect
        """
        allocated = []
        
        # Strategy 1: Try to find full pods (best locality)
        if num_tpus >= self.cores_per_pod:
            for pod in self.pods.values():
                if pod.available_cores >= self.cores_per_pod:
                    pod_tpus = [tpu.id for tpu in pod.tpu_cores if tpu.state == TPUState.IDLE]
                    allocated.extend(pod_tpus[:self.cores_per_pod])
                    
                    if len(allocated) >= num_tpus:
                        return allocated[:num_tpus]
        
        # Strategy 2: Allocate from partially available pods
        for pod in self.pods.values():
            if pod.available_cores > 0:
                pod_tpus = [tpu.id for tpu in pod.tpu_cores if tpu.state == TPUState.IDLE]
                allocated.extend(pod_tpus)
                
                if len(allocated) >= num_tpus:
                    return allocated[:num_tpus]
        
        return allocated
    
    def release_tpus(self, job_id: str) -> bool:
        """
        Release TPUs from completed job
        
        Args:
            job_id: Job to release
            
        Returns:
            Success status
        """
        with self.lock:
            if job_id not in self.jobs:
                logger.warning(f"Job {job_id} not found")
                return False
            
            job = self.jobs[job_id]
            
            # Release all assigned TPUs
            for tpu_id in job.assigned_tpus:
                self.tpus[tpu_id].release_job()
            
            job.completed_at = time.time()
            self.metrics['total_jobs_completed'] += 1
            
            # Calculate compute hours
            if job.started_at:
                duration_hours = (job.completed_at - job.started_at) / 3600.0
                compute_hours = duration_hours * len(job.assigned_tpus)
                self.metrics['total_compute_hours'] += compute_hours
            
            logger.info(f"✅ Released {len(job.assigned_tpus)} TPUs from job {job_id}")
            
            # Try to schedule queued jobs
            self._process_job_queue()
            
            return True
    
    def _process_job_queue(self):
        """Process queued jobs and allocate if resources available"""
        if not self.job_queue:
            return
        
        # Sort by priority (higher first)
        sorted_queue = sorted(self.job_queue, key=lambda j: j.priority, reverse=True)
        
        for job in sorted_queue:
            allocated_tpus = self._find_available_tpus(job.num_tpus_requested, job.job_type)
            
            if len(allocated_tpus) >= job.num_tpus_requested:
                # Allocate
                for tpu_id in allocated_tpus[:job.num_tpus_requested]:
                    self.tpus[tpu_id].assign_job(job.job_id, job.job_type)
                
                job.assigned_tpus = allocated_tpus[:job.num_tpus_requested]
                job.started_at = time.time()
                
                # Remove from queue
                self.job_queue.remove(job)
                
                logger.info(f"✅ Scheduled queued job {job.job_id} with {len(job.assigned_tpus)} TPUs")
    
    def scale_grid(self, new_size: int) -> bool:
        """
        Scale TPU grid up or down
        
        Args:
            new_size: New total TPU count
            
        Returns:
            Success status
        """
        with self.lock:
            if new_size < self.num_tpus:
                # Scale down - only if TPUs are idle
                active_tpus = sum(1 for tpu in self.tpus.values() if tpu.state != TPUState.IDLE)
                if active_tpus > new_size:
                    logger.warning(f"Cannot scale down: {active_tpus} TPUs are active")
                    return False
            
            old_size = self.num_tpus
            self.num_tpus = new_size
            self.num_pods = new_size // self.cores_per_pod
            
            # Reinitialize grid
            self._initialize_grid()
            
            logger.info(f"✅ Scaled TPU grid: {old_size:,} → {new_size:,} cores")
            return True
    
    def sync_model(self, model_version: str, tpu_ids: Optional[List[int]] = None) -> Dict:
        """
        Simulate model synchronization across TPUs
        
        Args:
            model_version: Model version identifier
            tpu_ids: Specific TPUs to sync (None = all)
        
        Returns:
            Sync status
        """
        with self.lock:
            target_tpus = tpu_ids if tpu_ids else list(self.tpus.keys())
            
            # Simulate sync latency
            sync_time = len(target_tpus) * 0.01  # 10ms per TPU
            
            for tpu_id in target_tpus:
                self.model_sync_status[tpu_id] = model_version
            
            self.current_model_version = model_version
            
            logger.info(f"✅ Synced model {model_version} to {len(target_tpus):,} TPUs (simulated time: {sync_time:.2f}s)")
            
            return {
                'model_version': model_version,
                'tpus_synced': len(target_tpus),
                'sync_time_sec': sync_time
            }
    
    def get_grid_status(self) -> Dict:
        """Get comprehensive grid status (Phase 3 Enhanced)"""
        with self.lock:
            # Calculate current utilization
            busy_tpus = sum(1 for tpu in self.tpus.values() if tpu.state == TPUState.BUSY)
            total_utilization = sum(tpu.utilization for tpu in self.tpus.values()) / self.num_tpus
            
            # Update metrics
            self.metrics['current_utilization'] = total_utilization
            if total_utilization > self.metrics['peak_utilization']:
                self.metrics['peak_utilization'] = total_utilization
            
            # Job statistics
            active_jobs = [j for j in self.jobs.values() if j.started_at and not j.completed_at]
            queued_jobs = len(self.job_queue)
            
            # Phase 3: Pod health and statistics
            pod_health = self.check_pod_health()
            active_pods = [pod for pod in self.pods.values() if pod.is_active]
            
            # Detailed pod stats for all pods (Phase 3: show all pods for 8-pod setup)
            pod_stats = [pod.to_dict() for pod in self.pods.values()]
            
            # Pod performance aggregation
            total_pod_games = sum(pod.total_games_completed for pod in self.pods.values())
            total_pod_positions = sum(pod.total_positions_generated for pod in self.pods.values())
            avg_pod_throughput = sum(pod.pod_throughput_games_per_sec for pod in active_pods) / len(active_pods) if active_pods else 0.0
            
            return {
                'grid': {
                    'total_tpus': self.num_tpus,
                    'total_pods': self.num_pods,
                    'cores_per_pod': self.cores_per_pod,
                    'idle_tpus': self.num_tpus - busy_tpus,
                    'busy_tpus': busy_tpus,
                    'offline_tpus': 0,
                    'active_pods': len(active_pods),
                    'inactive_pods': self.num_pods - len(active_pods)
                },
                'utilization': {
                    'current_percent': round(total_utilization, 2),
                    'peak_percent': round(self.metrics['peak_utilization'], 2),
                    'busy_cores': busy_tpus,
                    'idle_cores': self.num_tpus - busy_tpus
                },
                'jobs': {
                    'active': len(active_jobs),
                    'queued': queued_jobs,
                    'total_scheduled': self.metrics['total_jobs_scheduled'],
                    'total_completed': self.metrics['total_jobs_completed'],
                    'total_failed': self.metrics['total_jobs_failed']
                },
                'performance': {
                    'total_compute_hours': round(self.metrics['total_compute_hours'], 2),
                    'avg_queue_time_sec': round(self.metrics['avg_queue_time_sec'], 2),
                    'total_games_completed': total_pod_games,
                    'total_positions_generated': total_pod_positions,
                    'avg_pod_throughput_games_per_sec': round(avg_pod_throughput, 3)
                },
                'model': {
                    'current_version': self.current_model_version,
                    'synced_tpus': len(self.model_sync_status)
                },
                'pod_health': pod_health,
                'pods': pod_stats  # Phase 3: All pods for monitoring
            }
    
    def get_job_status(self, job_id: str) -> Optional[Dict]:
        """Get status of specific job"""
        with self.lock:
            if job_id not in self.jobs:
                return None
            return self.jobs[job_id].to_dict()
    
    def get_tpu_details(self, tpu_id: int) -> Optional[Dict]:
        """Get detailed info for specific TPU"""
        with self.lock:
            if tpu_id not in self.tpus:
                return None
            return self.tpus[tpu_id].to_dict()


# Global TPU grid instance
_tpu_grid_manager = None


def get_tpu_grid(num_tpus: int = 5000) -> TPUGridManager:
    """Get or create global TPU grid manager"""
    global _tpu_grid_manager
    
    if _tpu_grid_manager is None:
        _tpu_grid_manager = TPUGridManager(num_tpus=num_tpus)
    
    return _tpu_grid_manager


def reset_tpu_grid():
    """Reset global TPU grid (for testing)"""
    global _tpu_grid_manager
    _tpu_grid_manager = None
