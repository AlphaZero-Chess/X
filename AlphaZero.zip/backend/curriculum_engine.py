"""
Curriculum Engine for AlphaZero Self-Evolution
LLM-guided curriculum planning and position complexity scoring
"""
import logging
import json
import numpy as np
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timezone
import asyncio
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)

# Import emergentintegrations
try:
    from emergentintegrations.llm.chat import LlmChat, UserMessage
    EMERGENT_AVAILABLE = True
except ImportError:
    EMERGENT_AVAILABLE = False
    logger.warning("emergentintegrations not available, LLM features disabled")


class CurriculumEngine:
    """LLM-assisted curriculum planning for self-play training"""
    
    def __init__(self, cache_dir: str = "/app/backend/cache/curriculum", use_llm: bool = True):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.use_llm = use_llm
        
        # Initialize LLM client if enabled
        self.llm_client = None
        if self.use_llm and EMERGENT_AVAILABLE:
            try:
                api_key = os.environ.get('EMERGENT_LLM_KEY')
                if api_key:
                    self.llm_client = LlmChat(
                        api_key=api_key,
                        session_id="curriculum_engine",
                        system_message="You are an AI chess curriculum planner analyzing games to create optimal training plans."
                    ).with_model("anthropic", "claude-3-7-sonnet-20250219")
                    logger.info("Curriculum Engine initialized with LLM (Claude 3.7 Sonnet)")
                else:
                    logger.warning("EMERGENT_LLM_KEY not found, using numerical-only mode")
                    self.use_llm = False
            except Exception as e:
                logger.warning(f"LLM initialization failed, using numerical-only mode: {e}")
                self.use_llm = False
        elif not EMERGENT_AVAILABLE:
            logger.warning("emergentintegrations not available, using numerical-only mode")
            self.use_llm = False
        
        # Curriculum state
        self.current_plan = None
        self.load_curriculum_state()
    
    def score_position_complexity(self, fen: str, move_number: int, game_result: str) -> Dict[str, float]:
        """
        Score position complexity across multiple dimensions
        
        Returns:
            {
                'tactical': 0.0-1.0,
                'positional': 0.0-1.0,
                'endgame': 0.0-1.0,
                'overall': 0.0-1.0
            }
        """
        scores = {
            'tactical': 0.0,
            'positional': 0.0,
            'endgame': 0.0,
            'overall': 0.0
        }
        
        try:
            import chess
            board = chess.Board(fen)
            
            # Count pieces for endgame detection
            piece_count = len(board.piece_map())
            
            # Endgame score (fewer pieces = higher endgame score)
            scores['endgame'] = max(0.0, (32 - piece_count) / 24.0)
            
            # Tactical score (based on captures and checks available)
            captures = sum(1 for move in board.legal_moves if board.is_capture(move))
            checks = sum(1 for move in board.legal_moves if board.gives_check(move))
            scores['tactical'] = min(1.0, (captures * 0.1 + checks * 0.2))
            
            # Positional score (middle game with many pieces)
            if 16 <= piece_count <= 28 and move_number >= 10:
                scores['positional'] = 0.7 + (move_number / 100.0)
            else:
                scores['positional'] = 0.3
            
            # Overall complexity
            scores['overall'] = (scores['tactical'] + scores['positional'] + scores['endgame']) / 3.0
            
        except Exception as e:
            logger.error(f"Error scoring position complexity: {e}")
            scores['overall'] = 0.5  # Default medium complexity
        
        return scores
    
    async def analyze_game_with_llm(self, pgn: str, game_result: str) -> Dict[str, any]:
        """
        Use LLM to analyze game and extract learning insights
        
        Returns:
            {
                'opening_type': str,
                'key_mistakes': List[str],
                'tactical_themes': List[str],
                'learning_priority': 'high'|'medium'|'low',
                'complexity_category': 'endgame'|'tactical'|'positional'|'opening'
            }
        """
        if not self.use_llm or not self.llm_client:
            return self._fallback_analysis(pgn, game_result)
        
        try:
            prompt = f"""Analyze this chess game (PGN format) and extract learning insights for AlphaZero training:

Game PGN:
{pgn}

Result: {game_result}

Provide a JSON response with:
1. opening_type: Name the opening played (e.g., "Sicilian Defense", "King's Indian")
2. key_mistakes: List 2-3 critical mistakes (if any)
3. tactical_themes: List tactical patterns present (pins, forks, skewers, etc.)
4. learning_priority: 'high', 'medium', or 'low' (based on instructional value)
5. complexity_category: 'endgame', 'tactical', 'positional', or 'opening'

Return ONLY valid JSON, no explanation."""

            user_message = UserMessage(text=prompt)
            response = await self.llm_client.send_message(user_message)
            
            # Parse JSON response
            analysis = json.loads(response)
            
            # Validate required fields
            required_fields = ['opening_type', 'key_mistakes', 'tactical_themes', 
                             'learning_priority', 'complexity_category']
            if all(field in analysis for field in required_fields):
                return analysis
            else:
                logger.warning("LLM response missing required fields, using fallback")
                return self._fallback_analysis(pgn, game_result)
                
        except Exception as e:
            logger.error(f"LLM game analysis failed: {e}")
            return self._fallback_analysis(pgn, game_result)
    
    def _fallback_analysis(self, pgn: str, game_result: str) -> Dict[str, any]:
        """Fallback analysis without LLM (numerical only)"""
        # Simple heuristic-based analysis
        move_count = pgn.count('.') if pgn else 0
        
        complexity_category = 'opening'
        if move_count > 40:
            complexity_category = 'endgame'
        elif move_count > 20:
            complexity_category = 'positional'
        elif move_count > 10:
            complexity_category = 'tactical'
        
        return {
            'opening_type': 'Unknown',
            'key_mistakes': [],
            'tactical_themes': [],
            'learning_priority': 'medium',
            'complexity_category': complexity_category
        }
    
    async def create_curriculum_plan(self, recent_games: List[Dict], total_games_played: int) -> Dict[str, any]:
        """
        Create curriculum training plan based on recent self-play games
        
        Args:
            recent_games: List of recent game dictionaries with PGN and results
            total_games_played: Total games played so far
        
        Returns:
            Curriculum plan with training priorities and focus areas
        """
        logger.info(f"Creating curriculum plan from {len(recent_games)} recent games")
        
        # Analyze games
        game_analyses = []
        for game in recent_games[:20]:  # Analyze last 20 games max
            pgn = game.get('pgn', '')
            result = game.get('result', '*')
            analysis = await self.analyze_game_with_llm(pgn, result)
            game_analyses.append(analysis)
        
        # Aggregate insights
        complexity_counts = {}
        priority_counts = {'high': 0, 'medium': 0, 'low': 0}
        all_mistakes = []
        all_themes = []
        
        for analysis in game_analyses:
            cat = analysis.get('complexity_category', 'tactical')
            complexity_counts[cat] = complexity_counts.get(cat, 0) + 1
            
            priority = analysis.get('learning_priority', 'medium')
            priority_counts[priority] = priority_counts.get(priority, 0) + 1
            
            all_mistakes.extend(analysis.get('key_mistakes', []))
            all_themes.extend(analysis.get('tactical_themes', []))
        
        # Determine training focus
        if complexity_counts:
            primary_focus = max(complexity_counts.items(), key=lambda x: x[1])[0]
        else:
            primary_focus = 'tactical'
        
        # Create plan
        plan = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'total_games_analyzed': len(game_analyses),
            'total_games_played': total_games_played,
            'primary_focus': primary_focus,
            'complexity_distribution': complexity_counts,
            'priority_distribution': priority_counts,
            'common_mistakes': list(set(all_mistakes))[:5],  # Top 5 unique mistakes
            'tactical_themes': list(set(all_themes))[:5],  # Top 5 unique themes
            'training_recommendations': self._generate_recommendations(
                primary_focus, complexity_counts, total_games_played
            ),
            'next_milestone': self._calculate_next_milestone(total_games_played)
        }
        
        # Save plan
        self.current_plan = plan
        self.save_curriculum_state()
        
        logger.info(f"Curriculum plan created: Focus={primary_focus}, Games={total_games_played}")
        
        return plan
    
    def _generate_recommendations(self, primary_focus: str, distribution: Dict, 
                                  total_games: int) -> List[str]:
        """Generate training recommendations based on analysis"""
        recommendations = []
        
        # Phase-based recommendations
        if total_games < 100:
            recommendations.append("Focus on endgame fundamentals (pawn structures, king activity)")
            recommendations.append("Practice basic tactical patterns (pins, forks, skewers)")
        elif total_games < 1000:
            recommendations.append("Develop positional understanding (piece coordination, space control)")
            recommendations.append("Study complex tactical combinations")
        else:
            recommendations.append("Refine strategic planning in complex positions")
            recommendations.append("Master rare endgame positions")
        
        # Focus-specific recommendations
        if primary_focus == 'endgame':
            recommendations.append("Prioritize endgame training positions")
        elif primary_focus == 'tactical':
            recommendations.append("Increase tactical puzzle exposure")
        elif primary_focus == 'positional':
            recommendations.append("Study closed positions and maneuvering")
        
        return recommendations
    
    def _calculate_next_milestone(self, total_games: int) -> Dict[str, any]:
        """Calculate next training milestone"""
        milestones = [100, 500, 1000, 2500, 5000, 10000]
        
        for milestone in milestones:
            if total_games < milestone:
                return {
                    'games': milestone,
                    'games_remaining': milestone - total_games,
                    'description': f"Reach {milestone} self-play games"
                }
        
        # Beyond all milestones
        next_round = ((total_games // 10000) + 1) * 10000
        return {
            'games': next_round,
            'games_remaining': next_round - total_games,
            'description': f"Reach {next_round} self-play games"
        }
    
    def save_curriculum_state(self):
        """Save current curriculum state to cache"""
        try:
            if self.current_plan:
                state_file = self.cache_dir / "current_plan.json"
                with open(state_file, 'w') as f:
                    json.dump(self.current_plan, f, indent=2)
                logger.debug("Curriculum state saved")
        except Exception as e:
            logger.error(f"Failed to save curriculum state: {e}")
    
    def load_curriculum_state(self):
        """Load curriculum state from cache"""
        try:
            state_file = self.cache_dir / "current_plan.json"
            if state_file.exists():
                with open(state_file, 'r') as f:
                    self.current_plan = json.load(f)
                logger.info("Curriculum state loaded")
        except Exception as e:
            logger.warning(f"Failed to load curriculum state: {e}")
    
    def get_current_plan(self) -> Optional[Dict]:
        """Get current curriculum plan"""
        return self.current_plan
    
    def set_llm_mode(self, enabled: bool):
        """Enable or disable LLM-assisted curriculum (Hybrid Reflection Mode)"""
        self.use_llm = enabled
        if enabled and not self.llm_client and EMERGENT_AVAILABLE:
            try:
                api_key = os.environ.get('EMERGENT_LLM_KEY')
                if api_key:
                    self.llm_client = LlmChat(
                        api_key=api_key,
                        session_id="curriculum_engine",
                        system_message="You are an AI chess curriculum planner analyzing games to create optimal training plans."
                    ).with_model("anthropic", "claude-3-7-sonnet-20250219")
                    logger.info("LLM mode enabled")
                else:
                    logger.error("EMERGENT_LLM_KEY not found")
                    self.use_llm = False
            except Exception as e:
                logger.error(f"Failed to enable LLM mode: {e}")
                self.use_llm = False
        elif not enabled:
            logger.info("LLM mode disabled (numerical-only)")
