"""
Cloud TPU Grid API Routes
REST and WebSocket endpoints for cloud control panel
"""
from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect, BackgroundTasks
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import asyncio
import json
import logging
from datetime import datetime, timezone

from cloud_simulator import cloud_simulator

logger = logging.getLogger(__name__)

# Create router with /api/cloud prefix
cloud_router = APIRouter(prefix="/api/cloud", tags=["cloud"])

# WebSocket connection manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"WebSocket connected. Total connections: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        logger.info(f"WebSocket disconnected. Total connections: {len(self.active_connections)}")

    async def broadcast(self, message: dict):
        """Broadcast message to all connected clients"""
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error sending message: {e}")
                disconnected.append(connection)
        
        # Remove disconnected clients
        for conn in disconnected:
            self.disconnect(conn)

manager = ConnectionManager()

# Data models
class ScaleRequest(BaseModel):
    target_tpus: int = Field(..., ge=100, le=10000, description="Target TPU count (100-10,000)")

class FaultInjectionRequest(BaseModel):
    region: str = Field(..., description="Target region or 'random'")
    fault_type: str = Field(..., description="Fault type: 'crash', 'latency', or 'recovery'")
    num_nodes: int = Field(default=10, ge=1, le=100, description="Number of nodes to affect")

class JobSubmitRequest(BaseModel):
    name: str = Field(..., description="Job name")
    tpus_required: int = Field(..., ge=1, le=1000, description="TPUs required")
    priority: int = Field(default=3, ge=1, le=5, description="Job priority (1=lowest, 5=highest)")
    region: str = Field(default="us-east", description="Target region")

# REST Endpoints
@cloud_router.get("/status")
async def get_cloud_status():
    """
    Get current cloud grid status
    Returns overview of all regions, TPU counts, and utilization
    """
    try:
        status = cloud_simulator.get_status()
        return {
            "success": True,
            **status
        }
    except Exception as e:
        logger.error(f"Error getting cloud status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@cloud_router.post("/scale")
async def scale_grid(request: ScaleRequest):
    """
    Scale TPU grid up or down
    Adds or removes TPU nodes across regions
    """
    try:
        result = cloud_simulator.scale(request.target_tpus)
        
        # Broadcast update to WebSocket clients
        await manager.broadcast({
            "type": "scale_update",
            "data": result,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error scaling grid: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@cloud_router.get("/metrics")
async def get_cloud_metrics():
    """
    Get detailed cloud metrics
    Returns throughput, utilization, fault rates, and latency matrix
    """
    try:
        metrics = cloud_simulator.get_metrics()
        return {
            "success": True,
            **metrics
        }
    except Exception as e:
        logger.error(f"Error getting cloud metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@cloud_router.post("/inject-fault")
async def inject_fault(request: FaultInjectionRequest):
    """
    Inject faults into the grid for testing
    Simulates node crashes, latency issues, or recovery
    """
    try:
        result = cloud_simulator.inject_fault(
            region=request.region,
            fault_type=request.fault_type,
            num_nodes=request.num_nodes
        )
        
        # Broadcast fault event to WebSocket clients
        await manager.broadcast({
            "type": "fault_injection",
            "data": result,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error injecting fault: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@cloud_router.get("/jobs")
async def get_jobs():
    """
    Get job queue status
    Returns running and queued jobs
    """
    try:
        jobs = cloud_simulator.get_jobs()
        return {
            "success": True,
            **jobs
        }
    except Exception as e:
        logger.error(f"Error getting jobs: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@cloud_router.post("/jobs/submit")
async def submit_job(request: JobSubmitRequest):
    """
    Submit a new training job to the queue
    """
    try:
        job_id = cloud_simulator.submit_job(
            name=request.name,
            tpus_required=request.tpus_required,
            priority=request.priority,
            region=request.region
        )
        
        return {
            "success": True,
            "job_id": job_id,
            "message": f"Job {request.name} submitted successfully"
        }
    except Exception as e:
        logger.error(f"Error submitting job: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@cloud_router.get("/regions")
async def get_regions():
    """Get list of available regions"""
    from cloud_simulator import REGIONS
    return {
        "success": True,
        "regions": REGIONS
    }

# WebSocket Endpoint
@cloud_router.websocket("/live")
async def websocket_endpoint(websocket: WebSocket):
    """
    WebSocket endpoint for real-time cloud metrics streaming
    Sends updates every 2 seconds
    """
    await manager.connect(websocket)
    
    try:
        # Send initial status
        initial_status = cloud_simulator.get_status()
        await websocket.send_json({
            "type": "initial_status",
            "data": initial_status,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        # Start streaming loop
        while True:
            try:
                # Update simulation state
                cloud_simulator.update_simulation()
                
                # Get current metrics
                status = cloud_simulator.get_status()
                metrics = cloud_simulator.get_metrics()
                jobs = cloud_simulator.get_jobs()
                
                # Send update to client
                await websocket.send_json({
                    "type": "live_update",
                    "data": {
                        "status": status,
                        "metrics": metrics,
                        "jobs": jobs
                    },
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })
                
                # Wait 2 seconds before next update
                await asyncio.sleep(2)
                
            except WebSocketDisconnect:
                break
            except Exception as e:
                logger.error(f"Error in WebSocket loop: {e}")
                break
    
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        manager.disconnect(websocket)

# Configuration endpoint
@cloud_router.get("/ui-config")
async def get_ui_config():
    """
    Get UI configuration for frontend
    Returns default settings for the control panel
    """
    from cloud_simulator import REGIONS
    
    return {
        "success": True,
        "config": {
            "regions": REGIONS,
            "update_interval_ms": 2000,
            "default_theme": "dark",
            "max_tpus": 10000,
            "min_tpus": 100,
            "default_tpus": 5000
        }
    }
