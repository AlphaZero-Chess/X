# TPU Backend Runbook

Step-by-step CLI commands for testing and running AlphaZero with TPU backend.

## Table of Contents

1. [Environment Setup](#environment-setup)
2. [Testing](#testing)
3. [Demo](#demo)
4. [Integration with AlphaZero](#integration-with-alphazero)
5. [Troubleshooting](#troubleshooting)

---

## Environment Setup

### 1. Check Python Version

```bash
python3 --version
# Required: Python 3.8 or higher
```

### 2. Install Base Requirements

```bash
cd /app/backend
pip install torch torchvision numpy python-chess
```

### 3. Verify PyTorch Installation

```bash
python3 -c "import torch; print(f'PyTorch {torch.__version__}')"
python3 -c "import torch; print(f'CUDA available: {torch.cuda.is_available()}')"
```

**Expected Output (with GPU):**
```
PyTorch 2.0.0+cu118
CUDA available: True
```

**Expected Output (CPU only):**
```
PyTorch 2.0.0
CUDA available: False
```

### 4. (Optional) Install JAX for Real TPU

```bash
# For Cloud TPU
pip install jax[tpu] -f https://storage.googleapis.com/jax-releases/libtpu_releases.html

# Verify
python3 -c "import jax; print(f'JAX {jax.__version__}')"
python3 -c "import jax; print(f'TPU devices: {len(jax.devices(\"tpu\"))}')"
```

### 5. (Optional) Install PyTorch XLA for Real TPU

```bash
# Follow official guide
pip install torch_xla

# Verify
python3 -c "import torch_xla; print('PyTorch XLA installed')"
```

### 6. Check Hardware Detection

```bash
python3 -c "from tpu_backend.utils import print_hardware_info; print_hardware_info()"
```

**Expected Output:**
```
============================================================
HARDWARE DETECTION
============================================================

CPU: ✓ Available

CUDA GPU: ✓ Available
  - Devices: 1
  - Device Name: NVIDIA Tesla T4

JAX TPU: ✗ Not Available

PyTorch XLA TPU: ✗ Not Available

============================================================
```

---

## Testing

### 1. Run Unit Tests

```bash
cd /app/backend
python3 tests/test_tpu_backend.py
```

**Expected Output:**
```
============================================================
TPU BACKEND UNIT TESTS
============================================================

test_backend_initialization ... ok
test_list_backends ... ok
test_device_info ... ok
...

============================================================
Tests run: 15
Failures: 0
Errors: 0
Success rate: 100.0%
============================================================
```

### 2. Run Integration Tests

```bash
cd /app/backend
python3 tests/test_tpu_integration.py
```

**Expected Output:**
```
============================================================
TPU BACKEND INTEGRATION TESTS
============================================================

test_chess_model_inference ... 
  Inference time: 12.34ms for batch of 4
ok

test_chess_model_training ... 
  Training loss: 0.5432
ok
...
```

### 3. Run Specific Test

```bash
# Test only simulated backend
python3 -m unittest tests.test_tpu_backend.TestSimulatedTPUBackend

# Test only performance
python3 -m unittest tests.test_tpu_integration.TestTPUPerformanceBenchmark
```

---

## Demo

### 1. Run 10-Game Demo (Auto Backend)

```bash
cd /app/backend
python3 demo_tpu_selfplay.py
```

**Expected Output:**
```
============================================================
TPU BACKEND DEMO - 10 SELF-PLAY CHESS GAMES
============================================================

HARDWARE DETECTION
============================================================

CPU: ✓ Available
CUDA GPU: ✓ Available
  - Devices: 1
  - Device Name: NVIDIA Tesla T4

...

Initializing TPU backend (mode: auto)...
✓ Backend initialized: Simulated
✓ Device info: {'backend': 'simulated', 'device_type': 'cuda', ...}

Initializing chess model...
✓ Model compiled

Playing 10 self-play games...

Game 1/10... ✓ 45 moves, max_moves, winner: draw, 2.34s
Game 2/10... ✓ 38 moves, max_moves, winner: draw, 1.98s
...
Game 10/10... ✓ 52 moves, max_moves, winner: draw, 2.67s

============================================================
DEMO RESULTS
============================================================

Games played: 10
Total moves: 423
Average moves per game: 42.3
Total time: 23.45s
Average time per game: 2.35s
Average time per move: 0.055s
Demo elapsed time: 24.12s

Results breakdown:
  max_moves: 10 (100.0%)

Backend: Simulated
  Total inferences: 423
  Avg inference time: 52.34ms

============================================================

✓ Results saved to: /app/backend/demo_results_20250815_143022.json

✓ Demo completed successfully!
```

### 2. Force Simulated Backend

```bash
python3 demo_tpu_selfplay.py --backend simulated
```

### 3. Force JAX TPU Backend (if available)

```bash
python3 demo_tpu_selfplay.py --backend jax
```

### 4. Force PyTorch XLA TPU Backend (if available)

```bash
python3 demo_tpu_selfplay.py --backend torch_xla
```

### 5. Run More Games

```bash
# Run 50 games
python3 demo_tpu_selfplay.py --games 50

# Run 100 games with specific backend
python3 demo_tpu_selfplay.py --games 100 --backend simulated
```

### 6. Run Without Saving Results

```bash
python3 demo_tpu_selfplay.py --no-save
```

---

## Integration with AlphaZero

### 1. Check AlphaZero Components

```bash
cd /app/backend
python3 -c "from neural_network import ChessNet; print('✓ ChessNet available')"
python3 -c "from mcts import MCTS; print('✓ MCTS available')"
python3 -c "from self_play import SelfPlay; print('✓ SelfPlay available')"
```

### 2. Test TPU Backend with AlphaZero Neural Network

```bash
python3 << 'EOF'
from tpu_backend import get_tpu_backend
from neural_network import ChessNet
import torch

# Initialize backend
backend = get_tpu_backend(mode='auto')
print(f"Backend: {backend.backend_name}")

# Load model
model = ChessNet()
model = backend.compile_model(model)
print("✓ ChessNet compiled for TPU")

# Test inference
import numpy as np
board_input = np.random.randn(4, 12, 8, 8).astype(np.float32)
policy, value = backend.inference(model, board_input)
print(f"✓ Inference successful: policy shape {policy.shape}, value shape {value.shape}")
EOF
```

### 3. Run AlphaZero Self-Play with TPU Backend

```bash
# This assumes AlphaZero is modified to use TPU backend
python3 selfplay_trainer.py --backend tpu --mode auto
```

---

## Troubleshooting

### Issue: "ModuleNotFoundError: No module named 'tpu_backend'"

**Solution:**
```bash
cd /app/backend
python3 -c "import sys; sys.path.insert(0, '.'); from tpu_backend import get_tpu_backend; print('✓ Import successful')"
```

### Issue: "CUDA out of memory"

**Solution:** Reduce batch size
```bash
python3 << 'EOF'
from tpu_backend import get_tpu_backend, TPUConfig

config = TPUConfig(batch_size=8)  # Reduce from default 256
backend = get_tpu_backend(mode='simulated', config=config)
print("✓ Backend initialized with smaller batch size")
EOF
```

### Issue: "No TPU devices found"

**Expected:** This is normal if you don't have TPU hardware. Backend automatically falls back to simulation.

**Verify:**
```bash
python3 -c "from tpu_backend import get_tpu_backend; backend = get_tpu_backend(mode='auto'); print(f'Using: {backend.backend_name}')"
```

### Issue: Tests failing

**Debug:**
```bash
# Run single test with verbose output
python3 -m unittest tests.test_tpu_backend.TestSimulatedTPUBackend.test_inference -v

# Check PyTorch installation
python3 -c "import torch; print(torch.__version__); print(torch.cuda.is_available())"

# Check device
python3 -c "from tpu_backend import get_tpu_backend; backend = get_tpu_backend(mode='simulated'); print(backend.get_device_info())"
```

### Issue: Demo runs but very slow

**Check:**
```bash
# Verify GPU is being used
python3 -c "from tpu_backend import get_tpu_backend; backend = get_tpu_backend(mode='simulated'); info = backend.get_device_info(); print(f'Device type: {info.get(\"device_type\")}')"

# Expected: 'cuda' (fast)
# If 'cpu': Install PyTorch with CUDA support
```

**Install PyTorch with CUDA:**
```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
```

---

## Quick Reference

### Check Installation
```bash
python3 -c "from tpu_backend import get_tpu_backend; backend = get_tpu_backend(mode='auto'); print(f'✓ Backend: {backend.backend_name}'); print(backend.get_device_info())"
```

### Run Full Test Suite
```bash
cd /app/backend
python3 tests/test_tpu_backend.py && python3 tests/test_tpu_integration.py && python3 demo_tpu_selfplay.py --games 5
```

### View Demo Results
```bash
ls -lh /app/backend/demo_results_*.json
cat /app/backend/demo_results_*.json | python3 -m json.tool | head -50
```

### Performance Benchmark
```bash
python3 << 'EOF'
from tpu_backend import get_tpu_backend
import torch
import time

backend = get_tpu_backend(mode='simulated')
model = torch.nn.Linear(100, 100)
model = backend.compile_model(model)

# Warmup
for _ in range(10):
    x = torch.randn(32, 100)
    backend.inference(model, x)

# Benchmark
start = time.time()
for _ in range(100):
    x = torch.randn(32, 100)
    backend.inference(model, x)
elapsed = time.time() - start

print(f"Throughput: {100 * 32 / elapsed:.0f} samples/sec")
EOF
```

---

## Environment Checklist for Real TPU

### Cloud TPU Setup (Google Cloud)

1. **Create TPU VM:**
```bash
gcloud compute tpus tpu-vm create alphazero-tpu \
  --zone=us-central1-a \
  --accelerator-type=v3-8 \
  --version=tpu-vm-base
```

2. **SSH into TPU VM:**
```bash
gcloud compute tpus tpu-vm ssh alphazero-tpu --zone=us-central1-a
```

3. **Install Dependencies on TPU VM:**
```bash
pip install jax[tpu] -f https://storage.googleapis.com/jax-releases/libtpu_releases.html
pip install torch numpy python-chess
```

4. **Copy Code to TPU VM:**
```bash
# On local machine
gcloud compute tpus tpu-vm scp --recurse /app/backend alphazero-tpu:~ --zone=us-central1-a
```

5. **Run on TPU:**
```bash
# On TPU VM
cd ~/backend
python3 demo_tpu_selfplay.py --backend jax
```

### Verify TPU Access

```bash
# On TPU VM
python3 -c "import jax; print(f'TPU cores: {len(jax.devices(\"tpu\"))}')"
# Expected: TPU cores: 8 (for v3-8)
```

---

## Summary

**Simulated Mode (No TPU hardware):**
```bash
cd /app/backend
pip install torch numpy python-chess
python3 tests/test_tpu_backend.py
python3 demo_tpu_selfplay.py
```

**Real TPU Mode (JAX):**
```bash
cd /app/backend
pip install jax[tpu] torch numpy python-chess
python3 tests/test_tpu_backend.py
python3 demo_tpu_selfplay.py --backend jax
```

**Real TPU Mode (PyTorch XLA):**
```bash
cd /app/backend
pip install torch_xla torch numpy python-chess
python3 tests/test_tpu_backend.py
python3 demo_tpu_selfplay.py --backend torch_xla
```
