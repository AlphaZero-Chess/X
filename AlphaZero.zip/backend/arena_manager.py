"""
Live Self-Play Arena Manager
Manages AlphaZero vs AlphaZero live matches with real-time streaming
"""
import asyncio
import logging
import time
import uuid
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List
from pathlib import Path
import json
import chess

from neural_network import AlphaZeroNetwork, ModelManager
from chess_engine import ChessEngine
from mcts import MCTS

logger = logging.getLogger(__name__)


class ArenaSession:
    """Represents a single arena session"""
    
    def __init__(
        self,
        session_id: str,
        player1_model: AlphaZeroNetwork,
        player2_model: AlphaZeroNetwork,
        player1_name: str,
        player2_name: str,
        config: Dict[str, Any]
    ):
        self.session_id = session_id
        self.player1_model = player1_model
        self.player2_model = player2_model
        self.player1_name = player1_name
        self.player2_name = player2_name
        self.config = config
        
        # Session state
        self.current_game = 0
        self.total_games = config.get('games', 10)
        self.move_delay = config.get('move_delay', 1.2)
        self.num_simulations = config.get('mcts_simulations', 800)
        self.save_pgn = config.get('save_pgn', True)
        self.commentary_enabled = config.get('commentary', True)
        
        # Statistics
        self.stats = {
            'games_completed': 0,
            'player1_wins': 0,
            'player2_wins': 0,
            'draws': 0,
            'total_moves': 0,
            'start_time': datetime.now(timezone.utc)
        }
        
        # Current game state
        self.engine = None
        self.current_move_number = 0
        self.game_history = []
        self.is_running = False
        self.stop_requested = False
        
        # PGN storage
        self.pgn_dir = Path(config.get('pgn_dir', '/app/backend/cache/arena_pgns'))
        self.pgn_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Arena session created: {session_id}")
        logger.info(f"  Player 1: {player1_name}")
        logger.info(f"  Player 2: {player2_name}")
        logger.info(f"  Games: {self.total_games}, Delay: {self.move_delay}s")
    
    def get_status(self) -> Dict[str, Any]:
        """Get current arena status"""
        return {
            'session_id': self.session_id,
            'is_running': self.is_running,
            'current_game': self.current_game,
            'total_games': self.total_games,
            'current_move': self.current_move_number,
            'player1_name': self.player1_name,
            'player2_name': self.player2_name,
            'stats': self.stats,
            'current_fen': self.engine.get_fen() if self.engine else None
        }
    
    def save_pgn(self, result: str):
        """Save completed game as PGN"""
        if not self.save_pgn or not self.game_history:
            return
        
        try:
            timestamp = datetime.now(timezone.utc).strftime('%Y.%m.%d %H:%M:%S')
            pgn_lines = [
                '[Event "AlphaZero Arena"]',
                '[Site "Live Self-Play"]',
                f'[Date "{timestamp}"]',
                f'[Round "{self.current_game}"]',
                f'[White "{self.player1_name}"]',
                f'[Black "{self.player2_name}"]',
                f'[Result "{result}"]',
                ''
            ]
            
            # Format moves
            move_text = ''
            for i, move_entry in enumerate(self.game_history):
                if i % 2 == 0:
                    move_text += f"{i//2 + 1}. "
                move_text += f"{move_entry['move']} "
            
            move_text += result
            pgn_lines.append(move_text)
            
            # Save to file
            filename = f"arena_game_{self.session_id}_{self.current_game:03d}.pgn"
            pgn_file = self.pgn_dir / filename
            
            with open(pgn_file, 'w') as f:
                f.write('\n'.join(pgn_lines))
            
            logger.info(f"Saved PGN: {filename}")
            
        except Exception as e:
            logger.error(f"Error saving PGN: {e}")
    
    def request_stop(self):
        """Request arena to stop gracefully"""
        self.stop_requested = True
        logger.info(f"Stop requested for arena session: {self.session_id}")


class ArenaManager:
    """Manages live AlphaZero vs AlphaZero arena sessions"""
    
    def __init__(self):
        self.model_manager = ModelManager()
        self.active_session: Optional[ArenaSession] = None
        self.event_queue = asyncio.Queue()
        logger.info("Arena Manager initialized")
    
    async def start_arena(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Start a new arena session
        
        Config:
        {
            "players": ["model_v1", "model_v2"],  # Model names
            "games": 10,
            "move_delay": 1.2,
            "mcts_simulations": 800,
            "save_pgn": true,
            "commentary": true
        }
        """
        if self.active_session and self.active_session.is_running:
            raise Exception("Arena session already running")
        
        # Load models
        player1_name = config.get('players', [None, None])[0]
        player2_name = config.get('players', [None, None])[1]
        
        # Load or use active models
        player1_model = await self._load_model(player1_name)
        player2_model = await self._load_model(player2_name)
        
        # Create session
        session_id = str(uuid.uuid4())
        self.active_session = ArenaSession(
            session_id=session_id,
            player1_model=player1_model,
            player2_model=player2_model,
            player1_name=player1_name or "ActiveModel",
            player2_name=player2_name or "ActiveModel",
            config=config
        )
        
        # Start arena in background
        asyncio.create_task(self._run_arena(self.active_session))
        
        return {
            'success': True,
            'session_id': session_id,
            'message': 'Arena started',
            'config': config
        }
    
    async def _load_model(self, model_name: Optional[str]) -> AlphaZeroNetwork:
        """Load a model by name or return active model"""
        if model_name:
            model, _ = self.model_manager.load_model(model_name)
            if model is None:
                raise Exception(f"Model not found: {model_name}")
            return model
        else:
            # Use active model or fresh network
            models = self.model_manager.list_models()
            if models:
                model, _ = self.model_manager.load_model(models[-1])
                return model
            else:
                return AlphaZeroNetwork()
    
    async def _run_arena(self, session: ArenaSession):
        """Run the arena session (main game loop)"""
        session.is_running = True
        
        try:
            # Emit start event
            await self._emit_event({
                'type': 'arena_start',
                'session_id': session.session_id,
                'player1': session.player1_name,
                'player2': session.player2_name,
                'total_games': session.total_games
            })
            
            # Play games
            for game_num in range(1, session.total_games + 1):
                if session.stop_requested:
                    break
                
                session.current_game = game_num
                await self._play_single_game(session)
                
                # Short delay between games
                if game_num < session.total_games:
                    await asyncio.sleep(2.0)
            
            # Emit completion event
            await self._emit_event({
                'type': 'arena_complete',
                'session_id': session.session_id,
                'stats': session.stats
            })
            
        except Exception as e:
            logger.error(f"Arena error: {e}")
            await self._emit_event({
                'type': 'arena_error',
                'error': str(e)
            })
        finally:
            session.is_running = False
    
    async def _play_single_game(self, session: ArenaSession):
        """Play a single game in the arena"""
        # Initialize game
        session.engine = ChessEngine()
        session.current_move_number = 0
        session.game_history = []
        
        # Emit game start
        await self._emit_event({
            'type': 'game_start',
            'game_number': session.current_game,
            'fen': session.engine.get_fen()
        })
        
        # Initialize MCTS for both players
        mcts_player1 = MCTS(
            session.player1_model,
            num_simulations=session.num_simulations,
            c_puct=1.5,
            temperature=0.1
        )
        
        mcts_player2 = MCTS(
            session.player2_model,
            num_simulations=session.num_simulations,
            c_puct=1.5,
            temperature=0.1
        )
        
        move_count = 0
        
        # Play until game over
        while not session.engine.is_game_over() and move_count < 200:
            if session.stop_requested:
                break
            
            move_count += 1
            session.current_move_number = move_count
            
            # Select model based on turn
            current_player = session.player1_name if session.engine.board.turn == chess.WHITE else session.player2_name
            current_mcts = mcts_player1 if session.engine.board.turn == chess.WHITE else mcts_player2
            
            # Get move from MCTS
            start_time = time.time()
            best_move, move_probs, root_value = current_mcts.search(
                session.engine,
                temperature=0.1,
                add_noise=False
            )
            think_time = time.time() - start_time
            
            if not best_move:
                break
            
            # Make move
            session.engine.make_move(best_move)
            
            # Store move in history
            move_entry = {
                'move_number': move_count,
                'move': best_move,
                'player': current_player,
                'fen': session.engine.get_fen(),
                'evaluation': float(root_value),
                'think_time': think_time
            }
            session.game_history.append(move_entry)
            
            # Generate commentary (optional)
            commentary = await self._generate_commentary(session, move_entry)
            
            # Emit move event
            await self._emit_event({
                'type': 'move',
                'game_number': session.current_game,
                'move_number': move_count,
                'move': best_move,
                'player': current_player,
                'fen': session.engine.get_fen(),
                'evaluation': float(root_value),
                'legal_moves': session.engine.get_legal_moves(),
                'is_game_over': session.engine.is_game_over(),
                'commentary': commentary
            })
            
            # Delay before next move
            await asyncio.sleep(session.move_delay)
            
            session.stats['total_moves'] += 1
        
        # Game over
        result = session.engine.get_result()
        
        # Update statistics
        session.stats['games_completed'] += 1
        if result == "1-0":
            session.stats['player1_wins'] += 1
            winner = session.player1_name
        elif result == "0-1":
            session.stats['player2_wins'] += 1
            winner = session.player2_name
        else:
            session.stats['draws'] += 1
            winner = "Draw"
        
        # Save PGN
        session.save_pgn(result)
        
        # Emit game end
        await self._emit_event({
            'type': 'game_end',
            'game_number': session.current_game,
            'result': result,
            'winner': winner,
            'total_moves': move_count,
            'stats': session.stats
        })
    
    async def _generate_commentary(self, session: ArenaSession, move_entry: Dict) -> str:
        """Generate LLM commentary for a move"""
        if not session.commentary_enabled:
            return ""
        
        try:
            # Try to use LLM for commentary
            from llm_plugin import generate_llm_response
            
            prompt = f"""Provide brief chess commentary for this move in an AlphaZero self-play game:
            
Move: {move_entry['move']}
Player: {move_entry['player']}
Move number: {move_entry['move_number']}
Evaluation: {move_entry['evaluation']:.3f}

Give a single sentence analysis focusing on strategic significance."""
            
            commentary = await generate_llm_response(prompt, max_tokens=50)
            return commentary
            
        except Exception as e:
            # Fallback to simple commentary
            eval_val = move_entry['evaluation']
            if abs(eval_val) < 0.2:
                return f"{move_entry['player']} maintains balanced position."
            elif eval_val > 0.5:
                return f"{move_entry['player']} gains significant advantage."
            elif eval_val < -0.5:
                return f"{move_entry['player']} faces pressure."
            else:
                return f"{move_entry['player']} plays {move_entry['move']}."
    
    async def _emit_event(self, event: Dict[str, Any]):
        """Emit event to the queue for streaming"""
        try:
            await self.event_queue.put(event)
        except Exception as e:
            logger.error(f"Error emitting event: {e}")
    
    async def stop_arena(self) -> Dict[str, Any]:
        """Stop the current arena session"""
        if not self.active_session:
            return {'success': False, 'message': 'No active arena session'}
        
        self.active_session.request_stop()
        
        return {
            'success': True,
            'message': 'Arena stop requested',
            'session_id': self.active_session.session_id
        }
    
    def get_status(self) -> Dict[str, Any]:
        """Get current arena status"""
        if self.active_session:
            return self.active_session.get_status()
        else:
            return {
                'session_id': None,
                'is_running': False,
                'message': 'No active session'
            }
    
    async def get_event_stream(self):
        """Get event stream for Server-Sent Events"""
        while True:
            try:
                # Wait for event with timeout
                event = await asyncio.wait_for(self.event_queue.get(), timeout=30)
                yield event
            except asyncio.TimeoutError:
                # Send keepalive
                yield {'type': 'keepalive'}
            except Exception as e:
                logger.error(f"Stream error: {e}")
                break
