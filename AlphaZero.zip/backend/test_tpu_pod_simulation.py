"""
Test Suite for TPU Pod Simulation and Autoscaling (Phase 3)
============================================================

Tests:
1. Pod lifecycle (activate, deactivate, warmup, cooldown)
2. Pod health monitoring and heartbeats
3. Pod-level job allocation
4. Autoscaler pod scaling decisions
5. Cross-pod workload distribution
6. Hybrid scaling logic
"""

import time
import logging
from typing import Dict, List

from tpu_cluster_manager import (
    TPUGridManager,
    JobType,
    PodState,
    TPUState,
    get_tpu_grid,
    reset_tpu_grid
)
from tpu_pod_autoscaler import (
    TPUPodAutoscaler,
    PodScalingConfig,
    PodScalingAction,
    get_pod_autoscaler,
    reset_pod_autoscaler
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def test_pod_lifecycle():
    """Test 1: Pod lifecycle management"""
    logger.info("\n" + "="*80)
    logger.info("TEST 1: POD LIFECYCLE MANAGEMENT")
    logger.info("="*80)
    
    # Reset and create grid
    reset_tpu_grid()
    grid = get_tpu_grid(num_tpus=64)  # 8 pods × 8 cores
    
    logger.info(f"✅ Grid initialized: {grid.num_pods} pods, {grid.num_tpus} TPUs")
    
    # Test 1.1: Check initial state (all pods inactive)
    active_pods = grid.get_active_pods()
    assert len(active_pods) == 0, "Expected no active pods initially"
    logger.info(f"✅ Initial state: {len(active_pods)} active pods")
    
    # Test 1.2: Activate a pod
    success = grid.activate_pod(0)
    assert success, "Failed to activate pod 0"
    active_pods = grid.get_active_pods()
    assert 0 in active_pods, "Pod 0 should be active"
    logger.info(f"✅ Pod 0 activated")
    
    # Test 1.3: Check pod state
    pod_status = grid.get_pod_status(0)
    assert pod_status['state'] == PodState.ACTIVE.value, "Pod should be active"
    assert pod_status['is_active'] == True, "Pod should report as active"
    logger.info(f"✅ Pod 0 state: {pod_status['state']}")
    
    # Test 1.4: Deactivate pod (should succeed - no jobs)
    success = grid.deactivate_pod(0)
    assert success, "Failed to deactivate pod 0"
    active_pods = grid.get_active_pods()
    assert 0 not in active_pods, "Pod 0 should be inactive"
    logger.info(f"✅ Pod 0 deactivated")
    
    # Test 1.5: Activate multiple pods
    for pod_id in range(4):
        success = grid.activate_pod(pod_id)
        assert success, f"Failed to activate pod {pod_id}"
    
    active_pods = grid.get_active_pods()
    assert len(active_pods) == 4, "Expected 4 active pods"
    logger.info(f"✅ Activated {len(active_pods)} pods")
    
    logger.info("✅ TEST 1 PASSED: Pod lifecycle management working")
    return True


def test_pod_allocation():
    """Test 2: Pod-level job allocation"""
    logger.info("\n" + "="*80)
    logger.info("TEST 2: POD-LEVEL JOB ALLOCATION")
    logger.info("="*80)
    
    # Reset and create grid
    reset_tpu_grid()
    grid = get_tpu_grid(num_tpus=64)
    
    # Test 2.1: Allocate pods for a job
    success, allocated_pods = grid.allocate_pods(
        job_id="selfplay_test",
        job_type=JobType.SELFPLAY,
        num_pods=3,
        priority=7,
        auto_activate=True
    )
    
    assert success, "Failed to allocate pods"
    assert len(allocated_pods) == 3, f"Expected 3 pods, got {len(allocated_pods)}"
    logger.info(f"✅ Allocated {len(allocated_pods)} pods for selfplay_test")
    
    # Test 2.2: Check pod states
    for pod_id in allocated_pods:
        pod_status = grid.get_pod_status(pod_id)
        assert pod_status['is_active'], f"Pod {pod_id} should be active"
        assert pod_status['busy_cores'] > 0, f"Pod {pod_id} should have busy cores"
        logger.info(f"  Pod {pod_id}: {pod_status['busy_cores']}/{pod_status['size']} cores busy")
    
    # Test 2.3: Release pods
    success = grid.release_pods("selfplay_test")
    assert success, "Failed to release pods"
    logger.info(f"✅ Released pods from selfplay_test")
    
    # Test 2.4: Verify pods are idle
    for pod_id in allocated_pods:
        pod_status = grid.get_pod_status(pod_id)
        assert pod_status['busy_cores'] == 0, f"Pod {pod_id} should have no busy cores"
    
    logger.info("✅ TEST 2 PASSED: Pod allocation working")
    return True


def test_pod_health_monitoring():
    """Test 3: Pod health monitoring"""
    logger.info("\n" + "="*80)
    logger.info("TEST 3: POD HEALTH MONITORING")
    logger.info("="*80)
    
    # Reset and create grid
    reset_tpu_grid()
    grid = get_tpu_grid(num_tpus=64)
    
    # Activate some pods
    for pod_id in range(4):
        grid.activate_pod(pod_id)
    
    # Test 3.1: Update heartbeats
    grid.update_pod_heartbeats()
    logger.info("✅ Updated pod heartbeats")
    
    # Test 3.2: Check pod health
    pod_health = grid.check_pod_health()
    
    assert pod_health['total_pods'] == 8, "Expected 8 total pods"
    assert pod_health['healthy_pods'] == 4, "Expected 4 healthy pods"
    assert pod_health['inactive_pods'] == 4, "Expected 4 inactive pods"
    
    logger.info(f"✅ Pod health: {pod_health['healthy_pods']} healthy, "
               f"{pod_health['unhealthy_pods']} unhealthy, "
               f"{pod_health['inactive_pods']} inactive")
    
    # Test 3.3: Check individual pod health
    pod_status = grid.get_pod_status(0)
    assert pod_status['is_healthy'], "Pod 0 should be healthy"
    logger.info(f"✅ Pod 0 health check passed")
    
    logger.info("✅ TEST 3 PASSED: Pod health monitoring working")
    return True


def test_autoscaler_initialization():
    """Test 4: Autoscaler initialization"""
    logger.info("\n" + "="*80)
    logger.info("TEST 4: AUTOSCALER INITIALIZATION")
    logger.info("="*80)
    
    # Reset
    reset_tpu_grid()
    reset_pod_autoscaler()
    
    # Create grid and autoscaler
    grid = get_tpu_grid(num_tpus=64)
    
    config = PodScalingConfig(
        min_pods=2,
        max_pods=8,
        cores_per_pod=8,
        target_utilization=0.70
    )
    
    autoscaler = TPUPodAutoscaler(
        tpu_grid_manager=grid,
        config=config,
        enable_auto_scaling=False  # Manual mode for testing
    )
    
    assert autoscaler.config.max_pods == 8, "Max pods should be 8"
    assert autoscaler.config.min_pods == 2, "Min pods should be 2"
    
    logger.info(f"✅ Autoscaler initialized: {config.min_pods}-{config.max_pods} pods")
    
    # Test 4.1: Get status
    status = autoscaler.get_autoscaler_status()
    
    assert status['enabled'] == False, "Autoscaler should not be enabled"
    assert status['config']['max_pods'] == 8, "Config max pods should be 8"
    
    logger.info(f"✅ Autoscaler status:")
    logger.info(f"  Active pods: {status['current_metrics']['active_pods']}")
    logger.info(f"  Inactive pods: {status['current_metrics']['inactive_pods']}")
    
    logger.info("✅ TEST 4 PASSED: Autoscaler initialization working")
    return True


def test_workload_based_scaling():
    """Test 5: Workload-based pod scaling"""
    logger.info("\n" + "="*80)
    logger.info("TEST 5: WORKLOAD-BASED POD SCALING")
    logger.info("="*80)
    
    # Reset
    reset_tpu_grid()
    reset_pod_autoscaler()
    
    # Create grid and autoscaler
    grid = get_tpu_grid(num_tpus=64)
    autoscaler = TPUPodAutoscaler(
        tpu_grid_manager=grid,
        enable_auto_scaling=False
    )
    
    # Test 5.1: Request pods for self-play
    num_pods = autoscaler.request_pods_for_workload(
        workload_type='selfplay',
        estimated_size=1000
    )
    
    logger.info(f"✅ Requested {num_pods} pods for selfplay")
    
    active_pods = grid.get_active_pods()
    assert len(active_pods) >= 3, f"Expected at least 3 active pods for selfplay, got {len(active_pods)}"
    logger.info(f"  Active pods: {len(active_pods)}")
    
    # Test 5.2: Request pods for training
    autoscaler.release_pods_from_workload(num_pods)
    
    num_pods = autoscaler.request_pods_for_workload(
        workload_type='training',
        estimated_size=100
    )
    
    logger.info(f"✅ Requested {num_pods} pods for training")
    
    # Test 5.3: Request pods for evaluation
    autoscaler.release_pods_from_workload(num_pods)
    
    num_pods = autoscaler.request_pods_for_workload(
        workload_type='evaluation',
        estimated_size=20
    )
    
    logger.info(f"✅ Requested {num_pods} pods for evaluation")
    
    logger.info("✅ TEST 5 PASSED: Workload-based scaling working")
    return True


def test_hybrid_scaling_logic():
    """Test 6: Hybrid scaling logic"""
    logger.info("\n" + "="*80)
    logger.info("TEST 6: HYBRID SCALING LOGIC")
    logger.info("="*80)
    
    # Reset
    reset_tpu_grid()
    reset_pod_autoscaler()
    
    # Create grid and autoscaler
    grid = get_tpu_grid(num_tpus=64)
    autoscaler = TPUPodAutoscaler(
        tpu_grid_manager=grid,
        enable_auto_scaling=False
    )
    
    # Test 6.1: Scale up scenario (high utilization)
    # Activate 2 pods and simulate high utilization
    grid.allocate_pods(
        job_id="high_util_job",
        job_type=JobType.SELFPLAY,
        num_pods=2,
        auto_activate=True
    )
    
    metrics = autoscaler._collect_metrics()
    logger.info(f"✅ Collected metrics: {metrics.active_pods} active pods, "
               f"{metrics.avg_pod_utilization:.2%} utilization")
    
    decision = autoscaler._make_scaling_decision(metrics)
    logger.info(f"✅ Scaling decision: {decision.action.value}")
    logger.info(f"  Reason: {decision.reason}")
    
    # Test 6.2: Scale down scenario (low utilization)
    grid.release_pods("high_util_job")
    
    # Wait a bit to simulate idle time
    time.sleep(0.5)
    
    metrics = autoscaler._collect_metrics()
    logger.info(f"✅ Collected metrics after release: {metrics.active_pods} active pods")
    
    logger.info("✅ TEST 6 PASSED: Hybrid scaling logic working")
    return True


def test_grid_status_with_pods():
    """Test 7: Grid status with pod information"""
    logger.info("\n" + "="*80)
    logger.info("TEST 7: GRID STATUS WITH POD INFORMATION")
    logger.info("="*80)
    
    # Reset
    reset_tpu_grid()
    grid = get_tpu_grid(num_tpus=64)
    
    # Activate some pods and allocate jobs
    grid.allocate_pods(
        job_id="test_job",
        job_type=JobType.SELFPLAY,
        num_pods=4,
        auto_activate=True
    )
    
    # Get grid status
    status = grid.get_grid_status()
    
    logger.info(f"✅ Grid status retrieved:")
    logger.info(f"  Total TPUs: {status['grid']['total_tpus']}")
    logger.info(f"  Total Pods: {status['grid']['total_pods']}")
    logger.info(f"  Active Pods: {status['grid']['active_pods']}")
    logger.info(f"  Busy TPUs: {status['grid']['busy_tpus']}")
    logger.info(f"  Utilization: {status['utilization']['current_percent']:.2f}%")
    
    # Check pod health
    pod_health = status['pod_health']
    logger.info(f"  Pod Health:")
    logger.info(f"    Healthy: {pod_health['healthy_pods']}")
    logger.info(f"    Unhealthy: {pod_health['unhealthy_pods']}")
    logger.info(f"    Inactive: {pod_health['inactive_pods']}")
    
    # Check individual pods
    assert 'pods' in status, "Status should include pods"
    assert len(status['pods']) == 8, "Should have 8 pods in status"
    
    logger.info(f"  Individual Pods:")
    for pod in status['pods'][:4]:  # Show first 4
        logger.info(f"    Pod {pod['pod_id']}: {pod['state']}, "
                   f"{pod['busy_cores']}/{pod['size']} busy, "
                   f"{pod['utilization']:.1f}% util")
    
    logger.info("✅ TEST 7 PASSED: Grid status with pods working")
    return True


def run_all_tests():
    """Run all TPU pod simulation tests"""
    logger.info("\n" + "="*80)
    logger.info("PHASE 3: TPU POD SIMULATION TEST SUITE")
    logger.info("="*80)
    
    tests = [
        ("Pod Lifecycle", test_pod_lifecycle),
        ("Pod Allocation", test_pod_allocation),
        ("Pod Health Monitoring", test_pod_health_monitoring),
        ("Autoscaler Initialization", test_autoscaler_initialization),
        ("Workload-Based Scaling", test_workload_based_scaling),
        ("Hybrid Scaling Logic", test_hybrid_scaling_logic),
        ("Grid Status with Pods", test_grid_status_with_pods)
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            if result:
                passed += 1
        except Exception as e:
            logger.error(f"❌ {test_name} FAILED: {e}")
            import traceback
            traceback.print_exc()
            failed += 1
    
    # Summary
    logger.info("\n" + "="*80)
    logger.info("TEST SUITE SUMMARY")
    logger.info("="*80)
    logger.info(f"Total Tests: {len(tests)}")
    logger.info(f"Passed: {passed} ✅")
    logger.info(f"Failed: {failed} ❌")
    logger.info(f"Success Rate: {passed/len(tests)*100:.1f}%")
    logger.info("="*80)
    
    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    
    if success:
        logger.info("\n🎉 ALL TESTS PASSED!")
        exit(0)
    else:
        logger.error("\n❌ SOME TESTS FAILED")
        exit(1)
