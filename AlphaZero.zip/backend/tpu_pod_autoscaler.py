"""
TPU Pod Autoscaler - Phase 3: Hybrid Pod-Level Autoscaling
============================================================

Manages dynamic pod allocation with hybrid scaling strategy:
- Static limits: Maximum 8 pods (configurable)
- Dynamic allocation: Based on workload, utilization, and queue depth
- Pod-aware: Scales entire pods (8 cores per pod) not individual TPUs
- Workload-based triggers: Self-play, training, evaluation patterns

Features:
- Warm-up and cool-down periods to prevent thrashing
- Pod locality awareness for better performance
- Integration with TPUGridManager for pod lifecycle
- Real-time metrics and scaling history
- Configurable scaling policies and thresholds

Architecture:
    TPUTrainingOrchestrator
            ↓
    TPUPodAutoscaler (decides pod allocation)
            ↓
    TPUGridManager (manages pod lifecycle)
"""

import logging
import time
import threading
from typing import Dict, Optional, List, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timezone

from tpu_cluster_manager import TPUGridManager, JobType, PodState

logger = logging.getLogger(__name__)


class PodScalingPolicy(Enum):
    """Pod-level scaling policies"""
    WORKLOAD_BASED = "workload_based"  # Scale based on job type and size
    UTILIZATION_BASED = "utilization_based"  # Scale based on pod utilization
    QUEUE_BASED = "queue_based"  # Scale based on job queue
    HYBRID = "hybrid"  # Combination of all policies


class PodScalingAction(Enum):
    """Pod scaling actions"""
    SCALE_UP = "scale_up"
    SCALE_DOWN = "scale_down"
    NO_ACTION = "no_action"


@dataclass
class PodScalingConfig:
    """
    Pod autoscaling configuration
    
    Phase 3 Configuration: 8 pods × 8 cores = 64 TPUs
    """
    # Pod limits
    min_pods: int = 2  # Minimum active pods
    max_pods: int = 8  # Maximum active pods (Phase 3)
    cores_per_pod: int = 8  # TPU cores per pod
    
    # Scaling behavior
    scaling_interval_seconds: int = 30  # Check interval
    scale_up_cooldown_seconds: int = 60  # Wait 1 min after scale-up
    scale_down_cooldown_seconds: int = 120  # Wait 2 min after scale-down
    warmup_time_seconds: float = 10.0  # Pod warmup time
    cooldown_time_seconds: float = 5.0  # Pod cooldown time
    
    # Utilization thresholds
    target_utilization: float = 0.70  # Target 70% utilization
    scale_up_threshold: float = 0.80  # Scale up at 80%
    scale_down_threshold: float = 0.30  # Scale down at 30%
    
    # Workload-based scaling (static allocation hints)
    selfplay_min_pods: int = 3  # Minimum pods for self-play
    training_min_pods: int = 2  # Minimum pods for training
    evaluation_min_pods: int = 1  # Minimum pods for evaluation
    
    # Queue thresholds
    queue_scale_up_threshold: int = 5  # Scale up if 5+ jobs queued
    idle_timeout_seconds: float = 300.0  # Scale down after 5 min idle
    
    # Scaling increments (pod-based)
    scale_up_increment_pods: int = 2  # Add 2 pods at a time
    scale_down_increment_pods: int = 1  # Remove 1 pod at a time
    
    # Policy weights (for hybrid mode)
    workload_weight: float = 0.4
    utilization_weight: float = 0.4
    queue_weight: float = 0.2


@dataclass
class PodScalingDecision:
    """Pod scaling decision with reasoning"""
    action: PodScalingAction
    current_active_pods: int
    target_active_pods: int
    reason: str
    metrics: Dict
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict:
        return {
            'action': self.action.value,
            'current_active_pods': self.current_active_pods,
            'target_active_pods': self.target_active_pods,
            'reason': self.reason,
            'metrics': self.metrics,
            'timestamp': self.timestamp
        }


@dataclass
class PodMetrics:
    """Current pod metrics for scaling decisions"""
    total_pods: int
    active_pods: int
    inactive_pods: int
    busy_pods: int  # Pods with active jobs
    avg_pod_utilization: float
    queued_jobs: int
    running_jobs: int
    current_workload_type: Optional[str] = None  # 'selfplay', 'training', 'evaluation'
    timestamp: float = field(default_factory=time.time)


class TPUPodAutoscaler:
    """
    TPU Pod Autoscaler - Phase 3: Hybrid Pod-Level Scaling
    
    Manages dynamic allocation of TPU pods based on:
    1. Workload type (self-play needs more pods than training)
    2. Current utilization (scale up if pods are busy)
    3. Queue depth (scale up if jobs are waiting)
    
    Hybrid Strategy:
    - Static limits: max 8 pods (Phase 3)
    - Dynamic allocation: activate/deactivate based on need
    - Pod-aware: scales in pod increments (8 cores per pod)
    
    Example:
        autoscaler = TPUPodAutoscaler(tpu_grid_manager)
        autoscaler.start()
        
        # Request optimal pod allocation
        num_pods = autoscaler.request_pods_for_workload(
            workload_type='selfplay',
            num_games=1000
        )
        
        autoscaler.stop()
    """
    
    def __init__(
        self,
        tpu_grid_manager: TPUGridManager,
        config: Optional[PodScalingConfig] = None,
        enable_auto_scaling: bool = True
    ):
        """
        Initialize TPU Pod Autoscaler
        
        Args:
            tpu_grid_manager: TPUGridManager instance
            config: Scaling configuration
            enable_auto_scaling: Enable automatic scaling loop
        """
        self.tpu_grid = tpu_grid_manager
        self.config = config or PodScalingConfig()
        self.enable_auto_scaling = enable_auto_scaling
        
        logger.info("="*80)
        logger.info("INITIALIZING TPU POD AUTOSCALER (PHASE 3)")
        logger.info(f"Pod Range: {self.config.min_pods} - {self.config.max_pods} pods")
        logger.info(f"Cores per Pod: {self.config.cores_per_pod}")
        logger.info(f"Total TPU Cores: {self.config.max_pods * self.config.cores_per_pod}")
        logger.info(f"Target Utilization: {self.config.target_utilization:.0%}")
        logger.info(f"Auto Scaling: {enable_auto_scaling}")
        logger.info("="*80)
        
        # State tracking
        self.last_scale_up_time = 0.0
        self.last_scale_down_time = 0.0
        self.scaling_history: List[PodScalingDecision] = []
        self.total_scale_up_events = 0
        self.total_scale_down_events = 0
        
        # Current workload tracking
        self.current_workload = None
        self.workload_start_time = None
        
        # Control thread
        self.running = False
        self.autoscaler_thread = None
        self.lock = threading.RLock()
        
        logger.info("✅ TPU Pod Autoscaler initialized")
    
    def start(self):
        """Start autoscaling loop"""
        if not self.enable_auto_scaling:
            logger.info("Auto-scaling disabled, running in manual mode")
            return
        
        if self.running:
            logger.warning("Autoscaler already running")
            return
        
        self.running = True
        self.autoscaler_thread = threading.Thread(
            target=self._autoscaling_loop,
            daemon=True
        )
        self.autoscaler_thread.start()
        logger.info("🚀 Pod Autoscaler started")
    
    def stop(self):
        """Stop autoscaling loop"""
        self.running = False
        if self.autoscaler_thread:
            self.autoscaler_thread.join(timeout=5)
        logger.info("⏹️  Pod Autoscaler stopped")
    
    def request_pods_for_workload(
        self,
        workload_type: str,
        estimated_size: Optional[int] = None,
        priority: int = 5
    ) -> int:
        """
        Request optimal number of pods for a workload
        
        Args:
            workload_type: 'selfplay', 'training', 'evaluation'
            estimated_size: Estimated workload size (games, epochs, etc.)
            priority: Job priority (1-10)
            
        Returns:
            Recommended number of pods to allocate
        """
        with self.lock:
            # Static allocation hints based on workload type
            if workload_type == 'selfplay':
                base_pods = self.config.selfplay_min_pods
                
                # Scale up for large self-play jobs
                if estimated_size and estimated_size > 500:
                    base_pods = min(self.config.max_pods, base_pods + 2)
            
            elif workload_type == 'training':
                base_pods = self.config.training_min_pods
            
            elif workload_type == 'evaluation':
                base_pods = self.config.evaluation_min_pods
            
            else:
                base_pods = self.config.min_pods
            
            # Check available pods
            metrics = self._collect_metrics()
            available_pods = metrics.inactive_pods
            
            # Ensure we don't exceed limits
            recommended_pods = min(base_pods, self.config.max_pods)
            
            # Activate pods if needed
            active_pods = metrics.active_pods
            pods_to_activate = max(0, recommended_pods - active_pods)
            
            if pods_to_activate > 0:
                logger.info(f"🔄 Activating {pods_to_activate} pods for {workload_type} workload")
                self._activate_pods(pods_to_activate)
            
            # Track current workload
            self.current_workload = workload_type
            self.workload_start_time = time.time()
            
            return recommended_pods
    
    def release_pods_from_workload(self, num_pods: int):
        """
        Release pods after workload completion
        
        Args:
            num_pods: Number of pods to potentially release
        """
        with self.lock:
            self.current_workload = None
            
            # Pods will be deactivated by autoscaling loop if idle
            logger.info(f"📤 Workload complete, {num_pods} pods available for release")
    
    def _autoscaling_loop(self):
        """Main autoscaling loop (runs in background thread)"""
        while self.running:
            try:
                # Collect metrics
                metrics = self._collect_metrics()
                
                # Make scaling decision
                decision = self._make_scaling_decision(metrics)
                
                # Execute scaling action
                if decision.action != PodScalingAction.NO_ACTION:
                    self._execute_scaling_action(decision)
                
                # Sleep until next interval
                time.sleep(self.config.scaling_interval_seconds)
            
            except Exception as e:
                logger.error(f"Autoscaling loop error: {e}")
                import traceback
                traceback.print_exc()
                time.sleep(self.config.scaling_interval_seconds)
    
    def _collect_metrics(self) -> PodMetrics:
        """Collect current pod metrics"""
        grid_status = self.tpu_grid.get_grid_status()
        
        total_pods = grid_status['grid']['total_pods']
        active_pods = grid_status['grid']['active_pods']
        inactive_pods = grid_status['grid']['inactive_pods']
        
        # Calculate busy pods (pods with active jobs)
        pods_data = grid_status['pods']
        busy_pods = sum(1 for pod in pods_data if pod['busy_cores'] > 0)
        
        # Average pod utilization
        avg_pod_util = sum(pod['utilization'] for pod in pods_data if pod['is_active']) / max(active_pods, 1)
        
        # Job metrics
        queued_jobs = grid_status['jobs']['queued']
        running_jobs = grid_status['jobs']['active']
        
        return PodMetrics(
            total_pods=total_pods,
            active_pods=active_pods,
            inactive_pods=inactive_pods,
            busy_pods=busy_pods,
            avg_pod_utilization=avg_pod_util,
            queued_jobs=queued_jobs,
            running_jobs=running_jobs,
            current_workload_type=self.current_workload
        )
    
    def _make_scaling_decision(self, metrics: PodMetrics) -> PodScalingDecision:
        """Make pod scaling decision based on metrics"""
        current_time = time.time()
        
        # Check cooldown periods
        if current_time - self.last_scale_up_time < self.config.scale_up_cooldown_seconds:
            return PodScalingDecision(
                action=PodScalingAction.NO_ACTION,
                current_active_pods=metrics.active_pods,
                target_active_pods=metrics.active_pods,
                reason="Scale-up cooldown active",
                metrics=metrics.__dict__
            )
        
        if current_time - self.last_scale_down_time < self.config.scale_down_cooldown_seconds:
            return PodScalingDecision(
                action=PodScalingAction.NO_ACTION,
                current_active_pods=metrics.active_pods,
                target_active_pods=metrics.active_pods,
                reason="Scale-down cooldown active",
                metrics=metrics.__dict__
            )
        
        # Evaluate scaling signals
        utilization_signal = self._evaluate_utilization_signal(metrics)
        queue_signal = self._evaluate_queue_signal(metrics)
        workload_signal = self._evaluate_workload_signal(metrics)
        
        # Weighted decision
        weighted_signal = (
            utilization_signal * self.config.utilization_weight +
            queue_signal * self.config.queue_weight +
            workload_signal * self.config.workload_weight
        )
        
        # Determine action
        if weighted_signal > 0.4:  # Strong scale-up signal
            action = PodScalingAction.SCALE_UP
            target_pods = min(
                metrics.active_pods + self.config.scale_up_increment_pods,
                self.config.max_pods
            )
            reason = f"Scale up: util={utilization_signal:.2f}, queue={queue_signal:.2f}, workload={workload_signal:.2f}"
        
        elif weighted_signal < -0.4:  # Strong scale-down signal
            action = PodScalingAction.SCALE_DOWN
            target_pods = max(
                metrics.active_pods - self.config.scale_down_increment_pods,
                self.config.min_pods
            )
            reason = f"Scale down: util={utilization_signal:.2f}, queue={queue_signal:.2f}"
        
        else:
            action = PodScalingAction.NO_ACTION
            target_pods = metrics.active_pods
            reason = "Metrics within acceptable range"
        
        return PodScalingDecision(
            action=action,
            current_active_pods=metrics.active_pods,
            target_active_pods=target_pods,
            reason=reason,
            metrics=metrics.__dict__
        )
    
    def _evaluate_utilization_signal(self, metrics: PodMetrics) -> float:
        """Evaluate utilization-based scaling signal [-1.0, 1.0]"""
        if metrics.avg_pod_utilization > self.config.scale_up_threshold:
            # Scale up signal
            excess = metrics.avg_pod_utilization - self.config.scale_up_threshold
            return min(1.0, excess / 0.20)
        
        elif metrics.avg_pod_utilization < self.config.scale_down_threshold:
            # Scale down signal
            deficit = self.config.scale_down_threshold - metrics.avg_pod_utilization
            return -min(1.0, deficit / 0.30)
        
        else:
            return 0.0
    
    def _evaluate_queue_signal(self, metrics: PodMetrics) -> float:
        """Evaluate queue-based scaling signal [-1.0, 1.0]"""
        if metrics.queued_jobs > self.config.queue_scale_up_threshold:
            # Scale up for queued jobs
            excess = metrics.queued_jobs - self.config.queue_scale_up_threshold
            return min(1.0, excess / 10.0)
        
        elif metrics.queued_jobs == 0 and metrics.running_jobs == 0:
            # Scale down if idle
            if self.workload_start_time:
                idle_time = time.time() - self.workload_start_time
                if idle_time > self.config.idle_timeout_seconds:
                    return -0.8
            return -0.3
        
        else:
            return 0.0
    
    def _evaluate_workload_signal(self, metrics: PodMetrics) -> float:
        """Evaluate workload-based scaling signal [-1.0, 1.0]"""
        if metrics.current_workload_type == 'selfplay':
            # Self-play needs more pods
            if metrics.active_pods < self.config.selfplay_min_pods:
                return 0.8
            return 0.2
        
        elif metrics.current_workload_type == 'training':
            # Training needs moderate pods
            if metrics.active_pods < self.config.training_min_pods:
                return 0.6
            return 0.0
        
        elif metrics.current_workload_type == 'evaluation':
            # Evaluation needs fewer pods
            if metrics.active_pods > self.config.evaluation_min_pods + 1:
                return -0.4
            return 0.0
        
        else:
            return 0.0
    
    def _execute_scaling_action(self, decision: PodScalingDecision):
        """Execute pod scaling action"""
        with self.lock:
            if decision.action == PodScalingAction.NO_ACTION:
                return
            
            logger.info("="*80)
            logger.info(f"⚙️  POD SCALING ACTION: {decision.action.value.upper()}")
            logger.info(f"Current Active Pods: {decision.current_active_pods}")
            logger.info(f"Target Active Pods: {decision.target_active_pods}")
            logger.info(f"Reason: {decision.reason}")
            logger.info("="*80)
            
            # Calculate pods to change
            pod_delta = decision.target_active_pods - decision.current_active_pods
            
            if pod_delta > 0:
                # Scale up: activate pods
                success = self._activate_pods(pod_delta)
                if success:
                    self.last_scale_up_time = time.time()
                    self.total_scale_up_events += 1
            
            elif pod_delta < 0:
                # Scale down: deactivate pods
                success = self._deactivate_pods(abs(pod_delta))
                if success:
                    self.last_scale_down_time = time.time()
                    self.total_scale_down_events += 1
            
            # Record in history
            self.scaling_history.append(decision)
            if len(self.scaling_history) > 100:
                self.scaling_history = self.scaling_history[-100:]
    
    def _activate_pods(self, num_pods: int) -> bool:
        """Activate inactive pods"""
        activated = 0
        
        # Find inactive pods and activate them
        for pod_id, pod in self.tpu_grid.pods.items():
            if activated >= num_pods:
                break
            
            if not pod.is_active:
                success = self.tpu_grid.activate_pod(pod_id)
                if success:
                    activated += 1
        
        if activated > 0:
            logger.info(f"✅ Activated {activated} pods")
        
        return activated == num_pods
    
    def _deactivate_pods(self, num_pods: int) -> bool:
        """Deactivate idle active pods"""
        deactivated = 0
        
        # Find idle active pods and deactivate them
        for pod_id, pod in self.tpu_grid.pods.items():
            if deactivated >= num_pods:
                break
            
            if pod.is_active and pod.busy_cores == 0:
                success = self.tpu_grid.deactivate_pod(pod_id)
                if success:
                    deactivated += 1
        
        if deactivated > 0:
            logger.info(f"⏸️  Deactivated {deactivated} pods")
        
        return deactivated == num_pods
    
    def get_autoscaler_status(self) -> Dict:
        """Get autoscaler status and metrics"""
        with self.lock:
            current_metrics = self._collect_metrics()
            
            # Check cooldown status
            current_time = time.time()
            scale_up_cooldown = max(0, self.config.scale_up_cooldown_seconds - (current_time - self.last_scale_up_time))
            scale_down_cooldown = max(0, self.config.scale_down_cooldown_seconds - (current_time - self.last_scale_down_time))
            
            return {
                'enabled': self.enable_auto_scaling and self.running,
                'config': {
                    'min_pods': self.config.min_pods,
                    'max_pods': self.config.max_pods,
                    'cores_per_pod': self.config.cores_per_pod,
                    'target_utilization': self.config.target_utilization,
                    'scaling_interval_seconds': self.config.scaling_interval_seconds
                },
                'current_metrics': {
                    'total_pods': current_metrics.total_pods,
                    'active_pods': current_metrics.active_pods,
                    'inactive_pods': current_metrics.inactive_pods,
                    'busy_pods': current_metrics.busy_pods,
                    'avg_pod_utilization': round(current_metrics.avg_pod_utilization, 3),
                    'queued_jobs': current_metrics.queued_jobs,
                    'current_workload': current_metrics.current_workload_type
                },
                'cooldown_status': {
                    'scale_up_cooldown_remaining': round(scale_up_cooldown, 1),
                    'scale_down_cooldown_remaining': round(scale_down_cooldown, 1)
                },
                'statistics': {
                    'total_scale_up_events': self.total_scale_up_events,
                    'total_scale_down_events': self.total_scale_down_events
                },
                'recent_history': [d.to_dict() for d in self.scaling_history[-10:]],
                'timestamp': datetime.now(timezone.utc).isoformat()
            }


# Global instance
_pod_autoscaler = None


def get_pod_autoscaler(
    tpu_grid_manager: Optional[TPUGridManager] = None,
    config: Optional[PodScalingConfig] = None
) -> TPUPodAutoscaler:
    """Get or create global pod autoscaler instance"""
    global _pod_autoscaler
    
    if _pod_autoscaler is None:
        if tpu_grid_manager is None:
            from tpu_cluster_manager import get_tpu_grid
            # Phase 3: Use 64 TPUs (8 pods × 8 cores)
            tpu_grid_manager = get_tpu_grid(num_tpus=64)
        
        _pod_autoscaler = TPUPodAutoscaler(
            tpu_grid_manager=tpu_grid_manager,
            config=config,
            enable_auto_scaling=True
        )
    
    return _pod_autoscaler


def reset_pod_autoscaler():
    """Reset global pod autoscaler (for testing)"""
    global _pod_autoscaler
    if _pod_autoscaler:
        _pod_autoscaler.stop()
    _pod_autoscaler = None
