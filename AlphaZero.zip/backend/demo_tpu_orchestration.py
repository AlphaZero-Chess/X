"""
Demo script for TPU Training Orchestration
Runs a small-scale training cycle to demonstrate the AlphaZero improvement loop
"""

import asyncio
import requests
import time
import json
from datetime import datetime

BACKEND_URL = "http://localhost:8001"

def print_banner(text):
    """Print formatted banner"""
    print("\n" + "="*80)
    print(f"  {text}")
    print("="*80 + "\n")

def start_training_cycle():
    """Start a small training cycle"""
    print_banner("STARTING TPU TRAINING CYCLE")
    
    config = {
        "num_selfplay_games": 10,  # Small number for demo
        "num_tpus_selfplay": 50,
        "num_tpus_training": 25,
        "num_training_epochs": 2,
        "num_eval_games": 10,
        "batch_size": 128,
        "learning_rate": 0.001,
        "continuous": False
    }
    
    print(f"Configuration:")
    print(f"  - Self-play games: {config['num_selfplay_games']}")
    print(f"  - TPUs for self-play: {config['num_tpus_selfplay']}")
    print(f"  - TPUs for training: {config['num_tpus_training']}")
    print(f"  - Training epochs: {config['num_training_epochs']}")
    print(f"  - Evaluation games: {config['num_eval_games']}")
    
    try:
        response = requests.post(
            f"{BACKEND_URL}/api/training/cycle/start",
            json=config,
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            print(f"\n✅ Training cycle started!")
            print(f"  - Cycle ID: {data['cycle_id']}")
            print(f"  - Cycle Number: {data['cycle_number']}")
            print(f"  - Current Model: {data['current_model']}")
            return True
        else:
            print(f"\n❌ Failed to start training cycle: {response.text}")
            return False
    
    except Exception as e:
        print(f"\n❌ Error: {e}")
        return False

def monitor_training_cycle():
    """Monitor training cycle progress"""
    print_banner("MONITORING TRAINING CYCLE")
    
    last_phase = None
    start_time = time.time()
    
    while True:
        try:
            response = requests.get(
                f"{BACKEND_URL}/api/training/cycle/status",
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                
                if not data.get('is_running'):
                    print("\n✅ Training cycle completed!")
                    break
                
                cycle = data.get('cycle', {})
                phase = cycle.get('phase')
                overall_progress = data.get('overall_progress', 0)
                
                # Print phase updates
                if phase != last_phase:
                    last_phase = phase
                    elapsed = time.time() - start_time
                    print(f"\n[{elapsed:.1f}s] Phase: {phase.upper().replace('_', ' ')}")
                
                # Print progress every 3 seconds
                print(f"  Progress: {overall_progress:.1f}% | Phase: {phase}", end='\r')
                
                # Detailed progress
                if phase == 'self_play':
                    positions = cycle.get('positions_generated', 0)
                    print(f"  Self-Play: {cycle.get('selfplay_progress', 0)}% | Positions: {positions:,}     ", end='\r')
                
                elif phase == 'training':
                    loss = cycle.get('training_loss', 0)
                    print(f"  Training: {cycle.get('training_progress', 0)}% | Loss: {loss:.4f}     ", end='\r')
                
                elif phase == 'evaluation':
                    win_rate = cycle.get('evaluation_win_rate', 0) * 100
                    print(f"  Evaluation: {cycle.get('evaluation_progress', 0)}% | Win Rate: {win_rate:.1f}%     ", end='\r')
                
                time.sleep(3)
            
        except requests.Timeout:
            print("\n⏱️  Request timeout, retrying...")
            time.sleep(2)
        except Exception as e:
            print(f"\n❌ Monitoring error: {e}")
            break

def show_results():
    """Show training results"""
    print_banner("TRAINING RESULTS")
    
    try:
        # Get metrics
        response = requests.get(f"{BACKEND_URL}/api/training/metrics", timeout=10)
        if response.status_code == 200:
            data = response.json()
            
            agg = data.get('aggregate_metrics', {})
            buffer = data.get('replay_buffer', {})
            tpu = data.get('tpu_grid', {})
            
            print("📊 Aggregate Metrics:")
            print(f"  - Total Cycles: {agg.get('total_cycles_completed', 0)}")
            print(f"  - Models Promoted: {agg.get('total_models_promoted', 0)}")
            print(f"  - Current Model Version: v{agg.get('current_model_version', 0)}")
            print(f"  - Current Model ELO: {agg.get('current_model_elo', 1500):.0f}")
            print(f"  - Avg Eval Win Rate: {agg.get('avg_evaluation_win_rate', 0)*100:.1f}%")
            print(f"  - Total Positions Generated: {agg.get('total_positions_generated', 0):,}")
            
            print(f"\n💾 Replay Buffer:")
            print(f"  - Size: {buffer.get('total_size', 0):,} / {buffer.get('capacity', 0):,}")
            print(f"  - Utilization: {buffer.get('utilization', 0)*100:.1f}%")
            
            print(f"\n🖥️  TPU Grid:")
            print(f"  - Total TPUs: {tpu.get('total_tpus', 0):,}")
            print(f"  - Busy TPUs: {tpu.get('busy_tpus', 0)}")
            print(f"  - Compute Hours: {tpu.get('total_compute_hours', 0):.2f}")
        
        # Get history
        response = requests.get(f"{BACKEND_URL}/api/training/cycle/history", timeout=10)
        if response.status_code == 200:
            data = response.json()
            cycles = data.get('cycles', [])
            
            if cycles:
                print(f"\n📈 Recent Cycles:")
                print(f"{'Cycle':<8} {'Positions':<12} {'Loss':<10} {'Win Rate':<12} {'ELO Δ':<10} {'Promoted'}")
                print("-" * 70)
                
                for cycle in cycles[-5:]:  # Last 5 cycles
                    cycle_num = cycle.get('cycle_number', 0)
                    positions = cycle.get('positions_generated', 0)
                    loss = cycle.get('training_loss', 0)
                    win_rate = cycle.get('evaluation_win_rate', 0) * 100
                    elo_delta = cycle.get('elo_delta', 0)
                    promoted = "✓" if cycle.get('model_promoted', False) else "✗"
                    
                    print(f"{cycle_num:<8} {positions:<12,} {loss:<10.4f} {win_rate:<12.1f} {elo_delta:<+10.0f} {promoted}")
    
    except Exception as e:
        print(f"❌ Error fetching results: {e}")

def main():
    """Main demo function"""
    print_banner("TPU TRAINING ORCHESTRATION DEMO")
    print(f"Backend: {BACKEND_URL}")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Check backend health
    try:
        response = requests.get(f"{BACKEND_URL}/api/training/cycle/status", timeout=5)
        if response.status_code != 200:
            print("\n❌ Backend not responding. Please ensure the backend is running.")
            return
    except Exception as e:
        print(f"\n❌ Cannot connect to backend: {e}")
        return
    
    print("\n✅ Backend is ready!")
    
    # Start training cycle
    if not start_training_cycle():
        return
    
    # Wait for cycle to start
    time.sleep(3)
    
    # Monitor progress
    monitor_training_cycle()
    
    # Show results
    time.sleep(2)
    show_results()
    
    print_banner("DEMO COMPLETE")
    print("The TPU Training Orchestration system successfully executed a complete")
    print("AlphaZero training cycle:")
    print("  1. Self-Play → Generated positions using MCTS")
    print("  2. Training → Updated neural network weights")
    print("  3. Evaluation → Compared new vs old model")
    print("  4. Promotion → Promoted model if improved")
    print("\nCheck the results above to see model improvement metrics!")
    print("\nYou can now:")
    print("  - View the frontend at the application URL")
    print("  - Run more cycles by calling the API again")
    print("  - Examine training history and metrics")

if __name__ == "__main__":
    main()
