"""
Phase 4 API Routes - TPU-Enhanced Evaluation & Promotion

Endpoints:
- POST /api/alphazero/eval/start          - Start pod-balanced evaluation
- GET  /api/alphazero/eval/status         - Get evaluation status
- GET  /api/alphazero/eval/results        - Get evaluation results
- GET  /api/alphazero/models              - List all models
- POST /api/alphazero/models/promote      - Manual model promotion
- POST /api/alphazero/models/rollback     - Rollback to previous version
- WS   /ws/alphazero/eval/live            - Live evaluation updates
"""

from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect, BackgroundTasks
from pydantic import BaseModel, Field
from typing import Optional, Dict, List
import logging
from datetime import datetime

from evaluation_manager import get_evaluation_manager, reset_evaluation_manager
from model_registry import get_model_registry, reset_model_registry
from neural_network import AlphaZeroNetwork, ModelManager

logger = logging.getLogger(__name__)

# Create router
phase4_router = APIRouter(prefix="/api/alphazero", tags=["AlphaZero Phase 4"])


# ====================
# Request Models
# ====================

class StartEvaluationRequest(BaseModel):
    challenger_name: str = Field(..., description="Name of challenger model")
    champion_name: str = Field(default="best_model", description="Name of champion model")
    num_eval_games: int = Field(default=200, ge=10, le=1000, description="Total evaluation games")
    pods_for_eval: int = Field(default=2, ge=1, le=16, description="Number of pods to use")
    use_tpu_pods: bool = Field(default=True, description="Use TPU pods (False = CPU)")
    autoscale_eval: bool = Field(default=True, description="Allow autoscaling")
    pod_warmup_seconds: int = Field(default=10, ge=0, le=60, description="Pod warmup time")
    aggregation_mode: str = Field(default="weighted_by_games", description="Aggregation strategy")
    elo_k_factor: int = Field(default=32, ge=8, le=64, description="ELO K-factor")
    num_simulations: int = Field(default=400, ge=100, le=800, description="MCTS simulations per move")
    async_mode: bool = Field(default=True, description="Run in background")


class ManualPromotionRequest(BaseModel):
    model_name: str = Field(..., description="Model to promote")
    elo: float = Field(..., description="ELO rating")
    reason: str = Field(default="Manual promotion", description="Reason for promotion")
    metadata: Optional[Dict] = Field(default=None, description="Additional metadata")


class RollbackRequest(BaseModel):
    version: int = Field(..., ge=0, description="Version to rollback to")
    reason: str = Field(default="Manual rollback", description="Reason for rollback")


# ====================
# Evaluation Endpoints
# ====================

@phase4_router.post("/eval/start")
async def start_evaluation(request: StartEvaluationRequest, background_tasks: BackgroundTasks):
    """
    Start TPU-enhanced pod-balanced evaluation
    
    This endpoint starts a distributed evaluation across multiple TPU pods,
    aggregates results, and calculates TPU-aware ELO ratings.
    """
    try:
        eval_manager = get_evaluation_manager()
        model_manager = ModelManager()
        
        logger.info(f"Starting evaluation: {request.challenger_name} vs {request.champion_name}")
        
        # Load models
        challenger_model, challenger_metadata = model_manager.load_model(request.challenger_name)
        if challenger_model is None:
            raise HTTPException(status_code=404, detail=f"Challenger model {request.challenger_name} not found")
        
        champion_model, champion_metadata = model_manager.load_model(request.champion_name)
        if champion_model is None:
            # Try loading current best
            registry = get_model_registry()
            champion_model, champion_info = registry.get_current_best()
            if champion_model is None:
                raise HTTPException(status_code=404, detail=f"Champion model {request.champion_name} not found")
            champion_metadata = champion_info
        
        # Get ELO ratings
        challenger_elo = challenger_metadata.get('elo', 1500.0) if challenger_metadata else 1500.0
        champion_elo = champion_metadata.get('elo', 1500.0) if champion_metadata else 1500.0
        
        # Update evaluation manager with num_simulations
        eval_manager.num_simulations = request.num_simulations
        
        # Start evaluation
        job, results = await eval_manager.start_evaluation(
            challenger_model=challenger_model,
            champion_model=champion_model,
            challenger_name=request.challenger_name,
            champion_name=request.champion_name,
            challenger_elo=challenger_elo,
            champion_elo=champion_elo,
            num_eval_games=request.num_eval_games,
            pods_for_eval=request.pods_for_eval,
            use_tpu_pods=request.use_tpu_pods,
            autoscale_eval=request.autoscale_eval,
            pod_warmup_seconds=request.pod_warmup_seconds,
            aggregation_mode=request.aggregation_mode,
            elo_k_factor=request.elo_k_factor,
            async_mode=request.async_mode
        )
        
        if request.async_mode:
            return {
                "success": True,
                "message": "Evaluation started in background",
                "job_id": job.job_id,
                "status": job.status.value,
                "challenger": request.challenger_name,
                "champion": request.champion_name,
                "total_games": request.num_eval_games,
                "pods": request.pods_for_eval
            }
        else:
            return {
                "success": True,
                "message": "Evaluation completed",
                "job_id": job.job_id,
                "results": results
            }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error starting evaluation: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@phase4_router.get("/eval/status")
async def get_evaluation_status(job_id: Optional[str] = None):
    """
    Get evaluation status
    
    If job_id is provided, returns status for that job.
    Otherwise, returns status of all active evaluations.
    """
    try:
        eval_manager = get_evaluation_manager()
        
        if job_id:
            status = eval_manager.get_job_status(job_id)
            if status is None:
                raise HTTPException(status_code=404, detail=f"Evaluation job {job_id} not found")
            return {
                "success": True,
                **status
            }
        else:
            # Return all active jobs
            active_jobs = []
            for job_id, job in eval_manager.active_jobs.items():
                active_jobs.append({
                    'job_id': job.job_id,
                    'status': job.status.value,
                    'progress': job.calculate_progress(),
                    'games_completed': job.games_completed,
                    'total_games': job.total_games,
                    'challenger': job.challenger_name,
                    'champion': job.champion_name
                })
            
            return {
                "success": True,
                "active_evaluations": len(active_jobs),
                "jobs": active_jobs
            }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting evaluation status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@phase4_router.get("/eval/results")
async def get_evaluation_results(job_id: str):
    """
    Get evaluation results for a completed job
    
    Returns detailed results including:
    - Overall win rate and ELO delta
    - Per-pod breakdown
    - Aggregation details
    """
    try:
        eval_manager = get_evaluation_manager()
        
        results = eval_manager.get_job_results(job_id)
        if results is None:
            raise HTTPException(status_code=404, detail=f"Results for job {job_id} not found")
        
        return {
            "success": True,
            **results
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting evaluation results: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Model Management Endpoints
# ====================

@phase4_router.get("/models")
async def list_models():
    """
    List all models in registry
    
    Returns:
    - Current best model
    - All archived versions
    - Promotion history
    """
    try:
        registry = get_model_registry()
        
        versions = registry.list_all_versions()
        summary = registry.get_registry_summary()
        
        return {
            "success": True,
            "current_best": summary['current_best'],
            "total_versions": summary['total_versions'],
            "versions": versions,
            "max_elo": summary['max_elo']
        }
    
    except Exception as e:
        logger.error(f"Error listing models: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@phase4_router.get("/models/{model_name}")
async def get_model_info(model_name: str):
    """Get detailed information about a specific model"""
    try:
        model_manager = ModelManager()
        
        info = model_manager.get_model_info(model_name)
        if info is None:
            raise HTTPException(status_code=404, detail=f"Model {model_name} not found")
        
        return {
            "success": True,
            **info
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting model info: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@phase4_router.post("/models/promote")
async def manual_promotion(request: ManualPromotionRequest):
    """
    Manually promote a model
    
    This endpoint allows manual promotion of a model, bypassing automatic thresholds.
    Useful for forced updates or emergency promotions.
    """
    try:
        registry = get_model_registry()
        model_manager = ModelManager()
        
        logger.info(f"Manual promotion requested: {request.model_name}")
        
        # Load model
        model, metadata = model_manager.load_model(request.model_name)
        if model is None:
            raise HTTPException(status_code=404, detail=f"Model {request.model_name} not found")
        
        # Promote
        success, message = registry.promote_model(
            model=model,
            model_name=request.model_name,
            elo=request.elo,
            metadata=request.metadata,
            promoted_by="manual",
            reason=request.reason
        )
        
        if not success:
            raise HTTPException(status_code=400, detail=message)
        
        return {
            "success": True,
            "message": message,
            "model": request.model_name,
            "elo": request.elo
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in manual promotion: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@phase4_router.post("/models/rollback")
async def rollback_model(request: RollbackRequest):
    """
    Rollback to a previous model version
    
    Restores a previous model version as the current best.
    Useful for undoing bad promotions or recovering from issues.
    """
    try:
        registry = get_model_registry()
        
        logger.info(f"Rollback requested to version {request.version}")
        
        success, message = registry.rollback_to_version(
            version=request.version,
            rolled_back_by="manual_api"
        )
        
        if not success:
            raise HTTPException(status_code=400, detail=message)
        
        return {
            "success": True,
            "message": message,
            "version": request.version
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in rollback: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@phase4_router.get("/models/history/promotions")
async def get_promotion_history():
    """Get promotion history"""
    try:
        registry = get_model_registry()
        history = registry.get_promotion_history()
        
        return {
            "success": True,
            "total_promotions": len(history),
            "promotions": history
        }
    
    except Exception as e:
        logger.error(f"Error getting promotion history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@phase4_router.get("/models/history/rollbacks")
async def get_rollback_history():
    """Get rollback history"""
    try:
        registry = get_model_registry()
        history = registry.get_rollback_history()
        
        return {
            "success": True,
            "total_rollbacks": len(history),
            "rollbacks": history
        }
    
    except Exception as e:
        logger.error(f"Error getting rollback history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# WebSocket Endpoint
# ====================

@phase4_router.websocket("/ws/eval/live")
async def websocket_evaluation_live(websocket: WebSocket, job_id: str):
    """
    WebSocket endpoint for live evaluation updates
    
    Query parameters:
    - job_id: Evaluation job ID to subscribe to
    
    Sends real-time updates as evaluation progresses.
    """
    await websocket.accept()
    
    eval_manager = get_evaluation_manager()
    
    # Register client
    eval_manager.register_ws_client(job_id, websocket)
    
    try:
        # Send initial status
        status = eval_manager.get_job_status(job_id)
        if status:
            await websocket.send_json({
                "type": "initial_status",
                **status
            })
        
        # Keep connection alive and listen for client messages
        while True:
            # Wait for messages (or send periodic heartbeats)
            try:
                data = await websocket.receive_text()
                # Echo back (heartbeat)
                await websocket.send_json({"type": "heartbeat", "status": "connected"})
            except WebSocketDisconnect:
                break
    
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    
    finally:
        # Unregister client
        eval_manager.unregister_ws_client(job_id, websocket)
        try:
            await websocket.close()
        except:
            pass


# ====================
# Admin Endpoints
# ====================

@phase4_router.post("/admin/reset-evaluation-manager")
async def admin_reset_evaluation_manager():
    """Reset evaluation manager (for testing)"""
    try:
        reset_evaluation_manager()
        return {
            "success": True,
            "message": "Evaluation manager reset"
        }
    except Exception as e:
        logger.error(f"Error resetting evaluation manager: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@phase4_router.post("/admin/reset-model-registry")
async def admin_reset_model_registry():
    """Reset model registry (for testing)"""
    try:
        reset_model_registry()
        return {
            "success": True,
            "message": "Model registry reset"
        }
    except Exception as e:
        logger.error(f"Error resetting model registry: {e}")
        raise HTTPException(status_code=500, detail=str(e))
