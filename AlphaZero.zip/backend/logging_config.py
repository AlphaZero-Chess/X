"""
Safe Logging Configuration for Windows + Async Environments
===========================================================

Fixes the "underlying buffer has been detached" error that occurs on Windows
when using FastAPI/Uvicorn with UTF-8 logging and async operations.

Issues Solved:
1. Stream detachment during async loop restarts
2. UTF-8 encoding for emoji/Unicode characters
3. Buffer safety for long-running servers
4. Cross-platform compatibility

Usage:
    from logging_config import setup_safe_logging
    
    # Setup logging before any other imports
    setup_safe_logging()
"""

import sys
import io
import logging
from typing import Optional
import os


class SafeStreamHandler(logging.StreamHandler):
    """
    Stream handler that safely handles detached buffers
    
    Automatically re-creates the stream if it becomes detached,
    which commonly happens on Windows with async operations.
    """
    
    def __init__(self, stream=None):
        """Initialize with optional stream"""
        # Don't call super().__init__() yet
        self.stream = None
        self._stream_type = 'stdout' if stream is sys.stdout else 'stderr'
        self._encoding = 'utf-8'
        self._errors = 'replace'
        
        # Initialize the stream safely
        self._init_stream(stream)
        
        # Now call parent init with the safe stream
        super().__init__(self.stream)
    
    def _init_stream(self, stream=None):
        """Initialize or re-initialize the stream safely"""
        try:
            # Use provided stream or default
            if stream is None:
                stream = sys.stdout if self._stream_type == 'stdout' else sys.stderr
            
            # Check if stream has valid buffer
            if hasattr(stream, 'buffer') and stream.buffer is not None:
                # Stream is valid, use it
                self.stream = stream
            else:
                # Stream is invalid, create new one
                self._create_safe_stream()
        except (ValueError, AttributeError):
            # Stream is detached or invalid, create new one
            self._create_safe_stream()
    
    def _create_safe_stream(self):
        """Create a new safe stream"""
        try:
            # Get the underlying buffer
            if self._stream_type == 'stdout':
                base_stream = sys.__stdout__
            else:
                base_stream = sys.__stderr__
            
            # Check if we need to create a wrapper
            if hasattr(base_stream, 'buffer') and base_stream.buffer is not None:
                # Create UTF-8 wrapper only if we have a valid buffer
                try:
                    # Don't detach - just wrap the buffer reference
                    self.stream = io.TextIOWrapper(
                        base_stream.buffer,
                        encoding=self._encoding,
                        errors=self._errors,
                        line_buffering=True
                    )
                except (ValueError, AttributeError):
                    # Fallback to base stream
                    self.stream = base_stream
            else:
                # Use base stream as-is
                self.stream = base_stream
                
        except Exception as e:
            # Last resort: use original sys stream
            self.stream = sys.__stdout__ if self._stream_type == 'stdout' else sys.__stderr__
    
    def emit(self, record):
        """
        Emit a record with safe stream handling
        
        If the stream is detached, re-create it before emitting.
        """
        try:
            # Check if stream is still valid
            if self.stream is None or not hasattr(self.stream, 'write'):
                self._create_safe_stream()
            
            # Try to emit
            super().emit(record)
            
        except ValueError as e:
            # Buffer detached error
            if 'detached' in str(e).lower():
                try:
                    # Re-create stream and try again
                    self._create_safe_stream()
                    super().emit(record)
                except Exception:
                    # Give up silently to avoid logging loops
                    pass
            else:
                # Other ValueError, try fallback
                self.handleError(record)
                
        except Exception:
            # Any other error, use standard error handling
            self.handleError(record)
    
    def flush(self):
        """Flush with error handling"""
        try:
            if self.stream and hasattr(self.stream, 'flush'):
                self.stream.flush()
        except (ValueError, AttributeError):
            # Stream is detached or invalid, ignore
            pass


def setup_safe_logging(
    level: int = logging.INFO,
    format_string: Optional[str] = None,
    include_console: bool = True,
    include_file: bool = False,
    log_file: Optional[str] = None
):
    """
    Setup safe logging configuration for Windows + Async environments
    
    Args:
        level: Logging level (default: INFO)
        format_string: Custom format string (default: timestamp - name - level - message)
        include_console: Include console handler (default: True)
        include_file: Include file handler (default: False)
        log_file: Path to log file if include_file is True
    
    Example:
        setup_safe_logging(
            level=logging.INFO,
            include_console=True,
            include_file=True,
            log_file='/app/logs/server.log'
        )
    """
    
    # Default format
    if format_string is None:
        format_string = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
    formatter = logging.Formatter(format_string)
    
    # Get root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    
    # Clear existing handlers
    root_logger.handlers.clear()
    
    # Add console handler with safe stream handling
    if include_console:
        console_handler = SafeStreamHandler(sys.stdout)
        console_handler.setLevel(level)
        console_handler.setFormatter(formatter)
        root_logger.addHandler(console_handler)
    
    # Add file handler if requested
    if include_file and log_file:
        try:
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
            file_handler.setLevel(level)
            file_handler.setFormatter(formatter)
            root_logger.addHandler(file_handler)
        except Exception as e:
            # If file handler fails, log to console
            if include_console:
                root_logger.error(f"Failed to setup file logging: {e}")
    
    # Prevent propagation issues
    root_logger.propagate = False
    
    return root_logger


def get_safe_worker_logger(
    worker_id: int,
    base_dir: str = "/app/data/logs/selfplay",
    level: int = logging.INFO
) -> logging.Logger:
    """
    Get a safe logger for worker processes
    
    Args:
        worker_id: Worker identifier
        base_dir: Base directory for log files
        level: Logging level
    
    Returns:
        Configured logger instance
    """
    os.makedirs(base_dir, exist_ok=True)
    log_path = os.path.join(base_dir, f"worker_{worker_id}.log")
    
    worker_logger = logging.getLogger(f"worker.{worker_id}")
    worker_logger.setLevel(level)
    worker_logger.propagate = False
    
    # Clear existing handlers
    worker_logger.handlers.clear()
    
    # File handler with UTF-8 encoding
    try:
        fh = logging.FileHandler(log_path, mode='a', encoding='utf-8')
        fmt = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        fh.setFormatter(fmt)
        worker_logger.addHandler(fh)
    except Exception:
        pass  # File logging is optional for workers
    
    # Console handler with safe stream
    ch = SafeStreamHandler(sys.stderr)
    fmt = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    ch.setFormatter(fmt)
    worker_logger.addHandler(ch)
    
    return worker_logger


# Auto-setup on import (can be disabled by setting env var)
if os.environ.get('DISABLE_AUTO_LOGGING_SETUP') != '1':
    # Only setup if not already configured
    if not logging.getLogger().handlers:
        setup_safe_logging()
