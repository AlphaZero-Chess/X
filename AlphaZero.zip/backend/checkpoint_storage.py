"""
Checkpoint Storage Backend for Persistent Training
Supports local filesystem and S3-like object storage

Features:
- Local storage mode (default)
- S3-compatible storage (AWS, MinIO, etc.)
- Checkpoint versioning and retention
- Metadata management
- Atomic saves with rollback
"""

import os
import json
import shutil
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
import hashlib
import torch

logger = logging.getLogger(__name__)


class CheckpointMetadata:
    """Checkpoint metadata structure"""
    
    def __init__(
        self,
        checkpoint_id: str,
        job_id: str,
        epoch: int,
        iteration: int,
        timestamp: str,
        loss: float,
        model_path: str,
        optimizer_path: Optional[str] = None,
        metrics: Optional[Dict] = None,
        storage_backend: str = "local",
        size_bytes: int = 0
    ):
        self.checkpoint_id = checkpoint_id
        self.job_id = job_id
        self.epoch = epoch
        self.iteration = iteration
        self.timestamp = timestamp
        self.loss = loss
        self.model_path = model_path
        self.optimizer_path = optimizer_path
        self.metrics = metrics or {}
        self.storage_backend = storage_backend
        self.size_bytes = size_bytes
    
    def to_dict(self) -> Dict:
        return {
            'checkpoint_id': self.checkpoint_id,
            'job_id': self.job_id,
            'epoch': self.epoch,
            'iteration': self.iteration,
            'timestamp': self.timestamp,
            'loss': self.loss,
            'model_path': self.model_path,
            'optimizer_path': self.optimizer_path,
            'metrics': self.metrics,
            'storage_backend': self.storage_backend,
            'size_bytes': self.size_bytes
        }
    
    @classmethod
    def from_dict(cls, data: Dict):
        return cls(**data)


class LocalCheckpointStorage:
    """Local filesystem checkpoint storage"""
    
    def __init__(self, base_dir: str = "/app/backend/cache/checkpoints"):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self.metadata_dir = self.base_dir / "metadata"
        self.metadata_dir.mkdir(exist_ok=True)
        logger.info(f"LocalCheckpointStorage initialized: {self.base_dir}")
    
    def save_checkpoint(
        self,
        checkpoint_id: str,
        job_id: str,
        model_state: Dict,
        optimizer_state: Optional[Dict],
        epoch: int,
        iteration: int,
        loss: float,
        metrics: Optional[Dict] = None
    ) -> CheckpointMetadata:
        """
        Save checkpoint to local storage
        
        Args:
            checkpoint_id: Unique checkpoint identifier
            job_id: Training job ID
            model_state: Model state dict
            optimizer_state: Optimizer state dict
            epoch: Current epoch
            iteration: Current iteration
            loss: Current loss
            metrics: Additional metrics
        
        Returns:
            CheckpointMetadata
        """
        try:
            # Create checkpoint directory
            checkpoint_dir = self.base_dir / job_id / checkpoint_id
            checkpoint_dir.mkdir(parents=True, exist_ok=True)
            
            # Save model state
            model_path = checkpoint_dir / "model.pt"
            torch.save(model_state, model_path)
            
            # Save optimizer state if provided
            optimizer_path = None
            if optimizer_state is not None:
                optimizer_path = checkpoint_dir / "optimizer.pt"
                torch.save(optimizer_state, optimizer_path)
            
            # Calculate sizes
            size_bytes = model_path.stat().st_size
            if optimizer_path:
                size_bytes += optimizer_path.stat().st_size
            
            # Create metadata
            metadata = CheckpointMetadata(
                checkpoint_id=checkpoint_id,
                job_id=job_id,
                epoch=epoch,
                iteration=iteration,
                timestamp=datetime.now(timezone.utc).isoformat(),
                loss=loss,
                model_path=str(model_path),
                optimizer_path=str(optimizer_path) if optimizer_path else None,
                metrics=metrics,
                storage_backend="local",
                size_bytes=size_bytes
            )
            
            # Save metadata
            metadata_path = self.metadata_dir / f"{checkpoint_id}.json"
            with open(metadata_path, 'w') as f:
                json.dump(metadata.to_dict(), f, indent=2)
            
            logger.info(f"Checkpoint saved: {checkpoint_id} ({size_bytes / 1024 / 1024:.2f} MB)")
            return metadata
        
        except Exception as e:
            logger.error(f"Failed to save checkpoint {checkpoint_id}: {e}")
            raise
    
    def load_checkpoint(self, checkpoint_id: str) -> Optional[Dict]:
        """
        Load checkpoint from local storage
        
        Returns:
            Dict with 'model_state', 'optimizer_state', 'metadata'
        """
        try:
            # Load metadata
            metadata_path = self.metadata_dir / f"{checkpoint_id}.json"
            if not metadata_path.exists():
                logger.error(f"Checkpoint metadata not found: {checkpoint_id}")
                return None
            
            with open(metadata_path, 'r') as f:
                metadata_dict = json.load(f)
            
            metadata = CheckpointMetadata.from_dict(metadata_dict)
            
            # Load model state
            model_state = torch.load(metadata.model_path, map_location='cpu', weights_only=False)
            
            # Load optimizer state if available
            optimizer_state = None
            if metadata.optimizer_path and Path(metadata.optimizer_path).exists():
                optimizer_state = torch.load(metadata.optimizer_path, map_location='cpu', weights_only=False)
            
            logger.info(f"Checkpoint loaded: {checkpoint_id}")
            return {
                'model_state': model_state,
                'optimizer_state': optimizer_state,
                'metadata': metadata.to_dict()
            }
        
        except Exception as e:
            logger.error(f"Failed to load checkpoint {checkpoint_id}: {e}")
            return None
    
    def list_checkpoints(self, job_id: Optional[str] = None) -> List[CheckpointMetadata]:
        """List all checkpoints, optionally filtered by job_id"""
        checkpoints = []
        
        try:
            for metadata_file in self.metadata_dir.glob("*.json"):
                with open(metadata_file, 'r') as f:
                    metadata_dict = json.load(f)
                
                metadata = CheckpointMetadata.from_dict(metadata_dict)
                
                # Filter by job_id if provided
                if job_id is None or metadata.job_id == job_id:
                    checkpoints.append(metadata)
            
            # Sort by timestamp (newest first)
            checkpoints.sort(key=lambda x: x.timestamp, reverse=True)
            return checkpoints
        
        except Exception as e:
            logger.error(f"Failed to list checkpoints: {e}")
            return []
    
    def delete_checkpoint(self, checkpoint_id: str) -> bool:
        """Delete a checkpoint"""
        try:
            # Load metadata to get paths
            metadata_path = self.metadata_dir / f"{checkpoint_id}.json"
            if not metadata_path.exists():
                return False
            
            with open(metadata_path, 'r') as f:
                metadata_dict = json.load(f)
            
            metadata = CheckpointMetadata.from_dict(metadata_dict)
            
            # Delete checkpoint directory
            checkpoint_dir = Path(metadata.model_path).parent
            if checkpoint_dir.exists():
                shutil.rmtree(checkpoint_dir)
            
            # Delete metadata
            metadata_path.unlink()
            
            logger.info(f"Checkpoint deleted: {checkpoint_id}")
            return True
        
        except Exception as e:
            logger.error(f"Failed to delete checkpoint {checkpoint_id}: {e}")
            return False
    
    def cleanup_old_checkpoints(self, job_id: str, keep_last: int = 10) -> int:
        """
        Delete old checkpoints, keeping only the last N
        
        Returns:
            Number of checkpoints deleted
        """
        checkpoints = self.list_checkpoints(job_id=job_id)
        
        if len(checkpoints) <= keep_last:
            return 0
        
        # Delete old checkpoints
        to_delete = checkpoints[keep_last:]
        deleted_count = 0
        
        for checkpoint in to_delete:
            if self.delete_checkpoint(checkpoint.checkpoint_id):
                deleted_count += 1
        
        logger.info(f"Cleaned up {deleted_count} old checkpoints for job {job_id}")
        return deleted_count


class S3CheckpointStorage:
    """
    S3-compatible checkpoint storage
    
    Requires environment variables:
    - AWS_ACCESS_KEY_ID
    - AWS_SECRET_ACCESS_KEY
    - S3_BUCKET
    - AWS_REGION (optional, defaults to us-east-1)
    - S3_ENDPOINT_URL (optional, for MinIO/custom S3)
    """
    
    def __init__(self, bucket: Optional[str] = None, endpoint_url: Optional[str] = None):
        try:
            import boto3
            self.boto3 = boto3
        except ImportError:
            raise ImportError("boto3 is required for S3 storage. Install with: pip install boto3")
        
        self.bucket = bucket or os.environ.get('S3_BUCKET')
        if not self.bucket:
            raise ValueError("S3_BUCKET must be provided or set in environment")
        
        # Initialize S3 client
        self.s3_client = self.boto3.client(
            's3',
            endpoint_url=endpoint_url or os.environ.get('S3_ENDPOINT_URL'),
            region_name=os.environ.get('AWS_REGION', 'us-east-1')
        )
        
        # Local cache for metadata
        self.cache_dir = Path("/app/backend/cache/s3_metadata")
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"S3CheckpointStorage initialized: bucket={self.bucket}")
    
    def save_checkpoint(
        self,
        checkpoint_id: str,
        job_id: str,
        model_state: Dict,
        optimizer_state: Optional[Dict],
        epoch: int,
        iteration: int,
        loss: float,
        metrics: Optional[Dict] = None
    ) -> CheckpointMetadata:
        """Save checkpoint to S3"""
        try:
            # Save to temporary local files first
            temp_dir = Path("/tmp") / "checkpoint_upload" / checkpoint_id
            temp_dir.mkdir(parents=True, exist_ok=True)
            
            model_temp_path = temp_dir / "model.pt"
            torch.save(model_state, model_temp_path)
            
            optimizer_temp_path = None
            if optimizer_state is not None:
                optimizer_temp_path = temp_dir / "optimizer.pt"
                torch.save(optimizer_state, optimizer_temp_path)
            
            # Upload to S3
            s3_model_key = f"checkpoints/{job_id}/{checkpoint_id}/model.pt"
            self.s3_client.upload_file(str(model_temp_path), self.bucket, s3_model_key)
            
            s3_optimizer_key = None
            if optimizer_temp_path:
                s3_optimizer_key = f"checkpoints/{job_id}/{checkpoint_id}/optimizer.pt"
                self.s3_client.upload_file(str(optimizer_temp_path), self.bucket, s3_optimizer_key)
            
            # Calculate size
            size_bytes = model_temp_path.stat().st_size
            if optimizer_temp_path:
                size_bytes += optimizer_temp_path.stat().st_size
            
            # Create metadata
            metadata = CheckpointMetadata(
                checkpoint_id=checkpoint_id,
                job_id=job_id,
                epoch=epoch,
                iteration=iteration,
                timestamp=datetime.now(timezone.utc).isoformat(),
                loss=loss,
                model_path=f"s3://{self.bucket}/{s3_model_key}",
                optimizer_path=f"s3://{self.bucket}/{s3_optimizer_key}" if s3_optimizer_key else None,
                metrics=metrics,
                storage_backend="s3",
                size_bytes=size_bytes
            )
            
            # Save metadata to S3 and local cache
            metadata_key = f"checkpoints/{job_id}/{checkpoint_id}/metadata.json"
            metadata_json = json.dumps(metadata.to_dict(), indent=2)
            self.s3_client.put_object(
                Bucket=self.bucket,
                Key=metadata_key,
                Body=metadata_json,
                ContentType='application/json'
            )
            
            # Cache metadata locally
            cache_file = self.cache_dir / f"{checkpoint_id}.json"
            with open(cache_file, 'w') as f:
                json.dump(metadata.to_dict(), f, indent=2)
            
            # Cleanup temp files
            shutil.rmtree(temp_dir)
            
            logger.info(f"Checkpoint saved to S3: {checkpoint_id} ({size_bytes / 1024 / 1024:.2f} MB)")
            return metadata
        
        except Exception as e:
            logger.error(f"Failed to save checkpoint to S3 {checkpoint_id}: {e}")
            raise
    
    def load_checkpoint(self, checkpoint_id: str) -> Optional[Dict]:
        """Load checkpoint from S3"""
        try:
            # Load metadata from cache or S3
            cache_file = self.cache_dir / f"{checkpoint_id}.json"
            
            if cache_file.exists():
                with open(cache_file, 'r') as f:
                    metadata_dict = json.load(f)
            else:
                # Try to load from S3
                logger.warning(f"Metadata not in cache, searching S3...")
                return None
            
            metadata = CheckpointMetadata.from_dict(metadata_dict)
            
            # Download from S3 to temp directory
            temp_dir = Path("/tmp") / "checkpoint_download" / checkpoint_id
            temp_dir.mkdir(parents=True, exist_ok=True)
            
            # Parse S3 paths
            model_key = metadata.model_path.replace(f"s3://{self.bucket}/", "")
            model_temp_path = temp_dir / "model.pt"
            self.s3_client.download_file(self.bucket, model_key, str(model_temp_path))
            
            model_state = torch.load(model_temp_path, map_location='cpu', weights_only=False)
            
            optimizer_state = None
            if metadata.optimizer_path:
                optimizer_key = metadata.optimizer_path.replace(f"s3://{self.bucket}/", "")
                optimizer_temp_path = temp_dir / "optimizer.pt"
                self.s3_client.download_file(self.bucket, optimizer_key, str(optimizer_temp_path))
                optimizer_state = torch.load(optimizer_temp_path, map_location='cpu', weights_only=False)
            
            # Cleanup temp files
            shutil.rmtree(temp_dir)
            
            logger.info(f"Checkpoint loaded from S3: {checkpoint_id}")
            return {
                'model_state': model_state,
                'optimizer_state': optimizer_state,
                'metadata': metadata.to_dict()
            }
        
        except Exception as e:
            logger.error(f"Failed to load checkpoint from S3 {checkpoint_id}: {e}")
            return None
    
    def list_checkpoints(self, job_id: Optional[str] = None) -> List[CheckpointMetadata]:
        """List checkpoints from local cache"""
        checkpoints = []
        
        try:
            for cache_file in self.cache_dir.glob("*.json"):
                with open(cache_file, 'r') as f:
                    metadata_dict = json.load(f)
                
                metadata = CheckpointMetadata.from_dict(metadata_dict)
                
                if job_id is None or metadata.job_id == job_id:
                    checkpoints.append(metadata)
            
            checkpoints.sort(key=lambda x: x.timestamp, reverse=True)
            return checkpoints
        
        except Exception as e:
            logger.error(f"Failed to list checkpoints: {e}")
            return []


class CheckpointStorageManager:
    """
    Unified checkpoint storage manager
    Automatically selects backend based on configuration
    """
    
    def __init__(self, storage_mode: str = "auto"):
        """
        Initialize checkpoint storage
        
        Args:
            storage_mode: 'local', 's3', or 'auto' (auto-detect based on env)
        """
        self.storage_mode = storage_mode
        
        # Auto-detect storage backend
        if storage_mode == "auto":
            if os.environ.get('S3_BUCKET') and os.environ.get('AWS_ACCESS_KEY_ID'):
                self.storage_mode = "s3"
            else:
                self.storage_mode = "local"
        
        # Initialize backend
        if self.storage_mode == "s3":
            try:
                self.backend = S3CheckpointStorage()
                logger.info("Using S3 checkpoint storage")
            except Exception as e:
                logger.warning(f"Failed to initialize S3 storage, falling back to local: {e}")
                self.backend = LocalCheckpointStorage()
                self.storage_mode = "local"
        else:
            self.backend = LocalCheckpointStorage()
            logger.info("Using local checkpoint storage")
    
    def save_checkpoint(self, *args, **kwargs) -> CheckpointMetadata:
        """Save checkpoint using configured backend"""
        return self.backend.save_checkpoint(*args, **kwargs)
    
    def load_checkpoint(self, checkpoint_id: str) -> Optional[Dict]:
        """Load checkpoint using configured backend"""
        return self.backend.load_checkpoint(checkpoint_id)
    
    def list_checkpoints(self, job_id: Optional[str] = None) -> List[CheckpointMetadata]:
        """List checkpoints using configured backend"""
        return self.backend.list_checkpoints(job_id)
    
    def delete_checkpoint(self, checkpoint_id: str) -> bool:
        """Delete checkpoint using configured backend"""
        if hasattr(self.backend, 'delete_checkpoint'):
            return self.backend.delete_checkpoint(checkpoint_id)
        return False
    
    def cleanup_old_checkpoints(self, job_id: str, keep_last: int = 10) -> int:
        """Cleanup old checkpoints"""
        if hasattr(self.backend, 'cleanup_old_checkpoints'):
            return self.backend.cleanup_old_checkpoints(job_id, keep_last)
        return 0
    
    def get_storage_info(self) -> Dict:
        """Get storage backend information"""
        return {
            'storage_mode': self.storage_mode,
            'backend_type': type(self.backend).__name__
        }


# Global instance
_checkpoint_storage = None


def get_checkpoint_storage(storage_mode: str = "auto") -> CheckpointStorageManager:
    """Get or create global checkpoint storage instance"""
    global _checkpoint_storage
    
    if _checkpoint_storage is None:
        _checkpoint_storage = CheckpointStorageManager(storage_mode=storage_mode)
    
    return _checkpoint_storage
