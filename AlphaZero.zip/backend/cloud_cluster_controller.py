"""
Cloud Cluster Controller - Virtual Cloud Orchestration Layer

Master scheduler that manages:
- Node lifecycle (registration, health checks, decommission)
- Auto-scaling (100 → 10,000 TPUs)
- Region/zone awareness (us-east, us-west, eu-west, asia)
- Fault detection and recovery
- Resource allocation across regions

This layer sits above tpu_cluster_manager.py and provides Kubernetes-like orchestration.
"""

import asyncio
import time
import random
import logging
import threading
from collections import defaultdict
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field, asdict
from enum import Enum
from datetime import datetime, timezone
import json

logger = logging.getLogger(__name__)


class Region(Enum):
    """Cloud regions for TPU deployment"""
    US_EAST = "us-east"
    US_WEST = "us-west"
    EU_WEST = "eu-west"
    ASIA = "asia"


class NodeHealth(Enum):
    """Node health status"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"  # Slow/high latency
    UNHEALTHY = "unhealthy"  # Failed/crashed
    MAINTENANCE = "maintenance"
    UNKNOWN = "unknown"


class ScalingPolicy(Enum):
    """Auto-scaling policies"""
    MANUAL = "manual"
    AUTO_DEMAND = "auto_demand"  # Scale based on job queue
    AUTO_UTILIZATION = "auto_utilization"  # Scale based on utilization
    AUTO_TIME = "auto_time"  # Scale based on time of day


@dataclass
class CloudNode:
    """
    Virtual cloud node (represents a TPU pod or group of TPU cores)
    Mirrors behavior of real cloud instances
    """
    node_id: str
    region: Region
    zone: str  # Availability zone within region
    num_tpus: int  # TPUs allocated to this node
    tpu_ids: List[int]  # Underlying TPU IDs from grid
    health: NodeHealth = NodeHealth.HEALTHY
    
    # Performance characteristics
    base_latency_ms: float = 5.0
    current_latency_ms: float = 5.0
    network_bandwidth_gbps: float = 100.0
    
    # Operational state
    created_at: float = field(default_factory=time.time)
    last_heartbeat: float = field(default_factory=time.time)
    uptime_seconds: float = 0.0
    
    # Fault injection state
    is_crashed: bool = False
    is_partitioned: bool = False
    latency_spike_factor: float = 1.0  # Multiplier for latency
    
    # Metrics
    jobs_executed: int = 0
    compute_hours: float = 0.0
    
    def update_health(self):
        """Update health status based on conditions"""
        if self.is_crashed:
            self.health = NodeHealth.UNHEALTHY
        elif self.latency_spike_factor > 3.0 or self.is_partitioned:
            self.health = NodeHealth.DEGRADED
        else:
            self.health = NodeHealth.HEALTHY
        
        self.current_latency_ms = self.base_latency_ms * self.latency_spike_factor
    
    def heartbeat(self):
        """Record heartbeat from node"""
        self.last_heartbeat = time.time()
        self.uptime_seconds = time.time() - self.created_at
        self.update_health()
    
    def to_dict(self) -> Dict:
        return {
            'node_id': self.node_id,
            'region': self.region.value,
            'zone': self.zone,
            'num_tpus': self.num_tpus,
            'health': self.health.value,
            'latency_ms': round(self.current_latency_ms, 2),
            'bandwidth_gbps': self.network_bandwidth_gbps,
            'uptime_hours': round(self.uptime_seconds / 3600, 2),
            'jobs_executed': self.jobs_executed,
            'is_crashed': self.is_crashed,
            'is_partitioned': self.is_partitioned
        }


@dataclass
class RegionConfig:
    """Configuration for a cloud region"""
    region: Region
    zones: List[str]
    max_nodes: int = 1000
    base_latency_ms: float = 5.0
    
    # Fault injection configuration
    node_crash_rate: float = 0.001  # 0.1% chance per hour
    network_partition_rate: float = 0.0005  # 0.05% chance per hour
    latency_spike_rate: float = 0.01  # 1% chance per hour
    latency_spike_range: Tuple[float, float] = (2.0, 10.0)  # Multiplier range
    
    # Current state
    active_nodes: int = 0
    total_tpus: int = 0
    
    def to_dict(self) -> Dict:
        return {
            'region': self.region.value,
            'zones': self.zones,
            'max_nodes': self.max_nodes,
            'active_nodes': self.active_nodes,
            'total_tpus': self.total_tpus,
            'base_latency_ms': self.base_latency_ms,
            'fault_config': {
                'crash_rate': self.node_crash_rate,
                'partition_rate': self.network_partition_rate,
                'latency_spike_rate': self.latency_spike_rate
            }
        }


class CloudClusterController:
    """
    Master Cloud Cluster Controller
    
    Manages a virtual cloud infrastructure across multiple regions,
    providing Kubernetes-like orchestration for TPU resources.
    
    Features:
    - Multi-region node management (us-east, us-west, eu-west, asia)
    - Auto-scaling (100 → 10,000 TPUs)
    - Health monitoring and fault detection
    - Fault injection for testing
    - Region-aware resource allocation
    """
    
    def __init__(
        self,
        tpu_grid_manager,
        initial_size: int = 1000,
        scaling_policy: ScalingPolicy = ScalingPolicy.AUTO_DEMAND
    ):
        """
        Initialize Cloud Cluster Controller
        
        Args:
            tpu_grid_manager: Underlying TPU grid manager
            initial_size: Initial total TPU count
            scaling_policy: Auto-scaling policy
        """
        self.tpu_grid = tpu_grid_manager
        self.scaling_policy = scaling_policy
        
        logger.info("="*80)
        logger.info("INITIALIZING CLOUD CLUSTER CONTROLLER")
        logger.info(f"Initial Size: {initial_size:,} TPUs")
        logger.info(f"Scaling Policy: {scaling_policy.value}")
        logger.info("="*80)
        
        # Region configurations
        self.regions: Dict[Region, RegionConfig] = {
            Region.US_EAST: RegionConfig(
                region=Region.US_EAST,
                zones=['use1-az1', 'use1-az2', 'use1-az3'],
                base_latency_ms=3.0
            ),
            Region.US_WEST: RegionConfig(
                region=Region.US_WEST,
                zones=['usw2-az1', 'usw2-az2', 'usw2-az3'],
                base_latency_ms=4.0
            ),
            Region.EU_WEST: RegionConfig(
                region=Region.EU_WEST,
                zones=['euw1-az1', 'euw1-az2'],
                base_latency_ms=80.0  # Trans-Atlantic
            ),
            Region.ASIA: RegionConfig(
                region=Region.ASIA,
                zones=['apse1-az1', 'apse1-az2'],
                base_latency_ms=150.0  # Trans-Pacific
            )
        }
        
        # Node registry
        self.nodes: Dict[str, CloudNode] = {}
        self.nodes_by_region: Dict[Region, List[str]] = defaultdict(list)
        
        # Scaling configuration
        self.min_tpus = 100
        self.max_tpus = 10_000
        self.current_target_size = initial_size
        
        # Monitoring state
        self.total_nodes_created = 0
        self.total_nodes_decommissioned = 0
        self.total_faults_injected = 0
        
        # Thread safety
        self.lock = threading.RLock()
        
        # Health check thread
        self.health_check_thread = None
        self.health_check_interval = 10  # seconds
        self.running = False
        
        # Initialize cluster
        self._initialize_cluster(initial_size)
        
        # Start health monitoring
        self.start_health_monitoring()
        
        logger.info(f"✅ Cloud Cluster Controller initialized: {len(self.nodes)} nodes across {len(self.regions)} regions")
    
    def _initialize_cluster(self, total_tpus: int):
        """Initialize cluster with nodes distributed across regions"""
        # Distribute TPUs across regions (40% US-EAST, 30% US-WEST, 20% EU-WEST, 10% ASIA)
        distribution = {
            Region.US_EAST: 0.40,
            Region.US_WEST: 0.30,
            Region.EU_WEST: 0.20,
            Region.ASIA: 0.10
        }
        
        tpu_id_offset = 0
        
        for region, ratio in distribution.items():
            region_tpus = int(total_tpus * ratio)
            region_config = self.regions[region]
            
            # Create nodes (8 TPUs per node)
            tpus_per_node = 8
            num_nodes = max(1, region_tpus // tpus_per_node)
            
            for i in range(num_nodes):
                node_tpus = min(tpus_per_node, region_tpus - i * tpus_per_node)
                if node_tpus == 0:
                    break
                
                # Assign TPU IDs
                tpu_ids = list(range(tpu_id_offset, tpu_id_offset + node_tpus))
                tpu_id_offset += node_tpus
                
                # Select zone (round-robin)
                zone = region_config.zones[i % len(region_config.zones)]
                
                # Create node
                node_id = f"{region.value}-node-{self.total_nodes_created:05d}"
                node = CloudNode(
                    node_id=node_id,
                    region=region,
                    zone=zone,
                    num_tpus=node_tpus,
                    tpu_ids=tpu_ids,
                    base_latency_ms=region_config.base_latency_ms
                )
                
                self.nodes[node_id] = node
                self.nodes_by_region[region].append(node_id)
                self.total_nodes_created += 1
                
                # Update region state
                region_config.active_nodes += 1
                region_config.total_tpus += node_tpus
            
            logger.info(f"  {region.value}: {region_config.active_nodes} nodes, {region_config.total_tpus} TPUs")
    
    def scale_cluster(self, new_size: int) -> bool:
        """
        Scale cluster to new size
        
        Args:
            new_size: Target TPU count (100-10000)
        
        Returns:
            Success status
        """
        with self.lock:
            if new_size < self.min_tpus or new_size > self.max_tpus:
                logger.warning(f"Scale request out of bounds: {new_size} (allowed: {self.min_tpus}-{self.max_tpus})")
                return False
            
            current_size = sum(node.num_tpus for node in self.nodes.values())
            
            if new_size == current_size:
                logger.info(f"Cluster already at target size: {current_size}")
                return True
            
            logger.info(f"Scaling cluster: {current_size:,} → {new_size:,} TPUs")
            
            if new_size > current_size:
                # Scale up
                return self._scale_up(new_size - current_size)
            else:
                # Scale down
                return self._scale_down(current_size - new_size)
    
    def _scale_up(self, additional_tpus: int) -> bool:
        """Add nodes to cluster"""
        logger.info(f"Scaling up: adding {additional_tpus:,} TPUs")
        
        # Distribute new TPUs across regions (same distribution)
        distribution = {
            Region.US_EAST: 0.40,
            Region.US_WEST: 0.30,
            Region.EU_WEST: 0.20,
            Region.ASIA: 0.10
        }
        
        # Get current max TPU ID
        max_tpu_id = 0
        for node in self.nodes.values():
            if node.tpu_ids:
                max_tpu_id = max(max_tpu_id, max(node.tpu_ids))
        
        tpu_id_offset = max_tpu_id + 1
        
        for region, ratio in distribution.items():
            region_tpus = int(additional_tpus * ratio)
            region_config = self.regions[region]
            
            # Create nodes
            tpus_per_node = 8
            num_nodes = max(1, region_tpus // tpus_per_node)
            
            for i in range(num_nodes):
                node_tpus = min(tpus_per_node, region_tpus - i * tpus_per_node)
                if node_tpus == 0:
                    break
                
                tpu_ids = list(range(tpu_id_offset, tpu_id_offset + node_tpus))
                tpu_id_offset += node_tpus
                
                zone = region_config.zones[region_config.active_nodes % len(region_config.zones)]
                
                node_id = f"{region.value}-node-{self.total_nodes_created:05d}"
                node = CloudNode(
                    node_id=node_id,
                    region=region,
                    zone=zone,
                    num_tpus=node_tpus,
                    tpu_ids=tpu_ids,
                    base_latency_ms=region_config.base_latency_ms
                )
                
                self.nodes[node_id] = node
                self.nodes_by_region[region].append(node_id)
                self.total_nodes_created += 1
                
                region_config.active_nodes += 1
                region_config.total_tpus += node_tpus
        
        logger.info(f"✅ Scaled up: {len(self.nodes)} total nodes")
        return True
    
    def _scale_down(self, tpus_to_remove: int) -> bool:
        """Remove nodes from cluster"""
        logger.info(f"Scaling down: removing {tpus_to_remove:,} TPUs")
        
        # Remove nodes in reverse order (newest first)
        nodes_to_remove = []
        tpus_removed = 0
        
        # Sort nodes by creation time (newest first)
        sorted_nodes = sorted(self.nodes.values(), key=lambda n: n.created_at, reverse=True)
        
        for node in sorted_nodes:
            if tpus_removed >= tpus_to_remove:
                break
            
            # Only remove healthy, idle nodes
            if node.health == NodeHealth.HEALTHY:
                nodes_to_remove.append(node.node_id)
                tpus_removed += node.num_tpus
        
        if tpus_removed < tpus_to_remove:
            logger.warning(f"Could only remove {tpus_removed}/{tpus_to_remove} TPUs (insufficient idle nodes)")
        
        # Decommission nodes
        for node_id in nodes_to_remove:
            self._decommission_node(node_id)
        
        logger.info(f"✅ Scaled down: {len(self.nodes)} total nodes")
        return True
    
    def _decommission_node(self, node_id: str):
        """Remove node from cluster"""
        if node_id not in self.nodes:
            return
        
        node = self.nodes[node_id]
        region_config = self.regions[node.region]
        
        # Update region state
        region_config.active_nodes -= 1
        region_config.total_tpus -= node.num_tpus
        
        # Remove from registries
        del self.nodes[node_id]
        self.nodes_by_region[node.region].remove(node_id)
        self.total_nodes_decommissioned += 1
        
        logger.info(f"Decommissioned node: {node_id}")
    
    def inject_fault(
        self,
        fault_type: str,
        node_id: Optional[str] = None,
        region: Optional[Region] = None
    ) -> Dict:
        """
        Manually inject fault for testing
        
        Args:
            fault_type: 'crash', 'partition', or 'latency_spike'
            node_id: Specific node (optional)
            region: Target region for random node (optional)
        
        Returns:
            Fault injection result
        """
        with self.lock:
            # Select target node
            if node_id:
                if node_id not in self.nodes:
                    return {'success': False, 'error': f'Node {node_id} not found'}
                target_node = self.nodes[node_id]
            else:
                # Random node from region or entire cluster
                if region and region in self.nodes_by_region:
                    candidates = [self.nodes[nid] for nid in self.nodes_by_region[region]]
                else:
                    candidates = list(self.nodes.values())
                
                if not candidates:
                    return {'success': False, 'error': 'No nodes available'}
                
                target_node = random.choice(candidates)
            
            # Apply fault
            if fault_type == 'crash':
                target_node.is_crashed = True
                target_node.update_health()
                logger.warning(f"💥 Fault injected: Node {target_node.node_id} CRASHED")
            
            elif fault_type == 'partition':
                target_node.is_partitioned = True
                target_node.update_health()
                logger.warning(f"🔌 Fault injected: Node {target_node.node_id} NETWORK PARTITION")
            
            elif fault_type == 'latency_spike':
                spike_factor = random.uniform(2.0, 10.0)
                target_node.latency_spike_factor = spike_factor
                target_node.update_health()
                logger.warning(f"🐌 Fault injected: Node {target_node.node_id} LATENCY SPIKE (x{spike_factor:.1f})")
            
            else:
                return {'success': False, 'error': f'Unknown fault type: {fault_type}'}
            
            self.total_faults_injected += 1
            
            return {
                'success': True,
                'fault_type': fault_type,
                'node_id': target_node.node_id,
                'region': target_node.region.value,
                'zone': target_node.zone,
                'health': target_node.health.value
            }
    
    def recover_node(self, node_id: str) -> Dict:
        """Recover node from fault"""
        with self.lock:
            if node_id not in self.nodes:
                return {'success': False, 'error': f'Node {node_id} not found'}
            
            node = self.nodes[node_id]
            node.is_crashed = False
            node.is_partitioned = False
            node.latency_spike_factor = 1.0
            node.update_health()
            
            logger.info(f"✅ Node recovered: {node_id}")
            
            return {
                'success': True,
                'node_id': node_id,
                'health': node.health.value
            }
    
    def start_health_monitoring(self):
        """Start background health monitoring thread"""
        if self.health_check_thread and self.health_check_thread.is_alive():
            return
        
        self.running = True
        self.health_check_thread = threading.Thread(
            target=self._health_check_loop,
            daemon=True
        )
        self.health_check_thread.start()
        logger.info("Health monitoring started")
    
    def stop_health_monitoring(self):
        """Stop health monitoring"""
        self.running = False
        if self.health_check_thread:
            self.health_check_thread.join(timeout=5)
        logger.info("Health monitoring stopped")
    
    def _health_check_loop(self):
        """Background health check loop"""
        while self.running:
            try:
                self._perform_health_checks()
                time.sleep(self.health_check_interval)
            except Exception as e:
                logger.error(f"Health check error: {e}")
    
    def _perform_health_checks(self):
        """Perform health checks and simulate random faults"""
        with self.lock:
            for node in self.nodes.values():
                # Update heartbeat
                node.heartbeat()
                
                # Simulate random faults based on region config
                if node.health == NodeHealth.HEALTHY:
                    region_config = self.regions[node.region]
                    
                    # Random crash
                    if random.random() < region_config.node_crash_rate:
                        node.is_crashed = True
                        logger.warning(f"💥 Random fault: Node {node.node_id} crashed")
                    
                    # Random partition
                    elif random.random() < region_config.network_partition_rate:
                        node.is_partitioned = True
                        logger.warning(f"🔌 Random fault: Node {node.node_id} partitioned")
                    
                    # Random latency spike
                    elif random.random() < region_config.latency_spike_rate:
                        spike = random.uniform(*region_config.latency_spike_range)
                        node.latency_spike_factor = spike
                        logger.warning(f"🐌 Random fault: Node {node.node_id} latency spike x{spike:.1f}")
                
                node.update_health()
    
    def get_cluster_status(self) -> Dict:
        """Get comprehensive cluster status"""
        with self.lock:
            total_nodes = len(self.nodes)
            total_tpus = sum(node.num_tpus for node in self.nodes.values())
            
            # Health breakdown
            health_counts = defaultdict(int)
            for node in self.nodes.values():
                health_counts[node.health.value] += 1
            
            # Region breakdown
            region_stats = {}
            for region, config in self.regions.items():
                region_nodes = [self.nodes[nid] for nid in self.nodes_by_region[region]]
                
                region_stats[region.value] = {
                    'active_nodes': config.active_nodes,
                    'total_tpus': config.total_tpus,
                    'healthy_nodes': sum(1 for n in region_nodes if n.health == NodeHealth.HEALTHY),
                    'degraded_nodes': sum(1 for n in region_nodes if n.health == NodeHealth.DEGRADED),
                    'unhealthy_nodes': sum(1 for n in region_nodes if n.health == NodeHealth.UNHEALTHY),
                    'avg_latency_ms': round(sum(n.current_latency_ms for n in region_nodes) / len(region_nodes), 2) if region_nodes else 0,
                    'zones': config.zones
                }
            
            return {
                'cluster': {
                    'total_nodes': total_nodes,
                    'total_tpus': total_tpus,
                    'scaling_policy': self.scaling_policy.value,
                    'min_tpus': self.min_tpus,
                    'max_tpus': self.max_tpus
                },
                'health': dict(health_counts),
                'regions': region_stats,
                'lifecycle': {
                    'total_created': self.total_nodes_created,
                    'total_decommissioned': self.total_nodes_decommissioned,
                    'total_faults_injected': self.total_faults_injected
                },
                'timestamp': datetime.now(timezone.utc).isoformat()
            }
    
    def get_node_details(self, node_id: str) -> Optional[Dict]:
        """Get detailed info for specific node"""
        with self.lock:
            if node_id not in self.nodes:
                return None
            return self.nodes[node_id].to_dict()
    
    def list_nodes(
        self,
        region: Optional[Region] = None,
        health: Optional[NodeHealth] = None
    ) -> List[Dict]:
        """List nodes with optional filters"""
        with self.lock:
            nodes = list(self.nodes.values())
            
            if region:
                nodes = [n for n in nodes if n.region == region]
            
            if health:
                nodes = [n for n in nodes if n.health == health]
            
            return [n.to_dict() for n in nodes]
    
    def update_region_fault_config(
        self,
        region: Region,
        crash_rate: Optional[float] = None,
        partition_rate: Optional[float] = None,
        latency_spike_rate: Optional[float] = None
    ) -> bool:
        """Update fault injection rates for a region"""
        with self.lock:
            if region not in self.regions:
                return False
            
            config = self.regions[region]
            
            if crash_rate is not None:
                config.node_crash_rate = crash_rate
            if partition_rate is not None:
                config.network_partition_rate = partition_rate
            if latency_spike_rate is not None:
                config.latency_spike_rate = latency_spike_rate
            
            logger.info(f"Updated fault config for {region.value}")
            return True


# Global instance
_cloud_controller = None


def get_cloud_controller(
    tpu_grid_manager=None,
    initial_size: int = 1000,
    scaling_policy: ScalingPolicy = ScalingPolicy.AUTO_DEMAND
) -> CloudClusterController:
    """Get or create global cloud controller"""
    global _cloud_controller
    
    if _cloud_controller is None:
        if tpu_grid_manager is None:
            from tpu_cluster_manager import get_tpu_grid
            tpu_grid_manager = get_tpu_grid(num_tpus=initial_size)
        
        _cloud_controller = CloudClusterController(
            tpu_grid_manager=tpu_grid_manager,
            initial_size=initial_size,
            scaling_policy=scaling_policy
        )
    
    return _cloud_controller


def reset_cloud_controller():
    """Reset global controller (for testing)"""
    global _cloud_controller
    if _cloud_controller:
        _cloud_controller.stop_health_monitoring()
    _cloud_controller = None
