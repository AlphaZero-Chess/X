#!/usr/bin/env python3
"""
Quick test script for AlphaZero improvements
Tests MCTS, trainer, evaluator, and curriculum engine
"""
import sys
from pathlib import Path

# Add backend to path
backend_dir = Path(__file__).parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

print("="*60)
print("Testing AlphaZero Improvements")
print("="*60)

# Test 1: MCTS with Dirichlet noise
print("\n[1/5] Testing Enhanced MCTS...")
try:
    from mcts import MCTS
    from neural_network import AlphaZeroNetwork
    from chess_engine import ChessEngine
    
    network = AlphaZeroNetwork()
    mcts = MCTS(network, num_simulations=10, dirichlet_alpha=0.3, dirichlet_epsilon=0.25)
    engine = ChessEngine()
    
    # Test search with noise
    move, probs, value = mcts.search(engine, temperature=1.0, add_noise=True)
    print(f"  ✓ MCTS search successful")
    print(f"    Best move: {move}")
    print(f"    Root value: {value:.3f}")
    print(f"    Moves evaluated: {len(probs)}")
    
    # Test tree reuse
    mcts.move_root(move)
    print(f"  ✓ Tree reuse successful")
    
    # Test performance stats
    stats = mcts.get_performance_stats()
    print(f"  ✓ Performance stats: {stats['cache_size']} cached positions")
    
except Exception as e:
    print(f"  ✗ MCTS test failed: {e}")
    sys.exit(1)

# Test 2: Trainer with mixed precision
print("\n[2/5] Testing Enhanced Trainer...")
try:
    from trainer import AlphaZeroTrainer
    import torch
    
    network = AlphaZeroNetwork()
    
    # Test with and without mixed precision
    use_mp = torch.cuda.is_available()
    trainer = AlphaZeroTrainer(network, learning_rate=0.001, use_mixed_precision=use_mp)
    
    print(f"  ✓ Trainer initialized")
    print(f"    Mixed precision: {trainer.use_mixed_precision}")
    print(f"    Device: {trainer.device}")
    
    # Test training state
    state = trainer.get_training_state()
    print(f"  ✓ Training state: Epoch {state['epoch']}, Steps {state['total_steps']}")
    
    # Test checkpoint save/load
    checkpoint_path = trainer.save_checkpoint("test")
    print(f"  ✓ Checkpoint saved: {checkpoint_path}")
    
    loaded = trainer.load_checkpoint("test")
    print(f"  ✓ Checkpoint loaded: {loaded}")
    
except Exception as e:
    print(f"  ✗ Trainer test failed: {e}")
    sys.exit(1)

# Test 3: Evaluator with ELO
print("\n[3/5] Testing ELO Evaluator...")
try:
    from evaluator import ELOCalculator, ModelEvaluator
    
    # Test ELO calculation
    elo_result = ELOCalculator.calculate_elo_delta(
        wins=6, losses=3, draws=1,
        current_elo=1500, opponent_elo=1500,
        k_factor=32
    )
    
    print(f"  ✓ ELO calculation successful")
    print(f"    Before: {elo_result['elo_before']:.0f}")
    print(f"    After: {elo_result['elo_after']:.0f}")
    print(f"    Delta: {elo_result['elo_delta']:.0f}")
    print(f"    Win rate: {elo_result['actual_score']:.1%}")
    
    # Test evaluator initialization
    evaluator = ModelEvaluator(
        num_evaluation_games=10,
        num_simulations=50,
        win_threshold=0.55,
        elo_threshold=50.0
    )
    print(f"  ✓ Evaluator initialized")
    print(f"    Games: {evaluator.num_evaluation_games}")
    print(f"    ELO threshold: {evaluator.elo_threshold}")
    
except Exception as e:
    print(f"  ✗ Evaluator test failed: {e}")
    sys.exit(1)

# Test 4: Curriculum Engine
print("\n[4/5] Testing Curriculum Engine...")
try:
    from curriculum_engine import CurriculumEngine
    
    curriculum = CurriculumEngine()
    print(f"  ✓ Curriculum engine initialized")
    print(f"    LLM enabled: {curriculum.use_llm}")
    print(f"    Cache dir: {curriculum.cache_dir}")
    
    # Test position complexity scoring
    fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    scores = curriculum.score_position_complexity(fen, move_number=1, game_result="*")
    print(f"  ✓ Complexity scoring successful")
    print(f"    Tactical: {scores['tactical']:.2f}")
    print(f"    Positional: {scores['positional']:.2f}")
    print(f"    Endgame: {scores['endgame']:.2f}")
    print(f"    Overall: {scores['overall']:.2f}")
    
except Exception as e:
    print(f"  ✗ Curriculum engine test failed: {e}")
    sys.exit(1)

# Test 5: Config loading
print("\n[5/5] Testing Configuration...")
try:
    import json
    from pathlib import Path
    
    config_file = Path("/app/backend/config.json")
    if config_file.exists():
        with open(config_file, 'r') as f:
            config = json.load(f)
        
        print(f"  ✓ Config loaded successfully")
        print(f"    Self-play mode: {config['self_play']['mode']}")
        print(f"    MCTS sims: {config['self_play']['mcts_simulations']}")
        print(f"    Mixed precision: {config['training']['use_mixed_precision']}")
        print(f"    ELO threshold: {config['evaluation']['elo_threshold']}")
        print(f"    Auto scale: {config['scaling']['auto_scale']}")
        print(f"    Scale trigger: {config['scaling']['scale_trigger_games']} games")
    else:
        print(f"  ✗ Config file not found: {config_file}")
        sys.exit(1)
    
except Exception as e:
    print(f"  ✗ Config test failed: {e}")
    sys.exit(1)

print("\n" + "="*60)
print("✓ All tests passed!")
print("="*60)
print("\nNext steps:")
print("1. Run self-play: python selfplay_runner.py --mode count --target_games 10")
print("2. Check evolution state: curl http://localhost:8001/api/evolution/state")
print("3. Create curriculum plan: curl -X POST http://localhost:8001/api/curriculum/plan")
print("="*60)
