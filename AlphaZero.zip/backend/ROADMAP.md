# PGN-Integrated Curriculum Training Roadmap for AlphaZero Chess

## 🎯 Objective
Develop a **progressive training roadmap and backend pipeline** that integrates **external PGN data** (human GM + engine games) into AlphaZero's self-learning loop, accelerating growth toward **peak chess intelligence (ELO 3500+)** while maintaining the original AlphaZero reinforcement structure.

---

## 📋 System Overview

### Core Components

#### 1. **PGN Ingestion Pipeline** (`pgn_ingest.py`)
- Parses external PGN files (Human GM games + Engine games)
- Tags games by:
  - **Source**: Human / Engine / Self-Play
  - **Complexity**: Opening / Tactical / Positional / Endgame
  - **Result**: Win / Loss / Draw
- Extracts FEN sequences with full metadata
- Stores in `/backend/cache/pgn_ingest/processed/`

**Key Features:**
- Automatic complexity scoring for each position
- Game classification by dominant tactical/positional/endgame themes
- Efficient JSON storage for fast retrieval

#### 2. **Blended Training Pipeline** (`train_blended.py`)
- Combines external PGN data with self-play experience
- Implements curriculum-based weighted sampling
- Three-phase training strategy:

| Phase | Games Range | Data Ratio | Focus |
|-------|-------------|------------|-------|
| **Phase 1** | 0 - 1,000 | 70% Human / 30% Self-Play | Foundation Building |
| **Phase 2** | 1,000 - 5,000 | 50% Human / 50% Self-Play | Pattern Integration |
| **Phase 3** | 5,000+ | 20% Human / 80% Self-Play | Self-Evolution |

**Training Flow:**
```
External PGN Pool + Self-Play Pool 
  → Weighted Sampling (Phase-Based)
  → Shuffle & Blend
  → Train Network (5-10 epochs)
  → Save Checkpoint
```

#### 3. **Network Auto-Scaler** (`network_scaler.py`)
- Automatically scales network capacity at thresholds
- **Scaling Triggers:**
  - Total games >= 5,000 (first scale)
  - ELO plateau for 3+ consecutive cycles
  - Manual scale request

**Scaling Actions:**
- Increase filters: `current_filters × 1.5` (capped at 512)
- Add residual blocks: `+2 blocks` per scaling (capped at 40)
- Increase MCTS simulations: `current_sims × 1.5` (capped at 3,200)
- Transfer weights from previous network (where dimensions match)
- Update `config.json` automatically

**Example Scaling Progression:**
```
Start:    256 filters, 19 blocks,  800 MCTS sims  →
Scale 1:  384 filters, 21 blocks, 1200 MCTS sims  →
Scale 2:  512 filters, 23 blocks, 1600 MCTS sims
```

#### 4. **Enhanced IQ Tracker** (`iq_tracker_enhanced.py`)
- Tracks ELO progression toward **3500+ superhuman performance**
- Measures **evaluation consistency** (stability of position assessments)
- Monitors **evaluation stability** (variance over time)
- Calculates **growth rate** (ELO per 100 games)
- Estimates **games to target ELO**

**Metrics Tracked:**
- Current ELO
- ELO delta per evaluation
- Evaluation consistency score (0.0 - 1.0)
- Evaluation stability score (0.0 - 1.0)
- Progress to target (percentage)
- Growth rate trend

#### 5. **Evolution Metrics Tracker** (`evolution_metrics.py`)
- Comprehensive tracking of AlphaZero's evolution
- Records:
  - Phase transitions
  - Training cycles
  - Network scaling events
  - Game counts (external vs. self-play)
  - ELO progression
  - Consistency trends

**Dashboard Metrics:**
- Current curriculum phase
- Total games processed
- Data ratio (external/self-play)
- Network scaling count
- Progress to target ELO

#### 6. **Curriculum Roadmap Orchestrator** (`curriculum_roadmap.py`)
- **Master coordinator** for the complete training roadmap
- Executes full training cycles:

**Complete Cycle Flow:**
```
Step 1: Determine Curriculum Phase
   ↓
Step 2: Prepare Blended Training Data
   ├── Load External PGN Data
   └── Generate Self-Play Games
   ↓
Step 3: Train on Blended Data
   ├── Weighted Sampling
   └── Multi-Epoch Training
   ↓
Step 4: Evaluate Model
   ├── Play vs. Previous Model
   └── Calculate ELO Delta
   ↓
Step 5: Generate Reflection
   ├── Analyze Performance
   └── Identify Weaknesses
   ↓
Step 6: Check Scaling Trigger
   └── Scale Network if Needed
   ↓
Step 7: Record Evolution Metrics
   └── Update IQ Tracker
```

---

## 🔄 Training Cycle Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                     CURRICULUM ROADMAP CYCLE                    │
└─────────────────────────────────────────────────────────────────┘
                              ↓
              ┌───────────────────────────────┐
              │   Ingest External PGN Files   │
              │   (Human GM + Engine Games)   │
              └───────────────┬───────────────┘
                              ↓
              ┌───────────────────────────────┐
              │   Tag by Complexity Category  │
              │   (Opening/Tactical/Endgame)  │
              └───────────────┬───────────────┘
                              ↓
              ┌───────────────────────────────┐
              │  Determine Curriculum Phase   │
              │  (Phase 1 / 2 / 3)            │
              └───────────────┬───────────────┘
                              ↓
         ┌────────────────────┴────────────────────┐
         │                                         │
    ┌────▼─────┐                            ┌─────▼────┐
    │ External │                            │ Self-Play│
    │ PGN Data │                            │ Games    │
    └────┬─────┘                            └─────┬────┘
         │                                        │
         └────────────────┬───────────────────────┘
                          ↓
              ┌───────────────────────────────┐
              │    Blend with Weighted        │
              │    Sampling (Phase-Based)     │
              └───────────────┬───────────────┘
                              ↓
              ┌───────────────────────────────┐
              │   Train Network (5 epochs)    │
              │   Save Checkpoint             │
              └───────────────┬───────────────┘
                              ↓
              ┌───────────────────────────────┐
              │   Evaluate vs Previous Model  │
              │   Calculate ELO Delta         │
              └───────────────┬───────────────┘
                              ↓
              ┌───────────────────────────────┐
              │   Generate Reflection         │
              │   Identify Weaknesses         │
              └───────────────┬───────────────┘
                              ↓
              ┌───────────────────────────────┐
              │   Check Scaling Trigger       │
              │   Scale Network if Needed     │
              └───────────────┬───────────────┘
                              ↓
              ┌───────────────────────────────┐
              │   Record Evolution Metrics    │
              │   Update IQ Tracker           │
              └───────────────┬───────────────┘
                              ↓
                          ┌───────┐
                          │Repeat │
                          └───────┘
```

---

## 🚀 API Endpoints

### 1. **Upload External PGN**
```http
POST /api/roadmap/ingest-pgn
Content-Type: multipart/form-data

Parameters:
- file: PGN file (multipart)
- source_type: "human" or "engine"

Response:
{
  "success": true,
  "games_ingested": 50,
  "positions_extracted": 2500,
  "processed_file": "processed_20250810_120000_games.pgn.json"
}
```

### 2. **Get PGN Statistics**
```http
GET /api/roadmap/pgn-stats

Response:
{
  "success": true,
  "stats": {
    "total_games_ingested": 150,
    "human_games": 100,
    "engine_games": 50,
    "positions_extracted": 7500
  },
  "processed_files": [...]
}
```

### 3. **Get Roadmap Status**
```http
GET /api/roadmap/status

Response:
{
  "success": true,
  "roadmap": {
    "overall_progress": 42.5,
    "current_phase": 2,
    "phases": {
      "phase_1": {...},
      "phase_2": {...},
      "phase_3": {...}
    },
    "elo_status": {
      "current": 2400,
      "peak": 2450,
      "target": 3500
    }
  }
}
```

### 4. **Run Training Cycle**
```http
POST /api/roadmap/run-cycle?num_selfplay_games=25&num_external_games=50&num_epochs=5

Response:
{
  "success": true,
  "message": "Training cycle started in background",
  "config": {
    "num_selfplay_games": 25,
    "num_external_games": 50,
    "num_epochs": 5
  }
}
```

### 5. **Get IQ Tracking**
```http
GET /api/roadmap/iq-tracking

Response:
{
  "success": true,
  "current_status": {
    "current_elo": 2400,
    "target_elo": 3500,
    "progress_percent": 68.6,
    "evaluation_consistency": 0.85,
    "evaluation_stability": 0.90,
    "growth_rate_per_100_games": 25.3
  },
  "chart_data": {...}
}
```

### 6. **Get Network Capacity**
```http
GET /api/roadmap/network-capacity

Response:
{
  "success": true,
  "capacity": {
    "num_filters": 384,
    "num_residual_blocks": 21,
    "mcts_simulations": 1200,
    "scaling_count": 1,
    "estimated_parameters": 12500000
  }
}
```

### 7. **Manual Network Scaling**
```http
POST /api/roadmap/manual-scale

Response:
{
  "success": true,
  "message": "Network scaled successfully",
  "scaling_info": {
    "previous_filters": 256,
    "new_filters": 384,
    "previous_blocks": 19,
    "new_blocks": 21,
    "parameter_increase": 125.5
  },
  "new_mcts_simulations": 1200
}
```

---

## 📈 Progression to Superhuman Performance (ELO 3500+)

### Expected ELO Milestones

| Games Processed | Expected ELO | Phase | Description |
|----------------|-------------|-------|-------------|
| 0 | 1500 | Initialization | Starting baseline |
| 100 | 1700 | Phase 1 | Learning fundamentals from GM games |
| 500 | 2000 | Phase 1 | Developing tactical awareness |
| 1,000 | 2200 | Phase 1 → 2 | Strong club player level |
| 2,500 | 2500 | Phase 2 | Master level performance |
| 5,000 | 2800 | Phase 2 → 3 | Super GM level |
| 7,500 | 3000 | Phase 3 | Elite performance |
| 10,000 | 3200 | Phase 3 | Engine-level play |
| 15,000 | 3500+ | Phase 3 | **Superhuman - Target Reached** |

### IQ Growth Factors
- **Human PGN Learning**: Absorbs strategic principles from master games
- **Self-Play Innovation**: Discovers novel tactics and strategies
- **Curriculum Progression**: Gradual shift from imitation to innovation
- **Network Scaling**: Increased capacity enables deeper understanding
- **Evaluation Consistency**: Stable assessments indicate mastery

---

## 🧠 How to Reach Maximum Chess IQ

### Theoretical Upper Limit
AlphaZero's theoretical upper limit is constrained by:
1. **Network Capacity**: Larger networks can represent more complex patterns
2. **MCTS Depth**: More simulations = better position evaluation
3. **Training Data Quality**: Mix of human knowledge + self-discovery
4. **Hardware**: GPU memory and computation time

### Asymptotic Approach Strategy
To approach the theoretical upper limit:

1. **Phase 1 (Games 0-1,000)**: 
   - Foundation building from human games
   - Learn opening principles, tactical patterns
   - Build evaluation baseline

2. **Phase 2 (Games 1,000-5,000)**:
   - Balance human knowledge with self-discoveries
   - Develop unique playing style
   - Refine tactical execution

3. **Phase 3 (Games 5,000+)**:
   - Prioritize self-play for novel strategies
   - Fine-tune superhuman patterns
   - Optimize for ELO 3500+ performance

4. **Continuous Scaling**:
   - Increase network capacity every 5,000 games
   - Scale MCTS proportionally
   - Monitor evaluation consistency

5. **Reflection & Adaptation**:
   - Analyze losses for weakness patterns
   - Adjust training focus dynamically
   - Target specific position types (endgames, tactics, etc.)

### Expected Timeline (Moderate Hardware)
- **Phase 1**: ~100 hours (1,000 games)
- **Phase 2**: ~400 hours (4,000 games)
- **Phase 3**: ~1,000 hours (10,000 games)
- **Total to ELO 3500+**: ~1,500 hours (~2 months continuous training)

---

## 🛠️ Implementation Status

### ✅ Completed Components
- [x] PGN Ingestion Pipeline
- [x] Blended Training Pipeline
- [x] Network Auto-Scaler
- [x] Enhanced IQ Tracker (ELO + Consistency)
- [x] Evolution Metrics Tracker
- [x] Curriculum Roadmap Orchestrator
- [x] API Endpoints
- [x] Offline-capable architecture
- [x] Full documentation

### 📦 Deliverables
1. **Backend Modules** (6 new Python files)
2. **API Integration** (8 new endpoints in server.py)
3. **Comprehensive Roadmap Documentation** (this file)
4. **Training Cycle Diagram** (visual flow)

---

## 🎮 Usage Example

### Step 1: Upload PGN Files
```bash
curl -X POST "http://localhost:8001/api/roadmap/ingest-pgn?source_type=human" \
  -F "file=@grandmaster_games.pgn"
```

### Step 2: Check Roadmap Status
```bash
curl http://localhost:8001/api/roadmap/status
```

### Step 3: Run Training Cycle
```bash
curl -X POST "http://localhost:8001/api/roadmap/run-cycle?num_selfplay_games=25&num_external_games=50&num_epochs=5"
```

### Step 4: Monitor IQ Growth
```bash
curl http://localhost:8001/api/roadmap/iq-tracking
```

### Step 5: Check Network Capacity
```bash
curl http://localhost:8001/api/roadmap/network-capacity
```

---

## 🚨 Important Notes

### Compatibility
- **Fully offline-capable**: No remote APIs required
- **Compatible** with existing backend structure
- Uses `ActiveModel_Offline.pth` as evolving base model
- **No breaking changes** to current system

### Hardware Requirements
- **GPU**: 8-12GB VRAM (as specified)
- **CPU**: Multi-core recommended for parallel self-play
- **Storage**: ~10GB for PGN cache and models
- **RAM**: 16GB+ recommended

### Best Practices
- Upload high-quality PGN files (GM games, engine games)
- Start with Phase 1 (70% external data)
- Let the system auto-transition through phases
- Monitor evaluation consistency closely
- Allow auto-scaling when triggered
- Back up models regularly

---

## 📊 Monitoring Dashboard

### Key Metrics to Track
1. **Current ELO** (target: 3500+)
2. **Evaluation Consistency** (target: >0.9)
3. **Evaluation Stability** (target: >0.85)
4. **Growth Rate** (ELO per 100 games)
5. **Current Phase** (1, 2, or 3)
6. **Games Processed** (external vs. self-play ratio)
7. **Network Capacity** (filters, blocks, MCTS sims)
8. **Scaling Events** (count and timing)

---

## 🎯 Success Criteria

### AlphaZero is considered "Peak Intelligence" when:
- ✅ ELO >= 3500
- ✅ Evaluation Consistency >= 0.90
- ✅ Evaluation Stability >= 0.85
- ✅ Wins consistently against Stockfish at depth 30+
- ✅ Discovers novel opening novelties
- ✅ Solves complex endgames optimally

---

## 📝 Conclusion

This comprehensive roadmap enables AlphaZero to:
1. **Learn** from human grandmaster knowledge (external PGNs)
2. **Innovate** through self-play and reflection
3. **Scale** automatically as it grows
4. **Evolve** toward superhuman performance (ELO 3500+)
5. **Maintain** consistency and stability in evaluations

The system is designed to asymptotically approach the theoretical upper limit of chess intelligence given the hardware constraints, while preserving AlphaZero's self-play identity and emergent creativity.

**Next Steps:**
1. Upload your prepared PGN files (human + engine games)
2. Run the first training cycle
3. Monitor IQ growth and evolution metrics
4. Let the system auto-progress through curriculum phases
5. Reach ELO 3500+ superhuman performance! 🚀♟️

---

**Built with ❤️ for AlphaZero Chess Evolution**
