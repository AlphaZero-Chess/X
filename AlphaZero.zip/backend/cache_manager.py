"""
Cache Manager for Offline-Compatible AlphaZero Chess System
Handles reading/writing JSON cache files for analytics, settings, and collective intelligence
"""
import json
import os
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, Optional
import logging

logger = logging.getLogger(__name__)

# Cache directory
CACHE_DIR = Path(__file__).parent / "cache"
CACHE_DIR.mkdir(exist_ok=True)


def load_cache(filename: str) -> Optional[Dict[str, Any]]:
    """
    Load data from a cache file
    
    Args:
        filename: Name of the cache file (e.g., "analytics.json")
    
    Returns:
        Dictionary with cached data or None if file doesn't exist
    """
    try:
        cache_path = CACHE_DIR / filename
        if cache_path.exists():
            with open(cache_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                logger.info(f"Loaded cache from {filename}")
                return data
        else:
            logger.warning(f"Cache file {filename} not found")
            return None
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in cache file {filename}: {e}")
        return None
    except Exception as e:
        logger.error(f"Error loading cache {filename}: {e}")
        return None


def save_cache(filename: str, data: Dict[str, Any]) -> bool:
    """
    Save data to a cache file
    
    Args:
        filename: Name of the cache file (e.g., "analytics.json")
        data: Dictionary to save
    
    Returns:
        True if successful, False otherwise
    """
    try:
        cache_path = CACHE_DIR / filename
        
        # Ensure parent directory exists
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Add timestamp to data
        if 'last_update' not in data:
            data['last_update'] = datetime.now(timezone.utc).isoformat()
        
        # Write atomically by writing to temp file first
        temp_path = cache_path.with_suffix('.tmp')
        with open(temp_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, default=str)
        
        # Rename temp file to actual file (atomic operation)
        temp_path.replace(cache_path)
        
        logger.info(f"Saved cache to {filename}")
        return True
    except Exception as e:
        logger.error(f"Error saving cache {filename}: {e}")
        return False


def get_cache_path(filename: str) -> Path:
    """Get the full path to a cache file"""
    return CACHE_DIR / filename


def cache_exists(filename: str) -> bool:
    """Check if a cache file exists"""
    return (CACHE_DIR / filename).exists()


def delete_cache(filename: str) -> bool:
    """Delete a cache file"""
    try:
        cache_path = CACHE_DIR / filename
        if cache_path.exists():
            cache_path.unlink()
            logger.info(f"Deleted cache file {filename}")
            return True
        return False
    except Exception as e:
        logger.error(f"Error deleting cache {filename}: {e}")
        return False


def list_cache_files() -> list:
    """List all cache files"""
    try:
        return [f.name for f in CACHE_DIR.glob("*.json")]
    except Exception as e:
        logger.error(f"Error listing cache files: {e}")
        return []


def get_cache_size(filename: str) -> int:
    """Get cache file size in bytes"""
    try:
        cache_path = CACHE_DIR / filename
        if cache_path.exists():
            return cache_path.stat().st_size
        return 0
    except Exception as e:
        logger.error(f"Error getting cache size {filename}: {e}")
        return 0


def initialize_default_caches():
    """Initialize default cache files if they don't exist"""
    
    # Analytics cache
    if not cache_exists("analytics.json"):
        analytics_data = {
            "games_played": 0,
            "win_rate": 0.0,
            "draw_rate": 0.0,
            "loss_rate": 0.0,
            "average_depth": 0,
            "training_sessions": 0,
            "last_update": datetime.now(timezone.utc).isoformat(),
            "system_health": "initializing"
        }
        save_cache("analytics.json", analytics_data)
        logger.info("Initialized analytics.json")
    
    # Collective intelligence status cache
    if not cache_exists("collective_status.json"):
        collective_data = {
            "memory_experiences": 0,
            "trust_calibrations": 0,
            "arbitrations": 0,
            "global_strategies": 0,
            "system_health": "initializing",
            "last_update": datetime.now(timezone.utc).isoformat()
        }
        save_cache("collective_status.json", collective_data)
        logger.info("Initialized collective_status.json")
    
    # Settings cache
    if not cache_exists("settings.json"):
        settings_data = {
            "backend_port": 8001,
            "llmProvider": "claude-3-5-sonnet",
            "offlineMode": False,
            "autoSaveModels": True,
            "autoUpdate": False,
            "ethicsWatchdogEnabled": True,
            "last_update": datetime.now(timezone.utc).isoformat()
        }
        save_cache("settings.json", settings_data)
        logger.info("Initialized settings.json")


# Initialize defaults on module import
initialize_default_caches()
