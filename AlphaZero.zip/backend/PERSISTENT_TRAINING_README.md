# Phase 5: Persistent Distributed Training & Replay Streaming

## Overview

Phase 5 adds **persistent, resumable training** with automatic checkpoint management, durable replay buffers, and live metric streaming. Training jobs can be stopped, resumed, and monitored in real-time through an intuitive web interface.

## Key Features

### 1. **Persistent Training Manager** (`persistent_training_manager.py`)
- ✅ Resumable training jobs with automatic state persistence
- ✅ Configurable checkpoint intervals (default: every 5 minutes)
- ✅ Checkpoint retention policy (default: keep last 10)
- ✅ Progress tracking with ETA calculation
- ✅ Live metric streaming via WebSocket
- ✅ Integration with distributed TPU grid
- ✅ Self-play data generation

### 2. **Checkpoint Storage** (`checkpoint_storage.py`)
- ✅ **Local storage** (default): `/app/backend/cache/checkpoints`
- ✅ **S3-compatible storage**: AWS S3, MinIO, etc.
- ✅ Atomic checkpoint saves with rollback
- ✅ Automatic cleanup of old checkpoints
- ✅ Metadata indexing for fast lookup
- ✅ Model + optimizer state persistence

### 3. **Replay Buffer Service** (`replay_buffer_service.py`)
- ✅ **Sharded architecture** for parallel access (8 shards by default)
- ✅ **Eviction policies**: FIFO, Random, Priority-based
- ✅ **Durable storage** with MongoDB metadata + blob storage
- ✅ Efficient batch sampling
- ✅ Priority-based sampling support
- ✅ Shard-level statistics and monitoring

### 4. **REST API Endpoints**
All endpoints are prefixed with `/api/cloud/training/`

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/start-persistent` | POST | Start new training job |
| `/stop` | POST | Stop running job |
| `/restore` | POST | Restore from checkpoint |
| `/status/{job_id}` | GET | Get job details |
| `/jobs` | GET | List all jobs |
| `/checkpoints/{job_id}` | GET | List checkpoints |
| `/replay-buffer/stats` | GET | Replay buffer stats |
| `/live` | WebSocket | Live training updates |

### 5. **Frontend Components**
- ✅ `PersistentTrainingPanel.jsx` - Main control panel
- ✅ `CheckpointBrowser.jsx` - Browse and restore checkpoints
- ✅ `ReplayPreview.jsx` - Preview replay buffer contents
- ✅ Real-time progress tracking
- ✅ Live WebSocket updates every 2 seconds

---

## Quick Start

### 1. Start a Training Job (API)

```bash
curl -X POST http://localhost:8001/api/cloud/training/start-persistent \
  -H "Content-Type: application/json" \
  -d '{
    "job_name": "My Training Run",
    "num_epochs": 10,
    "batch_size": 256,
    "learning_rate": 0.001,
    "checkpoint_interval_minutes": 5,
    "max_checkpoints_retained": 10,
    "num_tpus": 100,
    "enable_self_play": true
  }'
```

**Response:**
```json
{
  "success": true,
  "job_id": "job_a1b2c3d4e5f6",
  "job_name": "My Training Run",
  "status": "running",
  "message": "Persistent training job started successfully"
}
```

### 2. Monitor Job Status

```bash
curl http://localhost:8001/api/cloud/training/status/job_a1b2c3d4e5f6
```

**Response:**
```json
{
  "success": true,
  "job": {
    "job_id": "job_a1b2c3d4e5f6",
    "job_name": "My Training Run",
    "status": "running",
    "current_epoch": 3,
    "total_epochs": 10,
    "current_loss": 0.423,
    "progress_percent": 30.0,
    "estimated_completion_at": "2025-01-15T14:30:00Z"
  },
  "progress_percent": 30.0,
  "checkpoints": [
    {
      "checkpoint_id": "ckpt_job_a1b2_2_1705318800",
      "epoch": 2,
      "loss": 0.456,
      "timestamp": "2025-01-15T13:00:00Z",
      "size_mb": 45.23
    }
  ],
  "replay_buffer": {
    "total_size": 1250,
    "utilization": 0.15,
    "num_shards": 8
  }
}
```

### 3. Stop a Job

```bash
curl -X POST http://localhost:8001/api/cloud/training/stop \
  -H "Content-Type: application/json" \
  -d '{"job_id": "job_a1b2c3d4e5f6"}'
```

### 4. Restore from Checkpoint

```bash
# Restore from latest checkpoint
curl -X POST http://localhost:8001/api/cloud/training/restore \
  -H "Content-Type: application/json" \
  -d '{"job_id": "job_a1b2c3d4e5f6"}'

# Restore from specific checkpoint
curl -X POST http://localhost:8001/api/cloud/training/restore \
  -H "Content-Type: application/json" \
  -d '{
    "job_id": "job_a1b2c3d4e5f6",
    "checkpoint_id": "ckpt_job_a1b2_2_1705318800"
  }'
```

---

## Storage Configuration

### Local Storage (Default)

No configuration required. Checkpoints are stored in:
```
/app/backend/cache/checkpoints/
├── {job_id}/
│   └── {checkpoint_id}/
│       ├── model.pt
│       └── optimizer.pt
└── metadata/
    └── {checkpoint_id}.json
```

### S3 Storage Setup

#### 1. Set Environment Variables

Add to `/app/backend/.env`:

```bash
# S3 Configuration
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
S3_BUCKET=your-checkpoint-bucket
AWS_REGION=us-east-1  # Optional, defaults to us-east-1

# For MinIO or custom S3-compatible service
S3_ENDPOINT_URL=https://minio.example.com  # Optional
```

#### 2. Install boto3

```bash
cd /app/backend
pip install boto3
```

#### 3. Auto-Detection

The system automatically detects S3 configuration and switches to S3 storage if:
- `S3_BUCKET` is set
- `AWS_ACCESS_KEY_ID` is set

#### 4. Manual Storage Mode

```python
from checkpoint_storage import get_checkpoint_storage

# Force local mode
storage = get_checkpoint_storage(storage_mode='local')

# Force S3 mode
storage = get_checkpoint_storage(storage_mode='s3')

# Auto-detect (default)
storage = get_checkpoint_storage(storage_mode='auto')
```

---

## Configuration Options

### Training Job Parameters

| Parameter | Type | Default | Range | Description |
|-----------|------|---------|-------|-------------|
| `job_name` | string | required | - | Name for the training job |
| `num_epochs` | int | 10 | 1-1000 | Number of training epochs |
| `batch_size` | int | 256 | 32-1024 | Training batch size |
| `learning_rate` | float | 0.001 | 0.0001-0.1 | Learning rate |
| `checkpoint_interval_minutes` | int | 5 | 1-60 | Minutes between checkpoints |
| `max_checkpoints_retained` | int | 10 | 1-50 | Max checkpoints to keep |
| `num_tpus` | int | 100 | 10-1000 | Number of TPUs to allocate |
| `enable_self_play` | bool | true | - | Generate self-play data |
| `resume_from_checkpoint` | string | null | - | Checkpoint ID to resume from |

### Replay Buffer Configuration

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `num_shards` | int | 8 | Number of buffer shards |
| `shard_size` | int | 10000 | Max samples per shard |
| `eviction_policy` | string | 'fifo' | 'fifo', 'random', or 'priority' |
| `enable_persistence` | bool | true | Persist buffer to disk |

---

## WebSocket Live Updates

### Connection

```javascript
const ws = new WebSocket('ws://localhost:8001/api/cloud/training/live');

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  
  if (data.type === 'training_update') {
    console.log(`Job ${data.job_id}: Epoch ${data.epoch}, Loss ${data.loss}`);
  }
};
```

### Update Format

```json
{
  "type": "training_update",
  "job_id": "job_a1b2c3d4e5f6",
  "status": "running",
  "epoch": 5,
  "loss": 0.312,
  "progress_percent": 50.0,
  "timestamp": "2025-01-15T14:00:00Z"
}
```

### Update Frequency

- **Default**: Every 2 seconds
- Sent when:
  - Epoch completes
  - Checkpoint is saved
  - Job status changes
  - Loss metric updates

---

## Frontend Usage

### 1. Navigate to Persistent Training Tab

Open the web UI at `http://localhost:3000` and click the **💾 Persistent** tab.

### 2. Start a Training Job

Fill in the form:
- **Job Name**: e.g., "Training Run 1"
- **Epochs**: 10
- **Batch Size**: 256
- **Learning Rate**: 0.001
- **Checkpoint Interval**: 5 minutes
- **TPUs**: 100
- **Enable Self-Play**: ✅

Click **Start Training Job**.

### 3. Monitor Progress

- See real-time progress bar
- View current epoch, loss, checkpoint count
- Live updates via WebSocket (🟢 Live indicator)

### 4. Browse Checkpoints

- Select a job to view its checkpoints
- See epoch, loss, size, and timestamp for each checkpoint
- Click **Restore** to resume from any checkpoint

### 5. Preview Replay Buffer

- View buffer statistics (size, utilization, shards)
- See sample replay tuples
- Monitor shard distribution

---

## Testing

### Run Unit Tests

```bash
cd /app/backend
python test_persistent_training.py
```

**Output:**
```
============================================================
PHASE 5: PERSISTENT TRAINING TESTS
============================================================

📋 Test Suite: Checkpoint Storage
------------------------------------------------------------
✅ Checkpoint saved: test_ckpt_1, size: 4328 bytes
✅ Checkpoint loaded: test_ckpt_2
✅ Listed 3 checkpoints
✅ Cleaned up 5 old checkpoints, 10 retained

📋 Test Suite: Replay Buffer Service
------------------------------------------------------------
✅ Added 50 replay tuples
✅ Sampled batch of 32 tuples
✅ Data distributed across 4 shards
✅ Buffer stats: 50 samples, 12.50% utilization

📋 Test Suite: Persistent Training Manager
------------------------------------------------------------
✅ Job created: Test Job
✅ Job state persisted and loaded successfully

============================================================
✅ ALL TESTS PASSED
============================================================
```

### Run Demo

```bash
cd /app/backend
python demo_persistent_training.py
```

---

## Architecture

### Training Loop Flow

```
┌─────────────────────────────────────────────────────┐
│  Persistent Training Manager                        │
├─────────────────────────────────────────────────────┤
│  1. Start Job                                       │
│     ↓                                               │
│  2. Generate Self-Play Data (optional)              │
│     ↓                                               │
│  3. Add to Replay Buffer (sharded)                  │
│     ↓                                               │
│  4. Sample Training Batch (priority/uniform)        │
│     ↓                                               │
│  5. Train on Distributed Grid (TPUs)                │
│     ↓                                               │
│  6. Update Metrics & Broadcast (WebSocket)          │
│     ↓                                               │
│  7. Save Checkpoint (every N minutes)               │
│     ↓                                               │
│  8. Cleanup Old Checkpoints (retention policy)      │
│     ↓                                               │
│  9. Loop back to step 2                             │
└─────────────────────────────────────────────────────┘
```

### Checkpoint Storage Architecture

```
┌──────────────────────────────────────────┐
│  CheckpointStorageManager (auto-detect)  │
└───────────────┬──────────────────────────┘
                │
        ┌───────┴────────┐
        │                │
┌───────▼──────┐  ┌──────▼──────┐
│ LocalStorage │  │  S3Storage  │
└──────────────┘  └─────────────┘
        │                │
    ┌───▼───┐       ┌────▼────┐
    │ Disk  │       │   S3    │
    └───────┘       └─────────┘
```

### Replay Buffer Sharding

```
┌─────────────────────────────────────────┐
│  ReplayBufferService (8 shards)         │
├─────────────────────────────────────────┤
│  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐│
│  │Shard0│  │Shard1│  │Shard2│  │Shard3││
│  │10K   │  │10K   │  │10K   │  │10K   ││
│  └──────┘  └──────┘  └──────┘  └──────┘│
│  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐│
│  │Shard4│  │Shard5│  │Shard6│  │Shard7││
│  │10K   │  │10K   │  │10K   │  │10K   ││
│  └──────┘  └──────┘  └──────┘  └──────┘│
├─────────────────────────────────────────┤
│  Total Capacity: 80,000 samples         │
│  Consistent Hashing for Shard Selection │
└─────────────────────────────────────────┘
```

---

## Troubleshooting

### Issue: Checkpoints not saving

**Symptoms:**
- No checkpoint files in storage
- Error messages about failed saves

**Solutions:**
1. Check disk space: `df -h /app/backend/cache`
2. Verify permissions: `ls -la /app/backend/cache/checkpoints`
3. Check backend logs for storage errors
4. For S3: Verify credentials and bucket permissions

### Issue: WebSocket connection failing

**Symptoms:**
- "🔴 Disconnected" indicator
- No live updates in UI

**Solutions:**
1. Check backend is running: `curl http://localhost:8001/api/`
2. Verify WebSocket endpoint: `ws://localhost:8001/api/cloud/training/live`
3. Check for CORS/proxy issues
4. Inspect browser console for errors

### Issue: Replay buffer not sampling

**Symptoms:**
- Empty batches
- "No replay samples available"

**Solutions:**
1. Ensure training data is being added
2. Check buffer stats: `curl http://localhost:8001/api/cloud/training/replay-buffer/stats`
3. Verify self-play is enabled
4. Wait for initial data generation

### Issue: Job not resuming from checkpoint

**Symptoms:**
- Restore fails
- Job starts from epoch 0

**Solutions:**
1. Verify checkpoint exists: `GET /api/cloud/training/checkpoints/{job_id}`
2. Check checkpoint metadata is valid
3. Ensure checkpoint wasn't corrupted during save
4. Try restoring from an earlier checkpoint

---

## Performance Optimization

### Checkpoint Size Reduction

1. **Use mixed precision training** (FP16):
   - Reduces checkpoint size by ~50%
   - Faster save/load times

2. **Selective state saving**:
   - Save only necessary optimizer states
   - Compress state dictionaries

3. **Incremental checkpoints**:
   - Save only changed parameters
   - Use delta compression

### Replay Buffer Tuning

1. **Shard count**:
   - More shards = better parallelism
   - Recommended: 8-16 shards for 100K+ samples

2. **Eviction policy**:
   - `fifo`: Simplest, good for most cases
   - `priority`: Better for curriculum learning
   - `random`: Uniform distribution

3. **Sampling strategy**:
   - Uniform: Fast, unbiased
   - Priority-based: Better for hard samples

---

## API Reference

### Start Training Job

**POST** `/api/cloud/training/start-persistent`

**Request Body:**
```json
{
  "job_name": "string",
  "num_epochs": 10,
  "batch_size": 256,
  "learning_rate": 0.001,
  "checkpoint_interval_minutes": 5,
  "max_checkpoints_retained": 10,
  "num_tpus": 100,
  "enable_self_play": true,
  "resume_from_checkpoint": "ckpt_..." // optional
}
```

**Response:**
```json
{
  "success": true,
  "job_id": "job_...",
  "job_name": "...",
  "status": "running",
  "message": "..."
}
```

### Get Job Status

**GET** `/api/cloud/training/status/{job_id}`

**Response:**
```json
{
  "success": true,
  "job": { /* job state */ },
  "progress_percent": 45.5,
  "checkpoints": [ /* checkpoint list */ ],
  "replay_buffer": { /* buffer stats */ },
  "storage_info": { /* storage backend */ }
}
```

### List All Jobs

**GET** `/api/cloud/training/jobs`

**Response:**
```json
{
  "success": true,
  "jobs": [ /* job summaries */ ],
  "total_jobs": 5
}
```

---

## Roadmap

### Completed ✅
- [x] Checkpoint storage (local + S3)
- [x] Replay buffer with sharding
- [x] Persistent training manager
- [x] REST API endpoints
- [x] WebSocket live updates
- [x] Frontend components
- [x] Unit tests and demo

### Future Enhancements 🚀
- [ ] Distributed checkpoint sharding
- [ ] Checkpoint compression (zstd)
- [ ] Multi-node replay buffer
- [ ] Advanced eviction policies (LFU, LRU)
- [ ] Checkpoint versioning and branching
- [ ] Training job scheduling and queueing
- [ ] Resource-aware autoscaling
- [ ] Fault-tolerant checkpoint saving
- [ ] Incremental checkpoint diffs

---

## Support

For issues or questions:
1. Check logs: `/var/log/supervisor/backend.*.log`
2. Run tests: `python test_persistent_training.py`
3. Run demo: `python demo_persistent_training.py`
4. Check API health: `curl http://localhost:8001/api/`

---

## License

Part of the AlphaZero Chess project.
