"""
Unit tests for Persistent Training System (Phase 5)
Tests checkpoint storage, replay buffer, and training manager
"""

import os
import sys
import pytest
import tempfile
import shutil
import asyncio
from pathlib import Path

# Add backend to path
sys.path.insert(0, '/app/backend')

from checkpoint_storage import LocalCheckpointStorage, CheckpointStorageManager
from replay_buffer_service import ReplayBufferService, ReplayTuple
from persistent_training_manager import PersistentTrainingManager, TrainingJobConfig, JobStatus


class TestCheckpointStorage:
    """Test checkpoint storage functionality"""
    
    def setup_method(self):
        """Setup test environment"""
        self.test_dir = tempfile.mkdtemp()
        self.storage = LocalCheckpointStorage(base_dir=self.test_dir)
    
    def teardown_method(self):
        """Cleanup test environment"""
        if Path(self.test_dir).exists():
            shutil.rmtree(self.test_dir)
    
    def test_save_checkpoint(self):
        """Test saving a checkpoint"""
        import torch
        
        # Create dummy model state
        model_state = {
            'layer1': torch.randn(10, 10),
            'layer2': torch.randn(5, 5)
        }
        
        metadata = self.storage.save_checkpoint(
            checkpoint_id='test_ckpt_1',
            job_id='test_job',
            model_state=model_state,
            optimizer_state=None,
            epoch=5,
            iteration=100,
            loss=0.5,
            metrics={'accuracy': 0.95}
        )
        
        assert metadata is not None
        assert metadata.checkpoint_id == 'test_ckpt_1'
        assert metadata.job_id == 'test_job'
        assert metadata.epoch == 5
        assert metadata.loss == 0.5
        assert metadata.size_bytes > 0
        print(f"✅ Checkpoint saved: {metadata.checkpoint_id}, size: {metadata.size_bytes} bytes")
    
    def test_load_checkpoint(self):
        """Test loading a checkpoint"""
        import torch
        
        # Save checkpoint first
        model_state = {'weights': torch.randn(5, 5)}
        
        self.storage.save_checkpoint(
            checkpoint_id='test_ckpt_2',
            job_id='test_job',
            model_state=model_state,
            optimizer_state=None,
            epoch=3,
            iteration=50,
            loss=0.3
        )
        
        # Load checkpoint
        checkpoint = self.storage.load_checkpoint('test_ckpt_2')
        
        assert checkpoint is not None
        assert 'model_state' in checkpoint
        assert 'metadata' in checkpoint
        assert checkpoint['metadata']['epoch'] == 3
        print(f"✅ Checkpoint loaded: {checkpoint['metadata']['checkpoint_id']}")
    
    def test_list_checkpoints(self):
        """Test listing checkpoints"""
        import torch
        
        # Create multiple checkpoints
        for i in range(3):
            self.storage.save_checkpoint(
                checkpoint_id=f'ckpt_{i}',
                job_id='test_job',
                model_state={'data': torch.randn(2, 2)},
                optimizer_state=None,
                epoch=i,
                iteration=i*10,
                loss=0.5 - i*0.1
            )
        
        checkpoints = self.storage.list_checkpoints(job_id='test_job')
        
        assert len(checkpoints) == 3
        # Should be sorted by timestamp (newest first)
        assert checkpoints[0].epoch >= checkpoints[-1].epoch
        print(f"✅ Listed {len(checkpoints)} checkpoints")
    
    def test_cleanup_old_checkpoints(self):
        """Test checkpoint cleanup/retention policy"""
        import torch
        
        # Create more checkpoints than retention limit
        for i in range(15):
            self.storage.save_checkpoint(
                checkpoint_id=f'ckpt_{i}',
                job_id='test_job',
                model_state={'data': torch.randn(2, 2)},
                optimizer_state=None,
                epoch=i,
                iteration=i*10,
                loss=0.5
            )
        
        # Cleanup, keeping only last 10
        deleted = self.storage.cleanup_old_checkpoints(job_id='test_job', keep_last=10)
        
        assert deleted == 5
        
        remaining = self.storage.list_checkpoints(job_id='test_job')
        assert len(remaining) == 10
        print(f"✅ Cleaned up {deleted} old checkpoints, {len(remaining)} retained")


class TestReplayBufferService:
    """Test replay buffer functionality"""
    
    def setup_method(self):
        """Setup test environment"""
        self.test_dir = tempfile.mkdtemp()
        self.buffer = ReplayBufferService(
            num_shards=4,
            shard_size=100,
            storage_dir=self.test_dir,
            enable_persistence=True
        )
    
    def teardown_method(self):
        """Cleanup test environment"""
        if Path(self.test_dir).exists():
            shutil.rmtree(self.test_dir)
    
    def test_add_replay_tuples(self):
        """Test adding replay tuples"""
        tuples = [
            {
                'state': [1, 2, 3],
                'policy': [0.1, 0.9],
                'value': 0.5,
                'priority': 1.0
            }
            for _ in range(50)
        ]
        
        self.buffer.add_replay_tuples(tuples, game_id='test_game_1')
        
        stats = self.buffer.get_buffer_stats()
        
        assert stats['total_size'] == 50
        assert stats['total_inserted'] == 50
        print(f"✅ Added {stats['total_size']} replay tuples")
    
    def test_sample_batch(self):
        """Test sampling from replay buffer"""
        # Add some tuples
        tuples = [
            {
                'state': [i],
                'policy': [i/100],
                'value': i/100,
                'priority': 1.0 + i*0.1
            }
            for i in range(100)
        ]
        
        self.buffer.add_replay_tuples(tuples, game_id='test_game_2')
        
        # Sample batch
        batch = self.buffer.sample_batch(batch_size=32, use_priority=False)
        
        assert len(batch) == 32
        assert all('state' in item for item in batch)
        print(f"✅ Sampled batch of {len(batch)} tuples")
    
    def test_sharding(self):
        """Test that tuples are distributed across shards"""
        # Add many tuples
        tuples = [
            {
                'state': [i],
                'policy': [i/100],
                'value': i/100,
                'priority': 1.0
            }
            for i in range(200)
        ]
        
        self.buffer.add_replay_tuples(tuples, game_id='test_game_3')
        
        stats = self.buffer.get_buffer_stats()
        shard_stats = stats['shard_stats']
        
        # Check that multiple shards have data
        non_empty_shards = sum(1 for s in shard_stats if s['size'] > 0)
        
        assert non_empty_shards > 1, "Tuples should be distributed across shards"
        print(f"✅ Data distributed across {non_empty_shards} shards")
    
    def test_buffer_stats(self):
        """Test buffer statistics"""
        tuples = [
            {
                'state': [i],
                'policy': [i/100],
                'value': i/100,
                'priority': 1.0
            }
            for i in range(50)
        ]
        
        self.buffer.add_replay_tuples(tuples, game_id='test_game_4')
        
        stats = self.buffer.get_buffer_stats()
        
        assert 'num_shards' in stats
        assert 'total_size' in stats
        assert 'utilization' in stats
        assert stats['total_size'] == 50
        print(f"✅ Buffer stats: {stats['total_size']} samples, {stats['utilization']:.2%} utilization")


class TestPersistentTrainingManager:
    """Test persistent training manager"""
    
    def setup_method(self):
        """Setup test environment"""
        self.test_dir = tempfile.mkdtemp()
        # Manager will be created in tests
    
    def teardown_method(self):
        """Cleanup test environment"""
        if Path(self.test_dir).exists():
            shutil.rmtree(self.test_dir)
    
    @pytest.mark.asyncio
    async def test_job_creation(self):
        """Test creating a training job"""
        from checkpoint_storage import CheckpointStorageManager
        from replay_buffer_service import ReplayBufferService
        
        # Create dependencies with test directories
        checkpoint_storage = CheckpointStorageManager(storage_mode='local')
        replay_buffer = ReplayBufferService(num_shards=2, shard_size=100, enable_persistence=False)
        
        # Mock training and selfplay managers (not actually running)
        manager = PersistentTrainingManager(
            checkpoint_storage=checkpoint_storage,
            replay_buffer=replay_buffer,
            training_manager=None,  # Would need mock
            selfplay_manager=None   # Would need mock
        )
        
        # Create job state (don't start actual training)
        from persistent_training_manager import TrainingJobState
        job_state = TrainingJobState(
            job_id='test_job_1',
            job_name='Test Job',
            status=JobStatus.PENDING,
            config=TrainingJobConfig(
                job_id='test_job_1',
                job_name='Test Job',
                num_epochs=5,
                batch_size=64,
                learning_rate=0.001
            )
        )
        
        manager.jobs['test_job_1'] = job_state
        
        # Test job listing
        jobs = manager.list_jobs()
        
        assert len(jobs) == 1
        assert jobs[0]['job_id'] == 'test_job_1'
        assert jobs[0]['job_name'] == 'Test Job'
        print(f"✅ Job created: {jobs[0]['job_name']}")
    
    def test_job_state_persistence(self):
        """Test job state saving and loading"""
        from checkpoint_storage import CheckpointStorageManager
        from replay_buffer_service import ReplayBufferService
        from persistent_training_manager import TrainingJobState
        
        checkpoint_storage = CheckpointStorageManager(storage_mode='local')
        replay_buffer = ReplayBufferService(num_shards=2, shard_size=100, enable_persistence=False)
        
        # Create manager with custom state dir
        state_dir = Path(self.test_dir) / "job_states"
        state_dir.mkdir(exist_ok=True)
        
        manager = PersistentTrainingManager(
            checkpoint_storage=checkpoint_storage,
            replay_buffer=replay_buffer,
            training_manager=None,
            selfplay_manager=None
        )
        manager.state_dir = state_dir
        
        # Create a job
        job_state = TrainingJobState(
            job_id='persist_test',
            job_name='Persistence Test',
            status=JobStatus.RUNNING,
            config=TrainingJobConfig(
                job_id='persist_test',
                job_name='Persistence Test',
                num_epochs=10,
                batch_size=128,
                learning_rate=0.002
            ),
            current_epoch=3,
            current_loss=0.25
        )
        
        manager.jobs['persist_test'] = job_state
        manager._save_job_state(job_state)
        
        # Check that state file was created
        state_file = state_dir / "persist_test.json"
        assert state_file.exists()
        
        # Load state in new manager
        new_manager = PersistentTrainingManager(
            checkpoint_storage=checkpoint_storage,
            replay_buffer=replay_buffer,
            training_manager=None,
            selfplay_manager=None
        )
        new_manager.state_dir = state_dir
        new_manager._load_job_states()
        
        # Verify state was loaded
        assert 'persist_test' in new_manager.jobs
        loaded_job = new_manager.jobs['persist_test']
        assert loaded_job.job_name == 'Persistence Test'
        assert loaded_job.current_epoch == 3
        print(f"✅ Job state persisted and loaded successfully")


def run_all_tests():
    """Run all tests"""
    print("\n" + "="*60)
    print("PHASE 5: PERSISTENT TRAINING TESTS")
    print("="*60 + "\n")
    
    print("📋 Test Suite: Checkpoint Storage")
    print("-" * 60)
    test_checkpoint = TestCheckpointStorage()
    
    test_checkpoint.setup_method()
    test_checkpoint.test_save_checkpoint()
    test_checkpoint.teardown_method()
    
    test_checkpoint.setup_method()
    test_checkpoint.test_load_checkpoint()
    test_checkpoint.teardown_method()
    
    test_checkpoint.setup_method()
    test_checkpoint.test_list_checkpoints()
    test_checkpoint.teardown_method()
    
    test_checkpoint.setup_method()
    test_checkpoint.test_cleanup_old_checkpoints()
    test_checkpoint.teardown_method()
    
    print("\n📋 Test Suite: Replay Buffer Service")
    print("-" * 60)
    test_replay = TestReplayBufferService()
    
    test_replay.setup_method()
    test_replay.test_add_replay_tuples()
    test_replay.teardown_method()
    
    test_replay.setup_method()
    test_replay.test_sample_batch()
    test_replay.teardown_method()
    
    test_replay.setup_method()
    test_replay.test_sharding()
    test_replay.teardown_method()
    
    test_replay.setup_method()
    test_replay.test_buffer_stats()
    test_replay.teardown_method()
    
    print("\n📋 Test Suite: Persistent Training Manager")
    print("-" * 60)
    test_manager = TestPersistentTrainingManager()
    
    test_manager.setup_method()
    asyncio.run(test_manager.test_job_creation())
    test_manager.teardown_method()
    
    test_manager.setup_method()
    test_manager.test_job_state_persistence()
    test_manager.teardown_method()
    
    print("\n" + "="*60)
    print("✅ ALL TESTS PASSED")
    print("="*60)


if __name__ == '__main__':
    run_all_tests()
