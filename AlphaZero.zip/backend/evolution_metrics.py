"""
Evolution Metrics Tracker
Comprehensive tracking of AlphaZero's evolution toward peak chess intelligence
"""
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


class EvolutionMetricsTracker:
    """
    Track comprehensive evolution metrics for AlphaZero
    Monitors progression through curriculum phases toward ELO 3500+
    """
    
    def __init__(self, cache_dir: str = "/app/backend/cache"):
        self.cache_dir = Path(cache_dir)
        self.metrics_file = self.cache_dir / "evolution_metrics.json"
        
        self.metrics = {
            'phases': [],
            'current_phase': 1,
            'total_games_processed': 0,
            'external_pgn_games': 0,
            'selfplay_games': 0,
            'network_scalings': 0,
            'peak_elo': 1500,
            'current_elo': 1500,
            'target_elo': 3500,
            'started_at': datetime.now(timezone.utc).isoformat(),
            'last_updated': datetime.now(timezone.utc).isoformat()
        }
        
        self.load_metrics()
        logger.info("Evolution Metrics Tracker initialized")
    
    def record_phase_transition(
        self,
        from_phase: int,
        to_phase: int,
        total_games: int,
        elo_at_transition: float
    ):
        """Record transition between curriculum phases"""
        transition = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'from_phase': from_phase,
            'to_phase': to_phase,
            'total_games': total_games,
            'elo': elo_at_transition
        }
        
        if 'phase_transitions' not in self.metrics:
            self.metrics['phase_transitions'] = []
        
        self.metrics['phase_transitions'].append(transition)
        self.metrics['current_phase'] = to_phase
        self.metrics['last_updated'] = transition['timestamp']
        
        self.save_metrics()
        
        logger.info(f"Phase transition recorded: {from_phase} → {to_phase} "
                   f"(Games: {total_games}, ELO: {elo_at_transition:.1f})")
    
    def record_training_cycle(
        self,
        cycle_data: Dict
    ):
        """
        Record a complete training cycle
        
        cycle_data should include:
        - external_games_used
        - selfplay_games_used
        - blended_positions
        - epochs
        - avg_loss
        - elo_before
        - elo_after
        - consistency_score
        """
        cycle = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            **cycle_data
        }
        
        if 'training_cycles' not in self.metrics:
            self.metrics['training_cycles'] = []
        
        self.metrics['training_cycles'].append(cycle)
        
        # Update totals
        self.metrics['total_games_processed'] += cycle_data.get('external_games_used', 0) + cycle_data.get('selfplay_games_used', 0)
        self.metrics['external_pgn_games'] += cycle_data.get('external_games_used', 0)
        self.metrics['selfplay_games'] += cycle_data.get('selfplay_games_used', 0)
        
        # Update ELO
        elo_after = cycle_data.get('elo_after', self.metrics['current_elo'])
        self.metrics['current_elo'] = elo_after
        if elo_after > self.metrics['peak_elo']:
            self.metrics['peak_elo'] = elo_after
        
        self.metrics['last_updated'] = cycle['timestamp']
        
        self.save_metrics()
        
        logger.info(f"Training cycle recorded: ELO {elo_after:.1f}, "
                   f"Total games: {self.metrics['total_games_processed']}")
    
    def record_network_scaling(
        self,
        scaling_info: Dict
    ):
        """Record network scaling event"""
        scaling = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            **scaling_info
        }
        
        if 'scaling_events' not in self.metrics:
            self.metrics['scaling_events'] = []
        
        self.metrics['scaling_events'].append(scaling)
        self.metrics['network_scalings'] += 1
        self.metrics['last_updated'] = scaling['timestamp']
        
        self.save_metrics()
        
        logger.info(f"Network scaling recorded: {scaling.get('previous_filters')} → {scaling.get('new_filters')} filters")
    
    def get_current_metrics(self) -> Dict:
        """Get current evolution metrics"""
        progress = (self.metrics['current_elo'] / self.metrics['target_elo']) * 100
        
        return {
            'current_phase': self.metrics['current_phase'],
            'total_games_processed': self.metrics['total_games_processed'],
            'external_pgn_games': self.metrics['external_pgn_games'],
            'selfplay_games': self.metrics['selfplay_games'],
            'data_ratio': {
                'external': self.metrics['external_pgn_games'] / max(1, self.metrics['total_games_processed']),
                'selfplay': self.metrics['selfplay_games'] / max(1, self.metrics['total_games_processed'])
            },
            'current_elo': self.metrics['current_elo'],
            'peak_elo': self.metrics['peak_elo'],
            'target_elo': self.metrics['target_elo'],
            'progress_to_target': progress,
            'network_scalings': self.metrics['network_scalings'],
            'started_at': self.metrics['started_at'],
            'last_updated': self.metrics['last_updated']
        }
    
    def get_phase_summary(self, phase: int) -> Dict:
        """Get summary of a specific curriculum phase"""
        if 'training_cycles' not in self.metrics:
            return {'error': 'No training cycles recorded'}
        
        phase_cycles = [c for c in self.metrics['training_cycles'] 
                       if c.get('curriculum_phase') == phase]
        
        if not phase_cycles:
            return {'phase': phase, 'cycles': 0, 'status': 'not_started'}
        
        elos = [c.get('elo_after', 0) for c in phase_cycles if c.get('elo_after')]
        
        return {
            'phase': phase,
            'cycles': len(phase_cycles),
            'total_games': sum(c.get('external_games_used', 0) + c.get('selfplay_games_used', 0) 
                             for c in phase_cycles),
            'starting_elo': elos[0] if elos else 0,
            'ending_elo': elos[-1] if elos else 0,
            'elo_gain': (elos[-1] - elos[0]) if len(elos) > 1 else 0,
            'avg_consistency': sum(c.get('consistency_score', 0) for c in phase_cycles) / len(phase_cycles),
            'status': 'completed' if self.metrics['current_phase'] > phase else 'in_progress'
        }
    
    def get_training_progression(self) -> List[Dict]:
        """Get training progression data for visualization"""
        if 'training_cycles' not in self.metrics:
            return []
        
        progression = []
        cumulative_games = 0
        
        for cycle in self.metrics['training_cycles']:
            cumulative_games += cycle.get('external_games_used', 0) + cycle.get('selfplay_games_used', 0)
            
            progression.append({
                'timestamp': cycle.get('timestamp'),
                'cumulative_games': cumulative_games,
                'elo': cycle.get('elo_after', 0),
                'phase': cycle.get('curriculum_phase', 1),
                'consistency': cycle.get('consistency_score', 0)
            })
        
        return progression
    
    def get_roadmap_status(self) -> Dict:
        """Get overall roadmap status toward peak intelligence"""
        phase_1_summary = self.get_phase_summary(1)
        phase_2_summary = self.get_phase_summary(2)
        phase_3_summary = self.get_phase_summary(3)
        
        current_metrics = self.get_current_metrics()
        
        return {
            'overall_progress': current_metrics['progress_to_target'],
            'current_phase': current_metrics['current_phase'],
            'phases': {
                'phase_1': {
                    **phase_1_summary,
                    'description': '70% Human PGNs / 30% Self-Play - Foundation Building',
                    'target_games': 1000
                },
                'phase_2': {
                    **phase_2_summary,
                    'description': '50% Human PGNs / 50% Self-Play - Pattern Integration',
                    'target_games': 5000
                },
                'phase_3': {
                    **phase_3_summary,
                    'description': '20% Human PGNs / 80% Self-Play - Self-Evolution',
                    'target_games': 10000
                }
            },
            'scaling_status': {
                'total_scalings': current_metrics['network_scalings'],
                'next_scaling_at': 5000 * (current_metrics['network_scalings'] + 1)
            },
            'elo_status': {
                'current': current_metrics['current_elo'],
                'peak': current_metrics['peak_elo'],
                'target': current_metrics['target_elo'],
                'progress_percent': current_metrics['progress_to_target']
            }
        }
    
    def save_metrics(self):
        """Save metrics to disk"""
        try:
            with open(self.metrics_file, 'w') as f:
                json.dump(self.metrics, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save evolution metrics: {e}")
    
    def load_metrics(self):
        """Load metrics from disk"""
        try:
            if self.metrics_file.exists():
                with open(self.metrics_file, 'r') as f:
                    loaded = json.load(f)
                    self.metrics.update(loaded)
                
                logger.info("Evolution metrics loaded")
        except Exception as e:
            logger.warning(f"Failed to load evolution metrics: {e}")


# Global instance
evolution_metrics_tracker = EvolutionMetricsTracker()
