"""
Parallel Self-Play System for AlphaZero
Multi-threaded game generation with queue-based result merging
"""
import numpy as np
import logging
import time
import threading
from typing import List, Dict, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from queue import Queue
import copy

from chess_engine import ChessEngine
from self_play import SelfPlayGame
from neural_network import AlphaZeroNetwork

logger = logging.getLogger(__name__)


class ParallelSelfPlayManager:
    """
    Multi-threaded self-play manager for accelerated game generation
    Thread-safe game generation with shared read-only neural network
    """
    
    def __init__(self, 
                 neural_network: AlphaZeroNetwork,
                 num_threads: int = 4,
                 num_simulations: int = 800,
                 c_puct: float = 1.0):
        """
        Initialize parallel self-play manager
        
        Args:
            neural_network: Shared neural network (read-only across threads)
            num_threads: Number of parallel worker threads
            num_simulations: MCTS simulations per move
            c_puct: MCTS exploration constant
        """
        self.neural_network = neural_network
        self.num_threads = num_threads
        self.num_simulations = num_simulations
        self.c_puct = c_puct
        
        # Performance tracking
        self.games_generated = 0
        self.total_positions = 0
        self.start_time = None
        
        # Thread safety
        self.lock = threading.Lock()
        
        logger.info(f"Initialized ParallelSelfPlayManager with {num_threads} threads")
    
    def _worker_generate_game(self, worker_id: int, temperature_threshold: int = 15) -> Dict:
        """
        Worker function to generate a single self-play game
        Each worker has its own SelfPlayGame instance
        
        Args:
            worker_id: Worker thread identifier
            temperature_threshold: Move threshold for temperature adjustment
            
        Returns:
            Dict with training_data and game_result
        """
        try:
            # Create worker-specific self-play instance
            # Neural network is shared (read-only) - thread-safe for inference
            self_play = SelfPlayGame(
                self.neural_network,
                num_simulations=self.num_simulations,
                c_puct=self.c_puct
            )
            
            # Generate game
            training_data, result, num_moves = self_play.play_game(
                temperature_threshold=temperature_threshold,
                store_fen=True
            )
            
            return {
                'success': True,
                'worker_id': worker_id,
                'training_data': training_data,
                'result': result,
                'num_moves': num_moves,
                'num_positions': len(training_data)
            }
            
        except Exception as e:
            logger.error(f"Worker {worker_id} failed: {e}")
            return {
                'success': False,
                'worker_id': worker_id,
                'error': str(e)
            }
    
    def generate_games_parallel(self, 
                                num_games: int,
                                temperature_threshold: int = 15,
                                progress_callback: Optional[callable] = None) -> tuple:
        """
        Generate multiple self-play games in parallel
        
        Args:
            num_games: Total number of games to generate
            temperature_threshold: Move threshold for temperature
            progress_callback: Optional callback(completed, total, message)
            
        Returns:
            (all_training_data, game_results) tuple
        """
        self.start_time = time.time()
        all_training_data = []
        game_results = []
        
        logger.info(f"Starting parallel self-play: {num_games} games with {self.num_threads} threads")
        
        # Create thread pool
        with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
            # Submit all game generation tasks
            futures = []
            for game_idx in range(num_games):
                future = executor.submit(
                    self._worker_generate_game,
                    worker_id=game_idx,
                    temperature_threshold=temperature_threshold
                )
                futures.append(future)
            
            # Collect results as they complete
            completed = 0
            for future in as_completed(futures):
                result = future.result()
                
                if result['success']:
                    # Merge training data
                    all_training_data.extend(result['training_data'])
                    
                    # Track game result
                    game_results.append({
                        'game_num': completed + 1,
                        'worker_id': result['worker_id'],
                        'result': result['result'],
                        'num_moves': result['num_moves'],
                        'num_positions': result['num_positions']
                    })
                    
                    completed += 1
                    
                    # Update progress
                    if progress_callback:
                        progress_callback(completed, num_games, 
                                        f"Game {completed}/{num_games} complete")
                    
                    # Log progress
                    elapsed = time.time() - self.start_time
                    games_per_min = (completed / elapsed) * 60 if elapsed > 0 else 0
                    logger.info(f"Game {completed}/{num_games} complete "
                              f"({result['result']}, {result['num_moves']} moves) - "
                              f"{games_per_min:.1f} games/min")
                else:
                    logger.error(f"Game generation failed: {result.get('error', 'Unknown error')}")
        
        # Final statistics
        total_time = time.time() - self.start_time
        self.games_generated += len(game_results)
        self.total_positions += len(all_training_data)
        
        games_per_min = (len(game_results) / total_time) * 60 if total_time > 0 else 0
        
        logger.info(f"Parallel self-play complete: {len(game_results)} games, "
                   f"{len(all_training_data)} positions in {total_time:.2f}s "
                   f"({games_per_min:.1f} games/min)")
        
        return all_training_data, game_results
    
    def generate_single_game(self, temperature_threshold: int = 15) -> tuple:
        """
        Generate a single game (compatibility with sequential API)
        
        Returns:
            (training_data, game_result) tuple
        """
        result = self._worker_generate_game(0, temperature_threshold)
        
        if result['success']:
            game_result = {
                'result': result['result'],
                'num_moves': result['num_moves'],
                'num_positions': result['num_positions']
            }
            return result['training_data'], game_result
        else:
            raise Exception(f"Game generation failed: {result.get('error', 'Unknown error')}")
    
    def get_performance_stats(self) -> Dict:
        """Get performance statistics"""
        elapsed = time.time() - self.start_time if self.start_time else 0
        games_per_min = (self.games_generated / elapsed) * 60 if elapsed > 0 else 0
        
        return {
            'games_generated': self.games_generated,
            'total_positions': self.total_positions,
            'elapsed_seconds': elapsed,
            'games_per_minute': games_per_min,
            'num_threads': self.num_threads,
            'num_simulations': self.num_simulations
        }


class AdaptiveSelfPlayManager:
    """
    Self-play manager with automatic parallel/sequential selection
    Automatically uses parallel mode if configured, otherwise sequential
    """
    
    def __init__(self,
                 neural_network: AlphaZeroNetwork,
                 num_simulations: int = 800,
                 enable_parallel: bool = False,
                 num_threads: int = 4):
        """
        Initialize adaptive self-play manager
        
        Args:
            neural_network: Neural network for self-play
            num_simulations: MCTS simulations per move
            enable_parallel: Enable parallel mode
            num_threads: Number of threads for parallel mode
        """
        self.neural_network = neural_network
        self.num_simulations = num_simulations
        self.enable_parallel = enable_parallel
        self.num_threads = num_threads
        
        # Initialize appropriate manager
        if enable_parallel and num_threads > 1:
            self.manager = ParallelSelfPlayManager(
                neural_network,
                num_threads=num_threads,
                num_simulations=num_simulations
            )
            logger.info(f"Using parallel self-play with {num_threads} threads")
        else:
            from self_play import SelfPlayManager
            self.manager = SelfPlayManager(neural_network, num_simulations=num_simulations)
            logger.info("Using sequential self-play")
        
        self.is_parallel = isinstance(self.manager, ParallelSelfPlayManager)
    
    def generate_games(self, num_games: int, progress_callback: Optional[callable] = None):
        """Generate games using configured mode"""
        if self.is_parallel:
            return self.manager.generate_games_parallel(num_games, progress_callback=progress_callback)
        else:
            # Sequential mode
            return self.manager.generate_games(num_games, store_fen=True)
    
    def generate_single_game(self):
        """Generate single game"""
        return self.manager.generate_single_game(store_fen=True)
    
    def get_performance_stats(self):
        """Get performance statistics"""
        if hasattr(self.manager, 'get_performance_stats'):
            return self.manager.get_performance_stats()
        return {}
