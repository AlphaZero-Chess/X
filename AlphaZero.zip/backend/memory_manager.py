"""
Memory Manager for AlphaZero Memory System
Handles storage, retrieval, and management of PGN memories
"""
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from pathlib import Path
import json

logger = logging.getLogger(__name__)

class MemoryManager:
    """Manage AlphaZero memory storage and retrieval"""
    
    def __init__(self, cache_dir: str = "backend/cache/memories"):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    async def store_memories(self, db, games: List[Dict[str, Any]]) -> int:
        """
        Store games in MongoDB memories collection
        
        Args:
            db: MongoDB database instance
            games: List of game dictionaries
            
        Returns:
            Number of games stored
        """
        if not games:
            return 0
        
        try:
            # Convert datetime objects to ISO strings
            for game in games:
                if isinstance(game.get("timestamp_recalled"), datetime):
                    game["timestamp_recalled"] = game["timestamp_recalled"].isoformat()
            
            result = await db.memories.insert_many(games)
            logger.info(f"Stored {len(result.inserted_ids)} memories in database")
            return len(result.inserted_ids)
        except Exception as e:
            logger.error(f"Error storing memories: {e}")
            # Fallback to cache
            return self._cache_memories(games)
    
    def _cache_memories(self, games: List[Dict[str, Any]]) -> int:
        """
        Cache memories to local filesystem when MongoDB is unavailable
        """
        try:
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            cache_file = self.cache_dir / f"memories_{timestamp}.json"
            
            # Convert datetime objects
            for game in games:
                if isinstance(game.get("timestamp_recalled"), datetime):
                    game["timestamp_recalled"] = game["timestamp_recalled"].isoformat()
            
            with open(cache_file, 'w') as f:
                json.dump(games, f, indent=2)
            
            logger.info(f"Cached {len(games)} memories to {cache_file}")
            return len(games)
        except Exception as e:
            logger.error(f"Failed to cache memories: {e}")
            return 0
    
    async def get_memories(self, db, filters: Optional[Dict] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Retrieve memories from database
        
        Args:
            db: MongoDB database instance
            filters: Optional filter dictionary
            limit: Maximum number of memories to retrieve
            
        Returns:
            List of game dictionaries
        """
        try:
            query = filters or {}
            memories = await db.memories.find(query, {"_id": 0}).sort("timestamp_recalled", -1).limit(limit).to_list(limit)
            return memories
        except Exception as e:
            logger.error(f"Error retrieving memories: {e}")
            return []
    
    async def get_memory_by_id(self, db, memory_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve a specific memory by ID
        """
        try:
            memory = await db.memories.find_one({"memory_id": memory_id}, {"_id": 0})
            return memory
        except Exception as e:
            logger.error(f"Error retrieving memory {memory_id}: {e}")
            return None
    
    async def get_memory_stats(self, db) -> Dict[str, Any]:
        """
        Get statistics about stored memories
        """
        try:
            total_memories = await db.memories.count_documents({})
            
            # Get breakdown by result
            pipeline = [
                {"$group": {
                    "_id": "$result",
                    "count": {"$sum": 1}
                }}
            ]
            result_breakdown = await db.memories.aggregate(pipeline).to_list(10)
            
            # Get breakdown by source file
            pipeline = [
                {"$group": {
                    "_id": "$source_file",
                    "count": {"$sum": 1},
                    "avg_moves": {"$avg": "$move_count"}
                }},
                {"$sort": {"count": -1}},
                {"$limit": 10}
            ]
            source_breakdown = await db.memories.aggregate(pipeline).to_list(10)
            
            # Get recent memories
            recent = await db.memories.find().sort("timestamp_recalled", -1).limit(5).to_list(5)
            
            return {
                "total_memories": total_memories,
                "result_breakdown": result_breakdown,
                "source_breakdown": source_breakdown,
                "recent_uploads": [
                    {
                        "memory_id": m.get("memory_id"),
                        "source_file": m.get("source_file"),
                        "timestamp": m.get("timestamp_recalled")
                    }
                    for m in recent
                ]
            }
        except Exception as e:
            logger.error(f"Error getting memory stats: {e}")
            return {"total_memories": 0, "result_breakdown": [], "source_breakdown": []}
