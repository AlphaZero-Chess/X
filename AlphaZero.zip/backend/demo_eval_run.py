#!/usr/bin/env python3
"""
Phase 4 Demo - Pod-Balanced Evaluation

This demo runs a small pod-balanced evaluation and shows:
- Game distribution across pods
- Per-pod performance metrics
- Aggregated ELO calculation
- Promotion decision

Usage:
    python demo_eval_run.py [--pods N] [--games N]
"""

import asyncio
import logging
import argparse
from pathlib import Path

from evaluation_manager import EvaluationManager, reset_evaluation_manager
from model_registry import ModelRegistry, reset_model_registry
from neural_network import AlphaZeroNetwork
from tpu_cluster_manager import get_tpu_grid

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


async def run_demo(num_pods: int = 2, num_games: int = 20):
    """
    Run demonstration of pod-balanced evaluation
    
    Args:
        num_pods: Number of TPU pods to use
        num_games: Total number of games to play
    """
    logger.info("="*80)
    logger.info(f"PHASE 4 DEMO: Pod-Balanced Evaluation")
    logger.info(f"Configuration: {num_pods} pods × {num_games} games")
    logger.info("="*80)
    
    # Reset managers for clean demo
    reset_evaluation_manager()
    reset_model_registry()
    
    # Initialize managers
    eval_manager = EvaluationManager()
    registry = ModelRegistry()
    tpu_grid = get_tpu_grid()
    
    # Show TPU grid status
    grid_status = tpu_grid.get_grid_status()
    logger.info(f"\n📊 TPU Grid Status:")
    logger.info(f"   Total TPUs: {grid_status['grid']['total_tpus']:,}")
    logger.info(f"   Total Pods: {grid_status['grid']['total_pods']}")
    logger.info(f"   Utilization: {grid_status['utilization']['current_percent']:.1f}%")
    
    # Create two models for evaluation
    logger.info(f"\n🤖 Creating Models:")
    logger.info(f"   Challenger: demo_challenger (fresh network)")
    logger.info(f"   Champion: demo_champion (fresh network)")
    
    challenger_model = AlphaZeroNetwork()
    champion_model = AlphaZeroNetwork()
    
    # Run evaluation
    logger.info(f"\n🎮 Starting Evaluation:")
    logger.info(f"   Games: {num_games}")
    logger.info(f"   Pods: {num_pods}")
    logger.info(f"   MCTS Simulations: 400 per move")
    logger.info(f"   Aggregation: weighted_by_games")
    
    job, results = await eval_manager.start_evaluation(
        challenger_model=challenger_model,
        champion_model=champion_model,
        challenger_name="demo_challenger",
        champion_name="demo_champion",
        challenger_elo=1500.0,
        champion_elo=1500.0,
        num_eval_games=num_games,
        pods_for_eval=num_pods,
        use_tpu_pods=True,
        autoscale_eval=True,
        pod_warmup_seconds=5,
        aggregation_mode="weighted_by_games",
        elo_k_factor=32,
        async_mode=False  # Blocking for demo
    )
    
    # Display results
    logger.info(f"\n" + "="*80)
    logger.info(f"📈 EVALUATION RESULTS")
    logger.info("="*80)
    
    logger.info(f"\n🎯 Overall Results:")
    logger.info(f"   Job ID: {results['job_id']}")
    logger.info(f"   Total Games: {results['total_games']}")
    logger.info(f"   Challenger Wins: {results['challenger_wins']}")
    logger.info(f"   Champion Wins: {results['champion_wins']}")
    logger.info(f"   Draws: {results['draws']}")
    logger.info(f"   Challenger Win Rate: {results['challenger_win_rate']:.1%}")
    
    logger.info(f"\n📊 Per-Pod Breakdown:")
    for pod_id, pod_results in results['per_pod_results'].items():
        logger.info(f"   Pod {pod_id}:")
        logger.info(f"      Games: {pod_results['games_completed']}")
        logger.info(f"      Results: {pod_results['wins_challenger']}W-{pod_results['wins_champion']}L-{pod_results['draws']}D")
        logger.info(f"      Win Rate: {pod_results['win_rate_challenger']:.1%}")
        logger.info(f"      Avg Duration: {pod_results['avg_game_duration']:.2f}s/game")
    
    logger.info(f"\n🎲 ELO Calculations:")
    elo_calc = results['elo_calculations']
    logger.info(f"   ELO Before: {elo_calc['elo_before']:.0f}")
    logger.info(f"   ELO After: {elo_calc['elo_after']:.0f}")
    logger.info(f"   ELO Delta: {elo_calc['elo_delta']:+.0f}")
    logger.info(f"   Expected Score: {elo_calc['expected_score']:.3f}")
    logger.info(f"   Actual Score: {elo_calc['actual_score']:.3f}")
    logger.info(f"   K-Factor: {elo_calc['k_factor']}")
    
    logger.info(f"\n🔍 Per-Pod ELO Contributions:")
    for pod_id, pod_elo in results['per_pod_elo'].items():
        logger.info(f"   Pod {pod_id}: Δ {pod_elo['elo_delta']:+.0f} ({pod_elo['games']} games, {pod_elo['win_rate']:.1%} win rate)")
    
    # Check promotion criteria
    logger.info(f"\n🏆 Promotion Decision:")
    should_promote, reason = registry.should_promote(
        challenger_win_rate=results['challenger_win_rate'],
        elo_delta=elo_calc['elo_delta'],
        win_threshold=0.55,
        elo_threshold=50.0
    )
    
    logger.info(f"   Should Promote: {should_promote}")
    logger.info(f"   Reason: {reason}")
    
    if should_promote:
        logger.info(f"\n   ✅ Challenger would be promoted!")
        logger.info(f"   (Demo mode - not actually promoting)")
    else:
        logger.info(f"\n   ❌ Challenger would NOT be promoted")
        logger.info(f"   Needs: Win rate ≥ 55% OR ELO gain ≥ +50")
    
    # Show what manual promotion would look like
    logger.info(f"\n💡 Manual Promotion Example:")
    logger.info(f"   To manually promote this model:")
    logger.info(f"   POST /api/alphazero/models/promote")
    logger.info(f"   {{")
    logger.info(f'     "model_name": "demo_challenger",')
    logger.info(f'     "elo": {elo_calc["elo_after"]:.0f},')
    logger.info(f'     "reason": "Manual promotion after review"')
    logger.info(f"   }}")
    
    logger.info(f"\n🔄 Rollback Example:")
    logger.info(f"   To rollback to a previous version:")
    logger.info(f"   POST /api/alphazero/models/rollback")
    logger.info(f"   {{")
    logger.info(f'     "version": 0,')
    logger.info(f'     "reason": "Rolling back due to issues"')
    logger.info(f"   }}")
    
    logger.info(f"\n" + "="*80)
    logger.info(f"✅ DEMO COMPLETE")
    logger.info("="*80)


def main():
    parser = argparse.ArgumentParser(description="Phase 4 Evaluation Demo")
    parser.add_argument("--pods", type=int, default=2, help="Number of pods (default: 2)")
    parser.add_argument("--games", type=int, default=20, help="Number of games (default: 20)")
    
    args = parser.parse_args()
    
    # Run demo
    asyncio.run(run_demo(num_pods=args.pods, num_games=args.games))


if __name__ == "__main__":
    main()
