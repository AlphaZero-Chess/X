# AlphaZero Test Cycle Script

## Overview

`test_cycle.py` is a standalone script that validates the complete AlphaZero training pipeline by running a full **Self-Play → Train → Evaluate** cycle.

This script confirms that all components (MCTS, memory, training, and evaluation) are properly connected and functioning.

## Features

✅ **Complete Pipeline Test**
- Generates AlphaZero vs AlphaZero self-play games
- Trains model on generated data
- Evaluates model improvement with ELO calculation

✅ **Configurable Parameters**
- Number of games, threads, epochs
- Parallel or sequential self-play
- Custom model names and cache directories

✅ **Comprehensive Logging**
- Terminal output for progress monitoring
- Detailed logs saved to `/app/backend/cache/test_cycle.log`
- JSON results saved to `/app/backend/cache/test_cycle_results.json`

✅ **Offline Compatible**
- Runs entirely locally (CPU or GPU)
- No external dependencies required
- Works in air-gapped environments

## Installation

All dependencies are already included in `requirements.txt`:

```bash
cd /app/backend
pip install -r requirements.txt
```

## Usage

### Basic Usage

Run with default settings (20 games, 1 epoch, sequential):

```bash
python test_cycle.py
```

### Quick Test

Run a quick test with just 2 games:

```bash
python test_cycle.py --games 2
```

### Parallel Self-Play

Enable parallel self-play with 4 threads:

```bash
python test_cycle.py --games 20 --threads 4 --parallel
```

### Custom Configuration

```bash
python test_cycle.py \
  --games 10 \
  --epochs 2 \
  --threads 4 \
  --parallel \
  --base-model MyBaseModel \
  --new-model MyNewModel
```

## Command-Line Arguments

| Argument | Type | Default | Description |
|----------|------|---------|-------------|
| `--games` | int | 20 | Number of self-play games to generate |
| `--threads` | int | 4 | Number of threads for parallel self-play |
| `--parallel` | flag | False | Enable parallel self-play |
| `--epochs` | int | 1 | Number of training epochs |
| `--base-model` | str | ActiveModel_Offline | Base model name (without .pth) |
| `--new-model` | str | ActiveModel_TestCycle | New model name after training |
| `--cache-dir` | str | /app/backend/cache | Cache directory for outputs |

## Workflow

### Phase 1: Self-Play Generation

1. Loads or creates base model (`ActiveModel_Offline.pth`)
2. Generates N self-play games using MCTS (800 simulations per move)
3. Saves games as PGNs to `/backend/cache/selfplay/test_cycle_pgns/`
4. Stores training data (positions, policies, values) in memory

**Output:**
```
[Self-Play] Generated 20 games (AlphaZero vs AlphaZero)
[Memory] Stored PGNs → /backend/cache/selfplay/test_cycle_pgns/
```

### Phase 2: Training

1. Loads generated training data
2. Fine-tunes base model for 1 epoch (lightweight)
3. Saves updated model to `/backend/models/ActiveModel_TestCycle.pth`

**Output:**
```
[Training] Loaded 20 self-play games
[Training] Epoch 1 complete — loss: 0.342, lr: 0.001
[Training] Model saved → ActiveModel_TestCycle.pth
```

### Phase 3: Evaluation

1. Loads both models for comparison
2. Plays 20 evaluation games (alternating colors)
3. Calculates ELO delta and win rate
4. Saves results to JSON

**Output:**
```
[Evaluation] Playing 20 games
[Results] Win rate: 55% | ELO change: +24
```

**Note:** On the first run, evaluation is skipped (no previous model to compare). Run the script again to see evaluation metrics.

## Output Files

### Results JSON

Location: `/app/backend/cache/test_cycle_results.json`

```json
{
  "session_id": "2f00012e",
  "timestamp": "2025-10-15T21:15:00Z",
  "config": {
    "num_games": 20,
    "num_threads": 1,
    "enable_parallel": false,
    "num_epochs": 1,
    "base_model": "ActiveModel_Offline",
    "new_model": "ActiveModel_TestCycle"
  },
  "phases": {
    "selfplay": {
      "games_generated": 20,
      "positions_generated": 1847,
      "white_wins": 8,
      "black_wins": 7,
      "draws": 5,
      "time_seconds": 245.3,
      "games_per_minute": 4.9
    },
    "training": {
      "epochs": 1,
      "positions_trained": 1847,
      "final_loss": 0.342,
      "time_seconds": 23.5,
      "model_saved": "/app/backend/models/ActiveModel_TestCycle.pth"
    },
    "evaluation": {
      "games_played": 20,
      "challenger_win_rate": 0.55,
      "elo_delta": 24,
      "promoted": true,
      "time_seconds": 178.2
    }
  },
  "summary": {
    "success": true,
    "total_time_seconds": 447.0,
    "completed_phases": ["selfplay", "training", "evaluation"]
  }
}
```

### PGN Files

Location: `/app/backend/cache/selfplay/test_cycle_pgns/`

Each game is saved as a separate PGN file:
- `game_2f00012e_000001.pgn`
- `game_2f00012e_000002.pgn`
- etc.

### Log File

Location: `/app/backend/cache/test_cycle.log`

Contains detailed debug information for troubleshooting.

## First Run Behavior

On the first run:

1. **No Base Model**: Creates a fresh untrained `ActiveModel_Offline.pth`
2. **No Evaluation**: Skips Phase 3 (no previous model to compare)
3. **Success**: Self-play and training complete successfully

Run the script **again** to see evaluation metrics (comparing the trained model against the base).

## Performance

### Sequential Mode
- ~3-5 games/minute on CPU
- ~8-12 games/minute on GPU

### Parallel Mode (4 threads)
- ~10-15 games/minute on CPU
- ~25-35 games/minute on GPU

**Note:** Times vary based on game length and hardware.

## Troubleshooting

### Issue: Script runs for a long time

**Cause:** Chess self-play with 800 MCTS simulations per move is computationally intensive.

**Solutions:**
- Start with `--games 2` for quick testing
- Use `--parallel` flag with multiple threads for speedup
- Check logs in real-time: `tail -f /app/backend/cache/test_cycle.log`

### Issue: Out of memory

**Cause:** Too many games generating too much training data.

**Solutions:**
- Reduce `--games` to 10 or fewer
- Close other applications to free memory

### Issue: "No module named 'torch'"

**Cause:** Missing dependencies.

**Solution:**
```bash
cd /app/backend
pip install -r requirements.txt
```

### Issue: First run shows "skipping evaluation"

**Cause:** This is **expected behavior** on first run.

**Solution:** Run the script again to evaluate improvements.

## Architecture

The script uses existing AlphaZero modules:

- **Self-Play**: `self_play.py`, `parallel_selfplay.py`
- **Training**: `trainer.py`
- **Evaluation**: `evaluator.py`
- **Neural Network**: `neural_network.py`
- **MCTS**: `mcts.py`
- **Chess Engine**: `chess_engine.py`

## Development

To modify the script:

1. **Adjust MCTS Simulations**: Edit line 132 (selfplay) and 287 (evaluation)
2. **Change Batch Size**: Edit line 350 (training)
3. **Add Custom Metrics**: Extend the `results` dictionary
4. **Custom Logging**: Modify `setup_logging()` method

## Integration with Main Pipeline

This script is **standalone** and does not interfere with the main AlphaZero training loop.

It can be used to:
- Validate pipeline after code changes
- Test new configurations
- Debug training issues
- Generate quick evaluation reports

## License

Part of the AlphaZero Chess implementation.

## Support

For issues or questions:
1. Check `/app/backend/cache/test_cycle.log` for detailed errors
2. Review the JSON results for diagnostic information
3. Run with `--games 2` to quickly reproduce issues
