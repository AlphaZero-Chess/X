# Phase 2: Quick Start Guide

## 🚀 Getting Started with Distributed Optimization

This guide will help you quickly start using the Phase 2 distributed self-play system.

---

## Prerequisites

All dependencies are already installed in `/app/backend/requirements.txt`:
- PyTorch 2.9.0
- NumPy 2.3.3
- FastAPI
- python-chess
- Motor (MongoDB)

---

## Quick Test (2 minutes)

Test the system with a small smoke test:

```bash
cd /app/backend

# Test sequential mode (2 games, fast)
python selfplay_trainer.py \
  --mode sequential \
  --games 2 \
  --simulations 50 \
  --batch_games 2

# Test distributed mode (4 games, 2 workers)
python selfplay_trainer.py \
  --mode distributed \
  --workers 2 \
  --games 4 \
  --simulations 50 \
  --batch_games 4
```

---

## Run Comprehensive Tests

Run the full test suite:

```bash
cd /app/backend
python test_phase2_distributed.py
```

Expected output:
```
================================================================
PHASE 2: DISTRIBUTED OPTIMIZATION - TEST SUITE
================================================================

TEST 1: SEQUENTIAL MODE
...
✅ Sequential Mode: PASSED

TEST 2: DISTRIBUTED MODE
...
✅ Distributed Mode: PASSED

...

================================================================
TEST SUMMARY
================================================================
Sequential Mode: ✅ PASSED
Distributed Mode: ✅ PASSED
Replay Buffer Integrity: ✅ PASSED
Performance Comparison: ✅ PASSED
Worker Monitoring: ✅ PASSED
Auto Mode Selection: ✅ PASSED
================================================================
TOTAL: 6/6 tests passed
================================================================
```

---

## Production Training

### Small Scale (Testing)

Generate 100 games with distributed mode:

```bash
cd /app/backend

python selfplay_trainer.py \
  --mode distributed \
  --games 100 \
  --hours 2 \
  --simulations 800 \
  --batch_games 10 \
  --workers 4
```

### Medium Scale (Development)

Generate 1,000 games:

```bash
python selfplay_trainer.py \
  --mode distributed \
  --games 1000 \
  --hours 12 \
  --simulations 800 \
  --batch_games 50 \
  --workers 8
```

### Large Scale (Production)

Full 44M game training cycle:

```bash
python selfplay_trainer.py \
  --mode distributed \
  --games 44000000 \
  --hours 200 \
  --simulations 800 \
  --batch_games 100 \
  --workers 16
```

---

## Resume Training

If training is interrupted, resume from the last checkpoint:

```bash
python selfplay_trainer.py \
  --resume \
  --mode distributed \
  --games 44000000 \
  --hours 200
```

---

## Monitor Training

### View Logs

```bash
# Live training log
tail -f /app/backend/training.log

# Filter for important events
tail -f /app/backend/training.log | grep -E "✅|❌|📊|COMPLETE"

# View worker logs
tail -f /app/data/logs/selfplay/worker_*.log
```

### Check Status

```bash
# Get current status
curl http://localhost:8001/api/alphazero/distributed/status | jq

# Get worker health
curl http://localhost:8001/api/alphazero/distributed/workers | jq

# Get performance metrics
curl http://localhost:8001/api/alphazero/distributed/metrics | jq
```

---

## Start Training via API

### Using curl

```bash
curl -X POST http://localhost:8001/api/alphazero/distributed/start \
  -H "Content-Type: application/json" \
  -d '{
    "max_games": 1000,
    "max_hours": 10,
    "mode": "distributed",
    "num_workers": 4,
    "batch_games": 50,
    "num_simulations": 800
  }'
```

### Using Python

```python
import requests

response = requests.post(
    'http://localhost:8001/api/alphazero/distributed/start',
    json={
        'max_games': 1000,
        'max_hours': 10,
        'mode': 'distributed',
        'num_workers': 4,
        'batch_games': 50
    }
)

print(response.json())
```

---

## Performance Tuning

### CPU-Optimized (default)

```bash
python selfplay_trainer.py \
  --mode auto \  # Automatically detects optimal worker count
  --games 10000 \
  --simulations 800
```

### GPU-Optimized

```bash
# Set workers = num_gpus * 2
python selfplay_trainer.py \
  --mode distributed \
  --workers 4 \  # For 2 GPUs
  --games 10000 \
  --simulations 800
```

### TPU-Optimized

```bash
# Use more workers for TPU
python selfplay_trainer.py \
  --mode distributed \
  --workers 16 \
  --games 100000 \
  --simulations 800
```

---

## Troubleshooting

### Workers Not Starting

```bash
# Check Python path
which python

# Check imports
python -c "from selfplay_trainer import AlphaZeroSelfPlayTrainer; print('OK')"

# Check worker logs
ls -la /app/data/logs/selfplay/
```

### Replay Buffer Empty

```bash
# Test sequential mode first
python selfplay_trainer.py --mode sequential --games 2 --simulations 50

# Check if positions are generated
tail -f /app/backend/training.log | grep "positions"
```

### Low Performance

```bash
# Check CPU usage
htop

# Reduce workers if overloaded
python selfplay_trainer.py --mode distributed --workers 2 --games 10

# Reduce simulations for faster testing
python selfplay_trainer.py --simulations 100 --games 10
```

---

## Next Steps

After confirming Phase 2 works:

1. **Integrate with Frontend**: Use the API endpoints with AlphaZeroControlPanel
2. **Scale Up**: Increase workers and games for production training
3. **Move to Phase 3**: Full TPU simulation integration

---

## Key Metrics to Watch

During training, monitor these metrics:

- **Games/second**: Should be > 0.01 for distributed mode
- **Positions/second**: Should be > 30 for distributed mode  
- **Replay buffer utilization**: Should grow steadily
- **Worker failures**: Should be 0 or very low
- **Training loss**: Should decrease over time

---

## Getting Help

If you encounter issues:

1. Check `/app/backend/PHASE2_DISTRIBUTED_README.md` for detailed documentation
2. Review worker logs in `/app/data/logs/selfplay/`
3. Run tests: `python test_phase2_distributed.py`
4. Check API status: `curl http://localhost:8001/api/alphazero/distributed/status`

---

## Summary

**Phase 2 is complete and ready for use!**

- ✅ Sequential mode works
- ✅ Distributed mode works with fault tolerance
- ✅ API integration complete
- ✅ Tests passing
- ✅ Frontend ready

**Now proceed with Phase 3 for TPU simulation integration.**
