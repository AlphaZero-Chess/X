"""
Evolution Tracker - Phase 5 Adaptive Evolution
Tracks model lineage, IQ growth metrics, and evolution history

Features:
- Model lineage tree (parent-child relationships)
- IQ growth metrics (ELO, complexity, efficiency)
- Mutation history (hyperparameter and architecture changes)
- Performance correlation analysis
- Persistent storage for long-term tracking
"""

import json
import logging
import time
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict
from collections import defaultdict
import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class ModelNode:
    """Represents a model in the evolution lineage tree"""
    model_id: str
    model_name: str
    generation: int
    parent_id: Optional[str]
    
    # Performance metrics
    elo: float
    training_loss: float
    win_rate: float
    
    # Complexity metrics
    num_parameters: int
    architecture_complexity: float
    
    # Evolution metadata
    creation_method: str  # 'training_cycle', 'hpo', 'nas'
    mutations: List[str]
    timestamp: str
    
    # Training efficiency
    positions_trained: int
    training_time_seconds: float
    games_played: int
    
    # Lineage tracking
    children: List[str] = None
    depth: int = 0
    
    def __post_init__(self):
        if self.children is None:
            self.children = []
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ModelNode':
        return cls(**data)


@dataclass
class EvolutionCycle:
    """Represents one evolution cycle (training → evaluation → promotion)"""
    cycle_id: str
    cycle_number: int
    timestamp: str
    
    # Phase results
    selfplay_games: int
    positions_generated: int
    training_loss: float
    training_epochs: int
    
    # Evaluation results
    challenger_model_id: str
    champion_model_id: str
    evaluation_win_rate: float
    elo_delta: float
    promoted: bool
    
    # Performance
    cycle_duration_seconds: float
    games_per_second: float
    
    # Optimization triggers
    stagnation_detected: bool
    hpo_triggered: bool
    nas_triggered: bool
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'EvolutionCycle':
        return cls(**data)


class IQGrowthMetrics:
    """Calculate and track IQ growth metrics for the model"""
    
    @staticmethod
    def calculate_iq_score(
        elo: float,
        complexity: float,
        efficiency: float,
        base_elo: float = 1500
    ) -> float:
        """
        Calculate overall IQ score combining multiple factors
        
        IQ = (ELO_gain / 10) + (1 / complexity) * 100 + efficiency * 50
        """
        elo_component = (elo - base_elo) / 10
        complexity_component = (1.0 / max(complexity, 0.1)) * 100
        efficiency_component = efficiency * 50
        
        iq_score = elo_component + complexity_component + efficiency_component
        return max(0, iq_score)
    
    @staticmethod
    def calculate_training_efficiency(
        positions_trained: int,
        training_time_seconds: float,
        elo_gain: float
    ) -> float:
        """
        Calculate training efficiency: ELO gain per million positions per hour
        """
        if training_time_seconds <= 0 or positions_trained <= 0:
            return 0.0
        
        hours = training_time_seconds / 3600
        positions_millions = positions_trained / 1_000_000
        
        efficiency = elo_gain / (positions_millions * hours) if (positions_millions * hours) > 0 else 0
        return max(0, efficiency)
    
    @staticmethod
    def calculate_architecture_complexity(
        num_parameters: int,
        num_channels: int = 128,
        num_res_blocks: int = 6
    ) -> float:
        """
        Calculate normalized architecture complexity score
        Baseline: 128 channels, 6 res blocks ≈ 1.0
        """
        baseline_params = 5_000_000  # Approximate baseline
        complexity = (num_parameters / baseline_params) * (num_channels / 128) * (num_res_blocks / 6)
        return max(0.1, complexity)


class EvolutionTracker:
    """
    Main evolution tracking system
    Manages model lineage, IQ growth, and evolution history
    """
    
    def __init__(self, data_dir: str = "/app/backend/data/evolution"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Storage files
        self.lineage_file = self.data_dir / "model_lineage.json"
        self.cycles_file = self.data_dir / "evolution_cycles.json"
        self.metrics_file = self.data_dir / "iq_metrics.json"
        self.summary_file = self.data_dir / "evolution_summary.json"
        
        # In-memory storage
        self.lineage_tree: Dict[str, ModelNode] = {}
        self.evolution_cycles: List[EvolutionCycle] = []
        self.root_model_id: Optional[str] = None
        
        # Metrics calculator
        self.iq_metrics = IQGrowthMetrics()
        
        # Load existing data
        self.load_state()
        
        logger.info(f"Evolution Tracker initialized: {len(self.lineage_tree)} models, {len(self.evolution_cycles)} cycles")
    
    def register_model(
        self,
        model_name: str,
        elo: float,
        training_loss: float,
        win_rate: float,
        num_parameters: int,
        parent_id: Optional[str] = None,
        creation_method: str = "training_cycle",
        mutations: List[str] = None,
        positions_trained: int = 0,
        training_time_seconds: float = 0,
        games_played: int = 0,
        architecture_info: Dict = None
    ) -> str:
        """
        Register a new model in the lineage tree
        
        Returns:
            model_id (str)
        """
        if mutations is None:
            mutations = []
        
        # Generate unique model ID
        model_id = f"model_{int(time.time() * 1000)}_{len(self.lineage_tree)}"
        
        # Calculate generation and depth
        if parent_id is None:
            generation = 0
            depth = 0
            if self.root_model_id is None:
                self.root_model_id = model_id
        else:
            parent = self.lineage_tree.get(parent_id)
            if parent:
                generation = parent.generation + 1
                depth = parent.depth + 1
                parent.children.append(model_id)
            else:
                logger.warning(f"Parent {parent_id} not found, treating as root")
                generation = 0
                depth = 0
        
        # Calculate architecture complexity
        if architecture_info:
            complexity = self.iq_metrics.calculate_architecture_complexity(
                num_parameters,
                architecture_info.get('num_channels', 128),
                architecture_info.get('num_res_blocks', 6)
            )
        else:
            complexity = self.iq_metrics.calculate_architecture_complexity(num_parameters)
        
        # Create model node
        model_node = ModelNode(
            model_id=model_id,
            model_name=model_name,
            generation=generation,
            parent_id=parent_id,
            elo=elo,
            training_loss=training_loss,
            win_rate=win_rate,
            num_parameters=num_parameters,
            architecture_complexity=complexity,
            creation_method=creation_method,
            mutations=mutations,
            timestamp=datetime.now(timezone.utc).isoformat(),
            positions_trained=positions_trained,
            training_time_seconds=training_time_seconds,
            games_played=games_played,
            depth=depth
        )
        
        # Add to lineage tree
        self.lineage_tree[model_id] = model_node
        
        # Save state
        self.save_state()
        
        logger.info(f"Model registered: {model_name} (ID: {model_id}, Gen: {generation}, ELO: {elo:.0f})")
        
        return model_id
    
    def record_evolution_cycle(
        self,
        cycle_number: int,
        selfplay_games: int,
        positions_generated: int,
        training_loss: float,
        training_epochs: int,
        challenger_model_id: str,
        champion_model_id: str,
        evaluation_win_rate: float,
        elo_delta: float,
        promoted: bool,
        cycle_duration_seconds: float,
        stagnation_detected: bool = False,
        hpo_triggered: bool = False,
        nas_triggered: bool = False
    ) -> str:
        """
        Record a completed evolution cycle
        
        Returns:
            cycle_id (str)
        """
        cycle_id = f"cycle_{cycle_number}_{int(time.time())}"
        
        games_per_second = selfplay_games / cycle_duration_seconds if cycle_duration_seconds > 0 else 0
        
        cycle = EvolutionCycle(
            cycle_id=cycle_id,
            cycle_number=cycle_number,
            timestamp=datetime.now(timezone.utc).isoformat(),
            selfplay_games=selfplay_games,
            positions_generated=positions_generated,
            training_loss=training_loss,
            training_epochs=training_epochs,
            challenger_model_id=challenger_model_id,
            champion_model_id=champion_model_id,
            evaluation_win_rate=evaluation_win_rate,
            elo_delta=elo_delta,
            promoted=promoted,
            cycle_duration_seconds=cycle_duration_seconds,
            games_per_second=games_per_second,
            stagnation_detected=stagnation_detected,
            hpo_triggered=hpo_triggered,
            nas_triggered=nas_triggered
        )
        
        self.evolution_cycles.append(cycle)
        
        # Save state
        self.save_state()
        
        logger.info(f"Cycle recorded: #{cycle_number}, ELO Δ{elo_delta:+.1f}, Promoted: {promoted}")
        
        return cycle_id
    
    def get_iq_growth_history(self, limit: int = 100) -> List[Dict]:
        """
        Get IQ growth history over time
        
        Returns list of {timestamp, model_id, iq_score, elo, complexity, efficiency}
        """
        history = []
        
        # Sort models by timestamp
        sorted_models = sorted(
            self.lineage_tree.values(),
            key=lambda m: m.timestamp
        )
        
        for model in sorted_models[-limit:]:
            # Calculate efficiency
            base_elo = 1500 if self.root_model_id else model.elo
            if self.root_model_id and self.root_model_id in self.lineage_tree:
                base_elo = self.lineage_tree[self.root_model_id].elo
            
            elo_gain = model.elo - base_elo
            efficiency = self.iq_metrics.calculate_training_efficiency(
                model.positions_trained,
                model.training_time_seconds,
                elo_gain
            )
            
            # Calculate IQ score
            iq_score = self.iq_metrics.calculate_iq_score(
                model.elo,
                model.architecture_complexity,
                efficiency,
                base_elo
            )
            
            history.append({
                'timestamp': model.timestamp,
                'model_id': model.model_id,
                'model_name': model.model_name,
                'generation': model.generation,
                'iq_score': round(iq_score, 2),
                'elo': round(model.elo, 1),
                'complexity': round(model.architecture_complexity, 3),
                'efficiency': round(efficiency, 3),
                'creation_method': model.creation_method
            })
        
        return history
    
    def get_lineage_tree(self) -> Dict:
        """
        Get complete lineage tree structure
        
        Returns nested tree structure with parent-child relationships
        """
        if not self.root_model_id or self.root_model_id not in self.lineage_tree:
            return {}
        
        def build_tree(model_id: str) -> Dict:
            model = self.lineage_tree[model_id]
            
            tree_node = {
                'model_id': model_id,
                'model_name': model.model_name,
                'generation': model.generation,
                'elo': round(model.elo, 1),
                'creation_method': model.creation_method,
                'mutations': model.mutations,
                'timestamp': model.timestamp,
                'children': []
            }
            
            # Recursively build children
            for child_id in model.children:
                if child_id in self.lineage_tree:
                    tree_node['children'].append(build_tree(child_id))
            
            return tree_node
        
        return build_tree(self.root_model_id)
    
    def detect_stagnation(self, window: int = 5, elo_threshold: float = 25.0) -> Tuple[bool, Dict]:
        """
        Detect if evolution has stagnated
        
        Args:
            window: Number of recent cycles to analyze
            elo_threshold: Minimum total ELO improvement required
        
        Returns:
            (is_stagnated, analysis_details)
        """
        if len(self.evolution_cycles) < window:
            return False, {"reason": "Insufficient cycle history", "cycles_analyzed": len(self.evolution_cycles)}
        
        recent_cycles = self.evolution_cycles[-window:]
        
        # Calculate metrics
        total_elo_delta = sum(c.elo_delta for c in recent_cycles)
        avg_elo_delta = total_elo_delta / window
        promotions = sum(1 for c in recent_cycles if c.promoted)
        avg_win_rate = np.mean([c.evaluation_win_rate for c in recent_cycles])
        
        # Stagnation criteria
        is_stagnated = (
            total_elo_delta < elo_threshold and
            promotions < (window // 2)  # Less than half promoted
        )
        
        analysis = {
            "is_stagnated": is_stagnated,
            "cycles_analyzed": window,
            "total_elo_delta": round(total_elo_delta, 2),
            "avg_elo_delta": round(avg_elo_delta, 2),
            "promotions": promotions,
            "avg_win_rate": round(avg_win_rate, 3),
            "elo_threshold": elo_threshold,
            "reason": "ELO plateau detected" if is_stagnated else "Evolution progressing normally"
        }
        
        logger.info(f"Stagnation check: {analysis}")
        
        return is_stagnated, analysis
    
    def get_evolution_summary(self) -> Dict:
        """Get comprehensive evolution summary"""
        if not self.lineage_tree:
            return {"status": "No models tracked yet"}
        
        # Get latest model
        latest_model = max(self.lineage_tree.values(), key=lambda m: m.timestamp)
        
        # Calculate statistics
        total_models = len(self.lineage_tree)
        total_cycles = len(self.evolution_cycles)
        total_promotions = sum(1 for c in self.evolution_cycles if c.promoted)
        
        # Get root ELO
        root_elo = self.lineage_tree[self.root_model_id].elo if self.root_model_id else 1500
        total_elo_gain = latest_model.elo - root_elo
        
        # Get IQ growth
        iq_history = self.get_iq_growth_history(limit=total_models)
        current_iq = iq_history[-1]['iq_score'] if iq_history else 0
        
        # Method breakdown
        method_counts = defaultdict(int)
        for model in self.lineage_tree.values():
            method_counts[model.creation_method] += 1
        
        # Recent performance
        recent_cycles = self.evolution_cycles[-10:] if len(self.evolution_cycles) >= 10 else self.evolution_cycles
        avg_recent_elo_delta = np.mean([c.elo_delta for c in recent_cycles]) if recent_cycles else 0
        
        return {
            "total_models": total_models,
            "total_cycles": total_cycles,
            "total_promotions": total_promotions,
            "promotion_rate": round(total_promotions / total_cycles, 3) if total_cycles > 0 else 0,
            "generations": latest_model.generation + 1,
            "root_elo": round(root_elo, 1),
            "current_elo": round(latest_model.elo, 1),
            "total_elo_gain": round(total_elo_gain, 1),
            "current_iq_score": round(current_iq, 2),
            "latest_model": {
                "model_id": latest_model.model_id,
                "model_name": latest_model.model_name,
                "generation": latest_model.generation,
                "elo": round(latest_model.elo, 1),
                "creation_method": latest_model.creation_method,
                "timestamp": latest_model.timestamp
            },
            "creation_methods": dict(method_counts),
            "avg_recent_elo_delta": round(avg_recent_elo_delta, 2),
            "stagnation_analysis": self.detect_stagnation()[1]
        }
    
    def save_state(self):
        """Save evolution state to disk"""
        try:
            # Save lineage tree
            with open(self.lineage_file, 'w') as f:
                lineage_data = {
                    'root_model_id': self.root_model_id,
                    'models': {
                        model_id: model.to_dict()
                        for model_id, model in self.lineage_tree.items()
                    }
                }
                json.dump(lineage_data, f, indent=2)
            
            # Save evolution cycles
            with open(self.cycles_file, 'w') as f:
                cycles_data = {
                    'cycles': [cycle.to_dict() for cycle in self.evolution_cycles]
                }
                json.dump(cycles_data, f, indent=2)
            
            # Save IQ metrics
            with open(self.metrics_file, 'w') as f:
                json.dump(self.get_iq_growth_history(), f, indent=2)
            
            # Save summary
            with open(self.summary_file, 'w') as f:
                json.dump(self.get_evolution_summary(), f, indent=2)
            
            logger.debug("Evolution state saved")
        
        except Exception as e:
            logger.error(f"Failed to save evolution state: {e}")
    
    def load_state(self):
        """Load evolution state from disk"""
        try:
            # Load lineage tree
            if self.lineage_file.exists():
                with open(self.lineage_file, 'r') as f:
                    lineage_data = json.load(f)
                    self.root_model_id = lineage_data.get('root_model_id')
                    self.lineage_tree = {
                        model_id: ModelNode.from_dict(model_data)
                        for model_id, model_data in lineage_data.get('models', {}).items()
                    }
            
            # Load evolution cycles
            if self.cycles_file.exists():
                with open(self.cycles_file, 'r') as f:
                    cycles_data = json.load(f)
                    self.evolution_cycles = [
                        EvolutionCycle.from_dict(cycle_data)
                        for cycle_data in cycles_data.get('cycles', [])
                    ]
            
            logger.info(f"Evolution state loaded: {len(self.lineage_tree)} models, {len(self.evolution_cycles)} cycles")
        
        except Exception as e:
            logger.error(f"Failed to load evolution state: {e}")


# Global instance
_evolution_tracker = None


def get_evolution_tracker() -> EvolutionTracker:
    """Get or create global evolution tracker instance"""
    global _evolution_tracker
    
    if _evolution_tracker is None:
        _evolution_tracker = EvolutionTracker()
    
    return _evolution_tracker


def reset_evolution_tracker():
    """Reset global evolution tracker (for testing)"""
    global _evolution_tracker
    _evolution_tracker = None
