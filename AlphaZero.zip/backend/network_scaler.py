"""
Network Auto-Scaler for AlphaZero
Automatically scales network capacity when thresholds are met
Targets superhuman performance (ELO 3500+)
"""
import torch
import torch.nn as nn
import logging
import json
from pathlib import Path
from typing import Dict, Optional, Tuple
from datetime import datetime, timezone

from neural_network import AlphaZeroNetwork, ResidualBlock
from device_manager import device_manager

logger = logging.getLogger(__name__)


class NetworkScaler:
    """
    Automatically scale AlphaZero network based on training progress
    """
    
    def __init__(self, config_path: str = "/app/backend/config.json"):
        self.config_path = Path(config_path)
        self.scaling_history = []
        
        logger.info("Network Scaler initialized")
    
    def should_scale(self, total_games: int, current_elo: float, elo_plateau_cycles: int = 0) -> bool:
        """
        Determine if network should be scaled
        
        Scaling triggers:
        1. Total games >= 5000 (first scale)
        2. ELO plateau for 3+ cycles
        3. Manual scale request
        
        Args:
            total_games: Total games processed so far
            current_elo: Current ELO rating
            elo_plateau_cycles: Number of consecutive cycles with <5 ELO gain
            
        Returns:
            True if scaling should occur
        """
        # Load config
        config = self._load_config()
        scaling_config = config.get('scaling', {})
        
        if not scaling_config.get('auto_scale', True):
            return False
        
        # Check game threshold
        scale_trigger_games = scaling_config.get('scale_trigger_games', 5000)
        if total_games >= scale_trigger_games and len(self.scaling_history) == 0:
            logger.info(f"Scaling triggered: games threshold reached ({total_games} >= {scale_trigger_games})")
            return True
        
        # Check ELO plateau
        plateau_threshold = scaling_config.get('scale_trigger_elo_plateau', 5.0)
        plateau_cycles_threshold = scaling_config.get('plateau_check_cycles', 3)
        
        if elo_plateau_cycles >= plateau_cycles_threshold:
            logger.info(f"Scaling triggered: ELO plateau detected ({elo_plateau_cycles} cycles)")
            return True
        
        # Check if target ELO not yet reached and games are sufficient
        if total_games >= scale_trigger_games * (len(self.scaling_history) + 1):
            if current_elo < 3500:  # Target superhuman ELO
                logger.info(f"Scaling triggered: target ELO not reached (current: {current_elo})")
                return True
        
        return False
    
    def scale_network(
        self,
        current_network: AlphaZeroNetwork,
        scale_factor: float = 1.5
    ) -> Tuple[AlphaZeroNetwork, Dict[str, any]]:
        """
        Scale network capacity by increasing filters and layers
        
        Args:
            current_network: Current network
            scale_factor: Multiplier for network capacity
            
        Returns:
            Tuple of (scaled_network, scaling_info)
        """
        logger.info(f"Scaling network with factor {scale_factor}...")
        
        # Get current architecture parameters
        current_filters = current_network.num_filters
        current_blocks = current_network.num_residual_blocks
        
        # Calculate new parameters
        new_filters = int(current_filters * scale_factor)
        new_blocks = current_blocks + 2  # Add 2 residual blocks
        
        # Ensure reasonable limits
        new_filters = min(new_filters, 512)  # Cap at 512 filters
        new_blocks = min(new_blocks, 40)  # Cap at 40 blocks
        
        logger.info(f"Scaling: {current_filters} → {new_filters} filters, "
                   f"{current_blocks} → {new_blocks} residual blocks")
        
        # Create new network with scaled architecture
        scaled_network = AlphaZeroNetwork(
            num_filters=new_filters,
            num_residual_blocks=new_blocks
        )
        
        # Transfer weights from current network (where possible)
        self._transfer_weights(current_network, scaled_network)
        
        # Scaling info
        scaling_info = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'scale_factor': scale_factor,
            'previous_filters': current_filters,
            'new_filters': new_filters,
            'previous_blocks': current_blocks,
            'new_blocks': new_blocks,
            'parameter_increase': self._calculate_param_increase(current_network, scaled_network)
        }
        
        self.scaling_history.append(scaling_info)
        
        logger.info(f"Network scaled successfully - Parameter increase: {scaling_info['parameter_increase']:.1f}%")
        
        return scaled_network, scaling_info
    
    def scale_mcts_simulations(self, current_simulations: int, scale_factor: float = 1.5) -> int:
        """
        Scale MCTS simulations proportionally to network capacity
        
        Args:
            current_simulations: Current MCTS simulation count
            scale_factor: Scaling factor
            
        Returns:
            New simulation count
        """
        new_simulations = int(current_simulations * scale_factor)
        
        # Ensure reasonable limits
        new_simulations = min(new_simulations, 3200)  # Cap at 3200
        new_simulations = max(new_simulations, 400)  # Minimum 400
        
        logger.info(f"MCTS simulations scaled: {current_simulations} → {new_simulations}")
        
        return new_simulations
    
    def update_config_scaling(
        self,
        new_filters: int,
        new_blocks: int,
        new_mcts_sims: int
    ):
        """
        Update config.json with new scaling parameters
        """
        config = self._load_config()
        
        # Update self-play MCTS simulations
        if 'self_play' in config:
            config['self_play']['mcts_simulations'] = new_mcts_sims
        
        # Update evaluation MCTS simulations
        if 'evaluation' in config:
            config['evaluation']['mcts_simulations'] = int(new_mcts_sims * 0.5)
        
        # Add network architecture info
        if 'network_architecture' not in config:
            config['network_architecture'] = {}
        
        config['network_architecture']['num_filters'] = new_filters
        config['network_architecture']['num_residual_blocks'] = new_blocks
        config['network_architecture']['last_scaled'] = datetime.now(timezone.utc).isoformat()
        
        # Save config
        self._save_config(config)
        
        logger.info("Config updated with new scaling parameters")
    
    def _transfer_weights(
        self,
        source_network: AlphaZeroNetwork,
        target_network: AlphaZeroNetwork
    ):
        """
        Transfer weights from source to target network where dimensions match
        """
        source_state = source_network.state_dict()
        target_state = target_network.state_dict()
        
        transferred = 0
        skipped = 0
        
        for name, param in source_state.items():
            if name in target_state:
                target_param = target_state[name]
                
                # Check if dimensions match
                if param.shape == target_param.shape:
                    target_state[name] = param
                    transferred += 1
                else:
                    # Partial transfer for compatible dimensions
                    if len(param.shape) == len(target_param.shape):
                        # Transfer what we can
                        slices = tuple(slice(0, min(s, t)) for s, t in zip(param.shape, target_param.shape))
                        target_state[name][slices] = param[slices]
                        transferred += 1
                    else:
                        skipped += 1
        
        target_network.load_state_dict(target_state)
        
        logger.info(f"Weight transfer complete: {transferred} layers transferred, {skipped} skipped")
    
    def _calculate_param_increase(
        self,
        old_network: AlphaZeroNetwork,
        new_network: AlphaZeroNetwork
    ) -> float:
        """Calculate percentage increase in parameters"""
        old_params = sum(p.numel() for p in old_network.parameters())
        new_params = sum(p.numel() for p in new_network.parameters())
        
        increase = ((new_params - old_params) / old_params) * 100
        return increase
    
    def _load_config(self) -> Dict:
        """Load config from file"""
        try:
            with open(self.config_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            return {}
    
    def _save_config(self, config: Dict):
        """Save config to file"""
        try:
            with open(self.config_path, 'w') as f:
                json.dump(config, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save config: {e}")
    
    def get_scaling_history(self) -> list:
        """Get scaling history"""
        return self.scaling_history
    
    def get_current_capacity(self) -> Dict[str, any]:
        """
        Get current network capacity and scaling status
        """
        config = self._load_config()
        
        # Get architecture info
        arch = config.get('network_architecture', {})
        filters = arch.get('num_filters', 256)  # Default AlphaZero config
        blocks = arch.get('num_residual_blocks', 19)
        
        # Get MCTS config
        mcts_sims = config.get('self_play', {}).get('mcts_simulations', 800)
        
        return {
            'num_filters': filters,
            'num_residual_blocks': blocks,
            'mcts_simulations': mcts_sims,
            'scaling_count': len(self.scaling_history),
            'last_scaled': arch.get('last_scaled'),
            'estimated_parameters': self._estimate_parameters(filters, blocks)
        }
    
    def _estimate_parameters(self, filters: int, blocks: int) -> int:
        """Estimate total network parameters"""
        # Rough estimation
        conv_params = (3 * 3 * 14 * filters)  # Initial conv
        residual_params = blocks * (filters * filters * 3 * 3 * 2)  # Residual blocks
        policy_params = filters * 4672  # Policy head
        value_params = filters * 256 + 256  # Value head
        
        total = conv_params + residual_params + policy_params + value_params
        return total
