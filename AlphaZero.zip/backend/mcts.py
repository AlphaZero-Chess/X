import math
import numpy as np
import chess
from typing import Dict, Optional, List, Tuple
from chess_engine import ChessEngine
from device_manager import device_manager
import time
import logging

logger = logging.getLogger(__name__)

class MCTSNode:
    """Node in the Monte Carlo Tree Search"""
    
    def __init__(self, engine: ChessEngine, parent=None, move=None, prior=0.0):
        self.engine = engine.copy()
        self.parent = parent
        self.move = move  # Move that led to this node
        self.prior = prior  # Prior probability from NN
        
        self.children = {}  # {move_uci: MCTSNode}
        self.visit_count = 0
        self.value_sum = 0.0
        self.virtual_loss = 0  # For parallel search
        self.is_expanded = False
        
    def value(self):
        """Average value of this node (Q-value)"""
        if self.visit_count == 0:
            return 0.0
        return self.value_sum / self.visit_count
    
    def is_leaf(self):
        """Check if this is a leaf node"""
        return not self.is_expanded
    
    def select_child(self, c_puct):
        """Select child with highest UCB score (PUCT formula)"""
        best_score = -float('inf')
        best_move = None
        best_child = None
        
        for move, child in self.children.items():
            ucb_score = self.ucb_score(child, c_puct)
            if ucb_score > best_score:
                best_score = ucb_score
                best_move = move
                best_child = child
        
        return best_move, best_child
    
    def ucb_score(self, child, c_puct):
        """Calculate UCB score using PUCT formula"""
        # Q(s,a) + U(s,a)
        # U(s,a) = c_puct * P(s,a) * sqrt(N(s)) / (1 + N(s,a))
        
        # Q-value with virtual loss adjustment
        q_value = child.value()
        
        # Exploration term (U)
        u_value = c_puct * child.prior * math.sqrt(self.visit_count) / (1 + child.visit_count + child.virtual_loss)
        
        return q_value + u_value
    
    def expand(self, policy_probs: Dict[str, float]):
        """Expand node with children based on policy"""
        legal_moves = self.engine.get_legal_moves()
        
        for move in legal_moves:
            if move not in self.children:
                child_engine = self.engine.copy()
                child_engine.make_move(move)
                prior = policy_probs.get(move, 0.0)
                self.children[move] = MCTSNode(child_engine, parent=self, move=move, prior=prior)
        
        self.is_expanded = True
    
    def update(self, value: float):
        """Update node statistics"""
        self.visit_count += 1
        self.value_sum += value
    
    def backpropagate(self, value: float):
        """Backpropagate value up the tree"""
        self.update(value)
        if self.parent:
            self.parent.backpropagate(-value)  # Flip value for opponent
    
    def add_virtual_loss(self):
        """Add virtual loss for parallel search"""
        self.virtual_loss += 1
    
    def remove_virtual_loss(self):
        """Remove virtual loss after search completes"""
        self.virtual_loss = max(0, self.virtual_loss - 1)


class MCTS:
    """Monte Carlo Tree Search guided by neural network with full PUCT implementation"""
    
    def __init__(self, neural_network, num_simulations=800, c_puct=1.0, 
                 dirichlet_alpha=0.3, dirichlet_epsilon=0.25, temperature=1.0,
                 device=None, batch_size=8, enable_batching=False, dynamic_depth=False,
                 move_number=0):
        """
        Initialize MCTS
        
        Args:
            neural_network: Neural network for position evaluation
            num_simulations: Number of MCTS simulations per move
            c_puct: Exploration constant in PUCT formula
            dirichlet_alpha: Dirichlet noise alpha parameter
            dirichlet_epsilon: Weight for Dirichlet noise at root
            temperature: Temperature for move selection
            device: Device for neural network (uses device_manager if None)
            batch_size: Batch size for batched evaluation
            enable_batching: Enable batched neural network evaluation
            dynamic_depth: Enable dynamic search depth based on game phase
            move_number: Current move number for dynamic depth calculation
        """
        # Validate neural network is not None
        if neural_network is None:
            raise ValueError("Neural network cannot be None for MCTS initialization")
        
        # Validate neural network has predict method
        if not hasattr(neural_network, 'predict'):
            raise ValueError("Neural network must have a 'predict' method")
        
        self.neural_network = neural_network
        self.num_simulations = num_simulations
        self.c_puct = c_puct
        self.dirichlet_alpha = dirichlet_alpha
        self.dirichlet_epsilon = dirichlet_epsilon
        self.temperature = temperature
        self.device = device or device_manager.device
        
        # Batched evaluation settings
        self.batch_size = batch_size
        self.enable_batching = enable_batching
        self.evaluation_queue = []
        
        # Dynamic depth settings
        self.dynamic_depth = dynamic_depth
        self.move_number = move_number
        
        # State management
        self.root = None
        self.inference_cache = {}  # FEN-based cache
        self.cache_hits = 0
        self.cache_misses = 0
        
        # Performance metrics
        self.total_evaluations = 0
        self.batch_evaluations = 0
    
    def reset(self, board: ChessEngine):
        """Reset MCTS with new root position"""
        self.root = MCTSNode(board)
        self.clear_cache()
        logger.debug(f"MCTS reset to position: {board.get_fen()}")
    
    def move_root(self, move: str):
        """Move root forward after a move is made"""
        if self.root and move in self.root.children:
            # Reuse existing subtree
            self.root = self.root.children[move]
            self.root.parent = None
            logger.debug(f"Root moved to: {move}")
        else:
            logger.warning(f"Move {move} not in tree, resetting")
            self.root = None
    
    def _evaluate_position(self, node: MCTSNode) -> Tuple[Dict[str, float], float]:
        """Evaluate a single position with caching"""
        # Safety check: ensure neural network is still valid
        if self.neural_network is None:
            raise RuntimeError("Neural network is None - cannot evaluate position")
        
        fen = node.engine.get_fen()
        
        # Check cache first
        if fen in self.inference_cache:
            self.cache_hits += 1
            policy, value = self.inference_cache[fen]
        else:
            self.cache_misses += 1
            board_encoding = node.engine.encode_board()
            
            try:
                policy, value = self.neural_network.predict(board_encoding)
            except AttributeError as e:
                logger.error(f"Neural network does not have predict method: {e}")
                raise RuntimeError("Neural network predict() method not available") from e
            except Exception as e:
                logger.error(f"Error during neural network prediction: {e}")
                raise
            
            # Cache the result
            self.inference_cache[fen] = (policy, value)
            self.total_evaluations += 1
        
        # Convert policy to move probabilities
        move_probs = node.engine.get_move_probabilities(policy)
        return move_probs, value
    
    def _evaluate_batch(self, nodes: List[MCTSNode]) -> List[Tuple[Dict[str, float], float]]:
        """Evaluate multiple positions in a batch for efficiency"""
        if not nodes:
            return []
        
        results = []
        uncached_nodes = []
        uncached_indices = []
        
        # Check cache for each node
        for idx, node in enumerate(nodes):
            fen = node.engine.get_fen()
            if fen in self.inference_cache:
                self.cache_hits += 1
                policy, value = self.inference_cache[fen]
                move_probs = node.engine.get_move_probabilities(policy)
                results.append((move_probs, value))
            else:
                uncached_nodes.append(node)
                uncached_indices.append(idx)
                results.append(None)  # Placeholder
        
        # Batch evaluate uncached positions
        if uncached_nodes:
            self.cache_misses += len(uncached_nodes)
            self.batch_evaluations += 1
            
            # Prepare batch
            board_encodings = [node.engine.encode_board() for node in uncached_nodes]
            
            # Batch inference
            policies, values = self.neural_network.predict_batch(board_encodings)
            
            # Process results and cache
            for i, node in enumerate(uncached_nodes):
                fen = node.engine.get_fen()
                policy = policies[i]
                value = values[i] if len(values.shape) > 0 else float(values)
                
                # Cache result
                self.inference_cache[fen] = (policy, value)
                
                # Convert to move probabilities
                move_probs = node.engine.get_move_probabilities(policy)
                
                # Insert into results at correct position
                results[uncached_indices[i]] = (move_probs, value)
            
            self.total_evaluations += len(uncached_nodes)
        
        return results
    
    def get_dynamic_simulations(self, move_number: int) -> int:
        """Calculate number of simulations based on game phase"""
        if not self.dynamic_depth:
            return self.num_simulations
        
        # Early game (moves 0-10): fewer simulations
        if move_number < 10:
            return max(400, self.num_simulations // 2)
        # End game (moves 50+): more simulations
        elif move_number >= 50:
            return int(self.num_simulations * 1.5)
        # Mid game: standard simulations
        else:
            return self.num_simulations
    
    def _add_dirichlet_noise(self, move_probs: Dict[str, float]) -> Dict[str, float]:
        """Add Dirichlet noise to root node policy for exploration"""
        if not move_probs:
            return move_probs
        
        moves = list(move_probs.keys())
        probs = np.array([move_probs[m] for m in moves])
        
        # Generate Dirichlet noise
        noise = np.random.dirichlet([self.dirichlet_alpha] * len(moves))
        
        # Mix policy with noise
        noisy_probs = (1 - self.dirichlet_epsilon) * probs + self.dirichlet_epsilon * noise
        
        # Normalize
        noisy_probs = noisy_probs / noisy_probs.sum()
        
        return {move: float(prob) for move, prob in zip(moves, noisy_probs)}
    
    def run(self, root: Optional[MCTSNode] = None, add_noise: bool = True) -> MCTSNode:
        """Run MCTS simulations from root position"""
        if root is None:
            if self.root is None:
                raise ValueError("No root node set. Call reset() first.")
            root = self.root
        else:
            self.root = root
        
        start_time = time.time()
        
        # Run simulations
        for sim in range(self.num_simulations):
            node = root
            search_path = [node]
            
            # Selection: traverse tree using PUCT
            while not node.is_leaf() and not node.engine.is_game_over():
                move, node = node.select_child(self.c_puct)
                search_path.append(node)
            
            # Expansion and evaluation
            if not node.engine.is_game_over():
                # Get NN predictions with caching
                move_probs, value = self._evaluate_position(node)
                
                # Add Dirichlet noise at root for exploration
                if add_noise and node == root and sim == 0:
                    move_probs = self._add_dirichlet_noise(move_probs)
                
                # Expand node
                node.expand(move_probs)
            else:
                # Terminal node - use game result
                result = node.engine.get_result()
                if result == "1-0":
                    value = 1.0 if node.engine.board.turn == chess.BLACK else -1.0
                elif result == "0-1":
                    value = 1.0 if node.engine.board.turn == chess.WHITE else -1.0
                else:
                    value = 0.0
            
            # Backpropagation
            for node_in_path in reversed(search_path):
                node_in_path.update(value)
                value = -value  # Flip for alternating players
        
        search_time = time.time() - start_time
        
        # Log performance metrics periodically
        if self.num_simulations >= 100 and self.num_simulations % 100 == 0:
            cache_rate = self.cache_hits / (self.cache_hits + self.cache_misses) if (self.cache_hits + self.cache_misses) > 0 else 0
            logger.debug(f"MCTS: {self.num_simulations} sims in {search_time:.2f}s, Cache hit rate: {cache_rate:.1%}")
        
        return root
    
    def get_action_probs(self, root: Optional[MCTSNode] = None, temperature: Optional[float] = None) -> Dict[str, float]:
        """Get action probabilities from root visit counts"""
        if root is None:
            root = self.root
        if root is None:
            raise ValueError("No root node available")
        
        if temperature is None:
            temperature = self.temperature
        
        # Get visit counts
        visit_counts = {move: child.visit_count for move, child in root.children.items()}
        
        if not visit_counts:
            return {}
        
        if temperature == 0:
            # Deterministic: all weight on most visited
            best_move = max(visit_counts, key=visit_counts.get)
            return {move: (1.0 if move == best_move else 0.0) for move in visit_counts}
        else:
            # Stochastic: apply temperature
            moves = list(visit_counts.keys())
            counts = np.array([visit_counts[m] for m in moves], dtype=np.float64)
            
            # Apply temperature
            if temperature != 1.0:
                counts = counts ** (1.0 / temperature)
            
            # Normalize to probabilities
            probs = counts / counts.sum()
            
            return {move: float(prob) for move, prob in zip(moves, probs)}
    
    def search(self, engine: ChessEngine, temperature: Optional[float] = None, add_noise: bool = True):
        """Run MCTS search and return best move, policy, and root value"""
        # Reset root if needed
        if self.root is None or self.root.engine.get_fen() != engine.get_fen():
            self.reset(engine)
        
        # Run simulations
        root = self.run(self.root, add_noise=add_noise)
        
        # Get action probabilities
        action_probs = self.get_action_probs(root, temperature)
        
        if not action_probs:
            # Fallback: return random legal move
            legal_moves = engine.get_legal_moves()
            if legal_moves:
                return legal_moves[0], {legal_moves[0]: 1.0}, 0.0
            return None, {}, 0.0
        
        # Select move based on probabilities
        if temperature == 0:
            best_move = max(action_probs, key=action_probs.get)
        else:
            moves = list(action_probs.keys())
            probs = np.array([action_probs[m] for m in moves])
            best_move = np.random.choice(moves, p=probs)
        
        root_value = root.value()
        
        return best_move, action_probs, root_value
    
    def get_best_move(self, engine: ChessEngine) -> Tuple[str, float]:
        """Get best move (deterministic, temperature=0)"""
        best_move, _, value = self.search(engine, temperature=0, add_noise=False)
        return best_move, value
    
    def get_performance_stats(self) -> Dict[str, any]:
        """Get MCTS performance statistics"""
        total_requests = self.cache_hits + self.cache_misses
        cache_rate = self.cache_hits / total_requests if total_requests > 0 else 0
        return {
            'cache_hits': self.cache_hits,
            'cache_misses': self.cache_misses,
            'cache_hit_rate': cache_rate,
            'cache_size': len(self.inference_cache),
            'num_simulations': self.num_simulations,
            'c_puct': self.c_puct,
            'total_evaluations': self.total_evaluations,
            'batch_evaluations': self.batch_evaluations,
            'batching_enabled': self.enable_batching,
            'dynamic_depth_enabled': self.dynamic_depth
        }
    
    def clear_cache(self):
        """Clear inference cache"""
        self.inference_cache.clear()
        self.cache_hits = 0
        self.cache_misses = 0
