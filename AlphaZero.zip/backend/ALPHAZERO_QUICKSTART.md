# AlphaZero Training - Quick Start Guide

## 🚀 Start Training

### Option 1: Via API (Recommended)

```bash
curl -X POST http://localhost:8001/api/train/start-alphazero \
  -H "Content-Type: application/json" \
  -d '{
    "max_games": 44000000,
    "max_hours": 9.0,
    "num_simulations": 800
  }'
```

### Option 2: Via Python CLI

```bash
cd /app/backend
python3 selfplay_trainer.py
```

### Option 3: Small Test Run

```bash
cd /app/backend
python3 test_alphazero_training.py
```

## 📊 Monitor Progress

### Check Status
```bash
curl http://localhost:8001/api/train/status-alphazero
```

### View Metrics
```bash
curl http://localhost:8001/api/train/metrics-alphazero
```

### Watch Logs
```bash
tail -f /data/training_logs/selfplay_44M/*.log
```

## ⏸️ Stop Training

```bash
curl -X POST http://localhost:8001/api/train/stop-alphazero
```

## 🔄 Resume Training

```bash
curl -X POST http://localhost:8001/api/train/start-alphazero \
  -H "Content-Type: application/json" \
  -d '{"resume": true}'
```

## 📁 Output Location

All training data saved to: `/data/training_logs/selfplay_44M/`

- **Checkpoints**: `/data/training_logs/selfplay_44M/checkpoints/`
- **Metrics**: `/data/training_logs/selfplay_44M/training_metrics.json`
- **Models**: `/app/backend/models/`

## ⚙️ Key Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| max_games | 44M | Stop after this many games |
| max_hours | 9.0 | Stop after this many hours |
| num_simulations | 800 | MCTS sims per move |
| resume | false | Resume from checkpoint |

## 🎯 Expected Behavior

1. **Initialization**: 5-10 seconds
2. **First games**: 10-20 seconds each (CPU) or 2-5 seconds (GPU)
3. **Training batches**: Every 25-100 games
4. **Checkpoints**: Every 30 minutes
5. **Evaluations**: Every 1000 games
6. **Model promotions**: When win rate ≥55%

## 📈 Performance

- **Multi-GPU**: 50-100 games/sec
- **Single GPU**: 5-20 games/sec
- **CPU only**: 1-5 games/sec

## ✅ Verify Installation

```bash
cd /app/backend
python3 -c "from selfplay_trainer import AlphaZeroSelfPlayTrainer; print('✓ Ready')"
```

## 🐛 Troubleshooting

### Training won't start
- Check backend is running: `sudo supervisorctl status backend`
- Check logs: `tail -n 50 /var/log/supervisor/backend.err.log`

### Out of memory
- Reduce batch_size: 256 → 128
- Reduce replay_buffer_size: 1M → 500k
- Reduce num_simulations: 800 → 400

### Low performance
- Check GPU availability: `python3 -c "import torch; print(torch.cuda.is_available())"`
- Reduce MCTS simulations for faster games
- Increase worker processes

## 📖 Full Documentation

See `ALPHAZERO_TRAINING_GUIDE.md` for complete details.
