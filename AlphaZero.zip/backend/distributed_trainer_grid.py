"""
Distributed Training Orchestration for 5000-TPU Grid
Manages training cycles across virtual TPU cluster

AlphaZero Phases: Training, Evaluation, Model Promotion
- Aggregates data from replay buffer
- Distributes training across TPU pods
- Gradient synchronization and aggregation
- Model evaluation and promotion
"""

import logging
import time
import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import torch
import torch.nn as nn

from tpu_cluster_manager import (
    TPUGridManager,
    JobType,
    get_tpu_grid
)
from neural_network import AlphaZeroNetwork, ModelManager
from trainer import AlphaZeroTrainer
from evaluator import ModelEvaluator

logger = logging.getLogger(__name__)


@dataclass
class TrainingTask:
    """Training task specification"""
    task_id: str
    num_epochs: int
    batch_size: int
    learning_rate: float
    training_data: List[Dict]
    assigned_tpus: List[int]
    priority: int = 7  # Training has higher priority than self-play
    
    # Execution tracking
    epochs_completed: int = 0
    training_loss: float = 0.0
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    status: str = "pending"


class DistributedTrainingManager:
    """
    Manages distributed training across 5000-TPU grid
    
    Architecture:
    - Splits training data across TPU pods
    - Parallel gradient computation
    - Centralized gradient aggregation
    - Model synchronization
    
    Follows AlphaZero paper training loop:
    1. Sample batch from replay buffer
    2. Compute gradients on distributed TPUs
    3. Aggregate gradients
    4. Update model parameters
    5. Synchronize model across TPUs
    
    Example:
        manager = DistributedTrainingManager(grid, num_workers=32)
        metrics = manager.train_on_data(
            training_data=positions,
            num_tpus=500,
            num_epochs=3
        )
    """
    
    def __init__(
        self,
        tpu_grid: TPUGridManager,
        num_physical_workers: int = 32,
        batch_size: int = 256,
        learning_rate: float = 0.001
    ):
        """
        Initialize distributed training manager
        
        Args:
            tpu_grid: TPU grid manager instance
            num_physical_workers: Actual worker processes
            batch_size: Training batch size
            learning_rate: Learning rate
        """
        self.tpu_grid = tpu_grid
        self.num_physical_workers = num_physical_workers
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        
        # Task management
        self.tasks: Dict[str, TrainingTask] = {}
        
        # Physical worker pool
        self.worker_pool = ThreadPoolExecutor(max_workers=num_physical_workers)
        
        # Model manager
        self.model_manager = ModelManager()
        
        # Metrics
        self.total_training_iterations = 0
        self.total_tpu_hours = 0.0
        
        logger.info(f"Distributed Training Manager initialized: "
                   f"{num_physical_workers} physical workers, "
                   f"batch_size={batch_size}, lr={learning_rate}")
    
    def train_on_data(
        self,
        training_data: List[Dict],
        num_tpus: int,
        num_epochs: int = 3,
        model_name: str = "ActiveModel",
        priority: int = 7
    ) -> Dict:
        """
        Train model on distributed TPU grid
        
        Args:
            training_data: Training positions (from replay buffer)
            num_tpus: Number of TPUs to allocate
            num_epochs: Training epochs
            model_name: Model to train
            priority: Job priority
        
        Returns:
            Training metrics
        """
        logger.info("="*80)
        logger.info(f"DISTRIBUTED TRAINING CYCLE")
        logger.info(f"Training Data: {len(training_data):,} positions")
        logger.info(f"TPU Allocation: {num_tpus:,} cores")
        logger.info(f"Epochs: {num_epochs}")
        logger.info("="*80)
        
        start_time = time.time()
        
        # Load model
        network, metadata = self.model_manager.load_model(model_name)
        if network is None:
            raise ValueError(f"Failed to load model: {model_name}")
        
        # Allocate TPUs for training
        job_id = f"training_{int(time.time())}"
        success, assigned_tpus = self.tpu_grid.allocate_tpus(
            job_id=job_id,
            job_type=JobType.TRAINING,
            num_tpus=num_tpus,
            priority=priority
        )
        
        if not success:
            logger.warning(f"Training job queued - waiting for {num_tpus} TPUs")
            # In production, would wait for allocation
            # For simulation, proceed with smaller allocation
            assigned_tpus = list(range(min(num_tpus, 64)))
        
        logger.info(f"Allocated {len(assigned_tpus)} TPUs for training")
        
        # Create training task
        task = TrainingTask(
            task_id=job_id,
            num_epochs=num_epochs,
            batch_size=self.batch_size,
            learning_rate=self.learning_rate,
            training_data=training_data,
            assigned_tpus=assigned_tpus,
            priority=priority
        )
        
        self.tasks[job_id] = task
        
        # Execute training
        metrics = self._execute_training_task(task, network)
        
        # Release TPUs
        self.tpu_grid.release_tpus(job_id)
        
        # Save trained model
        new_model_name = f"Distributed_{int(time.time())}"
        model_path = self.model_manager.save_model(
            network,
            name=new_model_name,
            metadata={
                'training_method': 'distributed_tpu_grid',
                'num_tpus': len(assigned_tpus),
                'num_positions': len(training_data),
                'num_epochs': num_epochs,
                'training_loss': metrics.get('loss', 0.0),
                'timestamp': time.time()
            }
        )
        
        total_time = time.time() - start_time
        self.total_tpu_hours += (total_time / 3600.0) * len(assigned_tpus)
        
        logger.info("="*80)
        logger.info(f"✅ DISTRIBUTED TRAINING COMPLETE")
        logger.info(f"Loss: {metrics.get('loss', 0.0):.4f}")
        logger.info(f"Time: {total_time:.2f}s")
        logger.info(f"Model: {new_model_name}")
        logger.info(f"TPU Hours: {self.total_tpu_hours:.2f}")
        logger.info("="*80)
        
        metrics['model_name'] = new_model_name
        metrics['tpu_hours'] = self.total_tpu_hours
        
        # Sync model across grid
        self.tpu_grid.sync_model(new_model_name, assigned_tpus)
        
        return metrics
    
    def _execute_training_task(
        self,
        task: TrainingTask,
        network: AlphaZeroNetwork
    ) -> Dict:
        """
        Execute training task
        
        In real distributed TPU training, this would:
        1. Split data across TPU pods
        2. Compute gradients in parallel
        3. Aggregate gradients (all-reduce)
        4. Update model parameters
        
        For simulation, we execute standard training
        but track as if distributed across logical TPUs
        
        Args:
            task: Training task
            network: Neural network to train
        
        Returns:
            Training metrics
        """
        logger.info(f"[Task-{task.task_id}] Starting training: "
                   f"{task.num_epochs} epochs, {len(task.assigned_tpus)} TPUs")
        
        task.start_time = time.time()
        task.status = "running"
        
        try:
            # Create trainer
            trainer = AlphaZeroTrainer(network, learning_rate=task.learning_rate)
            
            total_loss = 0.0
            
            # Training loop
            for epoch in range(task.num_epochs):
                epoch_start = time.time()
                
                # Train on data
                metrics = trainer.train_epoch(
                    task.training_data,
                    batch_size=task.batch_size
                )
                
                task.epochs_completed += 1
                epoch_loss = metrics.get('loss', 0.0)
                total_loss += epoch_loss
                
                epoch_time = time.time() - epoch_start
                
                logger.info(f"[Task-{task.task_id}] Epoch {epoch+1}/{task.num_epochs}: "
                           f"Loss={epoch_loss:.4f}, Time={epoch_time:.2f}s")
            
            task.training_loss = total_loss / task.num_epochs if task.num_epochs > 0 else 0.0
            task.end_time = time.time()
            task.status = "completed"
            
            duration = task.end_time - task.start_time
            logger.info(f"[Task-{task.task_id}] Training complete: "
                       f"Avg Loss={task.training_loss:.4f}, Duration={duration:.2f}s")
            
            self.total_training_iterations += task.num_epochs
            
            return {
                'loss': task.training_loss,
                'epochs': task.num_epochs,
                'duration_sec': duration,
                'tpus_used': len(task.assigned_tpus)
            }
        
        except Exception as e:
            task.status = "failed"
            logger.error(f"[Task-{task.task_id}] Training failed: {e}")
            import traceback
            traceback.print_exc()
            return {'loss': float('inf'), 'error': str(e)}
    
    def evaluate_model(
        self,
        challenger_name: str,
        champion_name: str,
        num_eval_games: int = 10,
        num_tpus: int = 100
    ) -> Tuple[Dict, bool]:
        """
        Evaluate model improvement using TPU grid
        
        Args:
            challenger_name: New model to evaluate
            champion_name: Current champion model
            num_eval_games: Number of evaluation games
            num_tpus: TPUs to allocate for evaluation
        
        Returns:
            (eval_results, should_promote)
        """
        logger.info("="*80)
        logger.info(f"MODEL EVALUATION")
        logger.info(f"Challenger: {challenger_name}")
        logger.info(f"Champion: {champion_name}")
        logger.info(f"Games: {num_eval_games}")
        logger.info("="*80)
        
        # Allocate TPUs for evaluation
        job_id = f"evaluation_{int(time.time())}"
        success, assigned_tpus = self.tpu_grid.allocate_tpus(
            job_id=job_id,
            job_type=JobType.EVALUATION,
            num_tpus=num_tpus,
            priority=6
        )
        
        # Load models
        challenger, _ = self.model_manager.load_model(challenger_name)
        champion, _ = self.model_manager.load_model(champion_name)
        
        # Run evaluation
        evaluator = ModelEvaluator(
            num_evaluation_games=num_eval_games,
            num_simulations=400,
            win_threshold=0.55
        )
        
        results, should_promote = evaluator.evaluate_models(
            challenger,
            champion,
            challenger_name,
            champion_name
        )
        
        # Release TPUs
        self.tpu_grid.release_tpus(job_id)
        
        win_rate = results.get('challenger_win_rate', 0.0)
        
        logger.info("="*80)
        logger.info(f"✅ EVALUATION COMPLETE")
        logger.info(f"Win Rate: {win_rate:.1%}")
        logger.info(f"Promote: {should_promote}")
        logger.info("="*80)
        
        return results, should_promote
    
    def get_training_status(self) -> Dict:
        """Get current training status"""
        active_tasks = [t for t in self.tasks.values() if t.status == "running"]
        completed_tasks = [t for t in self.tasks.values() if t.status == "completed"]
        
        return {
            'active_tasks': len(active_tasks),
            'completed_tasks': len(completed_tasks),
            'total_tasks': len(self.tasks),
            'total_iterations': self.total_training_iterations,
            'total_tpu_hours': round(self.total_tpu_hours, 2),
            'physical_workers': self.num_physical_workers
        }
    
    def cleanup(self):
        """Cleanup resources"""
        self.worker_pool.shutdown(wait=True)
        logger.info("Distributed training manager cleaned up")


# Global instance
_distributed_training_manager = None


def get_distributed_training_manager(
    tpu_grid: Optional[TPUGridManager] = None,
    num_workers: int = 32
) -> DistributedTrainingManager:
    """Get or create distributed training manager"""
    global _distributed_training_manager
    
    if _distributed_training_manager is None:
        if tpu_grid is None:
            tpu_grid = get_tpu_grid()
        
        _distributed_training_manager = DistributedTrainingManager(
            tpu_grid=tpu_grid,
            num_physical_workers=num_workers
        )
    
    return _distributed_training_manager
