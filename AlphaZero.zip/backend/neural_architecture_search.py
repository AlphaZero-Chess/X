"""
Neural Architecture Search (NAS) Module for AlphaZero
Implements evolutionary architecture optimization with hybrid control

Features:
- Evolutionary mutations (channels, residual blocks, FC layers, activations)
- Population-based search with elitism
- ELO-based fitness evaluation
- Bayesian fine-tuning of discovered architectures
- Rollback mechanism on performance degradation
- Architecture lineage tracking
- Integration with TPU trainer and HPO
"""

import torch
import numpy as np
import logging
import json
import time
import random
import copy
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple
from threading import Thread, Lock
from collections import deque

from neural_network import AlphaZeroNetwork, ModelManager
from trainer import AlphaZeroTrainer
from evaluator import ModelEvaluator
from device_manager import device_manager

logger = logging.getLogger(__name__)

# =====================
# Architecture Genome
# =====================

class ArchitectureGenome:
    """
    Represents a neural architecture as an evolvable genome
    """
    
    # Constraints (from user configuration)
    MAX_CHANNELS = 256
    MIN_CHANNELS = 64
    MAX_RES_BLOCKS = 10
    MIN_RES_BLOCKS = 3
    MAX_FC_LAYERS = 5
    MIN_FC_LAYERS = 1
    ACTIVATION_OPTIONS = ['relu', 'gelu', 'mish', 'swish']
    
    def __init__(self, num_channels=128, num_res_blocks=6, activation='relu', 
                 value_fc_layers=None, generation=0, parent_id=None):
        """Initialize genome with architecture parameters"""
        self.num_channels = num_channels
        self.num_res_blocks = num_res_blocks
        self.activation = activation
        self.value_fc_layers = value_fc_layers or [256]
        self.generation = generation
        self.parent_id = parent_id
        self.genome_id = self._generate_id()
        
        # Performance metrics (populated after evaluation)
        self.elo = None
        self.win_rate = None
        self.training_loss = None
        self.evaluation_games = 0
        self.fitness_score = 0.0
        
    def _generate_id(self) -> str:
        """Generate unique genome ID"""
        timestamp = int(time.time() * 1000)
        random_suffix = random.randint(1000, 9999)
        return f"arch_gen{self.generation}_{timestamp}_{random_suffix}"
    
    def mutate(self, mutation_rate: float = 0.25) -> 'ArchitectureGenome':
        """
        Apply evolutionary mutations to create offspring
        
        Mutation types:
        1. Adjust num_channels (±25%)
        2. Adjust num_res_blocks (±1-2)
        3. Change activation function
        4. Modify value FC layers (add/remove/resize)
        """
        offspring = copy.deepcopy(self)
        offspring.generation = self.generation + 1
        offspring.parent_id = self.genome_id
        offspring.genome_id = offspring._generate_id()
        
        # Reset performance metrics
        offspring.elo = None
        offspring.win_rate = None
        offspring.training_loss = None
        offspring.fitness_score = 0.0
        
        mutations_applied = []
        
        # Mutation 1: Channels (25% chance)
        if random.random() < mutation_rate:
            delta = random.choice([-32, -16, 16, 32])
            offspring.num_channels = max(self.MIN_CHANNELS, 
                                        min(self.MAX_CHANNELS, 
                                            offspring.num_channels + delta))
            mutations_applied.append(f"channels{delta:+d}")
        
        # Mutation 2: Residual blocks (25% chance)
        if random.random() < mutation_rate:
            delta = random.choice([-2, -1, 1, 2])
            offspring.num_res_blocks = max(self.MIN_RES_BLOCKS,
                                          min(self.MAX_RES_BLOCKS,
                                              offspring.num_res_blocks + delta))
            mutations_applied.append(f"blocks{delta:+d}")
        
        # Mutation 3: Activation (15% chance)
        if random.random() < (mutation_rate * 0.6):
            offspring.activation = random.choice([a for a in self.ACTIVATION_OPTIONS 
                                                 if a != offspring.activation])
            mutations_applied.append(f"act_{offspring.activation}")
        
        # Mutation 4: Value FC layers (20% chance)
        if random.random() < (mutation_rate * 0.8):
            mutation_type = random.choice(['add', 'remove', 'resize'])
            
            if mutation_type == 'add' and len(offspring.value_fc_layers) < self.MAX_FC_LAYERS:
                # Add a new FC layer
                insert_pos = random.randint(0, len(offspring.value_fc_layers))
                new_size = random.choice([128, 256, 512])
                offspring.value_fc_layers.insert(insert_pos, new_size)
                mutations_applied.append(f"fc_add_{new_size}")
            
            elif mutation_type == 'remove' and len(offspring.value_fc_layers) > self.MIN_FC_LAYERS:
                # Remove an FC layer
                remove_pos = random.randint(0, len(offspring.value_fc_layers) - 1)
                removed_size = offspring.value_fc_layers.pop(remove_pos)
                mutations_applied.append(f"fc_remove_{removed_size}")
            
            elif mutation_type == 'resize' and len(offspring.value_fc_layers) > 0:
                # Resize an existing FC layer
                resize_pos = random.randint(0, len(offspring.value_fc_layers) - 1)
                delta = random.choice([-128, -64, 64, 128])
                old_size = offspring.value_fc_layers[resize_pos]
                offspring.value_fc_layers[resize_pos] = max(64, min(512, old_size + delta))
                mutations_applied.append(f"fc_resize_{old_size}→{offspring.value_fc_layers[resize_pos]}")
        
        logger.info(f"Genome mutated: {self.genome_id} → {offspring.genome_id} | "
                   f"Mutations: {', '.join(mutations_applied) if mutations_applied else 'none'}")
        
        return offspring
    
    def crossover(self, other: 'ArchitectureGenome') -> 'ArchitectureGenome':
        """
        Perform crossover with another genome to create hybrid offspring
        """
        offspring = ArchitectureGenome(
            num_channels=random.choice([self.num_channels, other.num_channels]),
            num_res_blocks=random.choice([self.num_res_blocks, other.num_res_blocks]),
            activation=random.choice([self.activation, other.activation]),
            value_fc_layers=random.choice([self.value_fc_layers.copy(), 
                                          other.value_fc_layers.copy()]),
            generation=max(self.generation, other.generation) + 1,
            parent_id=f"{self.genome_id}+{other.genome_id}"
        )
        
        logger.info(f"Genome crossover: {self.genome_id} × {other.genome_id} → {offspring.genome_id}")
        
        return offspring
    
    def to_dict(self) -> dict:
        """Convert genome to dictionary for serialization"""
        return {
            'genome_id': self.genome_id,
            'generation': self.generation,
            'parent_id': self.parent_id,
            'architecture': {
                'num_channels': self.num_channels,
                'num_res_blocks': self.num_res_blocks,
                'activation': self.activation,
                'value_fc_layers': self.value_fc_layers
            },
            'performance': {
                'elo': self.elo,
                'win_rate': self.win_rate,
                'training_loss': self.training_loss,
                'evaluation_games': self.evaluation_games,
                'fitness_score': self.fitness_score
            }
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'ArchitectureGenome':
        """Create genome from dictionary"""
        arch = data.get('architecture', {})
        perf = data.get('performance', {})
        
        genome = cls(
            num_channels=arch.get('num_channels', 128),
            num_res_blocks=arch.get('num_res_blocks', 6),
            activation=arch.get('activation', 'relu'),
            value_fc_layers=arch.get('value_fc_layers', [256]),
            generation=data.get('generation', 0),
            parent_id=data.get('parent_id')
        )
        
        genome.genome_id = data.get('genome_id', genome.genome_id)
        genome.elo = perf.get('elo')
        genome.win_rate = perf.get('win_rate')
        genome.training_loss = perf.get('training_loss')
        genome.evaluation_games = perf.get('evaluation_games', 0)
        genome.fitness_score = perf.get('fitness_score', 0.0)
        
        return genome
    
    def create_network(self) -> AlphaZeroNetwork:
        """Instantiate AlphaZero network from this genome"""
        return AlphaZeroNetwork(
            num_channels=self.num_channels,
            num_res_blocks=self.num_res_blocks,
            activation=self.activation,
            value_fc_layers=self.value_fc_layers,
            architecture_id=self.genome_id
        )


# =====================
# NAS Controller
# =====================

class NeuralArchitectureSearchController:
    """
    Main controller for Neural Architecture Search
    Manages population evolution, evaluation, and selection
    """
    
    def __init__(
        self,
        population_size: int = 12,
        mutation_rate: float = 0.25,
        elite_ratio: float = 0.25,
        max_generations: int = 10,
        evaluation_games: int = 10,
        elo_threshold: float = 5.0,
        auto_trigger: bool = False,
        checkpoint_dir: str = "/app/backend/checkpoints/nas",
        data_dir: str = "/app/backend/data"
    ):
        """
        Initialize NAS Controller
        
        Args:
            population_size: Number of architectures per generation (default: 12)
            mutation_rate: Probability of mutations (default: 0.25)
            elite_ratio: Fraction of top performers to preserve (default: 0.25)
            max_generations: Maximum generations to evolve (default: 10)
            evaluation_games: Games per architecture for fitness evaluation
            elo_threshold: Minimum ELO gain to promote (default: 5.0)
            auto_trigger: Auto-start after HPO completion
            checkpoint_dir: Directory for NAS checkpoints
            data_dir: Directory for results and history
        """
        self.population_size = population_size
        self.mutation_rate = mutation_rate
        self.elite_ratio = elite_ratio
        self.max_generations = max_generations
        self.evaluation_games = evaluation_games
        self.elo_threshold = elo_threshold
        self.auto_trigger = auto_trigger
        
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Evolution state
        self.active = False
        self.current_generation = 0
        self.population = []
        self.best_genome = None
        self.best_elo = 1500
        self.evolution_history = []
        self.negative_delta_streak = 0  # Track consecutive negative ELO changes
        
        # Thread management
        self.evolution_thread = None
        self.state_lock = Lock()
        
        # Model manager
        self.model_manager = ModelManager()
        
        # Baseline model for evaluation
        self.baseline_network = None
        self.baseline_elo = 1500
        
        # State persistence
        self.state_file = self.data_dir / "nas_state.json"
        self.history_file = self.data_dir / "nas_history.json"
        self.report_file = Path("/app/backend/NAS_SUMMARY.md")
        
        # Load previous state if exists
        self.load_state()
        
        logger.info(f"NAS Controller initialized: Population={population_size}, "
                   f"Generations={max_generations}, Elite Ratio={elite_ratio}")
    
    def initialize_population(self, seed_genome: Optional[ArchitectureGenome] = None):
        """
        Initialize population with diverse architectures
        
        Args:
            seed_genome: Optional seed architecture (e.g., current best model)
        """
        self.population = []
        
        if seed_genome is None:
            # Create default seed from standard architecture
            seed_genome = ArchitectureGenome(
                num_channels=128,
                num_res_blocks=6,
                activation='relu',
                value_fc_layers=[256],
                generation=0
            )
        
        # Add seed genome
        self.population.append(seed_genome)
        logger.info(f"Population seed: {seed_genome.to_dict()}")
        
        # Generate diverse population through mutations
        for i in range(self.population_size - 1):
            # Create mutant with varying mutation rates for diversity
            mutant = seed_genome.mutate(mutation_rate=random.uniform(0.3, 0.6))
            self.population.append(mutant)
        
        logger.info(f"Initialized population with {len(self.population)} architectures")
    
    def evaluate_genome(self, genome: ArchitectureGenome, baseline_network: AlphaZeroNetwork) -> float:
        """
        Evaluate genome fitness by training and testing against baseline
        
        Returns:
            Fitness score (higher is better)
        """
        try:
            logger.info(f"Evaluating genome: {genome.genome_id}")
            
            # Create network from genome
            network = genome.create_network()
            
            # Quick training on small dataset (for efficiency)
            trainer = AlphaZeroTrainer(network, learning_rate=0.001)
            
            # Generate mock training data (in production, use real self-play data)
            training_data = self._generate_mock_training_data(num_samples=500)
            
            # Train for 2 epochs
            training_start = time.time()
            for epoch in range(2):
                metrics = trainer.train_epoch(training_data, batch_size=64)
            training_time = time.time() - training_start
            
            training_loss = metrics.get('loss', 1.0)
            genome.training_loss = training_loss
            
            # Evaluate against baseline
            evaluator = ModelEvaluator(
                num_evaluation_games=self.evaluation_games,
                num_simulations=400,  # Faster evaluation
                win_threshold=0.50
            )
            
            eval_results, _ = evaluator.evaluate_models(
                network,
                baseline_network,
                genome.genome_id,
                "baseline"
            )
            
            win_rate = eval_results.get('challenger_win_rate', 0.5)
            genome.win_rate = win_rate
            genome.evaluation_games = self.evaluation_games
            
            # Calculate ELO gain
            elo_delta = (win_rate - 0.5) * 400  # Simplified ELO calculation
            genome.elo = self.baseline_elo + elo_delta
            
            # Calculate fitness score
            # Multi-objective: maximize ELO, minimize loss, minimize complexity
            arch_info = network.get_architecture_info()
            complexity_penalty = arch_info['complexity_score'] * 5  # Penalize overly complex models
            
            fitness = (
                elo_delta * 1.0 +                    # ELO gain (primary objective)
                -training_loss * 20.0 +              # Training loss penalty
                -complexity_penalty                   # Complexity penalty
            )
            
            genome.fitness_score = round(fitness, 2)
            
            logger.info(f"Genome {genome.genome_id} evaluated: "
                       f"ELO={genome.elo:.0f} (Δ{elo_delta:+.1f}), "
                       f"Win Rate={win_rate:.1%}, "
                       f"Loss={training_loss:.4f}, "
                       f"Fitness={fitness:.2f}")
            
            return fitness
        
        except Exception as e:
            logger.error(f"Error evaluating genome {genome.genome_id}: {e}")
            import traceback
            traceback.print_exc()
            genome.fitness_score = -1000  # Penalize failed genomes
            return -1000
    
    def _generate_mock_training_data(self, num_samples: int = 500) -> List[Dict]:
        """Generate mock training data for quick evaluation"""
        training_data = []
        
        for i in range(num_samples):
            # Random chess position (8x8x14 channels)
            position = np.random.randn(8, 8, 14).astype(np.float32)
            
            # Random policy
            policy = {}
            num_legal_moves = np.random.randint(10, 40)
            for _ in range(num_legal_moves):
                move_idx = np.random.randint(0, 4096)
                policy[f"move_{move_idx}"] = np.random.random()
            
            # Normalize policy
            total = sum(policy.values())
            policy = {k: v/total for k, v in policy.items()}
            
            # Random value
            value = np.random.uniform(-1.0, 1.0)
            
            training_data.append({
                'position': position,
                'policy': policy,
                'value': value,
                'fen': 'mock_position'
            })
        
        return training_data
    
    def select_parents(self) -> List[ArchitectureGenome]:
        """
        Select top genomes for next generation (elitism + tournament selection)
        
        Returns:
            List of parent genomes
        """
        # Sort by fitness (descending)
        sorted_population = sorted(self.population, key=lambda g: g.fitness_score, reverse=True)
        
        # Elite selection
        num_elites = max(1, int(self.population_size * self.elite_ratio))
        elites = sorted_population[:num_elites]
        
        logger.info(f"Selected {num_elites} elite genomes for next generation")
        
        return elites
    
    def evolve_generation(self):
        """Evolve one generation: evaluate, select, reproduce"""
        logger.info("="*80)
        logger.info(f"GENERATION {self.current_generation} - STARTING")
        logger.info("="*80)
        
        # Load or create baseline network
        if self.baseline_network is None:
            try:
                from config_loader import load_config
                config = load_config()
                active_model_name = config.get('active_model', 'ActiveModel_Offline.pth')
                self.baseline_network, _ = self.model_manager.load_model(Path(active_model_name).stem)
                logger.info(f"Loaded baseline model: {active_model_name}")
            except Exception as e:
                logger.warning(f"Could not load baseline model: {e}, using random baseline")
                self.baseline_network = AlphaZeroNetwork()
        
        # Evaluate all genomes in population
        for idx, genome in enumerate(self.population):
            logger.info(f"[{idx+1}/{len(self.population)}] Evaluating {genome.genome_id}...")
            self.evaluate_genome(genome, self.baseline_network)
        
        # Find best genome in this generation
        best_genome_gen = max(self.population, key=lambda g: g.fitness_score)
        
        logger.info(f"Generation {self.current_generation} best: {best_genome_gen.genome_id} | "
                   f"Fitness={best_genome_gen.fitness_score:.2f}, ELO={best_genome_gen.elo:.0f}")
        
        # Update global best if improved
        if self.best_genome is None or best_genome_gen.elo > self.best_elo:
            elo_improvement = (best_genome_gen.elo - self.best_elo) if self.best_genome else 0
            self.best_genome = best_genome_gen
            self.best_elo = best_genome_gen.elo
            self.negative_delta_streak = 0  # Reset streak on improvement
            
            logger.info(f"🎯 NEW BEST ARCHITECTURE FOUND: ELO {self.best_elo:.0f} (Δ{elo_improvement:+.1f})")
            
            # Save best model
            best_network = best_genome_gen.create_network()
            model_name = f"NAS_Best_Gen{self.current_generation}_{int(time.time())}"
            self.model_manager.save_model(best_network, name=model_name, metadata={
                'nas_generation': self.current_generation,
                'genome_id': best_genome_gen.genome_id,
                'elo': best_genome_gen.elo,
                'fitness': best_genome_gen.fitness_score,
                'architecture': best_genome_gen.to_dict()['architecture']
            })
            logger.info(f"Best model saved: {model_name}")
        else:
            # Check for negative streak
            elo_delta = best_genome_gen.elo - self.best_elo
            if elo_delta < 0:
                self.negative_delta_streak += 1
                logger.warning(f"⚠️ ELO decreased by {abs(elo_delta):.1f} | "
                              f"Negative streak: {self.negative_delta_streak}/2")
                
                # Rollback if 2 consecutive negative generations
                if self.negative_delta_streak >= 2:
                    logger.warning("🔄 ROLLBACK TRIGGERED: 2 consecutive negative ELO changes")
                    # Re-initialize population around best genome
                    self.initialize_population(seed_genome=self.best_genome)
                    self.negative_delta_streak = 0
                    return
        
        # Record generation in history
        generation_summary = {
            'generation': self.current_generation,
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'population_size': len(self.population),
            'best_genome': best_genome_gen.to_dict(),
            'avg_fitness': np.mean([g.fitness_score for g in self.population]),
            'avg_elo': np.mean([g.elo for g in self.population if g.elo is not None])
        }
        self.evolution_history.append(generation_summary)
        
        # Save state
        self.save_state()
        
        # Selection and reproduction for next generation
        parents = self.select_parents()
        new_population = parents.copy()  # Preserve elites
        
        # Generate offspring to fill population
        while len(new_population) < self.population_size:
            # 70% mutation, 30% crossover
            if random.random() < 0.7:
                parent = random.choice(parents)
                offspring = parent.mutate(mutation_rate=self.mutation_rate)
            else:
                parent1, parent2 = random.sample(parents, 2)
                offspring = parent1.crossover(parent2)
            
            new_population.append(offspring)
        
        self.population = new_population
        self.current_generation += 1
        
        logger.info("="*80)
        logger.info(f"GENERATION {self.current_generation - 1} - COMPLETE")
        logger.info("="*80)
    
    def run_search(self):
        """Run full NAS search for max_generations"""
        try:
            with self.state_lock:
                self.active = True
            
            logger.info("="*80)
            logger.info("NEURAL ARCHITECTURE SEARCH - STARTING")
            logger.info(f"Generations: {self.max_generations}, Population: {self.population_size}")
            logger.info("="*80)
            
            # Initialize population if not already done
            if not self.population:
                self.initialize_population()
            
            # Run evolution
            while self.current_generation < self.max_generations and self.active:
                self.evolve_generation()
            
            # Final summary
            logger.info("="*80)
            logger.info("NEURAL ARCHITECTURE SEARCH - COMPLETE")
            logger.info("="*80)
            
            if self.best_genome:
                logger.info(f"Best architecture found: {self.best_genome.genome_id}")
                logger.info(f"Final ELO: {self.best_elo:.0f}")
                logger.info(f"Architecture: {self.best_genome.to_dict()['architecture']}")
            
            # Generate report
            self.generate_report()
            
            # Save final state
            self.save_state()
        
        except Exception as e:
            logger.error(f"NAS search error: {e}")
            import traceback
            traceback.print_exc()
        
        finally:
            with self.state_lock:
                self.active = False
    
    def start_search(self):
        """Start NAS search in background thread"""
        if self.active:
            logger.warning("NAS search already active")
            return False
        
        self.evolution_thread = Thread(target=self.run_search, daemon=True)
        self.evolution_thread.start()
        
        logger.info("NAS search started in background")
        return True
    
    def stop_search(self):
        """Stop NAS search gracefully"""
        if not self.active:
            logger.warning("No NAS search active")
            return False
        
        with self.state_lock:
            self.active = False
        
        logger.info("NAS search stop requested")
        return True
    
    def get_status(self) -> dict:
        """Get current NAS status"""
        with self.state_lock:
            status = {
                'active': self.active,
                'current_generation': self.current_generation,
                'max_generations': self.max_generations,
                'population_size': self.population_size,
                'progress_percent': int((self.current_generation / self.max_generations) * 100) 
                                   if self.max_generations > 0 else 0,
                'best_elo': round(self.best_elo, 1) if self.best_genome else None,
                'best_genome_id': self.best_genome.genome_id if self.best_genome else None,
                'negative_delta_streak': self.negative_delta_streak,
                'auto_trigger': self.auto_trigger
            }
            
            if self.best_genome:
                status['best_architecture'] = self.best_genome.to_dict()['architecture']
                status['best_performance'] = self.best_genome.to_dict()['performance']
        
        return status
    
    def get_evolution_history(self, limit: int = 50) -> List[dict]:
        """Get evolution history"""
        with self.state_lock:
            return self.evolution_history[-limit:]
    
    def get_best_genome(self) -> Optional[ArchitectureGenome]:
        """Get best genome found so far"""
        with self.state_lock:
            return copy.deepcopy(self.best_genome) if self.best_genome else None
    
    def save_state(self):
        """Save NAS state to disk"""
        try:
            state = {
                'current_generation': self.current_generation,
                'best_elo': self.best_elo,
                'best_genome': self.best_genome.to_dict() if self.best_genome else None,
                'population': [g.to_dict() for g in self.population],
                'negative_delta_streak': self.negative_delta_streak,
                'timestamp': datetime.now(timezone.utc).isoformat()
            }
            
            with open(self.state_file, 'w') as f:
                json.dump(state, f, indent=2)
            
            # Save history separately
            with open(self.history_file, 'w') as f:
                json.dump({
                    'evolution_history': self.evolution_history,
                    'best_genome': self.best_genome.to_dict() if self.best_genome else None
                }, f, indent=2)
            
            logger.info(f"NAS state saved: Generation {self.current_generation}")
        
        except Exception as e:
            logger.error(f"Error saving NAS state: {e}")
    
    def load_state(self):
        """Load NAS state from disk"""
        if not self.state_file.exists():
            return
        
        try:
            with open(self.state_file, 'r') as f:
                state = json.load(f)
            
            self.current_generation = state.get('current_generation', 0)
            self.best_elo = state.get('best_elo', 1500)
            self.negative_delta_streak = state.get('negative_delta_streak', 0)
            
            if state.get('best_genome'):
                self.best_genome = ArchitectureGenome.from_dict(state['best_genome'])
            
            if state.get('population'):
                self.population = [ArchitectureGenome.from_dict(g) for g in state['population']]
            
            # Load history
            if self.history_file.exists():
                with open(self.history_file, 'r') as f:
                    history_data = json.load(f)
                    self.evolution_history = history_data.get('evolution_history', [])
            
            logger.info(f"NAS state loaded: Generation {self.current_generation}, "
                       f"Best ELO: {self.best_elo:.0f}")
        
        except Exception as e:
            logger.error(f"Error loading NAS state: {e}")
    
    def generate_report(self):
        """Generate comprehensive NAS report in Markdown"""
        try:
            report_lines = [
                "# AlphaZero Neural Architecture Search Report",
                "",
                f"**Generated:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}",
                f"**Total Generations:** {self.current_generation}",
                f"**Population Size:** {self.population_size}",
                "",
                "---",
                "",
                "## Best Architecture Discovered",
                ""
            ]
            
            if self.best_genome:
                arch = self.best_genome.to_dict()['architecture']
                perf = self.best_genome.to_dict()['performance']
                
                report_lines.append("```json")
                report_lines.append(json.dumps(arch, indent=2))
                report_lines.append("```")
                report_lines.append("")
                report_lines.extend([
                    "**Performance:**",
                    f"- ELO: **{perf['elo']:.0f}**",
                    f"- Win Rate: **{perf['win_rate']:.1%}**",
                    f"- Training Loss: **{perf['training_loss']:.4f}**",
                    f"- Fitness Score: **{perf['fitness_score']:.2f}**",
                    f"- Generation: **{self.best_genome.generation}**",
                    ""
                ])
            
            # Evolution summary
            if self.evolution_history:
                report_lines.extend([
                    "---",
                    "",
                    "## Evolution Summary",
                    "",
                    "| Generation | Best ELO | Avg ELO | Avg Fitness | Best Genome ID |",
                    "|------------|----------|---------|-------------|----------------|"
                ])
                
                for gen in self.evolution_history[-20:]:  # Last 20 generations
                    best_g = gen['best_genome']
                    report_lines.append(
                        f"| {gen['generation']} | "
                        f"{best_g['performance']['elo']:.0f} | "
                        f"{gen.get('avg_elo', 0):.0f} | "
                        f"{gen.get('avg_fitness', 0):.2f} | "
                        f"{best_g['genome_id'][:16]}... |"
                    )
                
                report_lines.append("")
            
            # Architecture diversity analysis
            if self.evolution_history:
                report_lines.extend([
                    "---",
                    "",
                    "## Architecture Diversity",
                    "",
                    "Unique architecture parameters explored:",
                    ""
                ])
                
                all_channels = set()
                all_blocks = set()
                all_activations = set()
                
                for gen in self.evolution_history:
                    arch = gen['best_genome']['architecture']
                    all_channels.add(arch['num_channels'])
                    all_blocks.add(arch['num_res_blocks'])
                    all_activations.add(arch['activation'])
                
                report_lines.extend([
                    f"- **Channels:** {sorted(all_channels)}",
                    f"- **Residual Blocks:** {sorted(all_blocks)}",
                    f"- **Activations:** {sorted(all_activations)}",
                    ""
                ])
            
            # Write report
            with open(self.report_file, 'w') as f:
                f.write('\n'.join(report_lines))
            
            logger.info(f"NAS report generated: {self.report_file}")
        
        except Exception as e:
            logger.error(f"Error generating NAS report: {e}")


# Global NAS controller instance
nas_controller = None

def get_nas_controller(
    population_size: int = 12,
    max_generations: int = 10,
    auto_trigger: bool = False
) -> NeuralArchitectureSearchController:
    """Get or create global NAS controller instance"""
    global nas_controller
    
    if nas_controller is None:
        nas_controller = NeuralArchitectureSearchController(
            population_size=population_size,
            max_generations=max_generations,
            auto_trigger=auto_trigger
        )
    
    return nas_controller
