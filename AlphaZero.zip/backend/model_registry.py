"""
Model Registry - Atomic Model Promotion with Version History

Features:
- Atomic promotion: Thread-safe model replacement with rollback
- Version history: Track all model versions with complete metadata
- Best model management: Maintain current best + versioned archive
- Rollback support: Restore previous model versions
- Promotion tracking: Record who/what/when/why of each promotion

This registry ensures safe, auditable model management for the AlphaZero
training pipeline with full traceability and recovery options.
"""

import json
import logging
import shutil
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import torch

from neural_network import AlphaZeroNetwork, ModelManager

logger = logging.getLogger(__name__)


class ModelRegistry:
    """
    Manages model versions, promotions, and rollbacks with atomic operations
    
    Key Features:
    1. Atomic Promotion: Thread-safe model replacement
    2. Version History: Complete lineage tracking
    3. Rollback: Restore any previous version
    4. Metadata: Rich metadata per model version
    5. Best Model: Always maintain latest champion
    """
    
    def __init__(
        self,
        models_dir: str = "/app/backend/models",
        registry_file: str = "/app/backend/cache/model_registry.json",
        max_archive_versions: int = 10
    ):
        """
        Initialize model registry
        
        Args:
            models_dir: Directory for model weights
            registry_file: JSON file for registry metadata
            max_archive_versions: Maximum archived versions to keep
        """
        self.models_dir = Path(models_dir)
        self.models_dir.mkdir(parents=True, exist_ok=True)
        
        self.registry_file = Path(registry_file)
        self.registry_file.parent.mkdir(parents=True, exist_ok=True)
        
        self.max_archive_versions = max_archive_versions
        
        # Thread lock for atomic operations
        self.lock = threading.Lock()
        
        # Model manager for save/load
        self.model_manager = ModelManager(model_dir=str(self.models_dir))
        
        # Load registry
        self.registry = self._load_registry()
        
        logger.info(f"ModelRegistry initialized: {len(self.registry.get('versions', []))} versions")
    
    def _load_registry(self) -> Dict:
        """Load registry from disk"""
        if self.registry_file.exists():
            try:
                with open(self.registry_file, 'r') as f:
                    registry = json.load(f)
                logger.info(f"Registry loaded: {len(registry.get('versions', []))} versions")
                return registry
            except Exception as e:
                logger.error(f"Failed to load registry: {e}")
        
        # Initialize new registry
        return {
            'current_best': {
                'name': 'model_v0',
                'version': 0,
                'elo': 1500.0,
                'promoted_at': datetime.now(timezone.utc).isoformat(),
                'promoted_by': 'initialization',
                'file': 'model_v0.pt'
            },
            'versions': [],
            'promotion_history': [],
            'rollback_history': []
        }
    
    def _save_registry(self):
        """Save registry to disk (atomic write)"""
        try:
            # Write to temp file first
            temp_file = self.registry_file.with_suffix('.tmp')
            with open(temp_file, 'w') as f:
                json.dump(self.registry, f, indent=2)
            
            # Atomic rename
            temp_file.replace(self.registry_file)
            
            logger.debug("Registry saved successfully")
        except Exception as e:
            logger.error(f"Failed to save registry: {e}")
    
    def promote_model(
        self,
        model: AlphaZeroNetwork,
        model_name: str,
        elo: float,
        metadata: Optional[Dict] = None,
        promoted_by: str = "auto_threshold",
        reason: str = "Evaluation passed promotion criteria"
    ) -> Tuple[bool, str]:
        """
        Atomically promote a model to become the new champion
        
        Args:
            model: Neural network model to promote
            model_name: Name for this model version
            elo: ELO rating of the model
            metadata: Additional metadata (cycle info, metrics, etc.)
            promoted_by: Source of promotion (auto_threshold, manual, etc.)
            reason: Human-readable reason for promotion
        
        Returns:
            (success: bool, message: str)
        """
        with self.lock:
            try:
                logger.info(f"Promoting model: {model_name} (ELO: {elo:.0f})")
                
                # Get current best
                current_best = self.registry['current_best']
                
                # Prepare metadata
                if metadata is None:
                    metadata = {}
                
                promotion_metadata = {
                    **metadata,
                    'version': len(self.registry['versions']),
                    'elo': elo,
                    'promoted_at': datetime.now(timezone.utc).isoformat(),
                    'promoted_by': promoted_by,
                    'promotion_reason': reason,
                    'previous_champion': current_best['name'],
                    'previous_champion_elo': current_best['elo']
                }
                
                # Save model weights
                model_file = self.model_manager.save_model(
                    model,
                    name=model_name,
                    metadata=promotion_metadata
                )
                
                # Archive current best (if not initial model)
                if current_best['version'] > 0:
                    self.registry['versions'].append(current_best.copy())
                
                # Update current best
                self.registry['current_best'] = {
                    'name': model_name,
                    'version': promotion_metadata['version'],
                    'elo': elo,
                    'promoted_at': promotion_metadata['promoted_at'],
                    'promoted_by': promoted_by,
                    'file': f"{model_name}.pt",
                    'metadata': promotion_metadata
                }
                
                # Record promotion
                self.registry['promotion_history'].append({
                    'model_name': model_name,
                    'version': promotion_metadata['version'],
                    'elo': elo,
                    'promoted_at': promotion_metadata['promoted_at'],
                    'promoted_by': promoted_by,
                    'reason': reason,
                    'previous_champion': current_best['name'],
                    'elo_improvement': elo - current_best['elo']
                })
                
                # Cleanup old archived versions
                self._cleanup_old_versions()
                
                # Save registry
                self._save_registry()
                
                # Create best_model symlink
                self._create_best_model_symlink(model_name)
                
                logger.info(f"✅ Model promoted: {model_name} (v{promotion_metadata['version']}) "
                           f"ELO: {current_best['elo']:.0f} → {elo:.0f} (Δ {elo - current_best['elo']:+.0f})")
                
                return True, f"Model {model_name} promoted successfully"
            
            except Exception as e:
                logger.error(f"Failed to promote model: {e}")
                import traceback
                traceback.print_exc()
                return False, f"Promotion failed: {str(e)}"
    
    def rollback_to_version(
        self,
        version: int,
        rolled_back_by: str = "manual"
    ) -> Tuple[bool, str]:
        """
        Rollback to a previous model version
        
        Args:
            version: Version number to rollback to
            rolled_back_by: Who initiated the rollback
        
        Returns:
            (success: bool, message: str)
        """
        with self.lock:
            try:
                logger.info(f"Rolling back to version {version}")
                
                # Find target version
                target_version = None
                
                # Check if it's the current version
                if self.registry['current_best']['version'] == version:
                    return False, "Already at requested version"
                
                # Search in archived versions
                for v in self.registry['versions']:
                    if v['version'] == version:
                        target_version = v
                        break
                
                if target_version is None:
                    return False, f"Version {version} not found in registry"
                
                # Load target model
                target_model, target_metadata = self.model_manager.load_model(target_version['name'])
                
                if target_model is None:
                    return False, f"Model file for version {version} not found"
                
                # Save current best to versions before rollback
                current_best = self.registry['current_best']
                self.registry['versions'].append(current_best.copy())
                
                # Restore target version as current best
                self.registry['current_best'] = target_version.copy()
                self.registry['current_best']['rolled_back_at'] = datetime.now(timezone.utc).isoformat()
                self.registry['current_best']['rolled_back_by'] = rolled_back_by
                
                # Record rollback
                self.registry['rollback_history'].append({
                    'from_version': current_best['version'],
                    'to_version': version,
                    'rolled_back_at': datetime.now(timezone.utc).isoformat(),
                    'rolled_back_by': rolled_back_by,
                    'from_model': current_best['name'],
                    'to_model': target_version['name']
                })
                
                # Save registry
                self._save_registry()
                
                # Update best_model symlink
                self._create_best_model_symlink(target_version['name'])
                
                logger.info(f"✅ Rolled back: {current_best['name']} (v{current_best['version']}) → "
                           f"{target_version['name']} (v{version})")
                
                return True, f"Rolled back to version {version} ({target_version['name']})"
            
            except Exception as e:
                logger.error(f"Failed to rollback: {e}")
                import traceback
                traceback.print_exc()
                return False, f"Rollback failed: {str(e)}"
    
    def get_current_best(self) -> Tuple[Optional[AlphaZeroNetwork], Dict]:
        """
        Get current best model
        
        Returns:
            (model, metadata)
        """
        current_best = self.registry['current_best']
        model, metadata = self.model_manager.load_model(current_best['name'])
        return model, current_best
    
    def get_version_info(self, version: int) -> Optional[Dict]:
        """Get information about a specific version"""
        # Check current best
        if self.registry['current_best']['version'] == version:
            return self.registry['current_best']
        
        # Check archived versions
        for v in self.registry['versions']:
            if v['version'] == version:
                return v
        
        return None
    
    def list_all_versions(self) -> List[Dict]:
        """List all model versions (current + archived)"""
        versions = [self.registry['current_best']]
        versions.extend(self.registry['versions'])
        
        # Sort by version number
        versions.sort(key=lambda v: v['version'], reverse=True)
        
        return versions
    
    def get_promotion_history(self) -> List[Dict]:
        """Get promotion history"""
        return self.registry.get('promotion_history', [])
    
    def get_rollback_history(self) -> List[Dict]:
        """Get rollback history"""
        return self.registry.get('rollback_history', [])
    
    def get_registry_summary(self) -> Dict:
        """Get summary of registry state"""
        return {
            'current_best': self.registry['current_best'],
            'total_versions': len(self.registry['versions']) + 1,  # +1 for current
            'total_promotions': len(self.registry['promotion_history']),
            'total_rollbacks': len(self.registry['rollback_history']),
            'max_elo': max(
                [self.registry['current_best']['elo']] + 
                [v['elo'] for v in self.registry['versions']]
            ),
            'registry_file': str(self.registry_file),
            'models_dir': str(self.models_dir)
        }
    
    def _cleanup_old_versions(self):
        """Remove old archived versions beyond max_archive_versions"""
        if len(self.registry['versions']) > self.max_archive_versions:
            # Sort by version (oldest first)
            sorted_versions = sorted(self.registry['versions'], key=lambda v: v['version'])
            
            # Keep only recent versions
            versions_to_keep = sorted_versions[-self.max_archive_versions:]
            versions_to_remove = sorted_versions[:-self.max_archive_versions]
            
            # Delete old model files
            for version in versions_to_remove:
                try:
                    model_file = self.models_dir / version['file']
                    if model_file.exists():
                        model_file.unlink()
                        logger.info(f"Cleaned up old model: {version['name']}")
                except Exception as e:
                    logger.warning(f"Failed to cleanup {version['name']}: {e}")
            
            self.registry['versions'] = versions_to_keep
            logger.info(f"Cleaned up {len(versions_to_remove)} old model versions")
    
    def _create_best_model_symlink(self, model_name: str):
        """Create/update best_model.pt symlink"""
        try:
            best_model_link = self.models_dir / "best_model.pt"
            target_model = self.models_dir / f"{model_name}.pt"
            
            # Remove existing symlink/file
            if best_model_link.exists() or best_model_link.is_symlink():
                best_model_link.unlink()
            
            # Create symlink or copy
            try:
                best_model_link.symlink_to(target_model.name)
            except OSError:
                # Symlinks might not be supported, copy instead
                shutil.copy(target_model, best_model_link)
            
            logger.debug(f"Best model link updated: {model_name}")
        
        except Exception as e:
            logger.warning(f"Failed to create best_model symlink: {e}")
    
    def should_promote(
        self,
        challenger_win_rate: float,
        elo_delta: float,
        win_threshold: float = 0.55,
        elo_threshold: float = 50.0
    ) -> Tuple[bool, str]:
        """
        Check if model should be promoted based on thresholds
        
        Args:
            challenger_win_rate: Win rate of challenger
            elo_delta: ELO improvement
            win_threshold: Minimum win rate for promotion
            elo_threshold: Minimum ELO improvement for promotion
        
        Returns:
            (should_promote: bool, reason: str)
        """
        win_rate_pass = challenger_win_rate >= win_threshold
        elo_pass = elo_delta >= elo_threshold
        
        if win_rate_pass and elo_pass:
            return True, f"Win rate {challenger_win_rate:.1%} >= {win_threshold:.1%} AND ELO Δ {elo_delta:+.0f} >= {elo_threshold:.0f}"
        elif win_rate_pass:
            return True, f"Win rate {challenger_win_rate:.1%} >= {win_threshold:.1%}"
        elif elo_pass:
            return True, f"ELO Δ {elo_delta:+.0f} >= {elo_threshold:.0f}"
        else:
            return False, f"Win rate {challenger_win_rate:.1%} < {win_threshold:.1%} AND ELO Δ {elo_delta:+.0f} < {elo_threshold:.0f}"


# Global instance
_model_registry = None


def get_model_registry() -> ModelRegistry:
    """Get or create global model registry"""
    global _model_registry
    
    if _model_registry is None:
        _model_registry = ModelRegistry()
    
    return _model_registry


def reset_model_registry():
    """Reset global model registry (for testing)"""
    global _model_registry
    _model_registry = None
