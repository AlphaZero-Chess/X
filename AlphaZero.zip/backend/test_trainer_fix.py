"""
Test script to validate the trainer.py position shape fix
"""
import sys
sys.path.insert(0, '/app/backend')

import numpy as np
from trainer import AlphaZeroTrainer
from neural_network import AlphaZeroNetwork

def test_position_validation():
    """Test that trainer correctly handles various position formats"""
    
    print("Testing position validation in AlphaZeroTrainer...")
    
    # Create a simple network
    network = AlphaZeroNetwork()
    trainer = AlphaZeroTrainer(network, learning_rate=0.001)
    
    # Test data with various formats
    test_cases = [
        {
            "name": "Valid numpy array",
            "data": [{
                "position": np.zeros((8, 8, 14), dtype=np.float32),
                "policy": {"e2e4": 1.0},
                "value": 0.5
            }],
            "should_work": True
        },
        {
            "name": "Valid list (from MongoDB)",
            "data": [{
                "position": np.zeros((8, 8, 14), dtype=np.float32).tolist(),
                "policy": {"e2e4": 1.0},
                "value": 0.5
            }],
            "should_work": True
        },
        {
            "name": "Mixed valid positions",
            "data": [
                {
                    "position": np.zeros((8, 8, 14), dtype=np.float32),
                    "policy": {"e2e4": 1.0},
                    "value": 0.5
                },
                {
                    "position": np.ones((8, 8, 14), dtype=np.float32).tolist(),
                    "policy": {"d2d4": 1.0},
                    "value": -0.3
                }
            ],
            "should_work": True
        },
        {
            "name": "Invalid shape (should be filtered out)",
            "data": [{
                "position": np.zeros((8, 8, 10), dtype=np.float32),  # Wrong shape
                "policy": {"e2e4": 1.0},
                "value": 0.5
            }],
            "should_work": False  # Should produce empty batch
        },
        {
            "name": "None position (should be filtered out)",
            "data": [{
                "position": None,
                "policy": {"e2e4": 1.0},
                "value": 0.5
            }],
            "should_work": False
        },
        {
            "name": "Mixed valid and invalid (valid ones should work)",
            "data": [
                {
                    "position": np.zeros((8, 8, 14), dtype=np.float32),
                    "policy": {"e2e4": 1.0},
                    "value": 0.5
                },
                {
                    "position": None,  # Invalid
                    "policy": {"d2d4": 1.0},
                    "value": -0.3
                },
                {
                    "position": np.ones((8, 8, 14), dtype=np.float32),
                    "policy": {"e2e3": 1.0},
                    "value": 0.2
                }
            ],
            "should_work": True  # Should filter out None and keep valid ones
        }
    ]
    
    passed = 0
    failed = 0
    
    for i, test_case in enumerate(test_cases):
        print(f"\nTest {i+1}: {test_case['name']}")
        try:
            batches = trainer.prepare_batch(test_case['data'], batch_size=32)
            
            if test_case['should_work']:
                if len(batches) > 0:
                    batch = batches[0]
                    print(f"  ✓ Batch created successfully")
                    print(f"    - Positions shape: {batch['positions'].shape}")
                    print(f"    - Policies shape: {batch['policies'].shape}")
                    print(f"    - Values shape: {batch['values'].shape}")
                    passed += 1
                else:
                    print(f"  ✗ Expected batch but got empty result")
                    failed += 1
            else:
                if len(batches) == 0:
                    print(f"  ✓ Correctly filtered out invalid data (empty batch)")
                    passed += 1
                else:
                    print(f"  ✗ Should have filtered out invalid data")
                    failed += 1
                    
        except Exception as e:
            print(f"  ✗ Error: {e}")
            if test_case['should_work']:
                failed += 1
            else:
                # If it should fail and it raised an error, that's also acceptable
                print(f"  ℹ Error was expected for invalid data")
                passed += 1
    
    print(f"\n{'='*60}")
    print(f"Test Results: {passed} passed, {failed} failed out of {len(test_cases)} tests")
    print(f"{'='*60}")
    
    return failed == 0

if __name__ == "__main__":
    success = test_position_validation()
    sys.exit(0 if success else 1)
