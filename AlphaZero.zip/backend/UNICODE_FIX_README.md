# Unicode Encoding Fix for Windows Environments

## Problem Summary
Windows console environments use `cp1252` encoding by default, which does not support emoji characters or certain Unicode symbols. This caused `UnicodeEncodeError` when logging messages containing emojis like 📥, 🚀, ✅, etc.

## Error Details
```
UnicodeEncodeError: 'charmap' codec can't encode character '\U0001f4e5' in position 33: character maps to <undefined>
```

## Solution Implemented

We implemented a **comprehensive multi-layered fix** that addresses the encoding issue at three levels:

### 1. Global Stream Encoding (Module Level)
Added at the top of `distributed_selfplay_v2.py` (lines 22-34):

```python
import sys
import io

# Fix for Windows console encoding issues with emoji characters
if sys.platform == 'win32':
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding='utf-8', errors='replace')
    except Exception:
        pass
```

**What it does:**
- Detects Windows platform automatically
- Wraps stdout and stderr with UTF-8 encoding
- Uses `errors='replace'` to gracefully handle any unsupported characters
- Fails silently if wrapping is not possible

### 2. File Handler UTF-8 Encoding
Updated in `_setup_worker_logger` function (line 51):

```python
fh = logging.FileHandler(log_path, mode='a', encoding='utf-8')
```

**What it does:**
- Forces UTF-8 encoding for log files
- Ensures emojis are properly written to worker log files
- Makes log files portable across different systems

### 3. Console Handler UTF-8 Stream (Windows-specific)
Updated in `_setup_worker_logger` function (lines 56-62):

```python
if sys.platform == 'win32':
    console_stream = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    ch = logging.StreamHandler(console_stream)
else:
    ch = logging.StreamHandler()
```

**What it does:**
- Creates a UTF-8 wrapped stream specifically for Windows console output
- Non-Windows systems use default handler (already UTF-8 compatible)
- Ensures worker process logging works correctly

### 4. Main CLI Logging Configuration
Updated in the `__main__` section (lines 596-604):

```python
log_handler = logging.StreamHandler(sys.stdout)
log_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[log_handler]
)
```

**What it does:**
- Uses the already-wrapped stdout for logging
- Ensures consistent UTF-8 encoding in CLI mode

## Benefits of This Approach

### ✅ Advantages:
1. **No code changes required**: All emoji log messages remain unchanged
2. **Cross-platform compatible**: Works on Windows, Linux, and macOS
3. **Graceful degradation**: Falls back safely if encoding cannot be changed
4. **Comprehensive coverage**: Fixes all logging scenarios (console, files, workers)
5. **Future-proof**: Handles all Unicode characters, not just emojis

### 🎯 What Was Fixed:
- Worker process console logging (main issue)
- Worker log file writing
- Main process logging
- CLI script logging
- Multi-process queue communication (already supported)

## Testing

A test script `test_unicode_fix.py` has been created to verify the fix:

```bash
python backend/test_unicode_fix.py
```

Expected output: All emoji characters should display correctly without errors.

## Alternative Approaches (Not Used)

### Option B: Remove Emojis
**Pros:** Simple, guaranteed to work
**Cons:** Loses visual clarity and user-friendly logging

### Option C: File Handler Only
**Pros:** Fixes file logging
**Cons:** Doesn't fix console output where the original error occurred

## Compatibility

- **Python:** 3.6+ (uses modern io.TextIOWrapper)
- **Windows:** 7, 8, 10, 11 (all versions)
- **Linux/macOS:** Works without modifications (UTF-8 by default)

## Files Modified

1. `/app/backend/distributed_selfplay_v2.py` - Main fix implementation
2. `/app/backend/test_unicode_fix.py` - Test verification script
3. `/app/backend/UNICODE_FIX_README.md` - This documentation

## Usage on Windows

Simply run your distributed self-play as normal:

```bash
python backend/distributed_selfplay_v2.py --mode smoke
python backend/distributed_selfplay_v2.py --mode scale --num_games 100
```

The encoding fixes are applied automatically on Windows systems.

## Technical Notes

### Why This Works:
- **cp1252** (Windows default) supports only Western European characters
- **UTF-8** supports all Unicode characters including emojis (U+1F4E5, etc.)
- Python's `io.TextIOWrapper` allows runtime encoding changes
- The `errors='replace'` parameter prevents crashes on unsupported chars

### Error Handling:
- If wrapping fails (rare), the script continues without UTF-8 forcing
- This allows the script to work even in restricted environments
- Individual emoji logs may still fail, but won't crash the worker

## Related Issues

This fix resolves:
- UnicodeEncodeError in worker_generate_games (line 225)
- All emoji logging throughout the distributed self-play system
- Potential encoding issues in other Python modules using emojis

## Future Considerations

For maximum compatibility, consider:
- Using environment variable `PYTHONIOENCODING=utf-8` before script execution
- Adding Windows-specific batch files that set encoding
- Documenting UTF-8 console setup for users
