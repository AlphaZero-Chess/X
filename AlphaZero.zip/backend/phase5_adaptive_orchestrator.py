"""
Phase 5 Adaptive Orchestrator - Autonomous Evolution Engine
Implements continuous long-cycle training with self-improvement

Features:
- Autonomous training cycles (indefinite until stopped)
- Stagnation detection (ΔELO < 25 over 5 cycles)
- Auto-trigger HPO when loss stagnates
- Auto-trigger NAS when performance stagnates
- Model evolution tracking and lineage
- Adaptive hyperparameter mutation
- Rollback on negative performance

Architecture:
    Cycle → Train → Evaluate → Promote
         ↓ (stagnation detected)
    HPO/NAS → Optimize → Resume Cycles
"""

import asyncio
import time
import logging
import uuid
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timezone
from dataclasses import dataclass
from pathlib import Path
from enum import Enum
import numpy as np

from tpu_training_orchestrator import TPUTrainingOrchestrator
from evolution_tracker import get_evolution_tracker, EvolutionTracker
from hyperparam_optimizer import get_hpo_optimizer, HyperparameterOptimizer
from neural_architecture_search import get_nas_controller, NeuralArchitectureSearchController
from model_registry import get_model_registry
from neural_network import AlphaZeroNetwork, ModelManager

logger = logging.getLogger(__name__)


class EvolutionPhase(str, Enum):
    """Evolution phases"""
    IDLE = "idle"
    TRAINING_CYCLE = "training_cycle"
    STAGNATION_ANALYSIS = "stagnation_analysis"
    HPO_OPTIMIZATION = "hpo_optimization"
    NAS_EVOLUTION = "nas_evolution"
    ROLLBACK = "rollback"
    COMPLETED = "completed"
    FAILED = "failed"


class StagnationType(str, Enum):
    """Types of stagnation detected"""
    NONE = "none"
    LOSS_PLATEAU = "loss_plateau"
    ELO_PLATEAU = "elo_plateau"
    WIN_RATE_PLATEAU = "win_rate_plateau"


@dataclass
class EvolutionConfig:
    """Configuration for adaptive evolution"""
    # Cycle parameters
    num_selfplay_games: int = 1000
    num_tpus_selfplay: int = 500
    num_tpus_training: int = 100
    num_training_epochs: int = 3
    num_eval_games: int = 20
    batch_size: int = 256
    learning_rate: float = 0.001
    
    # Stagnation detection
    stagnation_window: int = 5  # Cycles to analyze
    elo_threshold: float = 25.0  # Minimum ELO improvement required
    
    # Optimization triggers
    enable_hpo: bool = True
    enable_nas: bool = True
    auto_decide_optimization: bool = True  # Let system decide HPO vs NAS
    
    # HPO configuration
    hpo_max_trials: int = 10
    hpo_evaluation_games: int = 10
    
    # NAS configuration
    nas_population_size: int = 8
    nas_max_generations: int = 5
    
    # Limits
    max_cycles: Optional[int] = None  # None = indefinite
    max_hours: Optional[float] = None  # None = indefinite


class Phase5AdaptiveOrchestrator:
    """
    Phase 5 Adaptive Orchestrator
    Manages autonomous evolution with HPO and NAS integration
    """
    
    def __init__(
        self,
        config: EvolutionConfig = None,
        work_dir: str = "/app/backend/cache/phase5_evolution"
    ):
        """Initialize Phase 5 Adaptive Orchestrator"""
        
        self.config = config or EvolutionConfig()
        self.work_dir = Path(work_dir)
        self.work_dir.mkdir(parents=True, exist_ok=True)
        
        # Core components
        self.tpu_orchestrator = TPUTrainingOrchestrator()
        self.evolution_tracker = get_evolution_tracker()
        self.model_registry = get_model_registry()
        self.model_manager = ModelManager()
        
        # Optimization components (lazy initialization)
        self.hpo_optimizer: Optional[HyperparameterOptimizer] = None
        self.nas_controller: Optional[NeuralArchitectureSearchController] = None
        
        # State
        self.is_running = False
        self.current_phase = EvolutionPhase.IDLE
        self.evolution_session_id = None
        self.start_time = None
        self.total_cycles = 0
        self.cycles_history = []
        
        # Performance tracking
        self.best_elo = 1500.0
        self.best_model_id = None
        self.stagnation_streak = 0
        self.last_optimization_cycle = 0
        
        # Current cycle metrics
        self.current_cycle_metrics = {}
        
        logger.info("Phase 5 Adaptive Orchestrator initialized")
    
    async def start_evolution(self, config: EvolutionConfig = None) -> str:
        """
        Start autonomous evolution
        
        Args:
            config: Evolution configuration (optional, uses default if None)
        
        Returns:
            evolution_session_id
        """
        if self.is_running:
            raise RuntimeError("Evolution already running")
        
        if config:
            self.config = config
        
        self.evolution_session_id = f"evolution_{uuid.uuid4().hex[:8]}"
        self.is_running = True
        self.start_time = time.time()
        self.total_cycles = 0
        self.current_phase = EvolutionPhase.IDLE
        
        logger.info("="*80)
        logger.info(f"PHASE 5 EVOLUTION STARTED - Session: {self.evolution_session_id}")
        logger.info(f"Config: {self.config.num_selfplay_games} games/cycle, "
                   f"Stagnation threshold: ΔELO ≥ {self.config.elo_threshold} over {self.config.stagnation_window} cycles")
        logger.info(f"Optimization: HPO={'Enabled' if self.config.enable_hpo else 'Disabled'}, "
                   f"NAS={'Enabled' if self.config.enable_nas else 'Disabled'}")
        logger.info("="*80)
        
        # Register initial model in evolution tracker
        current_model, current_metadata = self.model_manager.load_model(
            self.tpu_orchestrator.current_model_name
        )
        
        if current_model:
            self.best_model_id = self.evolution_tracker.register_model(
                model_name=self.tpu_orchestrator.current_model_name,
                elo=self.tpu_orchestrator.current_model_elo,
                training_loss=0.0,
                win_rate=0.5,
                num_parameters=sum(p.numel() for p in current_model.parameters()),
                parent_id=None,
                creation_method="initial_model",
                mutations=[],
                positions_trained=0,
                training_time_seconds=0,
                games_played=0
            )
            self.best_elo = self.tpu_orchestrator.current_model_elo
        
        # Run evolution loop in background
        asyncio.create_task(self._evolution_loop())
        
        return self.evolution_session_id
    
    async def _evolution_loop(self):
        """Main evolution loop"""
        try:
            while self.is_running:
                # Check termination conditions
                if self._should_terminate():
                    logger.info("Evolution termination condition met")
                    break
                
                self.total_cycles += 1
                
                logger.info("="*80)
                logger.info(f"EVOLUTION CYCLE #{self.total_cycles}")
                logger.info("="*80)
                
                # Phase 1: Training Cycle
                self.current_phase = EvolutionPhase.TRAINING_CYCLE
                cycle_success = await self._run_training_cycle()
                
                if not cycle_success:
                    logger.error("Training cycle failed")
                    continue
                
                # Phase 2: Stagnation Analysis
                self.current_phase = EvolutionPhase.STAGNATION_ANALYSIS
                stagnation_type = await self._analyze_stagnation()
                
                # Phase 3: Optimization (if stagnation detected)
                if stagnation_type != StagnationType.NONE:
                    logger.info(f"Stagnation detected: {stagnation_type.value}")
                    
                    # Decide optimization strategy
                    optimization_success = await self._handle_stagnation(stagnation_type)
                    
                    if optimization_success:
                        logger.info("Optimization successful, resuming training cycles")
                        self.stagnation_streak = 0
                        self.last_optimization_cycle = self.total_cycles
                    else:
                        logger.warning("Optimization failed, continuing with current model")
                        self.stagnation_streak += 1
                else:
                    logger.info("No stagnation detected, continuing training cycles")
                    self.stagnation_streak = 0
                
                # Brief pause between cycles
                await asyncio.sleep(2)
            
            # Evolution completed
            self.current_phase = EvolutionPhase.COMPLETED
            logger.info("="*80)
            logger.info("PHASE 5 EVOLUTION COMPLETED")
            logger.info(f"Total Cycles: {self.total_cycles}")
            logger.info(f"Best ELO: {self.best_elo:.0f}")
            logger.info(f"Session Duration: {(time.time() - self.start_time) / 3600:.2f} hours")
            logger.info("="*80)
        
        except Exception as e:
            logger.error(f"Evolution loop error: {e}")
            import traceback
            traceback.print_exc()
            self.current_phase = EvolutionPhase.FAILED
        
        finally:
            self.is_running = False
    
    async def _run_training_cycle(self) -> bool:
        """
        Run one complete training cycle
        
        Returns:
            success (bool)
        """
        try:
            logger.info(f"Starting training cycle with current model: {self.tpu_orchestrator.current_model_name}")
            
            cycle_start = time.time()
            
            # Start TPU training cycle
            cycle = await self.tpu_orchestrator.start_training_cycle(
                num_selfplay_games=self.config.num_selfplay_games,
                num_tpus_selfplay=self.config.num_tpus_selfplay,
                num_tpus_training=self.config.num_tpus_training,
                num_training_epochs=self.config.num_training_epochs,
                num_eval_games=self.config.num_eval_games,
                batch_size=self.config.batch_size,
                learning_rate=self.config.learning_rate,
                continuous=False  # We control the loop
            )
            
            # Wait for cycle completion
            while self.tpu_orchestrator.is_running and self.is_running:
                await asyncio.sleep(5)
            
            cycle_duration = time.time() - cycle_start
            
            # Get cycle results
            cycle_status = self.tpu_orchestrator.get_cycle_status()
            
            if cycle_status is None:
                logger.error("No cycle status available")
                return False
            
            cycle_data = cycle_status['cycle']
            
            # Extract metrics
            positions_generated = cycle_data['positions_generated']
            training_loss = cycle_data['training_loss']
            evaluation_win_rate = cycle_data['evaluation_win_rate']
            elo_delta = cycle_data['elo_delta']
            model_promoted = cycle_data['model_promoted']
            
            # Update best metrics
            current_elo = self.tpu_orchestrator.current_model_elo
            if current_elo > self.best_elo:
                self.best_elo = current_elo
            
            # Register model in evolution tracker (if promoted)
            if model_promoted:
                new_model_name = self.tpu_orchestrator.current_model_name
                new_model, _ = self.model_manager.load_model(new_model_name)
                
                if new_model:
                    model_id = self.evolution_tracker.register_model(
                        model_name=new_model_name,
                        elo=current_elo,
                        training_loss=training_loss,
                        win_rate=evaluation_win_rate,
                        num_parameters=sum(p.numel() for p in new_model.parameters()),
                        parent_id=self.best_model_id,
                        creation_method="training_cycle",
                        mutations=[f"cycle_{self.total_cycles}"],
                        positions_trained=positions_generated,
                        training_time_seconds=cycle_duration,
                        games_played=self.config.num_selfplay_games
                    )
                    
                    self.best_model_id = model_id
            
            # Record cycle in evolution tracker
            challenger_model_id = self.best_model_id if model_promoted else "challenger_rejected"
            champion_model_id = self.best_model_id or "unknown"
            
            self.evolution_tracker.record_evolution_cycle(
                cycle_number=self.total_cycles,
                selfplay_games=self.config.num_selfplay_games,
                positions_generated=positions_generated,
                training_loss=training_loss,
                training_epochs=self.config.num_training_epochs,
                challenger_model_id=challenger_model_id,
                champion_model_id=champion_model_id,
                evaluation_win_rate=evaluation_win_rate,
                elo_delta=elo_delta,
                promoted=model_promoted,
                cycle_duration_seconds=cycle_duration,
                stagnation_detected=False,
                hpo_triggered=False,
                nas_triggered=False
            )
            
            # Store current cycle metrics
            self.current_cycle_metrics = {
                'cycle_number': self.total_cycles,
                'elo_delta': elo_delta,
                'training_loss': training_loss,
                'evaluation_win_rate': evaluation_win_rate,
                'promoted': model_promoted,
                'duration_seconds': cycle_duration
            }
            
            logger.info(f"Cycle #{self.total_cycles} complete: "
                       f"ELO Δ{elo_delta:+.1f}, "
                       f"Loss {training_loss:.4f}, "
                       f"Win Rate {evaluation_win_rate:.1%}, "
                       f"Promoted: {model_promoted}")
            
            return True
        
        except Exception as e:
            logger.error(f"Training cycle error: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    async def _analyze_stagnation(self) -> StagnationType:
        """
        Analyze if evolution has stagnated
        
        Returns:
            StagnationType
        """
        try:
            # Need minimum cycles for analysis
            if self.total_cycles < self.config.stagnation_window:
                return StagnationType.NONE
            
            # Don't trigger optimization too frequently
            cycles_since_last_opt = self.total_cycles - self.last_optimization_cycle
            if cycles_since_last_opt < self.config.stagnation_window:
                logger.info(f"Too soon for optimization (only {cycles_since_last_opt} cycles since last)")
                return StagnationType.NONE
            
            # Run stagnation detection
            is_stagnated, analysis = self.evolution_tracker.detect_stagnation(
                window=self.config.stagnation_window,
                elo_threshold=self.config.elo_threshold
            )
            
            if not is_stagnated:
                return StagnationType.NONE
            
            # Determine stagnation type
            recent_cycles = self.evolution_tracker.evolution_cycles[-self.config.stagnation_window:]
            
            # Check loss trend
            losses = [c.training_loss for c in recent_cycles]
            loss_trend = np.polyfit(range(len(losses)), losses, 1)[0]  # Slope
            
            # Check win rate
            avg_win_rate = analysis['avg_win_rate']
            
            # Decide stagnation type
            if loss_trend >= 0:  # Loss not decreasing (or increasing)
                stagnation_type = StagnationType.LOSS_PLATEAU
            elif avg_win_rate < 0.52:  # Very low win rate
                stagnation_type = StagnationType.WIN_RATE_PLATEAU
            else:  # ELO plateau with normal loss and win rate
                stagnation_type = StagnationType.ELO_PLATEAU
            
            logger.info(f"Stagnation Analysis: Type={stagnation_type.value}, "
                       f"Total ΔELO={analysis['total_elo_delta']:.1f}, "
                       f"Avg Win Rate={avg_win_rate:.1%}, "
                       f"Loss Trend={'↑' if loss_trend > 0 else '↓'}")
            
            return stagnation_type
        
        except Exception as e:
            logger.error(f"Stagnation analysis error: {e}")
            return StagnationType.NONE
    
    async def _handle_stagnation(self, stagnation_type: StagnationType) -> bool:
        """
        Handle stagnation by triggering appropriate optimization
        
        Args:
            stagnation_type: Type of stagnation detected
        
        Returns:
            success (bool)
        """
        try:
            # Decide optimization strategy
            if self.config.auto_decide_optimization:
                # Auto-decide based on stagnation type
                if stagnation_type == StagnationType.LOSS_PLATEAU:
                    # Loss plateau → HPO (learning rate, batch size)
                    if self.config.enable_hpo:
                        logger.info("Auto-decision: HPO for loss plateau")
                        return await self._run_hpo_optimization()
                    else:
                        logger.warning("HPO disabled, skipping optimization")
                        return False
                
                elif stagnation_type == StagnationType.ELO_PLATEAU:
                    # ELO plateau → NAS (architecture exploration)
                    if self.config.enable_nas:
                        logger.info("Auto-decision: NAS for ELO plateau")
                        return await self._run_nas_optimization()
                    else:
                        logger.warning("NAS disabled, skipping optimization")
                        return False
                
                elif stagnation_type == StagnationType.WIN_RATE_PLATEAU:
                    # Try both: HPO first, then NAS if needed
                    if self.config.enable_hpo:
                        logger.info("Auto-decision: HPO for win rate plateau")
                        hpo_success = await self._run_hpo_optimization()
                        if hpo_success:
                            return True
                    
                    if self.config.enable_nas:
                        logger.info("Auto-decision: NAS as fallback")
                        return await self._run_nas_optimization()
                    
                    return False
            
            else:
                # Manual decision: try HPO first, then NAS
                if self.config.enable_hpo:
                    logger.info("Running HPO (manual mode)")
                    hpo_success = await self._run_hpo_optimization()
                    if hpo_success:
                        return True
                
                if self.config.enable_nas:
                    logger.info("Running NAS (manual mode)")
                    return await self._run_nas_optimization()
                
                return False
        
        except Exception as e:
            logger.error(f"Stagnation handling error: {e}")
            return False
    
    async def _run_hpo_optimization(self) -> bool:
        """
        Run Hyperparameter Optimization
        
        Returns:
            success (bool)
        """
        try:
            self.current_phase = EvolutionPhase.HPO_OPTIMIZATION
            
            logger.info("="*80)
            logger.info("STARTING HPO OPTIMIZATION")
            logger.info("="*80)
            
            # Initialize HPO optimizer if needed
            if self.hpo_optimizer is None:
                self.hpo_optimizer = get_hpo_optimizer(
                    max_trials=self.config.hpo_max_trials,
                    evaluation_games=self.config.hpo_evaluation_games,
                    num_workers=4
                )
            
            # Start HPO
            hpo_success = self.hpo_optimizer.start_optimization(resume=False)
            
            if not hpo_success:
                logger.warning("HPO already running or failed to start")
                return False
            
            # Wait for HPO completion
            while self.hpo_optimizer.active and self.is_running:
                await asyncio.sleep(10)
                
                # Log progress
                hpo_status = self.hpo_optimizer.get_status()
                logger.info(f"HPO Progress: {hpo_status['current_trial']}/{hpo_status['max_trials']} trials")
            
            # Get best parameters
            best_params = self.hpo_optimizer.get_best_parameters()
            
            if best_params:
                logger.info(f"HPO Complete: Best parameters found")
                logger.info(f"  Learning Rate: {best_params.get('learning_rate', 'N/A')}")
                logger.info(f"  Batch Size: {best_params.get('batch_size', 'N/A')}")
                logger.info(f"  MCTS Simulations: {best_params.get('mcts_simulations', 'N/A')}")
                
                # Update config with best parameters
                self.config.learning_rate = best_params.get('learning_rate', self.config.learning_rate)
                self.config.batch_size = best_params.get('batch_size', self.config.batch_size)
                
                # Record optimization in evolution tracker
                last_cycle = self.evolution_tracker.evolution_cycles[-1]
                last_cycle.hpo_triggered = True
                self.evolution_tracker.save_state()
                
                logger.info("Config updated with optimized hyperparameters")
                return True
            else:
                logger.warning("HPO failed to find better parameters")
                return False
        
        except Exception as e:
            logger.error(f"HPO optimization error: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    async def _run_nas_optimization(self) -> bool:
        """
        Run Neural Architecture Search
        
        Returns:
            success (bool)
        """
        try:
            self.current_phase = EvolutionPhase.NAS_EVOLUTION
            
            logger.info("="*80)
            logger.info("STARTING NAS EVOLUTION")
            logger.info("="*80)
            
            # Initialize NAS controller if needed
            if self.nas_controller is None:
                self.nas_controller = get_nas_controller(
                    population_size=self.config.nas_population_size,
                    max_generations=self.config.nas_max_generations,
                    auto_trigger=False
                )
            
            # Start NAS
            nas_success = self.nas_controller.start_search()
            
            if not nas_success:
                logger.warning("NAS already running or failed to start")
                return False
            
            # Wait for NAS completion
            while self.nas_controller.active and self.is_running:
                await asyncio.sleep(10)
                
                # Log progress
                nas_status = self.nas_controller.get_status()
                logger.info(f"NAS Progress: Generation {nas_status['current_generation']}/{nas_status['max_generations']}")
            
            # Get best genome
            best_genome = self.nas_controller.get_best_genome()
            
            if best_genome:
                logger.info(f"NAS Complete: Best architecture found")
                logger.info(f"  Generation: {best_genome.generation}")
                logger.info(f"  ELO: {best_genome.elo:.0f}")
                logger.info(f"  Channels: {best_genome.num_channels}")
                logger.info(f"  Res Blocks: {best_genome.num_res_blocks}")
                logger.info(f"  Activation: {best_genome.activation}")
                
                # Create and register new network from best genome
                new_network = best_genome.create_network()
                model_name = f"NAS_Model_Cycle{self.total_cycles}_{int(time.time())}"
                
                self.model_manager.save_model(new_network, name=model_name, metadata={
                    'evolution_cycle': self.total_cycles,
                    'creation_method': 'nas',
                    'genome_id': best_genome.genome_id,
                    'elo': best_genome.elo
                })
                
                # Update orchestrator with new model
                self.tpu_orchestrator.current_network.load_state_dict(new_network.state_dict())
                self.tpu_orchestrator.current_model_name = model_name
                
                # Register in evolution tracker
                model_id = self.evolution_tracker.register_model(
                    model_name=model_name,
                    elo=best_genome.elo,
                    training_loss=best_genome.training_loss,
                    win_rate=best_genome.win_rate,
                    num_parameters=sum(p.numel() for p in new_network.parameters()),
                    parent_id=self.best_model_id,
                    creation_method="nas",
                    mutations=[f"nas_gen{best_genome.generation}"],
                    positions_trained=0,
                    training_time_seconds=0,
                    games_played=0,
                    architecture_info={
                        'num_channels': best_genome.num_channels,
                        'num_res_blocks': best_genome.num_res_blocks,
                        'activation': best_genome.activation
                    }
                )
                
                self.best_model_id = model_id
                
                # Record optimization in evolution tracker
                last_cycle = self.evolution_tracker.evolution_cycles[-1]
                last_cycle.nas_triggered = True
                self.evolution_tracker.save_state()
                
                logger.info(f"New architecture deployed: {model_name}")
                return True
            else:
                logger.warning("NAS failed to find better architecture")
                return False
        
        except Exception as e:
            logger.error(f"NAS optimization error: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _should_terminate(self) -> bool:
        """Check if evolution should terminate"""
        
        # Check max cycles
        if self.config.max_cycles and self.total_cycles >= self.config.max_cycles:
            logger.info(f"Max cycles reached: {self.total_cycles}/{self.config.max_cycles}")
            return True
        
        # Check max hours
        if self.config.max_hours:
            elapsed_hours = (time.time() - self.start_time) / 3600
            if elapsed_hours >= self.config.max_hours:
                logger.info(f"Max hours reached: {elapsed_hours:.2f}/{self.config.max_hours}")
                return True
        
        # Check manual stop
        if not self.is_running:
            logger.info("Manual stop requested")
            return True
        
        return False
    
    def stop_evolution(self):
        """Stop evolution gracefully"""
        logger.info("Evolution stop requested")
        self.is_running = False
        
        # Stop TPU orchestrator if running
        if self.tpu_orchestrator.is_running:
            self.tpu_orchestrator.stop_training()
        
        # Stop HPO if running
        if self.hpo_optimizer and self.hpo_optimizer.active:
            self.hpo_optimizer.stop_optimization()
        
        # Stop NAS if running
        if self.nas_controller and self.nas_controller.active:
            self.nas_controller.stop_search()
    
    def get_evolution_status(self) -> Dict:
        """Get current evolution status"""
        
        elapsed_seconds = (time.time() - self.start_time) if self.start_time else 0
        
        status = {
            'is_running': self.is_running,
            'session_id': self.evolution_session_id,
            'current_phase': self.current_phase.value,
            'total_cycles': self.total_cycles,
            'elapsed_seconds': int(elapsed_seconds),
            'elapsed_hours': elapsed_seconds / 3600,
            'best_elo': round(self.best_elo, 1),
            'stagnation_streak': self.stagnation_streak,
            'last_optimization_cycle': self.last_optimization_cycle,
            'current_cycle_metrics': self.current_cycle_metrics,
            'config': {
                'stagnation_window': self.config.stagnation_window,
                'elo_threshold': self.config.elo_threshold,
                'hpo_enabled': self.config.enable_hpo,
                'nas_enabled': self.config.enable_nas,
                'max_cycles': self.config.max_cycles,
                'max_hours': self.config.max_hours
            }
        }
        
        # Add sub-component status
        if self.tpu_orchestrator.is_running:
            cycle_status = self.tpu_orchestrator.get_cycle_status()
            if cycle_status:
                status['tpu_cycle_status'] = {
                    'phase': cycle_status['cycle']['phase'],
                    'progress': cycle_status['overall_progress']
                }
        
        if self.hpo_optimizer and self.hpo_optimizer.active:
            hpo_status = self.hpo_optimizer.get_status()
            status['hpo_status'] = {
                'active': hpo_status['active'],
                'current_trial': hpo_status['current_trial'],
                'max_trials': hpo_status['max_trials'],
                'progress': hpo_status['progress_percent']
            }
        
        if self.nas_controller and self.nas_controller.active:
            nas_status = self.nas_controller.get_status()
            status['nas_status'] = {
                'active': nas_status['active'],
                'current_generation': nas_status['current_generation'],
                'max_generations': nas_status['max_generations'],
                'progress': nas_status['progress_percent']
            }
        
        return status
    
    def get_evolution_history(self) -> Dict:
        """Get evolution history"""
        return {
            'session_id': self.evolution_session_id,
            'total_cycles': self.total_cycles,
            'cycles': self.evolution_tracker.get_evolution_summary(),
            'iq_growth': self.evolution_tracker.get_iq_growth_history(limit=50),
            'lineage_tree': self.evolution_tracker.get_lineage_tree()
        }


# Global instance
_phase5_orchestrator = None


def get_phase5_orchestrator(config: EvolutionConfig = None) -> Phase5AdaptiveOrchestrator:
    """Get or create global Phase 5 orchestrator"""
    global _phase5_orchestrator
    
    if _phase5_orchestrator is None:
        _phase5_orchestrator = Phase5AdaptiveOrchestrator(config=config)
    
    return _phase5_orchestrator


def reset_phase5_orchestrator():
    """Reset global orchestrator (for testing)"""
    global _phase5_orchestrator
    _phase5_orchestrator = None
