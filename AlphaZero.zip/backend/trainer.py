import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from datetime import datetime, timezone
from typing import List, Dict, Optional
import logging
from device_manager import device_manager
import time
from pathlib import Path

logger = logging.getLogger(__name__)

class AlphaZeroTrainer:
    """Enhanced training system for AlphaZero network with mixed precision and prioritized sampling"""
    
    def __init__(self, neural_network, learning_rate=0.001, 
                 use_mixed_precision=False, checkpoint_dir="/app/backend/checkpoints",
                 adaptive_lr=False, min_lr=0.0001, max_lr=0.01):
        """
        Initialize trainer
        
        Args:
            neural_network: AlphaZero neural network
            learning_rate: Initial learning rate for optimizer
            use_mixed_precision: Enable mixed precision training (requires GPU)
            checkpoint_dir: Directory for saving training checkpoints
            adaptive_lr: Enable adaptive learning rate adjustment
            min_lr: Minimum learning rate for adaptive adjustment
            max_lr: Maximum learning rate for adaptive adjustment
        """
        self.neural_network = neural_network
        self.initial_lr = learning_rate
        self.optimizer = optim.Adam(neural_network.parameters(), lr=learning_rate)
        self.device = device_manager.device
        self.neural_network.to(self.device)
        
        # Adaptive learning rate
        self.adaptive_lr = adaptive_lr
        self.min_lr = min_lr
        self.max_lr = max_lr
        self.current_lr = learning_rate
        
        # Mixed precision setup
        self.use_mixed_precision = use_mixed_precision and torch.cuda.is_available()
        self.scaler = torch.cuda.amp.GradScaler() if self.use_mixed_precision else None
        
        if self.use_mixed_precision:
            logger.info(f"Mixed precision training enabled on {device_manager.device_name}")
        else:
            logger.info(f"Trainer initialized on {device_manager.device_name}")
        
        # Checkpoint management
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        # Training state
        self.epoch = 0
        self.total_steps = 0
        self.best_loss = float('inf')
        self.training_history = []
        
    def prepare_batch(self, training_data: List[Dict], batch_size=32, sample_weights: Optional[List[float]] = None):
        """
        Prepare training batch from self-play data with optional prioritized sampling
        
        Args:
            training_data: List of training samples
            batch_size: Batch size
            sample_weights: Optional per-sample weights for prioritized sampling
        """
        if len(training_data) == 0:
            return []
        
        # Prioritized sampling if weights provided
        if sample_weights is not None and len(sample_weights) == len(training_data):
            # Normalize weights to probabilities
            weights = np.array(sample_weights, dtype=np.float64)
            weights = weights / weights.sum()
            
            # Sample indices based on weights
            num_samples = min(len(training_data), batch_size * 100)  # Over-sample for batching
            indices = np.random.choice(len(training_data), size=num_samples, replace=True, p=weights)
            sampled_data = [training_data[i] for i in indices]
        else:
            # Uniform random sampling
            sampled_data = training_data.copy()
            np.random.shuffle(sampled_data)
        
        batches = []
        for i in range(0, len(sampled_data), batch_size):
            batch = sampled_data[i:i + batch_size]
            
            # Extract positions, policies, and values
            positions = []
            target_policies = []
            target_values = []
            
            for entry_idx, entry in enumerate(batch):
                try:
                    # Support both 'position' and 'state' keys (handle numpy arrays properly)
                    position = entry.get('position') if entry.get('position') is not None else entry.get('state')
                    
                    # Validate position
                    if position is None:
                        logger.warning(f"Batch {i//batch_size} entry {entry_idx}: Skipping entry with None position")
                        continue
                    
                    # Convert to numpy array if not already
                    position_array = np.array(position, dtype=np.float32)
                    
                    # Validate shape
                    if position_array.shape != (8, 8, 14):
                        logger.warning(f"Batch {i//batch_size} entry {entry_idx}: Skipping entry with invalid position shape: {position_array.shape}, expected (8, 8, 14)")
                        continue
                    
                    # Get policy
                    policy = entry.get('policy')
                    if policy is None:
                        logger.warning(f"Batch {i//batch_size} entry {entry_idx}: Skipping entry with None policy")
                        continue
                    
                    # Convert policy dict to array
                    policy_array = np.zeros(4096, dtype=np.float32)
                    if isinstance(policy, dict):
                        from chess_engine import ChessEngine
                        import chess
                        engine = ChessEngine()
                        
                        invalid_moves = []
                        for move, prob in policy.items():
                            try:
                                # Validate UCI move format
                                if not isinstance(move, str):
                                    invalid_moves.append(f"{move} (not string)")
                                    continue
                                
                                if len(move) not in [4, 5]:
                                    invalid_moves.append(f"{move} (invalid length)")
                                    continue
                                
                                # Try to parse as UCI move
                                chess.Move.from_uci(move)
                                
                                # Convert to index
                                idx = engine.move_to_index(move)
                                if idx < 4096:
                                    policy_array[idx] = prob
                            except (ValueError, chess.InvalidMoveError) as e:
                                invalid_moves.append(f"{move} (UCI error)")
                                continue
                        
                        # Log invalid moves for debugging
                        if invalid_moves:
                            sample_invalid = invalid_moves[:3]
                            logger.error(f"Batch {i//batch_size} entry {entry_idx}: Found {len(invalid_moves)} invalid UCI moves in policy. Examples: {sample_invalid}")
                            logger.error(f"  Total policy keys: {len(policy)}, Entry keys: {list(entry.keys())}")
                            # Skip this entry if all moves are invalid
                            if len(invalid_moves) == len(policy):
                                logger.error(f"  All moves invalid - skipping entry")
                                continue
                    elif isinstance(policy, (list, np.ndarray)):
                        # Policy is already an array
                        policy_array = np.array(policy, dtype=np.float32)
                        if policy_array.shape != (4096,):
                            logger.warning(f"Batch {i//batch_size} entry {entry_idx}: Invalid policy array shape: {policy_array.shape}, expected (4096,)")
                            continue
                    else:
                        logger.warning(f"Batch {i//batch_size} entry {entry_idx}: Policy must be dict or array, got {type(policy)}")
                        continue
                    
                    # Validate value
                    value = entry.get('value', 0.0)
                    if not isinstance(value, (int, float)):
                        logger.warning(f"Batch {i//batch_size} entry {entry_idx}: Skipping entry with invalid value type: {type(value)}")
                        continue
                    
                    # All validations passed, add to batch
                    positions.append(position_array)
                    target_policies.append(policy_array)
                    target_values.append(float(value))
                    
                except Exception as e:
                    logger.error(f"Batch {i//batch_size} entry {entry_idx}: Error processing training entry: {e}")
                    import traceback
                    logger.error(traceback.format_exc())
                    continue
            
            # Skip batch if no valid positions
            if len(positions) == 0:
                logger.warning(f"Batch {i//batch_size} has no valid positions, skipping")
                continue
            
            # Convert to tensors with explicit stacking
            try:
                positions_array = np.stack(positions, axis=0)  # Shape: (batch, 8, 8, 14)
                positions_tensor = torch.FloatTensor(positions_array).permute(0, 3, 1, 2)  # Shape: (batch, 14, 8, 8)
                policies_tensor = torch.FloatTensor(np.array(target_policies))
                values_tensor = torch.FloatTensor(np.array(target_values)).unsqueeze(1)
            except Exception as e:
                logger.error(f"Error converting batch to tensors: {e}")
                logger.error(f"Positions shapes: {[p.shape for p in positions[:5]]}")
                continue
            
            batches.append({
                'positions': positions_tensor,
                'policies': policies_tensor,
                'values': values_tensor
            })
        
        return batches
    
    def train_epoch(self, training_data: List[Dict], batch_size=32, sample_weights: Optional[List[float]] = None):
        """Train for one epoch with optional mixed precision and prioritized sampling"""
        self.neural_network.train()
        
        batches = self.prepare_batch(training_data, batch_size, sample_weights)
        if not batches:
            return {'loss': 0.0, 'policy_loss': 0.0, 'value_loss': 0.0}
        
        total_loss = 0.0
        total_policy_loss = 0.0
        total_value_loss = 0.0
        
        for batch_idx, batch in enumerate(batches):
            positions = batch['positions'].to(self.device)
            target_policies = batch['policies'].to(self.device)
            target_values = batch['values'].to(self.device)
            
            self.optimizer.zero_grad()
            
            # Mixed precision training
            if self.use_mixed_precision:
                with torch.cuda.amp.autocast():
                    pred_log_policies, pred_values = self.neural_network(positions)
                    
                    # Policy loss: cross entropy
                    policy_loss = -torch.sum(target_policies * pred_log_policies) / positions.size(0)
                    
                    # Value loss: MSE
                    value_loss = nn.MSELoss()(pred_values, target_values)
                    
                    # Combined loss
                    loss = policy_loss + value_loss
                
                # Backward pass with gradient scaling
                self.scaler.scale(loss).backward()
                self.scaler.step(self.optimizer)
                self.scaler.update()
            else:
                # Standard training
                pred_log_policies, pred_values = self.neural_network(positions)
                
                # Calculate losses
                policy_loss = -torch.sum(target_policies * pred_log_policies) / positions.size(0)
                value_loss = nn.MSELoss()(pred_values, target_values)
                loss = policy_loss + value_loss
                
                # Backward pass
                loss.backward()
                self.optimizer.step()
            
            total_loss += loss.item()
            total_policy_loss += policy_loss.item()
            total_value_loss += value_loss.item()
            self.total_steps += 1
        
        self.epoch += 1
        num_batches = len(batches)
        
        avg_loss = total_loss / num_batches
        
        # Track best loss for checkpointing
        if avg_loss < self.best_loss:
            self.best_loss = avg_loss
        
        return {
            'loss': avg_loss,
            'policy_loss': total_policy_loss / num_batches,
            'value_loss': total_value_loss / num_batches,
            'num_batches': num_batches,
            'epoch': self.epoch,
            'total_steps': self.total_steps
        }
    
    def train(self, training_data: List[Dict], num_epochs=10, batch_size=32, 
              sample_weights: Optional[List[float]] = None):
        """Train for multiple epochs with performance timing"""
        training_history = []
        
        start_time = time.time()
        for epoch in range(num_epochs):
            epoch_start = time.time()
            metrics = self.train_epoch(training_data, batch_size, sample_weights)
            epoch_time = time.time() - epoch_start
            
            metrics['timestamp'] = datetime.now(timezone.utc).isoformat()
            metrics['epoch_time'] = epoch_time
            metrics['device'] = device_manager.device_name
            metrics['mixed_precision'] = self.use_mixed_precision
            training_history.append(metrics)
            
            logger.info(f"Epoch {metrics['epoch']}/{self.epoch + num_epochs} - "
                       f"Loss: {metrics['loss']:.4f}, "
                       f"Policy: {metrics['policy_loss']:.4f}, "
                       f"Value: {metrics['value_loss']:.4f}, "
                       f"Time: {epoch_time:.2f}s")
        
        total_time = time.time() - start_time
        logger.info(f"Training complete. Total time: {total_time:.2f}s on {device_manager.device_name}")
        
        return training_history
    
    def save_checkpoint(self, checkpoint_name: str = "latest", metadata: Optional[Dict] = None):
        """Save training checkpoint for resuming"""
        checkpoint_path = self.checkpoint_dir / f"checkpoint_{checkpoint_name}.pt"
        
        checkpoint = {
            'epoch': self.epoch,
            'total_steps': self.total_steps,
            'best_loss': self.best_loss,
            'model_state_dict': self.neural_network.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'metadata': metadata or {},
            'timestamp': datetime.now(timezone.utc).isoformat()
        }
        
        if self.use_mixed_precision and self.scaler:
            checkpoint['scaler_state_dict'] = self.scaler.state_dict()
        
        torch.save(checkpoint, checkpoint_path)
        logger.info(f"Checkpoint saved: {checkpoint_path}")
        
        return str(checkpoint_path)
    
    def load_checkpoint(self, checkpoint_name: str = "latest"):
        """Load training checkpoint to resume training"""
        checkpoint_path = self.checkpoint_dir / f"checkpoint_{checkpoint_name}.pt"
        
        if not checkpoint_path.exists():
            logger.warning(f"Checkpoint not found: {checkpoint_path}")
            return False
        
        try:
            checkpoint = torch.load(checkpoint_path, map_location=self.device, weights_only=False)
            
            self.neural_network.load_state_dict(checkpoint['model_state_dict'])
            self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            self.epoch = checkpoint.get('epoch', 0)
            self.total_steps = checkpoint.get('total_steps', 0)
            self.best_loss = checkpoint.get('best_loss', float('inf'))
            
            if self.use_mixed_precision and 'scaler_state_dict' in checkpoint:
                self.scaler.load_state_dict(checkpoint['scaler_state_dict'])
            
            logger.info(f"Checkpoint loaded: {checkpoint_path} (Epoch {self.epoch}, Steps {self.total_steps})")
            return True
        except Exception as e:
            logger.error(f"Failed to load checkpoint: {e}")
            return False
    
    def adjust_learning_rate(self, win_rate: float, adjust_factor: float = 0.1,
                            win_rate_low: float = 0.45, win_rate_high: float = 0.60):
        """
        Adjust learning rate based on model performance (win rate)
        
        Args:
            win_rate: Current win rate against previous model
            adjust_factor: Factor by which to adjust LR
            win_rate_low: Win rate threshold for increasing LR
            win_rate_high: Win rate threshold for decreasing LR
        """
        if not self.adaptive_lr:
            return
        
        old_lr = self.current_lr
        
        # Adjust based on win rate
        if win_rate < win_rate_low:
            # Model struggling - increase learning rate to explore more
            self.current_lr = min(self.current_lr * (1 + adjust_factor), self.max_lr)
        elif win_rate > win_rate_high:
            # Model doing well - decrease learning rate for fine-tuning
            self.current_lr = max(self.current_lr * (1 - adjust_factor), self.min_lr)
        
        # Update optimizer
        for param_group in self.optimizer.param_groups:
            param_group['lr'] = self.current_lr
        
        if abs(old_lr - self.current_lr) > 1e-6:
            logger.info(f"Adaptive LR: {old_lr:.6f} -> {self.current_lr:.6f} (win_rate: {win_rate:.3f})")
    
    def train_incremental(self, training_data: List[Dict], num_epochs=5, batch_size=32,
                         load_previous_model: bool = True, previous_model_name: str = None):
        """
        Incremental training: fine-tune existing weights with new data
        
        Args:
            training_data: New training data
            num_epochs: Number of epochs to train
            batch_size: Batch size
            load_previous_model: Load previous model weights before training
            previous_model_name: Name of previous model to load (None = use current weights)
            
        Returns:
            Training history
        """
        if load_previous_model and previous_model_name:
            try:
                from neural_network import ModelManager
                model_manager = ModelManager()
                loaded_network, metadata = model_manager.load_model(previous_model_name)
                
                if loaded_network:
                    # Transfer weights
                    self.neural_network.load_state_dict(loaded_network.state_dict())
                    logger.info(f"Loaded previous model weights from {previous_model_name} for incremental training")
                else:
                    logger.warning(f"Could not load previous model {previous_model_name}, using current weights")
            except Exception as e:
                logger.error(f"Error loading previous model: {e}, using current weights")
        
        # Standard training on new data
        return self.train(training_data, num_epochs=num_epochs, batch_size=batch_size)
    
    def get_training_state(self) -> Dict:
        """Get current training state"""
        return {
            'epoch': self.epoch,
            'total_steps': self.total_steps,
            'best_loss': self.best_loss,
            'device': str(self.device),
            'mixed_precision': self.use_mixed_precision,
            'learning_rate': self.optimizer.param_groups[0]['lr'],
            'adaptive_lr': self.adaptive_lr,
            'current_lr': self.current_lr,
            'min_lr': self.min_lr,
            'max_lr': self.max_lr
        }
