import logging
import math
from typing import Dict, Tuple, Optional
from chess_engine import ChessEngine
from mcts import MCTS
import chess
import time

logger = logging.getLogger(__name__)


class ELOCalculator:
    """Calculate ELO ratings for model comparison"""
    
    @staticmethod
    def calculate_expected_score(rating_a: float, rating_b: float) -> float:
        """Calculate expected score for player A against player B"""
        return 1.0 / (1.0 + 10.0 ** ((rating_b - rating_a) / 400.0))
    
    @staticmethod
    def update_rating(current_rating: float, expected_score: float, actual_score: float, k_factor: float = 32.0) -> float:
        """Update ELO rating based on match result"""
        return current_rating + k_factor * (actual_score - expected_score)
    
    @staticmethod
    def calculate_elo_delta(wins: int, losses: int, draws: int, 
                           current_elo: float = 1500.0, opponent_elo: float = 1500.0,
                           k_factor: float = 32.0) -> Dict[str, float]:
        """
        Calculate ELO change based on match results
        
        Args:
            wins: Number of wins
            losses: Number of losses
            draws: Number of draws
            current_elo: Current ELO rating
            opponent_elo: Opponent's ELO rating
            k_factor: K-factor for ELO calculation
        
        Returns:
            Dictionary with ELO calculations
        """
        total_games = wins + losses + draws
        
        if total_games == 0:
            return {
                'elo_before': current_elo,
                'elo_after': current_elo,
                'elo_delta': 0.0,
                'expected_score': 0.5,
                'actual_score': 0.5
            }
        
        # Calculate actual score (win=1, draw=0.5, loss=0)
        actual_score = (wins + 0.5 * draws) / total_games
        
        # Calculate expected score
        expected_score = ELOCalculator.calculate_expected_score(current_elo, opponent_elo)
        
        # Calculate new ELO
        # Multiply k_factor by number of games
        effective_k = k_factor * total_games
        new_elo = current_elo + effective_k * (actual_score - expected_score)
        elo_delta = new_elo - current_elo
        
        return {
            'elo_before': current_elo,
            'elo_after': new_elo,
            'elo_delta': elo_delta,
            'expected_score': expected_score,
            'actual_score': actual_score,
            'total_games': total_games,
            'k_factor': k_factor
        }


class EvaluationMatch:
    """Run evaluation matches between two models"""
    
    def __init__(self, model1, model2, num_simulations=400):
        """
        Initialize evaluation match
        
        Args:
            model1: First neural network model (challenger)
            model2: Second neural network model (champion)
            num_simulations: MCTS simulations per move (fewer than training for speed)
        """
        self.model1 = model1
        self.model2 = model2
        self.num_simulations = num_simulations
        self.mcts1 = MCTS(model1, num_simulations=num_simulations, c_puct=1.0)
        self.mcts2 = MCTS(model2, num_simulations=num_simulations, c_puct=1.0)
    
    def play_game(self, model1_plays_white: bool) -> str:
        """
        Play a single game between two models
        
        Args:
            model1_plays_white: If True, model1 plays as White, model2 as Black
        
        Returns:
            Game result: "1-0", "0-1", or "1/2-1/2"
        """
        engine = ChessEngine()
        move_count = 0
        max_moves = 500  # Safety limit
        
        while not engine.is_game_over() and move_count < max_moves:
            # Determine which model plays this turn
            if engine.board.turn == chess.WHITE:
                mcts = self.mcts1 if model1_plays_white else self.mcts2
            else:
                mcts = self.mcts2 if model1_plays_white else self.mcts1
            
            # Get best move (deterministic, temperature=0)
            try:
                best_move, _ = mcts.get_best_move(engine)
                engine.make_move(best_move)
                move_count += 1
            except Exception as e:
                logger.error(f"Error during move generation: {e}")
                # If move fails, return draw
                return "1/2-1/2"
        
        # Get game result
        if engine.is_game_over():
            return engine.get_result()
        else:
            # Reached move limit, consider it a draw
            return "1/2-1/2"
    
    def run_evaluation(self, num_games: int = 20) -> Dict:
        """
        Run evaluation match with alternating colors and performance tracking
        
        Args:
            num_games: Number of games to play (will be split evenly between colors)
        
        Returns:
            Dictionary with evaluation results
        """
        start_time = time.time()
        results = {
            'model1_wins': 0,
            'model2_wins': 0,
            'draws': 0,
            'games_played': 0,
            'model1_as_white_wins': 0,
            'model1_as_black_wins': 0,
            'model2_as_white_wins': 0,
            'model2_as_black_wins': 0
        }
        
        # Play games with alternating colors
        for i in range(num_games):
            model1_plays_white = (i % 2 == 0)
            
            logger.info(f"Playing evaluation game {i + 1}/{num_games} "
                       f"(Model1={'White' if model1_plays_white else 'Black'})")
            
            result = self.play_game(model1_plays_white)
            results['games_played'] += 1
            
            # Update statistics
            if result == "1-0":
                # White won
                if model1_plays_white:
                    results['model1_wins'] += 1
                    results['model1_as_white_wins'] += 1
                else:
                    results['model2_wins'] += 1
                    results['model2_as_white_wins'] += 1
            elif result == "0-1":
                # Black won
                if model1_plays_white:
                    results['model2_wins'] += 1
                    results['model2_as_black_wins'] += 1
                else:
                    results['model1_wins'] += 1
                    results['model1_as_black_wins'] += 1
            else:
                # Draw
                results['draws'] += 1
        
        eval_time = time.time() - start_time
        
        # Calculate win rates
        if results['games_played'] > 0:
            results['model1_win_rate'] = results['model1_wins'] / results['games_played']
            results['model2_win_rate'] = results['model2_wins'] / results['games_played']
            results['draw_rate'] = results['draws'] / results['games_played']
        else:
            results['model1_win_rate'] = 0.0
            results['model2_win_rate'] = 0.0
            results['draw_rate'] = 0.0
        
        results['evaluation_time'] = eval_time
        logger.info(f"Evaluation complete in {eval_time:.2f}s")
        
        return results


class ModelEvaluator:
    """Manage model evaluation, ELO calculation, and model gating"""
    
    def __init__(self, num_evaluation_games=20, num_simulations=400, 
                 win_threshold=0.55, elo_threshold=50.0):
        """
        Initialize evaluator
        
        Args:
            num_evaluation_games: Number of games per evaluation
            num_simulations: MCTS simulations per move during evaluation
            win_threshold: Win rate threshold for model promotion (default 55%)
            elo_threshold: ELO delta threshold for model promotion (default 50)
        """
        self.num_evaluation_games = num_evaluation_games
        self.num_simulations = num_simulations
        self.win_threshold = win_threshold
        self.elo_threshold = elo_threshold
    
    def evaluate_models(self, challenger_model, champion_model, 
                       challenger_name: str, champion_name: str,
                       challenger_elo: float = 1500.0, champion_elo: float = 1500.0) -> Tuple[Dict, bool]:
        """
        Evaluate challenger model against champion with ELO calculation
        
        Args:
            challenger_model: New model to evaluate
            champion_model: Current best model
            challenger_name: Name of challenger model
            champion_name: Name of champion model
            challenger_elo: Current ELO of challenger (default 1500)
            champion_elo: Current ELO of champion (default 1500)
        
        Returns:
            Tuple of (results dict, should_promote boolean)
        """
        logger.info(f"Starting evaluation: {challenger_name} (ELO {challenger_elo:.0f}) vs "
                   f"{champion_name} (ELO {champion_elo:.0f})")
        logger.info(f"Playing {self.num_evaluation_games} games with {self.num_simulations} sims/move")
        
        # Create evaluation match
        match = EvaluationMatch(challenger_model, champion_model, self.num_simulations)
        
        # Run evaluation
        results = match.run_evaluation(self.num_evaluation_games)
        
        # Add model names to results
        results['challenger_name'] = challenger_name
        results['champion_name'] = champion_name
        results['challenger_win_rate'] = results['model1_win_rate']
        results['champion_win_rate'] = results['model2_win_rate']
        
        # Calculate ELO changes
        elo_calc = ELOCalculator.calculate_elo_delta(
            wins=results['model1_wins'],
            losses=results['model2_wins'],
            draws=results['draws'],
            current_elo=challenger_elo,
            opponent_elo=champion_elo
        )
        
        results['challenger_elo_before'] = elo_calc['elo_before']
        results['challenger_elo_after'] = elo_calc['elo_after']
        results['elo_delta'] = elo_calc['elo_delta']
        results['expected_score'] = elo_calc['expected_score']
        results['actual_score'] = elo_calc['actual_score']
        
        # Update champion ELO (inverse calculation)
        champion_elo_calc = ELOCalculator.calculate_elo_delta(
            wins=results['model2_wins'],
            losses=results['model1_wins'],
            draws=results['draws'],
            current_elo=champion_elo,
            opponent_elo=challenger_elo
        )
        results['champion_elo_after'] = champion_elo_calc['elo_after']
        
        # Determine if challenger should be promoted (two criteria)
        # 1. Win rate threshold
        win_rate_pass = results['challenger_win_rate'] >= self.win_threshold
        
        # 2. ELO improvement threshold
        elo_pass = elo_calc['elo_delta'] >= self.elo_threshold
        
        # Promote if EITHER condition is met (not both required)
        should_promote = win_rate_pass or elo_pass
        results['promoted'] = should_promote
        results['promotion_reason'] = []
        
        if win_rate_pass:
            results['promotion_reason'].append(f"Win rate {results['challenger_win_rate']:.1%} >= {self.win_threshold:.1%}")
        if elo_pass:
            results['promotion_reason'].append(f"ELO gain {elo_calc['elo_delta']:.0f} >= {self.elo_threshold:.0f}")
        
        if not should_promote:
            results['promotion_reason'] = f"Win rate {results['challenger_win_rate']:.1%} < {self.win_threshold:.1%} and ELO gain {elo_calc['elo_delta']:.0f} < {self.elo_threshold:.0f}"
        
        logger.info(f"Evaluation complete:")
        logger.info(f"  Challenger win rate: {results['challenger_win_rate']:.1%}")
        logger.info(f"  ELO: {challenger_elo:.0f} -> {elo_calc['elo_after']:.0f} (Δ {elo_calc['elo_delta']:.0f})")
        logger.info(f"  Promoted: {should_promote}")
        if should_promote:
            logger.info(f"  Reason: {', '.join(results['promotion_reason'])}")
        
        return results, should_promote
