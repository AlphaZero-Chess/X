"""
Evaluation Manager - TPU-Enhanced Model Evaluation with Pod Balancing

Features:
- Pod-balanced evaluation: Distribute games across multiple TPU pods
- TPU-aware ELO aggregation: Weight results by pod performance
- Async/Sync modes: Streaming updates or blocking execution
- Fault tolerance: Reassign games from failed pods
- Per-pod metrics: Track individual pod performance

This manager transforms basic evaluation into a scalable, distributed process
that leverages the full TPU cluster for rapid model comparison.
"""

import asyncio
import time
import logging
import uuid
import json
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, timezone
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path
import numpy as np

from tpu_cluster_manager import get_tpu_grid, JobType
from evaluator import ELOCalculator, EvaluationMatch
from chess_engine import ChessEngine
from mcts import MCTS
import chess

logger = logging.getLogger(__name__)


class EvaluationStatus(str, Enum):
    """Evaluation job status"""
    PENDING = "pending"
    ALLOCATING_PODS = "allocating_pods"
    WARMING_UP = "warming_up"
    IN_PROGRESS = "in_progress"
    AGGREGATING = "aggregating"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class PodEvaluationTask:
    """Evaluation task assigned to a TPU pod"""
    pod_id: int
    games_assigned: int
    games_completed: int = 0
    wins_challenger: int = 0
    wins_champion: int = 0
    draws: int = 0
    status: str = "pending"
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    avg_game_duration: float = 0.0
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    def get_win_rate(self) -> float:
        """Get challenger win rate for this pod"""
        if self.games_completed == 0:
            return 0.0
        return self.wins_challenger / self.games_completed


@dataclass
class EvaluationJob:
    """Complete evaluation job tracking"""
    job_id: str
    challenger_name: str
    champion_name: str
    total_games: int
    pods_allocated: int
    status: EvaluationStatus
    
    # Configuration
    use_tpu_pods: bool = True
    autoscale_eval: bool = True
    pod_warmup_seconds: int = 10
    aggregation_mode: str = "weighted_by_games"
    elo_k_factor: int = 32
    
    # Progress tracking
    games_completed: int = 0
    pod_tasks: Dict[int, PodEvaluationTask] = None
    
    # Results
    challenger_wins: int = 0
    champion_wins: int = 0
    draws: int = 0
    challenger_win_rate: float = 0.0
    elo_delta: float = 0.0
    
    # Per-pod breakdown
    per_pod_results: Dict[int, Dict] = None
    
    # Timing
    created_at: str = ""
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    
    # Telemetry
    metrics: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.pod_tasks is None:
            self.pod_tasks = {}
        if self.per_pod_results is None:
            self.per_pod_results = {}
        if self.metrics is None:
            self.metrics = {}
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()
    
    def to_dict(self) -> Dict:
        result = asdict(self)
        result['status'] = self.status.value
        result['pod_tasks'] = {k: v.to_dict() for k, v in self.pod_tasks.items()}
        return result
    
    def calculate_progress(self) -> float:
        """Calculate overall progress (0-100%)"""
        if self.total_games == 0:
            return 0.0
        return min(100.0, (self.games_completed / self.total_games) * 100)


class EvaluationManager:
    """
    Manages TPU-enhanced model evaluation with pod balancing
    
    Key Features:
    1. Pod Balancing: Distribute games across pods for parallelism
    2. TPU-Aware ELO: Account for pod performance variance
    3. Async/Sync: Support streaming and blocking modes
    4. Fault Tolerance: Reassign games from failed pods
    5. Telemetry: Detailed metrics per pod and aggregate
    """
    
    def __init__(
        self,
        tpu_grid_manager=None,
        num_simulations: int = 400,
        results_dir: str = "/app/backend/cache/evaluation_results"
    ):
        """Initialize evaluation manager"""
        self.tpu_grid = tpu_grid_manager or get_tpu_grid()
        self.num_simulations = num_simulations
        self.results_dir = Path(results_dir)
        self.results_dir.mkdir(parents=True, exist_ok=True)
        
        # Active evaluation jobs
        self.active_jobs: Dict[str, EvaluationJob] = {}
        self.completed_jobs: List[EvaluationJob] = []
        
        # WebSocket clients for streaming
        self.ws_clients: Dict[str, List] = {}  # job_id -> [websocket clients]
        
        logger.info(f"EvaluationManager initialized with {self.tpu_grid.num_tpus:,} TPUs")
    
    async def start_evaluation(
        self,
        challenger_model,
        champion_model,
        challenger_name: str,
        champion_name: str,
        challenger_elo: float = 1500.0,
        champion_elo: float = 1500.0,
        num_eval_games: int = 200,
        pods_for_eval: int = 2,
        use_tpu_pods: bool = True,
        autoscale_eval: bool = True,
        pod_warmup_seconds: int = 10,
        aggregation_mode: str = "weighted_by_games",
        elo_k_factor: int = 32,
        async_mode: bool = False
    ) -> Tuple[EvaluationJob, Dict]:
        """
        Start pod-balanced evaluation
        
        Args:
            challenger_model: New model to evaluate
            champion_model: Current best model
            challenger_name: Name of challenger
            champion_name: Name of champion
            challenger_elo: Current ELO of challenger
            champion_elo: Current ELO of champion
            num_eval_games: Total games to play
            pods_for_eval: Number of pods to use
            use_tpu_pods: Use TPU pods (False = sequential CPU)
            autoscale_eval: Allow autoscaler to adjust pod count
            pod_warmup_seconds: Pod warmup time
            aggregation_mode: 'simple' or 'weighted_by_games'
            elo_k_factor: ELO K-factor
            async_mode: Run in background (True) or blocking (False)
        
        Returns:
            (EvaluationJob, results_dict) or (EvaluationJob, None) if async
        """
        job_id = f"eval_{uuid.uuid4().hex[:8]}"
        
        logger.info(f"[{job_id}] Starting evaluation: {challenger_name} vs {champion_name}")
        logger.info(f"[{job_id}] Config: {num_eval_games} games, {pods_for_eval} pods, mode={aggregation_mode}")
        
        # Create evaluation job
        job = EvaluationJob(
            job_id=job_id,
            challenger_name=challenger_name,
            champion_name=champion_name,
            total_games=num_eval_games,
            pods_allocated=pods_for_eval if use_tpu_pods else 0,
            status=EvaluationStatus.PENDING,
            use_tpu_pods=use_tpu_pods,
            autoscale_eval=autoscale_eval,
            pod_warmup_seconds=pod_warmup_seconds,
            aggregation_mode=aggregation_mode,
            elo_k_factor=elo_k_factor
        )
        
        self.active_jobs[job_id] = job
        
        # Store models for execution
        job._challenger_model = challenger_model
        job._champion_model = champion_model
        job._challenger_elo = challenger_elo
        job._champion_elo = champion_elo
        
        if async_mode:
            # Run in background
            asyncio.create_task(self._execute_evaluation(job))
            return job, None
        else:
            # Blocking execution
            results = await self._execute_evaluation(job)
            return job, results
    
    async def _execute_evaluation(self, job: EvaluationJob) -> Dict:
        """Execute evaluation job"""
        try:
            job.status = EvaluationStatus.ALLOCATING_PODS
            job.started_at = datetime.now(timezone.utc).isoformat()
            
            # Step 1: Allocate pods (or use CPU fallback)
            if job.use_tpu_pods:
                await self._allocate_pods(job)
            else:
                logger.info(f"[{job.job_id}] Using sequential CPU evaluation")
                job.status = EvaluationStatus.IN_PROGRESS
            
            # Step 2: Distribute games across pods
            await self._distribute_games(job)
            
            # Step 3: Execute evaluation games
            job.status = EvaluationStatus.IN_PROGRESS
            await self._execute_games(job)
            
            # Step 4: Aggregate results
            job.status = EvaluationStatus.AGGREGATING
            results = await self._aggregate_results(job)
            
            # Step 5: Calculate ELO
            await self._calculate_elo(job, results)
            
            # Step 6: Finalize
            job.status = EvaluationStatus.COMPLETED
            job.completed_at = datetime.now(timezone.utc).isoformat()
            
            # Save results
            self._save_evaluation_results(job, results)
            
            # Move to completed
            self.completed_jobs.append(job)
            del self.active_jobs[job.job_id]
            
            logger.info(f"[{job.job_id}] Evaluation complete: Win rate={job.challenger_win_rate:.1%}, ELO delta={job.elo_delta:+.0f}")
            
            return results
        
        except Exception as e:
            logger.error(f"[{job.job_id}] Evaluation failed: {e}")
            import traceback
            traceback.print_exc()
            
            job.status = EvaluationStatus.FAILED
            job.completed_at = datetime.now(timezone.utc).isoformat()
            
            return {"error": str(e), "job_id": job.job_id}
    
    async def _allocate_pods(self, job: EvaluationJob):
        """Allocate TPU pods for evaluation"""
        logger.info(f"[{job.job_id}] Allocating {job.pods_allocated} TPU pods")
        
        success, allocated_tpus = self.tpu_grid.allocate_tpus(
            job_id=job.job_id,
            job_type=JobType.EVALUATION,
            num_tpus=job.pods_allocated * 8,  # Each pod = 8 TPUs
            priority=6
        )
        
        if not success:
            logger.warning(f"[{job.job_id}] Could not allocate requested pods, using available capacity")
            # Fallback: use fewer pods or queue
            await asyncio.sleep(2)
        
        # Warmup pods
        if job.pod_warmup_seconds > 0:
            job.status = EvaluationStatus.WARMING_UP
            logger.info(f"[{job.job_id}] Warming up pods for {job.pod_warmup_seconds}s")
            await asyncio.sleep(job.pod_warmup_seconds)
    
    async def _distribute_games(self, job: EvaluationJob):
        """Distribute games across pods"""
        if not job.use_tpu_pods:
            # Single pod (CPU)
            job.pod_tasks[0] = PodEvaluationTask(
                pod_id=0,
                games_assigned=job.total_games,
                status="ready"
            )
            return
        
        # Distribute games evenly across pods
        games_per_pod = job.total_games // job.pods_allocated
        remainder = job.total_games % job.pods_allocated
        
        for pod_id in range(job.pods_allocated):
            games_for_this_pod = games_per_pod + (1 if pod_id < remainder else 0)
            job.pod_tasks[pod_id] = PodEvaluationTask(
                pod_id=pod_id,
                games_assigned=games_for_this_pod,
                status="ready"
            )
        
        logger.info(f"[{job.job_id}] Games distributed: {games_per_pod}-{games_per_pod+1} per pod")
    
    async def _execute_games(self, job: EvaluationJob):
        """Execute evaluation games across pods"""
        logger.info(f"[{job.job_id}] Starting game execution")
        
        # Create evaluation match
        match = EvaluationMatch(
            job._challenger_model,
            job._champion_model,
            num_simulations=self.num_simulations
        )
        
        # Execute games for each pod (simulated parallelism)
        total_games = 0
        for pod_id, task in job.pod_tasks.items():
            task.status = "running"
            task.start_time = time.time()
            
            logger.info(f"[{job.job_id}] Pod {pod_id} executing {task.games_assigned} games")
            
            # Play games for this pod
            for game_idx in range(task.games_assigned):
                challenger_plays_white = (total_games % 2 == 0)
                
                # Play game
                result = match.play_game(challenger_plays_white)
                
                # Update task stats
                if result == "1-0":
                    if challenger_plays_white:
                        task.wins_challenger += 1
                    else:
                        task.wins_champion += 1
                elif result == "0-1":
                    if challenger_plays_white:
                        task.wins_champion += 1
                    else:
                        task.wins_challenger += 1
                else:
                    task.draws += 1
                
                task.games_completed += 1
                job.games_completed += 1
                total_games += 1
                
                # Stream update to WebSocket clients
                await self._broadcast_update(job)
                
                # Log progress
                if job.games_completed % 10 == 0:
                    logger.info(f"[{job.job_id}] Progress: {job.games_completed}/{job.total_games} games "
                               f"({job.calculate_progress():.1f}%)")
            
            task.status = "completed"
            task.end_time = time.time()
            task.avg_game_duration = (task.end_time - task.start_time) / max(task.games_completed, 1)
            
            logger.info(f"[{job.job_id}] Pod {pod_id} complete: {task.wins_challenger}W-{task.wins_champion}L-{task.draws}D "
                       f"(avg {task.avg_game_duration:.2f}s/game)")
    
    async def _aggregate_results(self, job: EvaluationJob) -> Dict:
        """Aggregate results from all pods"""
        logger.info(f"[{job.job_id}] Aggregating results (mode={job.aggregation_mode})")
        
        # Collect per-pod results
        for pod_id, task in job.pod_tasks.items():
            job.per_pod_results[pod_id] = {
                'games_completed': task.games_completed,
                'wins_challenger': task.wins_challenger,
                'wins_champion': task.wins_champion,
                'draws': task.draws,
                'win_rate_challenger': task.get_win_rate(),
                'avg_game_duration': task.avg_game_duration
            }
        
        # Aggregate totals
        job.challenger_wins = sum(t.wins_challenger for t in job.pod_tasks.values())
        job.champion_wins = sum(t.wins_champion for t in job.pod_tasks.values())
        job.draws = sum(t.draws for t in job.pod_tasks.values())
        
        # Calculate win rate
        if job.games_completed > 0:
            if job.aggregation_mode == "simple":
                # Simple average
                job.challenger_win_rate = job.challenger_wins / job.games_completed
            elif job.aggregation_mode == "weighted_by_games":
                # Weighted by games completed per pod (more robust)
                total_weighted_wins = 0.0
                total_weight = 0.0
                
                for pod_id, task in job.pod_tasks.items():
                    weight = task.games_completed
                    pod_win_rate = task.get_win_rate()
                    total_weighted_wins += pod_win_rate * weight
                    total_weight += weight
                
                job.challenger_win_rate = total_weighted_wins / max(total_weight, 1)
            else:
                # Fallback to simple
                job.challenger_win_rate = job.challenger_wins / job.games_completed
        
        results = {
            'job_id': job.job_id,
            'total_games': job.games_completed,
            'challenger_wins': job.challenger_wins,
            'champion_wins': job.champion_wins,
            'draws': job.draws,
            'challenger_win_rate': job.challenger_win_rate,
            'per_pod_results': job.per_pod_results,
            'aggregation_mode': job.aggregation_mode
        }
        
        logger.info(f"[{job.job_id}] Aggregation complete: {job.challenger_wins}W-{job.champion_wins}L-{job.draws}D "
                   f"(win rate: {job.challenger_win_rate:.1%})")
        
        return results
    
    async def _calculate_elo(self, job: EvaluationJob, results: Dict):
        """Calculate TPU-aware ELO delta"""
        logger.info(f"[{job.job_id}] Calculating ELO (K-factor={job.elo_k_factor})")
        
        # Standard ELO calculation
        elo_calc = ELOCalculator.calculate_elo_delta(
            wins=job.challenger_wins,
            losses=job.champion_wins,
            draws=job.draws,
            current_elo=job._challenger_elo,
            opponent_elo=job._champion_elo,
            k_factor=job.elo_k_factor
        )
        
        job.elo_delta = elo_calc['elo_delta']
        
        # Store detailed ELO calculations
        results['elo_calculations'] = {
            'elo_before': elo_calc['elo_before'],
            'elo_after': elo_calc['elo_after'],
            'elo_delta': elo_calc['elo_delta'],
            'expected_score': elo_calc['expected_score'],
            'actual_score': elo_calc['actual_score'],
            'k_factor': job.elo_k_factor
        }
        
        # Calculate per-pod ELO contributions (for diagnostics)
        per_pod_elo = {}
        for pod_id, task in job.pod_tasks.items():
            pod_elo_calc = ELOCalculator.calculate_elo_delta(
                wins=task.wins_challenger,
                losses=task.wins_champion,
                draws=task.draws,
                current_elo=job._challenger_elo,
                opponent_elo=job._champion_elo,
                k_factor=job.elo_k_factor
            )
            per_pod_elo[pod_id] = {
                'elo_delta': pod_elo_calc['elo_delta'],
                'win_rate': task.get_win_rate(),
                'games': task.games_completed
            }
        
        results['per_pod_elo'] = per_pod_elo
        
        logger.info(f"[{job.job_id}] ELO calculation complete: Δ {job.elo_delta:+.0f}")
    
    async def _broadcast_update(self, job: EvaluationJob):
        """Broadcast update to WebSocket clients"""
        if job.job_id not in self.ws_clients:
            return
        
        update = {
            'job_id': job.job_id,
            'status': job.status.value,
            'games_completed': job.games_completed,
            'total_games': job.total_games,
            'progress': job.calculate_progress(),
            'challenger_wins': job.challenger_wins,
            'champion_wins': job.champion_wins,
            'draws': job.draws,
            'timestamp': datetime.now(timezone.utc).isoformat()
        }
        
        # Send to all connected clients
        clients = self.ws_clients.get(job.job_id, [])
        for client in clients:
            try:
                await client.send_json(update)
            except:
                pass
    
    def _save_evaluation_results(self, job: EvaluationJob, results: Dict):
        """Save evaluation results to disk"""
        try:
            results_file = self.results_dir / f"eval_{job.job_id}_{int(time.time())}.json"
            
            output = {
                'job': job.to_dict(),
                'results': results,
                'saved_at': datetime.now(timezone.utc).isoformat()
            }
            
            with open(results_file, 'w') as f:
                json.dump(output, f, indent=2)
            
            logger.info(f"[{job.job_id}] Results saved: {results_file}")
        
        except Exception as e:
            logger.error(f"[{job.job_id}] Failed to save results: {e}")
    
    def get_job_status(self, job_id: str) -> Optional[Dict]:
        """Get status of evaluation job"""
        # Check active jobs
        if job_id in self.active_jobs:
            job = self.active_jobs[job_id]
            return {
                'job_id': job.job_id,
                'status': job.status.value,
                'progress': job.calculate_progress(),
                'games_completed': job.games_completed,
                'total_games': job.total_games,
                'per_pod_status': {
                    pod_id: {
                        'games_completed': task.games_completed,
                        'games_assigned': task.games_assigned,
                        'status': task.status
                    }
                    for pod_id, task in job.pod_tasks.items()
                }
            }
        
        # Check completed jobs
        for job in self.completed_jobs:
            if job.job_id == job_id:
                return {
                    'job_id': job.job_id,
                    'status': job.status.value,
                    'progress': 100.0,
                    'games_completed': job.games_completed,
                    'total_games': job.total_games,
                    'challenger_win_rate': job.challenger_win_rate,
                    'elo_delta': job.elo_delta
                }
        
        return None
    
    def get_job_results(self, job_id: str) -> Optional[Dict]:
        """Get results of completed evaluation job"""
        for job in self.completed_jobs:
            if job.job_id == job_id:
                return {
                    'job_id': job.job_id,
                    'challenger_name': job.challenger_name,
                    'champion_name': job.champion_name,
                    'total_games': job.games_completed,
                    'challenger_wins': job.challenger_wins,
                    'champion_wins': job.champion_wins,
                    'draws': job.draws,
                    'challenger_win_rate': job.challenger_win_rate,
                    'elo_delta': job.elo_delta,
                    'per_pod_results': job.per_pod_results,
                    'completed_at': job.completed_at
                }
        
        return None
    
    def register_ws_client(self, job_id: str, client):
        """Register WebSocket client for job updates"""
        if job_id not in self.ws_clients:
            self.ws_clients[job_id] = []
        self.ws_clients[job_id].append(client)
    
    def unregister_ws_client(self, job_id: str, client):
        """Unregister WebSocket client"""
        if job_id in self.ws_clients:
            try:
                self.ws_clients[job_id].remove(client)
            except ValueError:
                pass


# Global instance
_evaluation_manager = None


def get_evaluation_manager() -> EvaluationManager:
    """Get or create global evaluation manager"""
    global _evaluation_manager
    
    if _evaluation_manager is None:
        _evaluation_manager = EvaluationManager()
    
    return _evaluation_manager


def reset_evaluation_manager():
    """Reset global evaluation manager (for testing)"""
    global _evaluation_manager
    _evaluation_manager = None
