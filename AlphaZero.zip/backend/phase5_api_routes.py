"""
Phase 5 API Routes - Adaptive Evolution & Long-Cycle Automation

Endpoints:
- POST /api/alphazero/evolution/start        - Start autonomous evolution
- GET  /api/alphazero/evolution/status       - Get evolution status
- POST /api/alphazero/evolution/stop         - Stop evolution
- GET  /api/alphazero/evolution/history      - Get evolution history
- GET  /api/alphazero/evolution/lineage      - Get model lineage tree
- GET  /api/alphazero/evolution/iq-growth    - Get IQ growth metrics
- GET  /api/alphazero/evolution/summary      - Get evolution summary
- WS   /ws/alphazero/evolution/live          - Live evolution updates
"""

from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect, BackgroundTasks
from pydantic import BaseModel, Field
from typing import Optional, Dict, List
import logging
import json
import asyncio
from datetime import datetime

from phase5_adaptive_orchestrator import (
    get_phase5_orchestrator,
    Phase5AdaptiveOrchestrator,
    EvolutionConfig,
    EvolutionPhase
)
from evolution_tracker import get_evolution_tracker

logger = logging.getLogger(__name__)

# Create router
phase5_router = APIRouter(prefix="/api/alphazero/evolution", tags=["AlphaZero Phase 5"])

# WebSocket clients registry
ws_clients: List[WebSocket] = []


# ====================
# Request Models
# ====================

class StartEvolutionRequest(BaseModel):
    # Cycle parameters
    num_selfplay_games: int = Field(default=1000, ge=100, le=5000, description="Games per cycle")
    num_tpus_selfplay: int = Field(default=500, ge=100, le=1000, description="TPUs for self-play")
    num_tpus_training: int = Field(default=100, ge=50, le=500, description="TPUs for training")
    num_training_epochs: int = Field(default=3, ge=1, le=10, description="Training epochs")
    num_eval_games: int = Field(default=20, ge=10, le=100, description="Evaluation games")
    batch_size: int = Field(default=256, ge=64, le=512, description="Batch size")
    learning_rate: float = Field(default=0.001, ge=0.0001, le=0.01, description="Learning rate")
    
    # Stagnation detection
    stagnation_window: int = Field(default=5, ge=3, le=10, description="Cycles to analyze")
    elo_threshold: float = Field(default=25.0, ge=10.0, le=100.0, description="Min ELO improvement")
    
    # Optimization triggers
    enable_hpo: bool = Field(default=True, description="Enable HPO")
    enable_nas: bool = Field(default=True, description="Enable NAS")
    auto_decide_optimization: bool = Field(default=True, description="Auto-decide HPO vs NAS")
    
    # HPO config
    hpo_max_trials: int = Field(default=10, ge=5, le=25, description="HPO trials")
    hpo_evaluation_games: int = Field(default=10, ge=5, le=20, description="HPO eval games")
    
    # NAS config
    nas_population_size: int = Field(default=8, ge=4, le=16, description="NAS population")
    nas_max_generations: int = Field(default=5, ge=3, le=10, description="NAS generations")
    
    # Limits
    max_cycles: Optional[int] = Field(default=None, ge=1, description="Max cycles (None=indefinite)")
    max_hours: Optional[float] = Field(default=None, ge=1.0, description="Max hours (None=indefinite)")


# ====================
# Evolution Endpoints
# ====================

@phase5_router.post("/start")
async def start_evolution(request: StartEvolutionRequest, background_tasks: BackgroundTasks):
    """
    Start Phase 5 Autonomous Evolution
    
    Initiates continuous long-cycle training with:
    - Automatic stagnation detection
    - HPO/NAS triggers on performance plateaus
    - Model evolution tracking
    - IQ growth monitoring
    """
    try:
        orchestrator = get_phase5_orchestrator()
        
        if orchestrator.is_running:
            raise HTTPException(status_code=400, detail="Evolution already running")
        
        logger.info("Starting Phase 5 Evolution")
        
        # Create config from request
        config = EvolutionConfig(
            num_selfplay_games=request.num_selfplay_games,
            num_tpus_selfplay=request.num_tpus_selfplay,
            num_tpus_training=request.num_tpus_training,
            num_training_epochs=request.num_training_epochs,
            num_eval_games=request.num_eval_games,
            batch_size=request.batch_size,
            learning_rate=request.learning_rate,
            stagnation_window=request.stagnation_window,
            elo_threshold=request.elo_threshold,
            enable_hpo=request.enable_hpo,
            enable_nas=request.enable_nas,
            auto_decide_optimization=request.auto_decide_optimization,
            hpo_max_trials=request.hpo_max_trials,
            hpo_evaluation_games=request.hpo_evaluation_games,
            nas_population_size=request.nas_population_size,
            nas_max_generations=request.nas_max_generations,
            max_cycles=request.max_cycles,
            max_hours=request.max_hours
        )
        
        # Start evolution
        session_id = await orchestrator.start_evolution(config)
        
        return {
            "success": True,
            "message": "Phase 5 Evolution started",
            "session_id": session_id,
            "config": request.dict(),
            "mode": "indefinite" if request.max_cycles is None and request.max_hours is None else "limited"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error starting evolution: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@phase5_router.get("/status")
async def get_evolution_status():
    """
    Get current evolution status
    
    Returns real-time status including:
    - Current phase (training, HPO, NAS, etc.)
    - Cycle progress
    - Best ELO achieved
    - Stagnation metrics
    - Sub-component status
    """
    try:
        orchestrator = get_phase5_orchestrator()
        
        status = orchestrator.get_evolution_status()
        
        return {
            "success": True,
            **status
        }
    
    except Exception as e:
        logger.error(f"Error getting evolution status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@phase5_router.post("/stop")
async def stop_evolution():
    """
    Stop evolution gracefully
    
    Stops current cycle, saves state, and terminates all sub-processes
    """
    try:
        orchestrator = get_phase5_orchestrator()
        
        if not orchestrator.is_running:
            raise HTTPException(status_code=400, detail="No evolution session active")
        
        orchestrator.stop_evolution()
        
        logger.info("Evolution stop requested")
        
        return {
            "success": True,
            "message": "Evolution stopping (completing current operation...)",
            "total_cycles": orchestrator.total_cycles,
            "best_elo": orchestrator.best_elo
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error stopping evolution: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@phase5_router.get("/history")
async def get_evolution_history():
    """
    Get complete evolution history
    
    Returns:
    - All training cycles
    - IQ growth timeline
    - Model lineage tree
    - Optimization events
    """
    try:
        orchestrator = get_phase5_orchestrator()
        
        history = orchestrator.get_evolution_history()
        
        return {
            "success": True,
            **history
        }
    
    except Exception as e:
        logger.error(f"Error getting evolution history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@phase5_router.get("/lineage")
async def get_model_lineage():
    """
    Get model lineage tree
    
    Returns hierarchical tree structure showing:
    - Parent-child relationships
    - Generation numbers
    - Creation methods (training, HPO, NAS)
    - Performance metrics per model
    """
    try:
        evolution_tracker = get_evolution_tracker()
        
        lineage_tree = evolution_tracker.get_lineage_tree()
        
        if not lineage_tree:
            return {
                "success": True,
                "lineage_tree": None,
                "message": "No models tracked yet"
            }
        
        return {
            "success": True,
            "lineage_tree": lineage_tree,
            "total_models": len(evolution_tracker.lineage_tree),
            "generations": max(m.generation for m in evolution_tracker.lineage_tree.values()) + 1 if evolution_tracker.lineage_tree else 0
        }
    
    except Exception as e:
        logger.error(f"Error getting model lineage: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@phase5_router.get("/iq-growth")
async def get_iq_growth(limit: int = 100):
    """
    Get IQ growth metrics over time
    
    Returns timeline of:
    - IQ scores
    - ELO progression
    - Architecture complexity
    - Training efficiency
    """
    try:
        evolution_tracker = get_evolution_tracker()
        
        iq_growth = evolution_tracker.get_iq_growth_history(limit=limit)
        
        return {
            "success": True,
            "iq_growth": iq_growth,
            "total_records": len(iq_growth)
        }
    
    except Exception as e:
        logger.error(f"Error getting IQ growth: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@phase5_router.get("/summary")
async def get_evolution_summary():
    """
    Get comprehensive evolution summary
    
    Returns high-level statistics:
    - Total cycles and promotions
    - ELO gains
    - Generations evolved
    - Creation method breakdown
    - Stagnation analysis
    """
    try:
        evolution_tracker = get_evolution_tracker()
        
        summary = evolution_tracker.get_evolution_summary()
        
        return {
            "success": True,
            **summary
        }
    
    except Exception as e:
        logger.error(f"Error getting evolution summary: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@phase5_router.get("/stagnation-check")
async def check_stagnation(window: int = 5, elo_threshold: float = 25.0):
    """
    Check if evolution is currently stagnated
    
    Args:
        window: Number of cycles to analyze
        elo_threshold: Minimum ELO improvement required
    
    Returns:
        Stagnation analysis with recommendation
    """
    try:
        evolution_tracker = get_evolution_tracker()
        
        is_stagnated, analysis = evolution_tracker.detect_stagnation(
            window=window,
            elo_threshold=elo_threshold
        )
        
        return {
            "success": True,
            "is_stagnated": is_stagnated,
            **analysis
        }
    
    except Exception as e:
        logger.error(f"Error checking stagnation: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# WebSocket Endpoint
# ====================

@phase5_router.websocket("/ws/live")
async def websocket_evolution_live(websocket: WebSocket):
    """
    WebSocket endpoint for live evolution updates
    
    Sends real-time updates as evolution progresses:
    - Phase changes
    - Cycle completions
    - ELO updates
    - Optimization events
    """
    await websocket.accept()
    ws_clients.append(websocket)
    
    try:
        orchestrator = get_phase5_orchestrator()
        
        # Send initial status
        initial_status = orchestrator.get_evolution_status()
        await websocket.send_json({
            "type": "initial_status",
            **initial_status
        })
        
        # Keep connection alive and send periodic updates
        while True:
            try:
                # Wait for messages or timeout
                data = await asyncio.wait_for(websocket.receive_text(), timeout=5.0)
                
                # Echo heartbeat
                await websocket.send_json({"type": "heartbeat", "status": "connected"})
            
            except asyncio.TimeoutError:
                # Send periodic status update
                current_status = orchestrator.get_evolution_status()
                await websocket.send_json({
                    "type": "status_update",
                    **current_status
                })
            
            except WebSocketDisconnect:
                break
    
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    
    finally:
        if websocket in ws_clients:
            ws_clients.remove(websocket)
        try:
            await websocket.close()
        except:
            pass


async def broadcast_evolution_event(event_type: str, data: Dict):
    """Broadcast evolution event to all connected WebSocket clients"""
    if not ws_clients:
        return
    
    message = {
        "type": event_type,
        "timestamp": datetime.utcnow().isoformat(),
        **data
    }
    
    # Send to all clients
    disconnected = []
    for client in ws_clients:
        try:
            await client.send_json(message)
        except:
            disconnected.append(client)
    
    # Remove disconnected clients
    for client in disconnected:
        ws_clients.remove(client)


# ====================
# Admin Endpoints
# ====================

@phase5_router.post("/admin/reset-tracker")
async def admin_reset_tracker():
    """Reset evolution tracker (for testing)"""
    try:
        from evolution_tracker import reset_evolution_tracker
        reset_evolution_tracker()
        
        return {
            "success": True,
            "message": "Evolution tracker reset"
        }
    except Exception as e:
        logger.error(f"Error resetting tracker: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@phase5_router.post("/admin/reset-orchestrator")
async def admin_reset_orchestrator():
    """Reset Phase 5 orchestrator (for testing)"""
    try:
        from phase5_adaptive_orchestrator import reset_phase5_orchestrator
        reset_phase5_orchestrator()
        
        return {
            "success": True,
            "message": "Phase 5 orchestrator reset"
        }
    except Exception as e:
        logger.error(f"Error resetting orchestrator: {e}")
        raise HTTPException(status_code=500, detail=str(e))
