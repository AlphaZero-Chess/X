"""
Blended Training Pipeline for AlphaZero
Combines external PGN data with self-play experience for curriculum-based training
"""
import torch
import numpy as np
import logging
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from datetime import datetime, timezone
import json
import random

from neural_network import AlphaZeroNetwork
from trainer import AlphaZeroTrainer
from memory_compression import MemoryCompressor
from pgn_ingest import PGNIngestor
from chess_engine import ChessEngine
from device_manager import device_manager

logger = logging.getLogger(__name__)


class BlendedTrainingPipeline:
    """
    Training pipeline that blends external PGN data with self-play experience
    Implements curriculum-based weighted sampling
    """
    
    def __init__(
        self,
        network: AlphaZeroNetwork,
        learning_rate: float = 0.001,
        cache_dir: str = "/app/backend/cache/blended_training"
    ):
        self.network = network
        self.trainer = AlphaZeroTrainer(network, learning_rate=learning_rate)
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize components
        self.pgn_ingestor = PGNIngestor()
        self.memory_compressor = MemoryCompressor()
        
        # Training history
        self.training_sessions = []
        
        logger.info("Blended Training Pipeline initialized")
    
    def prepare_external_pgn_data(
        self,
        source_filter: Optional[str] = None,
        complexity_filter: Optional[str] = None,
        max_games: int = 100
    ) -> List[Dict]:
        """
        Prepare external PGN data for training
        
        Args:
            source_filter: 'human' or 'engine'
            complexity_filter: 'opening', 'tactical', 'positional', 'endgame'
            max_games: Maximum games to load
            
        Returns:
            List of training positions from external PGNs
        """
        logger.info(f"Preparing external PGN data (source={source_filter}, complexity={complexity_filter})")
        
        # Get processed games
        games = self.pgn_ingestor.get_processed_games(
            source_filter=source_filter,
            complexity_filter=complexity_filter,
            limit=max_games
        )
        
        # Convert to training positions
        training_positions = []
        engine = ChessEngine()
        
        for game in games:
            game_result = game.get('result_value', 0.0)
            
            for position in game.get('positions', []):
                fen = position.get('fen')
                
                # Encode position
                engine.set_fen(fen)
                position_encoding = engine.encode_board()
                
                # Create training sample
                # Note: External PGNs don't have policy (move probabilities)
                # We'll use a uniform policy over legal moves as baseline
                legal_moves = list(engine.board.legal_moves)
                policy = np.zeros(4672)  # Total possible moves in chess
                
                if legal_moves:
                    # Uniform distribution over legal moves
                    move_prob = 1.0 / len(legal_moves)
                    for move in legal_moves:
                        move_idx = self._move_to_index(move)
                        policy[move_idx] = move_prob
                
                training_positions.append({
                    'position': position_encoding,
                    'policy': policy,
                    'value': game_result,
                    'fen': fen,
                    'source': 'external_pgn',
                    'game_id': game.get('game_id'),
                    'complexity': position.get('complexity_scores', {})
                })
        
        logger.info(f"Prepared {len(training_positions)} positions from {len(games)} external games")
        
        return training_positions
    
    def blend_training_data(
        self,
        external_data: List[Dict],
        selfplay_data: List[Dict],
        external_weight: float = 0.7,
        curriculum_phase: int = 1
    ) -> List[Dict]:
        """
        Blend external PGN data with self-play data using weighted sampling
        
        Args:
            external_data: Positions from external PGNs
            selfplay_data: Positions from self-play
            external_weight: Weight for external data (0.0-1.0)
            curriculum_phase: Current curriculum phase (1, 2, or 3)
            
        Returns:
            Blended dataset for training
        """
        logger.info(f"Blending training data (external_weight={external_weight}, phase={curriculum_phase})")
        
        # Adjust weights based on curriculum phase
        if curriculum_phase == 1:
            # Phase 1: 70% External, 30% Self-Play
            external_weight = 0.7
        elif curriculum_phase == 2:
            # Phase 2: 50% External, 50% Self-Play
            external_weight = 0.5
        else:  # Phase 3
            # Phase 3: 20% External, 80% Self-Play
            external_weight = 0.2
        
        selfplay_weight = 1.0 - external_weight
        
        # Calculate sample sizes
        total_samples = len(external_data) + len(selfplay_data)
        external_samples = int(total_samples * external_weight)
        selfplay_samples = int(total_samples * selfplay_weight)
        
        # Sample from each pool
        blended_data = []
        
        if external_data and external_samples > 0:
            external_sample = random.sample(
                external_data,
                min(external_samples, len(external_data))
            )
            blended_data.extend(external_sample)
        
        if selfplay_data and selfplay_samples > 0:
            selfplay_sample = random.sample(
                selfplay_data,
                min(selfplay_samples, len(selfplay_data))
            )
            blended_data.extend(selfplay_sample)
        
        # Shuffle blended data
        random.shuffle(blended_data)
        
        logger.info(f"Blended dataset: {len(blended_data)} positions "
                   f"({len([d for d in blended_data if d.get('source') == 'external_pgn'])} external, "
                   f"{len([d for d in blended_data if d.get('source') != 'external_pgn'])} self-play)")
        
        return blended_data
    
    def train_blended(
        self,
        external_data: List[Dict],
        selfplay_data: List[Dict],
        num_epochs: int = 5,
        batch_size: int = 64,
        curriculum_phase: int = 1,
        save_checkpoint: bool = True
    ) -> Dict[str, any]:
        """
        Train network on blended data
        
        Args:
            external_data: External PGN positions
            selfplay_data: Self-play positions
            num_epochs: Training epochs
            batch_size: Batch size
            curriculum_phase: Current curriculum phase
            save_checkpoint: Whether to save checkpoint after training
            
        Returns:
            Training metrics
        """
        logger.info(f"Starting blended training (phase={curriculum_phase}, epochs={num_epochs})")
        
        # Blend data
        blended_data = self.blend_training_data(
            external_data,
            selfplay_data,
            curriculum_phase=curriculum_phase
        )
        
        if not blended_data:
            logger.error("No training data available")
            return {'error': 'No training data'}
        
        # Train using standard trainer
        training_history = []
        
        for epoch in range(num_epochs):
            epoch_metrics = self.trainer.train_epoch(blended_data, batch_size=batch_size)
            training_history.append(epoch_metrics)
            
            logger.info(f"Epoch {epoch+1}/{num_epochs} - "
                       f"Loss: {epoch_metrics.get('loss', 0):.4f}, "
                       f"Policy Loss: {epoch_metrics.get('policy_loss', 0):.4f}, "
                       f"Value Loss: {epoch_metrics.get('value_loss', 0):.4f}")
        
        # Calculate training summary
        avg_loss = np.mean([m.get('loss', 0) for m in training_history])
        avg_policy_loss = np.mean([m.get('policy_loss', 0) for m in training_history])
        avg_value_loss = np.mean([m.get('value_loss', 0) for m in training_history])
        
        summary = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'curriculum_phase': curriculum_phase,
            'num_epochs': num_epochs,
            'batch_size': batch_size,
            'total_positions': len(blended_data),
            'external_positions': len([d for d in blended_data if d.get('source') == 'external_pgn']),
            'selfplay_positions': len([d for d in blended_data if d.get('source') != 'external_pgn']),
            'avg_loss': float(avg_loss),
            'avg_policy_loss': float(avg_policy_loss),
            'avg_value_loss': float(avg_value_loss),
            'training_history': training_history
        }
        
        # Save session
        self.training_sessions.append(summary)
        self._save_session(summary)
        
        logger.info(f"Blended training complete - Avg Loss: {avg_loss:.4f}")
        
        return summary
    
    def determine_curriculum_phase(self, total_games_played: int) -> int:
        """
        Determine curriculum phase based on total games played
        
        Phase 1 (0-1000): 70% Human, 30% Self-Play
        Phase 2 (1000-5000): 50% Human, 50% Self-Play
        Phase 3 (5000+): 20% Human, 80% Self-Play
        """
        if total_games_played < 1000:
            return 1
        elif total_games_played < 5000:
            return 2
        else:
            return 3
    
    def _move_to_index(self, move: 'chess.Move') -> int:
        """Convert chess move to index for policy vector"""
        # Simplified move indexing
        # In practice, would use proper move encoding scheme
        from_square = move.from_square
        to_square = move.to_square
        return from_square * 64 + to_square
    
    def _save_session(self, session: Dict):
        """Save training session to cache"""
        try:
            session_file = self.cache_dir / f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(session_file, 'w') as f:
                json.dump(session, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save training session: {e}")
    
    def get_training_history(self, limit: int = 10) -> List[Dict]:
        """Get recent training sessions"""
        return self.training_sessions[-limit:]
    
    def get_curriculum_recommendations(self, total_games: int) -> Dict[str, any]:
        """
        Get curriculum recommendations based on progress
        """
        phase = self.determine_curriculum_phase(total_games)
        
        recommendations = {
            'current_phase': phase,
            'total_games': total_games,
            'phase_description': '',
            'data_ratio': {},
            'focus_areas': [],
            'next_milestone': 0
        }
        
        if phase == 1:
            recommendations['phase_description'] = "Early Learning - Foundation Building"
            recommendations['data_ratio'] = {'human': 0.7, 'selfplay': 0.3}
            recommendations['focus_areas'] = [
                "Learn fundamental opening principles from GM games",
                "Absorb basic tactical patterns",
                "Build position evaluation baseline"
            ]
            recommendations['next_milestone'] = 1000
        elif phase == 2:
            recommendations['phase_description'] = "Intermediate Development - Pattern Integration"
            recommendations['data_ratio'] = {'human': 0.5, 'selfplay': 0.5}
            recommendations['focus_areas'] = [
                "Balance human strategic knowledge with self-discovered patterns",
                "Develop unique playing style",
                "Refine tactical execution"
            ]
            recommendations['next_milestone'] = 5000
        else:
            recommendations['phase_description'] = "Advanced Mastery - Self-Evolution"
            recommendations['data_ratio'] = {'human': 0.2, 'selfplay': 0.8}
            recommendations['focus_areas'] = [
                "Prioritize self-discovered novelties",
                "Refine superhuman strategies",
                "Target ELO 3500+ performance"
            ]
            recommendations['next_milestone'] = total_games + 5000
        
        return recommendations
