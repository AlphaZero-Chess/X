"""
Emergent Integrations Manager
Handles Emergent LLM Key retrieval and management
"""
import os
import logging

logger = logging.getLogger(__name__)


class EmergentIntegrationsManager:
    """Manager for Emergent LLM integrations"""
    
    def __init__(self):
        self.api_key = None
        self._load_key()
    
    def _load_key(self):
        """Load Emergent LLM key from environment"""
        try:
            self.api_key = os.environ.get('EMERGENT_LLM_KEY')
            if self.api_key:
                logger.info("Emergent LLM Key loaded successfully")
            else:
                logger.warning("EMERGENT_LLM_KEY not found in environment")
        except Exception as e:
            logger.error(f"Failed to load Emergent LLM Key: {e}")
    
    def get_api_key(self) -> str:
        """Get Emergent LLM API key"""
        if not self.api_key:
            self._load_key()
        
        if not self.api_key:
            raise ValueError("EMERGENT_LLM_KEY not configured")
        
        return self.api_key
    
    def is_available(self) -> bool:
        """Check if Emergent LLM key is available"""
        return self.api_key is not None


# Global instance
emergent_integrations_manager = EmergentIntegrationsManager()
