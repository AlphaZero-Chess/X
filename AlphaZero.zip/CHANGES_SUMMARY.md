# AlphaZero Training Fix - Changes Summary

## Date
October 18, 2025

## Issue
`/api/train/start-alphazero` endpoint was returning a 500 Internal Server Error with the message:
```
AlphaZeroSelfPlayTrainer.__init__() got an unexpected keyword argument 'win_threshold'
```

## Files Modified

### 1. `/app/backend/server.py`

#### Change 1: Removed Invalid Parameters from Trainer Initialization (Lines 1030-1039)

**Before:**
```python
alphazero_trainer = AlphaZeroSelfPlayTrainer(
    max_games=config.max_games,
    max_hours=config.max_hours,
    num_simulations=config.num_simulations,
    replay_buffer_size=config.replay_buffer_size,
    batch_size=config.batch_size,
    learning_rate=config.learning_rate,
    checkpoint_interval=config.checkpoint_interval,
    eval_interval=config.eval_interval,
    win_threshold=config.win_threshold,      # ❌ REMOVED - Not supported
    num_eval_games=config.num_eval_games    # ❌ REMOVED - Not supported
)
```

**After:**
```python
alphazero_trainer = AlphaZeroSelfPlayTrainer(
    max_games=config.max_games,
    max_hours=config.max_hours,
    num_simulations=config.num_simulations,
    replay_buffer_size=config.replay_buffer_size,
    batch_size=config.batch_size,
    learning_rate=config.learning_rate,
    checkpoint_interval=config.checkpoint_interval,
    eval_interval=config.eval_interval
)
```

#### Change 2: Removed Invalid Parameter from run() Method Call (Line 1044)

**Before:**
```python
def run_training():
    try:
        alphazero_trainer.run(resume=config.resume)  # ❌ REMOVED - Not supported
    except Exception as e:
        logger.error(f"AlphaZero training error: {e}")
        import traceback
        traceback.print_exc()
```

**After:**
```python
def run_training():
    try:
        alphazero_trainer.run()  # ✅ FIXED - No resume parameter
    except Exception as e:
        logger.error(f"AlphaZero training error: {e}")
        import traceback
        traceback.print_exc()
```

## Files Added
None - Only modifications were made to existing files.

## Technical Details

### AlphaZeroSelfPlayTrainer Supported Parameters
The trainer class (`/app/backend/selfplay_trainer.py`) only accepts these parameters:
- `max_games` (int)
- `max_hours` (float)
- `num_simulations` (int)
- `replay_buffer_size` (int)
- `batch_size` (int)
- `learning_rate` (float)
- `checkpoint_interval` (int)
- `eval_interval` (int)
- `log_dir` (str)
- `mode` (SelfPlayMode)
- `num_workers` (Optional[int])
- `enable_fault_tolerance` (bool)
- `enable_performance_tuning` (bool)

### AlphaZeroSelfPlayTrainer.run() Supported Parameters
The `run()` method only accepts:
- `batch_games` (int, default=100)
- `train_epochs` (int, default=10)

## Verification

### Test Command
```bash
curl -X POST http://localhost:8001/api/train/start-alphazero \
  -H "Content-Type: application/json" \
  -d '{
    "max_games": 1000,
    "max_hours": 0.5,
    "num_simulations": 400,
    "resume": false
  }'
```

### Expected Response
```json
{
  "success": true,
  "message": "AlphaZero training started",
  "config": {...},
  "estimated_duration_hours": 0.5,
  "target_games": 1000
}
```

### Log Verification
Backend logs showing successful training initialization:
```
INFO: 🚀 Worker 0-5 starting
INFO: ✅ Self-play manager initialized
INFO: 📥 Task received: generate 17 games
```

## Status
✅ **FIXED** - The `/api/train/start-alphazero` endpoint now works without 500 errors and training starts successfully.

---

## Additional Fix: Status Endpoint KeyError (October 18, 2025)

### Problem
The `/api/train/status-alphazero` endpoint was crashing with a **KeyError: 'active'** at line 1088.

### Root Cause
The `AlphaZeroSelfPlayTrainer.get_status()` method returns a dictionary with key `'is_running'`, but the endpoint was trying to access a non-existent `'active'` key. Additionally, `'max_games'` and `'max_hours'` were not included in the status dictionary.

### Fix Applied (Lines 1085-1104 in server.py)

**Before:**
```python
status = alphazero_trainer.get_status()

# Calculate ETA
if status['active'] and status.get('games_per_sec', 0) > 0:  # ❌ KeyError
    remaining_games = status['max_games'] - status['games_completed']  # ❌ KeyError
    remaining_time_by_games = remaining_games / status['games_per_sec']
    remaining_time_by_clock = (status['max_hours'] * 3600) - status['elapsed_seconds']  # ❌ KeyError
    ...
```

**After:**
```python
status = alphazero_trainer.get_status()

# Add active flag for compatibility (maps from is_running)
status['active'] = status.get('is_running', False)

# Add max_games and max_hours from trainer attributes
status['max_games'] = alphazero_trainer.max_games
status['max_hours'] = alphazero_trainer.max_hours

# Calculate ETA
if status.get('active', False) and status.get('games_per_sec', 0) > 0:  # ✅ Safe access
    remaining_games = status['max_games'] - status.get('games_completed', 0)  # ✅ Safe access
    remaining_time_by_games = remaining_games / status['games_per_sec']
    remaining_time_by_clock = (status['max_hours'] * 3600) - status.get('elapsed_seconds', 0)  # ✅ Safe access
    ...
```

### Changes Summary
1. ✅ Added `status['active']` mapping from `status.get('is_running', False)`
2. ✅ Added `status['max_games']` from `alphazero_trainer.max_games`
3. ✅ Added `status['max_hours']` from `alphazero_trainer.max_hours`
4. ✅ Changed `status['active']` to `status.get('active', False)` for defensive programming
5. ✅ Changed `status['games_completed']` to `status.get('games_completed', 0)`
6. ✅ Changed `status['elapsed_seconds']` to `status.get('elapsed_seconds', 0)`

### Verification
✅ Status endpoint works when no training is active
✅ Status endpoint works during active training
✅ No more KeyError exceptions

**Test Results:**
```bash
# No training active:
curl http://localhost:8001/api/train/status-alphazero
{"active": false, "message": "No training session active", ...}

# During training:
curl http://localhost:8001/api/train/status-alphazero
{"active": true, "games_completed": 0, "max_games": 1000, ...}
```
