# AlphaZero Training Fix - Changes Summary

## Date
October 18, 2025

## Issue
`/api/train/start-alphazero` endpoint was returning a 500 Internal Server Error with the message:
```
AlphaZeroSelfPlayTrainer.__init__() got an unexpected keyword argument 'win_threshold'
```

## Files Modified

### 1. `/app/backend/server.py`

#### Change 1: Removed Invalid Parameters from Trainer Initialization (Lines 1030-1039)

**Before:**
```python
alphazero_trainer = AlphaZeroSelfPlayTrainer(
    max_games=config.max_games,
    max_hours=config.max_hours,
    num_simulations=config.num_simulations,
    replay_buffer_size=config.replay_buffer_size,
    batch_size=config.batch_size,
    learning_rate=config.learning_rate,
    checkpoint_interval=config.checkpoint_interval,
    eval_interval=config.eval_interval,
    win_threshold=config.win_threshold,      # ❌ REMOVED - Not supported
    num_eval_games=config.num_eval_games    # ❌ REMOVED - Not supported
)
```

**After:**
```python
alphazero_trainer = AlphaZeroSelfPlayTrainer(
    max_games=config.max_games,
    max_hours=config.max_hours,
    num_simulations=config.num_simulations,
    replay_buffer_size=config.replay_buffer_size,
    batch_size=config.batch_size,
    learning_rate=config.learning_rate,
    checkpoint_interval=config.checkpoint_interval,
    eval_interval=config.eval_interval
)
```

#### Change 2: Removed Invalid Parameter from run() Method Call (Line 1044)

**Before:**
```python
def run_training():
    try:
        alphazero_trainer.run(resume=config.resume)  # ❌ REMOVED - Not supported
    except Exception as e:
        logger.error(f"AlphaZero training error: {e}")
        import traceback
        traceback.print_exc()
```

**After:**
```python
def run_training():
    try:
        alphazero_trainer.run()  # ✅ FIXED - No resume parameter
    except Exception as e:
        logger.error(f"AlphaZero training error: {e}")
        import traceback
        traceback.print_exc()
```

## Files Added
None - Only modifications were made to existing files.

## Technical Details

### AlphaZeroSelfPlayTrainer Supported Parameters
The trainer class (`/app/backend/selfplay_trainer.py`) only accepts these parameters:
- `max_games` (int)
- `max_hours` (float)
- `num_simulations` (int)
- `replay_buffer_size` (int)
- `batch_size` (int)
- `learning_rate` (float)
- `checkpoint_interval` (int)
- `eval_interval` (int)
- `log_dir` (str)
- `mode` (SelfPlayMode)
- `num_workers` (Optional[int])
- `enable_fault_tolerance` (bool)
- `enable_performance_tuning` (bool)

### AlphaZeroSelfPlayTrainer.run() Supported Parameters
The `run()` method only accepts:
- `batch_games` (int, default=100)
- `train_epochs` (int, default=10)

## Verification

### Test Command
```bash
curl -X POST http://localhost:8001/api/train/start-alphazero \
  -H "Content-Type: application/json" \
  -d '{
    "max_games": 1000,
    "max_hours": 0.5,
    "num_simulations": 400,
    "resume": false
  }'
```

### Expected Response
```json
{
  "success": true,
  "message": "AlphaZero training started",
  "config": {...},
  "estimated_duration_hours": 0.5,
  "target_games": 1000
}
```

### Log Verification
Backend logs showing successful training initialization:
```
INFO: 🚀 Worker 0-5 starting
INFO: ✅ Self-play manager initialized
INFO: 📥 Task received: generate 17 games
```

## Status
✅ **FIXED** - The `/api/train/start-alphazero` endpoint now works without 500 errors and training starts successfully.
