import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { CheckCircle, Brain, Database, TrendingUp, Clock } from 'lucide-react';

function TrainingSummary({ summary, onClose }) {
  if (!summary) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <Card 
        className="max-w-2xl w-full bg-white"
        onClick={(e) => e.stopPropagation()}
      >
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-600">
            <CheckCircle className="h-6 w-6" />
            Memory Training Complete!
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Model Info */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Brain className="h-5 w-5 text-green-600" />
              <h3 className="font-semibold text-green-900">Model Updated</h3>
            </div>
            <p className="text-green-800 font-mono text-sm">{summary.model_name}</p>
            {summary.is_active && (
              <span className="inline-block mt-2 px-2 py-1 bg-green-600 text-white text-xs rounded">
                🟢 Active Model
              </span>
            )}
          </div>

          {/* Training Stats */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-center gap-2 mb-1">
                <Database className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-900">Games Trained</span>
              </div>
              <p className="text-2xl font-bold text-blue-600">{summary.total_games}</p>
            </div>

            <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp className="h-4 w-4 text-purple-600" />
                <span className="text-sm font-medium text-purple-900">Total Positions</span>
              </div>
              <p className="text-2xl font-bold text-purple-600">{summary.total_positions?.toLocaleString()}</p>
            </div>

            <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
              <div className="flex items-center gap-2 mb-1">
                <Brain className="h-4 w-4 text-orange-600" />
                <span className="text-sm font-medium text-orange-900">Epochs</span>
              </div>
              <p className="text-2xl font-bold text-orange-600">{summary.epochs}</p>
            </div>

            <div className="p-4 bg-pink-50 rounded-lg border border-pink-200">
              <div className="flex items-center gap-2 mb-1">
                <Clock className="h-4 w-4 text-pink-600" />
                <span className="text-sm font-medium text-pink-900">Avg Loss</span>
              </div>
              <p className="text-2xl font-bold text-pink-600">{summary.average_loss?.toFixed(4)}</p>
            </div>
          </div>

          {/* Memory Sources */}
          {summary.memory_sources && summary.memory_sources.length > 0 && (
            <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
              <h4 className="font-semibold text-gray-900 mb-2">Training Sources</h4>
              <div className="space-y-1">
                {summary.memory_sources.map((source, index) => (
                  <div key={index} className="text-sm text-gray-700">
                    • {source}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Improvement Score (if available) */}
          {summary.improvement_score && (
            <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
              <h4 className="font-semibold text-yellow-900 mb-1">Improvement Score</h4>
              <p className="text-sm text-yellow-800">
                The model showed a {summary.improvement_score}% improvement in loss reduction compared to the initial epoch.
              </p>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button onClick={onClose} variant="outline">
              Close
            </Button>
            <Button 
              onClick={() => {
                // Navigate to models tab or refresh
                onClose();
              }}
              className="bg-blue-600 hover:bg-blue-700"
            >
              View Models
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default TrainingSummary;
