import React, { useState } from 'react';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { Globe2, Server } from 'lucide-react';
import CloudControlPanel from './CloudControlPanel';
import HybridDeploymentPanel from './HybridDeploymentPanel';

const CloudControlWrapper = () => {
  const [hybridMode, setHybridMode] = useState(false);
  
  return (
    <div className="space-y-4">
      {/* Mode Toggle */}
      <div className="flex items-center justify-end gap-3 p-4 bg-gradient-to-r from-slate-800/50 to-slate-900/50 rounded-lg border border-slate-700/50">
        <Label htmlFor="hybrid-toggle" className="text-sm font-medium text-slate-300 cursor-pointer flex items-center gap-2">
          <Server className="w-4 h-4" />
          Single Cloud
        </Label>
        <Switch
          id="hybrid-toggle"
          checked={hybridMode}
          onCheckedChange={setHybridMode}
        />
        <Label htmlFor="hybrid-toggle" className="text-sm font-medium text-slate-300 cursor-pointer flex items-center gap-2">
          <Globe2 className="w-4 h-4" />
          Hybrid Multi-Cloud
        </Label>
      </div>
      
      {/* Conditional Rendering */}
      {hybridMode ? (
        <HybridDeploymentPanel />
      ) : (
        <CloudControlPanel />
      )}
    </div>
  );
};

export default CloudControlWrapper;
