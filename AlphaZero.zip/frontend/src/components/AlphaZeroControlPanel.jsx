import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { motion } from 'framer-motion';
import { Play, Square, Download, Settings } from 'lucide-react';
import { toast } from 'sonner';

const AlphaZeroControlPanel = ({ status, loading, onStartTraining, onStopTraining, onExportLogs }) => {
  const [showStartModal, setShowStartModal] = useState(false);
  const [showStopModal, setShowStopModal] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);
  
  // Training configuration
  const [config, setConfig] = useState({
    device: 'auto',
    max_games: 44000000,
    max_hours: 9.0,
    num_simulations: 800,
    replay_buffer_size: 1000000,
    batch_size: 256,
    learning_rate: 0.001,
    checkpoint_interval: 1800,
    eval_interval: 1000,
    win_threshold: 0.55,
    num_eval_games: 40,
    resume: false,
    adaptive_learning: false
  });
  
  const handleStartTraining = async () => {
    try {
      await onStartTraining(config);
      setShowStartModal(false);
    } catch (err) {
      console.error('Error starting training:', err);
    }
  };
  
  const handleStopTraining = async () => {
    try {
      await onStopTraining();
      setShowStopModal(false);
    } catch (err) {
      console.error('Error stopping training:', err);
    }
  };
  
  const handleExport = (format) => {
    onExportLogs(format);
    setShowExportMenu(false);
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm" data-testid="control-panel-card">
        <CardHeader>
          <CardTitle className="text-2xl text-white flex items-center gap-2">
            <Settings className="text-cyan-400" size={28} />
            Training Controls
          </CardTitle>
        </CardHeader>
        
        <CardContent>
          <div className="flex flex-wrap gap-4">
            {/* Start Training Button */}
            <Button
              onClick={() => setShowStartModal(true)}
              disabled={status.active || loading}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-semibold px-6 py-3 rounded-lg shadow-lg hover:shadow-cyan-500/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              data-testid="start-training-button"
            >
              <Play className="mr-2" size={20} />
              Start Training
            </Button>
            
            {/* Stop Training Button */}
            <Button
              onClick={() => setShowStopModal(true)}
              disabled={!status.active || loading}
              className="bg-gradient-to-r from-red-500 to-orange-600 hover:from-red-600 hover:to-orange-700 text-white font-semibold px-6 py-3 rounded-lg shadow-lg hover:shadow-red-500/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              data-testid="stop-training-button"
            >
              <Square className="mr-2" size={20} />
              Stop Training
            </Button>
            
            {/* Export Logs Button */}
            <div className="relative">
              <Button
                onClick={() => setShowExportMenu(!showExportMenu)}
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-700 px-6 py-3 rounded-lg"
                data-testid="export-logs-button"
              >
                <Download className="mr-2" size={20} />
                Export Logs
              </Button>
              
              {showExportMenu && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute top-full mt-2 bg-slate-800 border border-slate-700 rounded-lg shadow-xl p-2 z-10"
                >
                  <Button
                    onClick={() => handleExport('json')}
                    variant="ghost"
                    className="w-full justify-start text-slate-300 hover:bg-slate-700"
                  >
                    Export as JSON
                  </Button>
                  <Button
                    onClick={() => handleExport('csv')}
                    variant="ghost"
                    className="w-full justify-start text-slate-300 hover:bg-slate-700"
                  >
                    Export as CSV
                  </Button>
                </motion.div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Start Training Modal */}
      <Dialog open={showStartModal} onOpenChange={setShowStartModal}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl text-cyan-400">Start AlphaZero Training</DialogTitle>
            <DialogDescription className="text-slate-400">
              Configure training parameters for massive-scale self-play training.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {/* Device Selection */}
            <div className="space-y-2">
              <Label htmlFor="device" className="text-slate-300">Device Mode</Label>
              <Select
                value={config.device}
                onValueChange={(value) => setConfig({ ...config, device: value })}
              >
                <SelectTrigger className="bg-slate-900 border-slate-700 text-white">
                  <SelectValue placeholder="Select device" />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700">
                  <SelectItem value="auto">Auto (Detect)</SelectItem>
                  <SelectItem value="tpu">TPU</SelectItem>
                  <SelectItem value="gpu">GPU</SelectItem>
                  <SelectItem value="simulated">Simulated</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {/* Max Games */}
            <div className="space-y-2">
              <Label htmlFor="max_games" className="text-slate-300">Maximum Games</Label>
              <input
                id="max_games"
                type="number"
                value={config.max_games}
                onChange={(e) => setConfig({ ...config, max_games: parseInt(e.target.value) })}
                className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white"
                min="1000"
                max="50000000"
              />
              <p className="text-xs text-slate-500">Default: 44,000,000 games</p>
            </div>
            
            {/* Max Hours */}
            <div className="space-y-2">
              <Label htmlFor="max_hours" className="text-slate-300">Maximum Hours</Label>
              <input
                id="max_hours"
                type="number"
                step="0.1"
                value={config.max_hours}
                onChange={(e) => setConfig({ ...config, max_hours: parseFloat(e.target.value) })}
                className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white"
                min="0.1"
                max="24"
              />
              <p className="text-xs text-slate-500">Default: 9 hours</p>
            </div>
            
            {/* MCTS Simulations */}
            <div className="space-y-2">
              <Label htmlFor="num_simulations" className="text-slate-300">MCTS Simulations per Move</Label>
              <input
                id="num_simulations"
                type="number"
                value={config.num_simulations}
                onChange={(e) => setConfig({ ...config, num_simulations: parseInt(e.target.value) })}
                className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white"
                min="100"
                max="1600"
              />
              <p className="text-xs text-slate-500">Default: 800 simulations</p>
            </div>
            
            {/* Advanced Settings */}
            <details className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
              <summary className="text-slate-300 cursor-pointer font-semibold">Advanced Settings</summary>
              <div className="space-y-4 mt-4">
                {/* Batch Size */}
                <div className="space-y-2">
                  <Label htmlFor="batch_size" className="text-slate-300">Batch Size</Label>
                  <input
                    id="batch_size"
                    type="number"
                    value={config.batch_size}
                    onChange={(e) => setConfig({ ...config, batch_size: parseInt(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white"
                    min="32"
                    max="512"
                  />
                </div>
                
                {/* Learning Rate */}
                <div className="space-y-2">
                  <Label htmlFor="learning_rate" className="text-slate-300">Learning Rate</Label>
                  <input
                    id="learning_rate"
                    type="number"
                    step="0.0001"
                    value={config.learning_rate}
                    onChange={(e) => setConfig({ ...config, learning_rate: parseFloat(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white"
                    min="0.0001"
                    max="0.01"
                  />
                </div>
                
                {/* Checkpoint Interval */}
                <div className="space-y-2">
                  <Label htmlFor="checkpoint_interval" className="text-slate-300">Checkpoint Interval (seconds)</Label>
                  <input
                    id="checkpoint_interval"
                    type="number"
                    value={config.checkpoint_interval}
                    onChange={(e) => setConfig({ ...config, checkpoint_interval: parseInt(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white"
                    min="300"
                    max="7200"
                  />
                </div>
                
                {/* Resume Training */}
                <div className="flex items-center space-x-2">
                  <Switch
                    id="resume"
                    checked={config.resume}
                    onCheckedChange={(checked) => setConfig({ ...config, resume: checked })}
                  />
                  <Label htmlFor="resume" className="text-slate-300">Resume from Checkpoint</Label>
                </div>
                
                {/* Adaptive Learning */}
                <div className="flex items-center space-x-2">
                  <Switch
                    id="adaptive_learning"
                    checked={config.adaptive_learning}
                    onCheckedChange={(checked) => setConfig({ ...config, adaptive_learning: checked })}
                  />
                  <Label htmlFor="adaptive_learning" className="text-slate-300">Enable Adaptive Learning Mode</Label>
                </div>
              </div>
            </details>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowStartModal(false)}
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              Cancel
            </Button>
            <Button
              onClick={handleStartTraining}
              disabled={loading}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white"
            >
              {loading ? 'Starting...' : 'Start Training'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Stop Training Confirmation Modal */}
      <Dialog open={showStopModal} onOpenChange={setShowStopModal}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl text-red-400">Stop Training?</DialogTitle>
            <DialogDescription className="text-slate-400">
              Are you sure you want to stop the training loop? A checkpoint will be saved before stopping.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
              <p className="text-slate-300 text-sm">
                <strong>Current Progress:</strong><br />
                Games: {status.games_completed?.toLocaleString()} / {status.max_games?.toLocaleString()}<br />
                ELO: {Math.round(status.current_elo || 1500)}<br />
                Elapsed: {Math.floor((status.elapsed_seconds || 0) / 3600)}h {Math.floor(((status.elapsed_seconds || 0) % 3600) / 60)}m
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowStopModal(false)}
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              Cancel
            </Button>
            <Button
              onClick={handleStopTraining}
              disabled={loading}
              className="bg-gradient-to-r from-red-500 to-orange-600 hover:from-red-600 hover:to-orange-700 text-white"
            >
              {loading ? 'Stopping...' : 'Stop Training'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
};

export default AlphaZeroControlPanel;
