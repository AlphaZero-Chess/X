import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { motion } from 'framer-motion';
import { TrendingDown, Gauge, Database, CheckCircle2, AlertCircle } from 'lucide-react';

const TrainingMetricsCard = ({ status }) => {
  const {
    active = false,
    loss = 0.0,
    learning_rate = 0.0,
    replay_buffer_size = 0,
    training_steps = 0
  } = status;
  
  // Determine training health status
  const getHealthStatus = () => {
    if (!active) {
      return { status: 'idle', label: 'Idle', color: 'slate', icon: AlertCircle };
    }
    
    // Check for potential issues
    if (replay_buffer_size === 0) {
      return { status: 'warning', label: 'No Data', color: 'yellow', icon: AlertCircle };
    }
    
    if (loss > 1.0) {
      return { status: 'high-loss', label: 'High Loss', color: 'orange', icon: AlertCircle };
    }
    
    return { status: 'healthy', label: 'Healthy', color: 'green', icon: CheckCircle2 };
  };
  
  const health = getHealthStatus();
  const HealthIcon = health.icon;
  
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm" data-testid="training-metrics-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl text-white flex items-center gap-2">
              <Gauge className="text-purple-400" size={24} />
              Training Metrics
            </CardTitle>
            <Badge 
              className={`
                ${health.color === 'green' ? 'bg-green-500/20 text-green-400 border-green-500/50' : ''}
                ${health.color === 'yellow' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50' : ''}
                ${health.color === 'orange' ? 'bg-orange-500/20 text-orange-400 border-orange-500/50' : ''}
                ${health.color === 'slate' ? 'bg-slate-500/20 text-slate-400 border-slate-500/50' : ''}
              `}
            >
              <HealthIcon className="mr-1" size={14} />
              {health.label}
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Loss Metric */}
          <motion.div 
            className="bg-slate-900/50 rounded-lg p-4 border border-slate-700"
            whileHover={{ scale: 1.02 }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <TrendingDown className="text-red-400" size={18} />
                <span className="text-slate-400 text-sm">Training Loss</span>
              </div>
              {loss === 0.0 && replay_buffer_size === 0 && (
                <Badge variant="outline" className="text-xs border-yellow-500/50 text-yellow-400">
                  No Training
                </Badge>
              )}
            </div>
            <div className="text-3xl font-bold text-white font-mono">
              {loss.toFixed(4)}
            </div>
            <div className="mt-2 text-xs text-slate-500">
              {loss === 0.0 && replay_buffer_size === 0 
                ? 'Waiting for training data...' 
                : loss < 0.5 
                  ? 'Excellent convergence' 
                  : loss < 1.0 
                    ? 'Good progress' 
                    : 'High loss - early training'}
            </div>
          </motion.div>
          
          {/* Learning Rate Metric */}
          <motion.div 
            className="bg-slate-900/50 rounded-lg p-4 border border-slate-700"
            whileHover={{ scale: 1.02 }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Gauge className="text-blue-400" size={18} />
              <span className="text-slate-400 text-sm">Learning Rate</span>
            </div>
            <div className="text-3xl font-bold text-white font-mono">
              {learning_rate.toExponential(4)}
            </div>
            <div className="mt-2 text-xs text-slate-500">
              Cosine annealing schedule • Step {training_steps.toLocaleString()}
            </div>
          </motion.div>
          
          {/* Replay Buffer Metric */}
          <motion.div 
            className="bg-slate-900/50 rounded-lg p-4 border border-slate-700"
            whileHover={{ scale: 1.02 }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Database className="text-cyan-400" size={18} />
                <span className="text-slate-400 text-sm">Replay Buffer</span>
              </div>
              {replay_buffer_size === 0 && active && (
                <Badge variant="outline" className="text-xs border-yellow-500/50 text-yellow-400">
                  ⚠️ Empty
                </Badge>
              )}
            </div>
            <div className="text-3xl font-bold text-white font-mono">
              {replay_buffer_size.toLocaleString()}
            </div>
            <div className="mt-2 text-xs text-slate-500">
              positions • Max: 1,000,000
            </div>
            
            {/* Buffer Fill Progress */}
            <div className="mt-3">
              <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min((replay_buffer_size / 1000000) * 100, 100)}%` }}
                  transition={{ duration: 0.5 }}
                  className="h-full bg-gradient-to-r from-cyan-500 to-blue-500"
                />
              </div>
              <div className="flex justify-between mt-1 text-xs text-slate-500">
                <span>{((replay_buffer_size / 1000000) * 100).toFixed(1)}% full</span>
                <span>{replay_buffer_size >= 1000000 ? 'At capacity' : 'Filling...'}</span>
              </div>
            </div>
          </motion.div>
          
          {/* Training Status Message */}
          {replay_buffer_size === 0 && active && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-yellow-500/10 border border-yellow-500/50 rounded-lg p-3"
            >
              <div className="flex items-start gap-2">
                <AlertCircle className="text-yellow-400 flex-shrink-0 mt-0.5" size={16} />
                <div className="text-xs text-yellow-300">
                  <strong>Replay buffer is empty.</strong> Training will begin once self-play generates position data.
                </div>
              </div>
            </motion.div>
          )}
          
          {!active && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-slate-900/30 border border-slate-700/50 rounded-lg p-3 text-center"
            >
              <p className="text-slate-400 text-xs">
                Start a training session to see live metrics
              </p>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default TrainingMetricsCard;
