import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Progress } from './ui/progress';
import { Brain, TrendingUp, Activity, Zap, RefreshCw } from 'lucide-react';
import axios from 'axios';

const AdaptiveLearningPanel = () => {
  const [status, setStatus] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [retraining, setRetraining] = useState(false);

  const backendUrl = process.env.REACT_APP_BACKEND_URL || '';

  useEffect(() => {
    fetchStatus();
    fetchStats();
    // Poll status every 10 seconds
    const interval = setInterval(() => {
      fetchStatus();
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const fetchStatus = async () => {
    try {
      const response = await axios.get(`${backendUrl}/api/adaptive-learning/status`);
      setStatus(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching adaptive learning status:', error);
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await axios.get(`${backendUrl}/api/adaptive-learning/stats`);
      setStats(response.data);
    } catch (error) {
      console.error('Error fetching adaptive learning stats:', error);
    }
  };

  const toggleAdaptiveLearning = async (enabled) => {
    try {
      await axios.post(`${backendUrl}/api/adaptive-learning/toggle`, { enabled });
      fetchStatus();
      fetchStats();
    } catch (error) {
      console.error('Error toggling adaptive learning:', error);
    }
  };

  const triggerRetrain = async () => {
    try {
      setRetraining(true);
      await axios.post(`${backendUrl}/api/adaptive-learning/trigger-retrain`);
      // Wait a few seconds then refresh status
      setTimeout(() => {
        fetchStatus();
        fetchStats();
        setRetraining(false);
      }, 3000);
    } catch (error) {
      console.error('Error triggering retrain:', error);
      setRetraining(false);
      alert(error.response?.data?.detail || 'Error triggering retraining');
    }
  };

  const resetStats = async () => {
    if (window.confirm('Are you sure you want to reset adaptive learning statistics?')) {
      try {
        await axios.post(`${backendUrl}/api/adaptive-learning/reset`);
        fetchStatus();
        fetchStats();
      } catch (error) {
        console.error('Error resetting stats:', error);
      }
    }
  };

  if (loading) {
    return (
      <Card className="shadow-xl">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <RefreshCw className="h-6 w-6 animate-spin text-blue-600" />
            <span className="ml-2">Loading adaptive learning status...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  const progressPercent = status?.games_per_retrain > 0
    ? (status.games_since_last_retrain / status.games_per_retrain) * 100
    : 0;

  return (
    <Card className="shadow-xl" data-testid="adaptive-learning-panel">
      <CardHeader className="bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900 dark:to-blue-900">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-6 w-6" />
            <span>Adaptive Learning</span>
          </div>
          <Badge variant={status?.enabled ? 'default' : 'secondary'}>
            {status?.enabled ? 'Active' : 'Disabled'}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6 pt-6">
        {/* Enable/Disable Toggle */}
        <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-900 rounded-lg">
          <div className="space-y-1">
            <div className="font-medium">Enable Adaptive Learning</div>
            <div className="text-sm text-slate-600 dark:text-slate-400">
              Model learns and improves from your games
            </div>
          </div>
          <Switch
            checked={status?.enabled || false}
            onCheckedChange={toggleAdaptiveLearning}
            data-testid="adaptive-learning-toggle"
          />
        </div>

        {status?.enabled && (
          <>
            {/* Training Progress */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Games Until Retrain</span>
                <span className="text-sm font-bold">
                  {status.games_until_next_retrain} / {status.games_per_retrain}
                </span>
              </div>
              <Progress value={progressPercent} className="h-2" />
              <div className="text-xs text-slate-600 dark:text-slate-400">
                {status.games_since_last_retrain} games collected since last training session
              </div>
            </div>

            {/* Statistics Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900 dark:to-blue-800 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="h-4 w-4 text-blue-600 dark:text-blue-300" />
                  <span className="text-xs font-medium">Total Games</span>
                </div>
                <div className="text-2xl font-bold">{status.games_collected || 0}</div>
              </div>

              <div className="p-4 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900 dark:to-purple-800 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="h-4 w-4 text-purple-600 dark:text-purple-300" />
                  <span className="text-xs font-medium">Retrains</span>
                </div>
                <div className="text-2xl font-bold">{status.total_retrains || 0}</div>
              </div>

              <div className="p-4 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900 dark:to-green-800 rounded-lg col-span-2">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-300" />
                  <span className="text-xs font-medium">Est. ELO</span>
                </div>
                <div className="text-2xl font-bold">{status.current_elo_estimate || 1500}</div>
                {stats?.elo_history && stats.elo_history.length > 0 && (
                  <div className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                    Last change: {stats.elo_history[stats.elo_history.length - 1]?.elo_delta > 0 ? '+' : ''}
                    {stats.elo_history[stats.elo_history.length - 1]?.elo_delta || 0} ELO
                  </div>
                )}
              </div>
            </div>

            {/* Configuration Info */}
            <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-lg space-y-2">
              <div className="text-sm font-medium mb-2">Configuration</div>
              <div className="text-xs text-slate-600 dark:text-slate-400 space-y-1">
                <div>Aggressiveness: <span className="font-semibold capitalize">{status.aggressiveness}</span></div>
                <div>Games per retrain: <span className="font-semibold">{status.games_per_retrain}</span></div>
                {status.last_retrain_timestamp && (
                  <div>
                    Last retrain: <span className="font-semibold">
                      {new Date(status.last_retrain_timestamp).toLocaleString()}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2">
              <Button
                onClick={triggerRetrain}
                disabled={retraining || status.games_since_last_retrain < 5}
                className="flex-1 bg-purple-600 hover:bg-purple-700"
                data-testid="trigger-retrain-btn"
              >
                {retraining ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Retraining...
                  </>
                ) : (
                  <>
                    <Brain className="mr-2 h-4 w-4" />
                    Trigger Retrain
                  </>
                )}
              </Button>
              <Button
                onClick={resetStats}
                variant="outline"
                className="flex-1"
                data-testid="reset-stats-btn"
              >
                Reset Stats
              </Button>
            </div>

            {/* ELO History Chart */}
            {stats?.elo_history && stats.elo_history.length > 0 && (
              <div className="space-y-2">
                <div className="text-sm font-medium">ELO Progress</div>
                <div className="h-32 bg-slate-50 dark:bg-slate-900 rounded-lg p-4 flex items-end gap-1">
                  {stats.elo_history.slice(-10).map((entry, idx) => {
                    const height = Math.abs(entry.elo_delta || 0);
                    const isPositive = (entry.elo_delta || 0) >= 0;
                    return (
                      <div
                        key={idx}
                        className={`flex-1 rounded-t ${
                          isPositive ? 'bg-green-500' : 'bg-red-500'
                        }`}
                        style={{ height: `${Math.min(100, height)}%` }}
                        title={`${isPositive ? '+' : ''}${entry.elo_delta} ELO`}
                      />
                    );
                  })}
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-400 text-center">
                  Last {Math.min(10, stats.elo_history.length)} training sessions
                </div>
              </div>
            )}
          </>
        )}

        {!status?.enabled && (
          <div className="p-6 text-center text-slate-600 dark:text-slate-400">
            <Brain className="h-12 w-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">
              Enable adaptive learning to allow the model to improve from your games
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AdaptiveLearningPanel;
