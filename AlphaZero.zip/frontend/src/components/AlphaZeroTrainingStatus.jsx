import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { motion } from 'framer-motion';
import { Activity, TrendingUp, Clock, Zap, Award, Cpu } from 'lucide-react';

const AlphaZeroTrainingStatus = ({ status }) => {
  const {
    active,
    games_completed = 0,
    max_games = 0,
    progress_pct = 0,
    current_elo = 1500,
    games_per_sec = 0,
    elapsed_seconds = 0,
    eta_seconds = 0,
    message = 'No training active',
    device_mode = 'Unknown',
    models_promoted = 0
  } = status;
  
  // Format time (seconds to HH:MM:SS)
  const formatTime = (seconds) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${h}h ${m}m ${s}s`;
  };
  
  // Status badge
  const statusBadge = active ? (
    <Badge className="bg-green-500/20 text-green-400 border-green-500/50">
      <span className="animate-pulse mr-1">●</span> Running
    </Badge>
  ) : (
    <Badge className="bg-slate-500/20 text-slate-400 border-slate-500/50">
      <span className="mr-1">●</span> Stopped
    </Badge>
  );
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm" data-testid="training-status-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl text-white flex items-center gap-2">
              <Activity className="text-cyan-400" size={28} />
              Training Status
            </CardTitle>
            {statusBadge}
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-slate-300">Progress</span>
              <span className="text-cyan-400 font-mono font-bold">
                {progress_pct.toFixed(1)}%
              </span>
            </div>
            <Progress 
              value={progress_pct} 
              className="h-3 bg-slate-700"
              indicatorClassName="bg-gradient-to-r from-cyan-500 to-blue-500"
            />
            <div className="flex justify-between text-xs text-slate-400">
              <span>{games_completed.toLocaleString()} games</span>
              <span>{max_games.toLocaleString()} target</span>
            </div>
          </div>
          
          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {/* ELO Rating */}
            <motion.div 
              className="bg-slate-900/50 rounded-lg p-4 border border-slate-700"
              whileHover={{ scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="text-green-400" size={18} />
                <span className="text-slate-400 text-xs">ELO Rating</span>
              </div>
              <div className="text-2xl font-bold text-white font-mono">
                {Math.round(current_elo)}
              </div>
            </motion.div>
            
            {/* Games/Sec */}
            <motion.div 
              className="bg-slate-900/50 rounded-lg p-4 border border-slate-700"
              whileHover={{ scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Zap className="text-yellow-400" size={18} />
                <span className="text-slate-400 text-xs">Throughput</span>
              </div>
              <div className="text-2xl font-bold text-white font-mono">
                {games_per_sec.toFixed(2)}
                <span className="text-sm text-slate-400 ml-1">g/s</span>
              </div>
            </motion.div>
            
            {/* Elapsed Time */}
            <motion.div 
              className="bg-slate-900/50 rounded-lg p-4 border border-slate-700"
              whileHover={{ scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Clock className="text-blue-400" size={18} />
                <span className="text-slate-400 text-xs">Elapsed</span>
              </div>
              <div className="text-lg font-bold text-white font-mono">
                {formatTime(elapsed_seconds)}
              </div>
            </motion.div>
            
            {/* ETA */}
            <motion.div 
              className="bg-slate-900/50 rounded-lg p-4 border border-slate-700"
              whileHover={{ scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Clock className="text-purple-400" size={18} />
                <span className="text-slate-400 text-xs">ETA</span>
              </div>
              <div className="text-lg font-bold text-white font-mono">
                {active ? formatTime(eta_seconds) : '--'}
              </div>
            </motion.div>
            
            {/* Device Mode */}
            <motion.div 
              className="bg-slate-900/50 rounded-lg p-4 border border-slate-700"
              whileHover={{ scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Cpu className="text-cyan-400" size={18} />
                <span className="text-slate-400 text-xs">Device</span>
              </div>
              <div className="text-lg font-bold text-white">
                {device_mode}
              </div>
            </motion.div>
            
            {/* Models Promoted */}
            <motion.div 
              className="bg-slate-900/50 rounded-lg p-4 border border-slate-700"
              whileHover={{ scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Award className="text-orange-400" size={18} />
                <span className="text-slate-400 text-xs">Promoted</span>
              </div>
              <div className="text-2xl font-bold text-white font-mono">
                {models_promoted || 0}
              </div>
            </motion.div>
          </div>
          
          {/* Status Message */}
          <div className="bg-slate-900/30 rounded-lg p-3 border border-slate-700/50">
            <p className="text-slate-300 text-sm text-center">
              {message}
            </p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default AlphaZeroTrainingStatus;
