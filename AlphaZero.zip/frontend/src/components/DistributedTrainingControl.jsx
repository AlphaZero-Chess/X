import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Slider } from './ui/slider';
import { motion } from 'framer-motion';
import { Play, Square, Settings, Users, Zap } from 'lucide-react';
import { toast } from 'sonner';
import axios from 'axios';

const DistributedTrainingControl = ({ onStatusChange }) => {
  const [showStartModal, setShowStartModal] = useState(false);
  const [showStopModal, setShowStopModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState(null);
  
  const backendUrl = process.env.REACT_APP_BACKEND_URL || '';
  
  // Training configuration
  const [config, setConfig] = useState({
    num_workers: 8,
    num_games_total: 1000,
    num_simulations: 800,
    replay_buffer_size: 1000000,
    batch_size: 256,
    learning_rate: 0.001,
    num_training_epochs: 3,
    num_eval_games: 10
  });
  
  useEffect(() => {
    fetchStatus();
    
    // Poll status every 5 seconds
    const interval = setInterval(fetchStatus, 5000);
    return () => clearInterval(interval);
  }, []);
  
  const fetchStatus = async () => {
    try {
      const response = await axios.get(`${backendUrl}/api/train/status-distributed`);
      setStatus(response.data);
      
      if (onStatusChange) {
        onStatusChange(response.data);
      }
    } catch (error) {
      console.error('Error fetching distributed status:', error);
    }
  };
  
  const handleStartTraining = async () => {
    try {
      setLoading(true);
      
      const response = await axios.post(`${backendUrl}/api/train/start-distributed`, config);
      
      toast.success('🚀 Distributed Training Started', {
        description: `${config.num_workers} workers launched for ${config.num_games_total} games`
      });
      
      setShowStartModal(false);
      fetchStatus();
      
    } catch (error) {
      console.error('Error starting distributed training:', error);
      toast.error('Failed to start training', {
        description: error.response?.data?.detail || error.message
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleStopTraining = async () => {
    try {
      setLoading(true);
      
      await axios.post(`${backendUrl}/api/train/stop-distributed`);
      
      toast.success('Training Stopped', {
        description: 'Workers are shutting down gracefully'
      });
      
      setShowStopModal(false);
      fetchStatus();
      
    } catch (error) {
      console.error('Error stopping training:', error);
      toast.error('Failed to stop training', {
        description: error.response?.data?.detail || error.message
      });
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm" data-testid="distributed-control-panel">
          <CardHeader>
            <CardTitle className="text-2xl text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="text-cyan-400" size={28} />
                Distributed Training Mode
              </div>
              {status?.active && (
                <Badge className="bg-green-500 text-white">
                  <div className="flex items-center gap-1">
                    <div className="h-2 w-2 rounded-full bg-white animate-pulse" />
                    Active
                  </div>
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          
          <CardContent>
            <div className="space-y-4">
              {/* Status Display */}
              {status && (
                <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-slate-400">Status:</span>
                      <span className="ml-2 text-white font-semibold">
                        {status.active ? 'Running' : 'Idle'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400">Workers:</span>
                      <span className="ml-2 text-white font-semibold">
                        {status.num_workers || 0}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400">Games:</span>
                      <span className="ml-2 text-white font-semibold">
                        {(status.games_completed || 0).toLocaleString()}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400">Positions:</span>
                      <span className="ml-2 text-white font-semibold">
                        {(status.positions_collected || 0).toLocaleString()}
                      </span>
                    </div>
                  </div>
                  {status.message && (
                    <div className="mt-3 pt-3 border-t border-slate-700">
                      <span className="text-xs text-slate-400">{status.message}</span>
                    </div>
                  )}
                </div>
              )}
              
              {/* Control Buttons */}
              <div className="flex gap-4">
                <Button
                  onClick={() => setShowStartModal(true)}
                  disabled={status?.active || loading}
                  className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-semibold py-3 rounded-lg shadow-lg hover:shadow-cyan-500/50 transition-all disabled:opacity-50"
                  data-testid="start-distributed-button"
                >
                  <Play className="mr-2" size={20} />
                  Start Distributed Training
                </Button>
                
                <Button
                  onClick={() => setShowStopModal(true)}
                  disabled={!status?.active || loading}
                  className="flex-1 bg-gradient-to-r from-red-500 to-orange-600 hover:from-red-600 hover:to-orange-700 text-white font-semibold py-3 rounded-lg shadow-lg hover:shadow-red-500/50 transition-all disabled:opacity-50"
                  data-testid="stop-distributed-button"
                >
                  <Square className="mr-2" size={20} />
                  Stop Training
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
      
      {/* Start Training Modal */}
      <Dialog open={showStartModal} onOpenChange={setShowStartModal}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl text-cyan-400">Configure Distributed Training</DialogTitle>
            <DialogDescription className="text-slate-400">
              Launch parallel self-play workers for high-throughput game generation
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {/* Number of Workers */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-slate-300">Number of Workers</Label>
                <span className="text-2xl font-bold text-cyan-400">{config.num_workers}</span>
              </div>
              <Slider
                value={[config.num_workers]}
                onValueChange={([value]) => setConfig({ ...config, num_workers: value })}
                min={2}
                max={16}
                step={1}
                className="w-full"
              />
              <p className="text-xs text-slate-500">
                Recommended: 8 workers (scales with CPU/GPU availability)
              </p>
            </div>
            
            {/* Total Games */}
            <div className="space-y-2">
              <Label className="text-slate-300">Total Games to Generate</Label>
              <input
                type="number"
                value={config.num_games_total}
                onChange={(e) => setConfig({ ...config, num_games_total: parseInt(e.target.value) || 100 })}
                className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white"
                min="100"
                max="10000"
              />
              <p className="text-xs text-slate-500">
                Total games distributed across all workers
              </p>
            </div>
            
            {/* MCTS Simulations */}
            <div className="space-y-2">
              <Label className="text-slate-300">MCTS Simulations per Move</Label>
              <Select
                value={config.num_simulations.toString()}
                onValueChange={(value) => setConfig({ ...config, num_simulations: parseInt(value) })}
              >
                <SelectTrigger className="bg-slate-900 border-slate-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700">
                  <SelectItem value="400">400 (Fast)</SelectItem>
                  <SelectItem value="800">800 (Default)</SelectItem>
                  <SelectItem value="1200">1200 (High Quality)</SelectItem>
                  <SelectItem value="1600">1600 (Maximum)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {/* Advanced Settings */}
            <details className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
              <summary className="text-slate-300 cursor-pointer font-semibold">Advanced Settings</summary>
              <div className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label className="text-slate-300">Replay Buffer Size</Label>
                  <input
                    type="number"
                    value={config.replay_buffer_size}
                    onChange={(e) => setConfig({ ...config, replay_buffer_size: parseInt(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white"
                    min="10000"
                    max="5000000"
                  />
                  <p className="text-xs text-slate-500">Maximum positions to store (default: 1,000,000)</p>
                </div>
                
                <div className="space-y-2">
                  <Label className="text-slate-300">Training Batch Size</Label>
                  <Select
                    value={config.batch_size.toString()}
                    onValueChange={(value) => setConfig({ ...config, batch_size: parseInt(value) })}
                  >
                    <SelectTrigger className="bg-slate-900 border-slate-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-900 border-slate-700">
                      <SelectItem value="64">64</SelectItem>
                      <SelectItem value="128">128</SelectItem>
                      <SelectItem value="256">256 (Default)</SelectItem>
                      <SelectItem value="512">512</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label className="text-slate-300">Learning Rate</Label>
                  <input
                    type="number"
                    step="0.0001"
                    value={config.learning_rate}
                    onChange={(e) => setConfig({ ...config, learning_rate: parseFloat(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white"
                    min="0.0001"
                    max="0.01"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label className="text-slate-300">Training Epochs</Label>
                  <input
                    type="number"
                    value={config.num_training_epochs}
                    onChange={(e) => setConfig({ ...config, num_training_epochs: parseInt(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white"
                    min="1"
                    max="10"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label className="text-slate-300">Evaluation Games</Label>
                  <input
                    type="number"
                    value={config.num_eval_games}
                    onChange={(e) => setConfig({ ...config, num_eval_games: parseInt(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white"
                    min="5"
                    max="40"
                  />
                </div>
              </div>
            </details>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowStartModal(false)}
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              Cancel
            </Button>
            <Button
              onClick={handleStartTraining}
              disabled={loading}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white"
            >
              {loading ? 'Starting...' : 'Launch Workers'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Stop Training Confirmation */}
      <Dialog open={showStopModal} onOpenChange={setShowStopModal}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl text-red-400">Stop Distributed Training?</DialogTitle>
            <DialogDescription className="text-slate-400">
              This will gracefully shut down all {status?.num_workers || 0} workers and save the current progress.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
              <p className="text-slate-300 text-sm">
                <strong>Current Progress:</strong><br />
                Games: {(status?.games_completed || 0).toLocaleString()}<br />
                Positions: {(status?.positions_collected || 0).toLocaleString()}<br />
                Workers: {status?.num_workers || 0} active
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowStopModal(false)}
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              Cancel
            </Button>
            <Button
              onClick={handleStopTraining}
              disabled={loading}
              className="bg-gradient-to-r from-red-500 to-orange-600 hover:from-red-600 hover:to-orange-700 text-white"
            >
              {loading ? 'Stopping...' : 'Stop Training'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default DistributedTrainingControl;
