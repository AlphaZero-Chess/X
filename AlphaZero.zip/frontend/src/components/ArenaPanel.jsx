import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner';
import { 
  Play, Square, TrendingUp, Clock, Trophy, MessageSquare, 
  Zap, Target, Crown, Swords, Timer, Activity 
} from 'lucide-react';
import ChessBoard from './ChessBoard';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function ArenaPanel() {
  const [models, setModels] = useState([]);
  const [arenaConfig, setArenaConfig] = useState({
    players: [null, null],
    games: 10,
    move_delay: 1.2,
    mcts_simulations: 800,
    save_pgn: true,
    commentary: true
  });
  
  const [arenaStatus, setArenaStatus] = useState({
    is_running: false,
    current_game: 0,
    total_games: 0,
    current_move: 0,
    current_fen: null,
    player1_name: '',
    player2_name: '',
    stats: {}
  });
  
  const [currentPosition, setCurrentPosition] = useState('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  const [moveLog, setMoveLog] = useState([]);
  const [commentary, setCommentary] = useState('');
  const [evaluation, setEvaluation] = useState(0);
  const [evaluationHistory, setEvaluationHistory] = useState([]);
  
  const eventSourceRef = useRef(null);

  useEffect(() => {
    loadModels();
    checkArenaStatus();
    
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, []);

  const loadModels = async () => {
    try {
      const response = await axios.get(`${API}/model/list`);
      if (response.data.success) {
        setModels(response.data.models);
      }
    } catch (error) {
      console.error('Error loading models:', error);
      toast.error('Failed to load models');
    }
  };

  const checkArenaStatus = async () => {
    try {
      const response = await axios.get(`${API}/arena/status`);
      if (response.data.success) {
        setArenaStatus(response.data);
        if (response.data.current_fen) {
          setCurrentPosition(response.data.current_fen);
        }
      }
    } catch (error) {
      console.error('Error checking arena status:', error);
    }
  };

  const startArena = async () => {
    try {
      const response = await axios.post(`${API}/arena/start`, arenaConfig);
      
      if (response.data.success) {
        toast.success('Arena started!');
        
        // Reset state
        setMoveLog([]);
        setCommentary('Arena starting...');
        setEvaluationHistory([]);
        
        // Start listening to events
        connectToEventStream();
      }
    } catch (error) {
      console.error('Error starting arena:', error);
      toast.error(error.response?.data?.detail || 'Failed to start arena');
    }
  };

  const stopArena = async () => {
    try {
      const response = await axios.post(`${API}/arena/stop`);
      
      if (response.data.success) {
        toast.info('Arena stop requested');
        
        // Close event stream
        if (eventSourceRef.current) {
          eventSourceRef.current.close();
          eventSourceRef.current = null;
        }
      }
    } catch (error) {
      console.error('Error stopping arena:', error);
      toast.error('Failed to stop arena');
    }
  };

  const connectToEventStream = () => {
    // Close existing connection if any
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    const eventSource = new EventSource(`${API}/arena/stream`);
    eventSourceRef.current = eventSource;

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        handleArenaEvent(data);
      } catch (error) {
        console.error('Error parsing event:', error);
      }
    };

    eventSource.onerror = (error) => {
      console.error('EventSource error:', error);
      eventSource.close();
      eventSourceRef.current = null;
      
      // Refresh status
      checkArenaStatus();
    };
  };

  const handleArenaEvent = (event) => {
    switch (event.type) {
      case 'arena_start':
        setArenaStatus(prev => ({
          ...prev,
          is_running: true,
          player1_name: event.player1,
          player2_name: event.player2,
          total_games: event.total_games
        }));
        toast.success(`Arena started: ${event.player1} vs ${event.player2}`);
        break;
      
      case 'game_start':
        setCurrentPosition(event.fen);
        setMoveLog([]);
        setCommentary(`Game ${event.game_number} started`);
        setEvaluationHistory([]);
        break;
      
      case 'move':
        setCurrentPosition(event.fen);
        setEvaluation(event.evaluation);
        
        // Add to move log
        const moveEntry = {
          move_number: event.move_number,
          move: event.move,
          player: event.player,
          evaluation: event.evaluation
        };
        setMoveLog(prev => [...prev, moveEntry]);
        
        // Update commentary
        if (event.commentary) {
          setCommentary(event.commentary);
        }
        
        // Add to evaluation history
        setEvaluationHistory(prev => [...prev, {
          move: event.move_number,
          value: event.evaluation
        }]);
        
        // Update status
        setArenaStatus(prev => ({
          ...prev,
          current_game: event.game_number,
          current_move: event.move_number
        }));
        break;
      
      case 'game_end':
        toast.success(`Game ${event.game_number} complete: ${event.winner} wins!`);
        setCommentary(`Game over: ${event.result} - ${event.winner}`);
        
        // Update stats
        setArenaStatus(prev => ({
          ...prev,
          stats: event.stats
        }));
        break;
      
      case 'arena_complete':
        toast.success('Arena complete!');
        setCommentary('All games completed');
        setArenaStatus(prev => ({
          ...prev,
          is_running: false,
          stats: event.stats
        }));
        
        // Close event stream
        if (eventSourceRef.current) {
          eventSourceRef.current.close();
          eventSourceRef.current = null;
        }
        break;
      
      case 'arena_error':
        toast.error(`Arena error: ${event.error}`);
        setCommentary(`Error: ${event.error}`);
        break;
      
      default:
        break;
    }
  };

  const renderEvaluationBar = () => {
    // Convert evaluation (-1 to 1) to percentage (0 to 100)
    const percentage = ((evaluation + 1) / 2) * 100;
    
    return (
      <div className="relative w-full h-10 bg-gradient-to-r from-slate-800 via-slate-700 to-slate-800 rounded-xl overflow-hidden border border-slate-600 shadow-inner">
        <div 
          className="absolute top-0 left-0 h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-blue-600 transition-all duration-500 ease-out"
          style={{ width: `${percentage}%` }}
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-white font-bold text-base drop-shadow-lg z-10">
            {evaluation > 0 ? '+' : ''}{evaluation.toFixed(2)}
          </span>
        </div>
      </div>
    );
  };

  const renderStats = () => {
    const stats = arenaStatus.stats || {};
    const total = stats.games_completed || 0;
    const p1Wins = stats.player1_wins || 0;
    const p2Wins = stats.player2_wins || 0;
    const draws = stats.draws || 0;
    
    // Calculate win percentages
    const p1WinRate = total > 0 ? ((p1Wins / total) * 100).toFixed(1) : 0;
    const p2WinRate = total > 0 ? ((p2Wins / total) * 100).toFixed(1) : 0;
    
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700 hover:border-slate-600 transition-all duration-300">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-slate-400 text-sm font-medium mb-1">Total Games</div>
                <div className="text-3xl font-bold text-white">{total}</div>
              </div>
              <Target className="text-slate-500" size={36} />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-cyan-900/40 to-blue-900/40 border-cyan-700/50 hover:border-cyan-600 transition-all duration-300">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="text-cyan-300 text-sm font-medium mb-1 truncate">
                  {arenaStatus.player1_name || 'Player 1'}
                </div>
                <div className="flex items-baseline gap-2">
                  <div className="text-3xl font-bold text-white">{p1Wins}</div>
                  <div className="text-sm text-cyan-400">({p1WinRate}%)</div>
                </div>
              </div>
              <Crown className="text-cyan-400" size={36} />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-purple-900/40 to-pink-900/40 border-purple-700/50 hover:border-purple-600 transition-all duration-300">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="text-purple-300 text-sm font-medium mb-1 truncate">
                  {arenaStatus.player2_name || 'Player 2'}
                </div>
                <div className="flex items-baseline gap-2">
                  <div className="text-3xl font-bold text-white">{p2Wins}</div>
                  <div className="text-sm text-purple-400">({p2WinRate}%)</div>
                </div>
              </div>
              <Crown className="text-purple-400" size={36} />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-slate-700/50 to-slate-800/50 border-slate-600 hover:border-slate-500 transition-all duration-300">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-slate-400 text-sm font-medium mb-1">Draws</div>
                <div className="text-3xl font-bold text-white">{draws}</div>
              </div>
              <Activity className="text-slate-500" size={36} />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  const renderProgressBar = () => {
    const progress = arenaStatus.total_games > 0 
      ? ((arenaStatus.current_game / arenaStatus.total_games) * 100) 
      : 0;
    
    return (
      <div className="w-full space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-slate-400">Tournament Progress</span>
          <span className="text-slate-300 font-medium">
            {arenaStatus.current_game} / {arenaStatus.total_games} games
          </span>
        </div>
        <div className="relative w-full h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
          <div 
            className="absolute top-0 left-0 h-full bg-gradient-to-r from-green-500 to-emerald-500 transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6" data-testid="arena-panel">
      {/* Header Section */}
      <div className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 border border-slate-700 rounded-2xl p-6 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/5 to-purple-500/5" />
        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-xl shadow-lg">
              <Trophy className="text-white" size={32} />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-white mb-1 tracking-tight">
                AI Arena Battles
              </h2>
              <p className="text-slate-400">
                Competitive AI vs AI matches with real-time analysis
              </p>
            </div>
          </div>
          {arenaStatus.is_running && (
            <div className="flex items-center gap-3 px-4 py-2 bg-green-500/20 border border-green-500/50 rounded-xl">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
              <span className="text-green-400 font-semibold">Live</span>
            </div>
          )}
        </div>
      </div>

      {/* Configuration Card */}
      <Card className="bg-slate-800/50 border-slate-700 rounded-2xl shadow-xl backdrop-blur-sm">
        <CardHeader className="border-b border-slate-700/50">
          <CardTitle className="flex items-center gap-3 text-white text-xl">
            <div className="p-2 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg">
              <Swords className="text-white" size={20} />
            </div>
            Battle Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Player 1 */}
            <div className="space-y-2">
              <label className="text-slate-300 text-sm font-medium flex items-center gap-2">
                <div className="w-2 h-2 bg-cyan-400 rounded-full" />
                Player 1 Model
              </label>
              <Select
                value={arenaConfig.players[0] || 'active'}
                onValueChange={(value) => {
                  const newPlayers = [...arenaConfig.players];
                  newPlayers[0] = value === 'active' ? null : value;
                  setArenaConfig({ ...arenaConfig, players: newPlayers });
                }}
                disabled={arenaStatus.is_running}
              >
                <SelectTrigger className="bg-slate-900 border-slate-600 text-white hover:border-cyan-500 transition-colors h-12 rounded-xl">
                  <SelectValue placeholder="Select model" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="active" className="text-white">Active Model</SelectItem>
                  {models.map(model => (
                    <SelectItem key={model.name} value={model.name} className="text-white">
                      {model.name} (ELO: {model.elo})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Player 2 */}
            <div className="space-y-2">
              <label className="text-slate-300 text-sm font-medium flex items-center gap-2">
                <div className="w-2 h-2 bg-purple-400 rounded-full" />
                Player 2 Model
              </label>
              <Select
                value={arenaConfig.players[1] || 'active'}
                onValueChange={(value) => {
                  const newPlayers = [...arenaConfig.players];
                  newPlayers[1] = value === 'active' ? null : value;
                  setArenaConfig({ ...arenaConfig, players: newPlayers });
                }}
                disabled={arenaStatus.is_running}
              >
                <SelectTrigger className="bg-slate-900 border-slate-600 text-white hover:border-purple-500 transition-colors h-12 rounded-xl">
                  <SelectValue placeholder="Select model" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="active" className="text-white">Active Model</SelectItem>
                  {models.map(model => (
                    <SelectItem key={model.name} value={model.name} className="text-white">
                      {model.name} (ELO: {model.elo})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Number of Games */}
            <div className="space-y-2">
              <label className="text-slate-300 text-sm font-medium flex items-center gap-2">
                <Target size={14} className="text-green-400" />
                Number of Games
              </label>
              <input
                type="number"
                min="1"
                max="100"
                value={arenaConfig.games}
                onChange={(e) => setArenaConfig({ ...arenaConfig, games: parseInt(e.target.value) })}
                disabled={arenaStatus.is_running}
                className="w-full bg-slate-900 border border-slate-600 rounded-xl px-4 py-3 text-white font-medium focus:border-green-500 focus:ring-2 focus:ring-green-500/20 outline-none transition-all"
              />
            </div>

            {/* Move Delay */}
            <div className="space-y-2">
              <label className="text-slate-300 text-sm font-medium flex items-center gap-2">
                <Timer size={14} className="text-blue-400" />
                Move Delay (seconds)
              </label>
              <input
                type="number"
                min="0.1"
                max="10"
                step="0.1"
                value={arenaConfig.move_delay}
                onChange={(e) => setArenaConfig({ ...arenaConfig, move_delay: parseFloat(e.target.value) })}
                disabled={arenaStatus.is_running}
                className="w-full bg-slate-900 border border-slate-600 rounded-xl px-4 py-3 text-white font-medium focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
              />
            </div>
          </div>

          {/* Controls */}
          <div className="flex gap-4 pt-4 border-t border-slate-700/50">
            <Button
              onClick={startArena}
              disabled={arenaStatus.is_running}
              className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-semibold h-12 rounded-xl shadow-lg hover:shadow-green-500/25 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              data-testid="start-arena-button"
            >
              <Play size={20} className="mr-2" />
              Start Arena Battle
            </Button>
            <Button
              onClick={stopArena}
              disabled={!arenaStatus.is_running}
              className="flex-1 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-semibold h-12 rounded-xl shadow-lg hover:shadow-red-500/25 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              data-testid="stop-arena-button"
            >
              <Square size={20} className="mr-2" />
              Stop Arena
            </Button>
          </div>

          {/* Progress Bar */}
          {arenaStatus.is_running && arenaStatus.total_games > 0 && (
            <div className="pt-4 border-t border-slate-700/50">
              {renderProgressBar()}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Live Battle Display */}
      {arenaStatus.is_running && (
        <Card className="bg-slate-800/50 border-slate-700 rounded-2xl shadow-xl backdrop-blur-sm overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700/50">
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center gap-3">
                <div className="p-2 bg-blue-500/20 rounded-lg">
                  <Zap className="text-blue-400" size={20} />
                </div>
                <div>
                  <div className="text-xl font-bold">
                    Live Battle - Game {arenaStatus.current_game} of {arenaStatus.total_games}
                  </div>
                  <div className="text-sm text-slate-400 font-normal mt-1">
                    Move {arenaStatus.current_move}
                  </div>
                </div>
              </CardTitle>
              <div className="flex items-center gap-2 px-3 py-1 bg-blue-500/20 rounded-lg border border-blue-500/30">
                <Clock className="text-blue-400" size={16} />
                <span className="text-blue-300 text-sm font-medium">Real-time</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Chessboard Section */}
              <div className="space-y-4">
                <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-700">
                  <ChessBoard fen={currentPosition} />
                </div>
                
                {/* Evaluation Bar */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300 text-sm font-medium">Position Evaluation</span>
                    <div className="flex items-center gap-2">
                      <span className={`text-sm font-bold ${evaluation > 0 ? 'text-cyan-400' : 'text-purple-400'}`}>
                        {evaluation > 0 ? arenaStatus.player1_name : arenaStatus.player2_name}
                      </span>
                      <span className="text-xs text-slate-500">advantage</span>
                    </div>
                  </div>
                  {renderEvaluationBar()}
                </div>
              </div>

              {/* Analysis Section */}
              <div className="space-y-4">
                {/* Commentary */}
                <Card className="bg-gradient-to-br from-blue-900/20 to-cyan-900/20 border-blue-700/30">
                  <CardContent className="pt-4">
                    <div className="flex items-center gap-2 text-cyan-400 mb-3">
                      <MessageSquare size={18} />
                      <span className="font-semibold text-sm">Live Commentary</span>
                    </div>
                    <p className="text-slate-200 leading-relaxed">{commentary}</p>
                  </CardContent>
                </Card>

                {/* Move Log */}
                <Card className="bg-slate-900/50 border-slate-700">
                  <CardContent className="pt-4">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-slate-300 font-semibold text-sm">Move History</span>
                      <span className="text-xs text-slate-500">{moveLog.length} moves</span>
                    </div>
                    <div className="max-h-72 overflow-y-auto space-y-1 pr-2 scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-slate-900">
                      {moveLog.length > 0 ? (
                        moveLog.slice(-15).reverse().map((entry, idx) => (
                          <div 
                            key={idx} 
                            className="flex items-center justify-between px-3 py-2 bg-slate-800/50 rounded-lg hover:bg-slate-800 transition-colors"
                          >
                            <span className="text-slate-300 font-medium text-sm">
                              {entry.move_number}. {entry.move}
                            </span>
                            <div className="flex items-center gap-3">
                              <span className="text-xs text-slate-500">{entry.player}</span>
                              <span className={`text-sm font-bold px-2 py-0.5 rounded ${
                                entry.evaluation > 0 
                                  ? 'bg-cyan-500/20 text-cyan-400' 
                                  : 'bg-purple-500/20 text-purple-400'
                              }`}>
                                {entry.evaluation > 0 ? '+' : ''}{entry.evaluation.toFixed(2)}
                              </span>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-8 text-slate-500">
                          <Activity size={40} className="mx-auto mb-2 opacity-50" />
                          <p className="text-sm">Waiting for moves...</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Statistics Section */}
      <Card className="bg-slate-800/50 border-slate-700 rounded-2xl shadow-xl backdrop-blur-sm">
        <CardHeader className="border-b border-slate-700/50">
          <CardTitle className="flex items-center gap-3 text-white text-xl">
            <div className="p-2 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg">
              <TrendingUp className="text-white" size={20} />
            </div>
            Tournament Statistics
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          {renderStats()}
        </CardContent>
      </Card>
    </div>
  );
}
