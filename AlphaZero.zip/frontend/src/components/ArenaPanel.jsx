import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner';
import { Play, Square, TrendingUp, Clock, Trophy, MessageSquare } from 'lucide-react';
import ChessBoard from './ChessBoard';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function ArenaPanel() {
  const [models, setModels] = useState([]);
  const [arenaConfig, setArenaConfig] = useState({
    players: [null, null],
    games: 10,
    move_delay: 1.2,
    mcts_simulations: 800,
    save_pgn: true,
    commentary: true
  });
  
  const [arenaStatus, setArenaStatus] = useState({
    is_running: false,
    current_game: 0,
    total_games: 0,
    current_move: 0,
    current_fen: null,
    player1_name: '',
    player2_name: '',
    stats: {}
  });
  
  const [currentPosition, setCurrentPosition] = useState('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  const [moveLog, setMoveLog] = useState([]);
  const [commentary, setCommentary] = useState('');
  const [evaluation, setEvaluation] = useState(0);
  const [evaluationHistory, setEvaluationHistory] = useState([]);
  
  const eventSourceRef = useRef(null);

  useEffect(() => {
    loadModels();
    checkArenaStatus();
    
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, []);

  const loadModels = async () => {
    try {
      const response = await axios.get(`${API}/model/list`);
      if (response.data.success) {
        setModels(response.data.models);
      }
    } catch (error) {
      console.error('Error loading models:', error);
      toast.error('Failed to load models');
    }
  };

  const checkArenaStatus = async () => {
    try {
      const response = await axios.get(`${API}/arena/status`);
      if (response.data.success) {
        setArenaStatus(response.data);
        if (response.data.current_fen) {
          setCurrentPosition(response.data.current_fen);
        }
      }
    } catch (error) {
      console.error('Error checking arena status:', error);
    }
  };

  const startArena = async () => {
    try {
      const response = await axios.post(`${API}/arena/start`, arenaConfig);
      
      if (response.data.success) {
        toast.success('Arena started!');
        
        // Reset state
        setMoveLog([]);
        setCommentary('Arena starting...');
        setEvaluationHistory([]);
        
        // Start listening to events
        connectToEventStream();
      }
    } catch (error) {
      console.error('Error starting arena:', error);
      toast.error(error.response?.data?.detail || 'Failed to start arena');
    }
  };

  const stopArena = async () => {
    try {
      const response = await axios.post(`${API}/arena/stop`);
      
      if (response.data.success) {
        toast.info('Arena stop requested');
        
        // Close event stream
        if (eventSourceRef.current) {
          eventSourceRef.current.close();
          eventSourceRef.current = null;
        }
      }
    } catch (error) {
      console.error('Error stopping arena:', error);
      toast.error('Failed to stop arena');
    }
  };

  const connectToEventStream = () => {
    // Close existing connection if any
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    const eventSource = new EventSource(`${API}/arena/stream`);
    eventSourceRef.current = eventSource;

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        handleArenaEvent(data);
      } catch (error) {
        console.error('Error parsing event:', error);
      }
    };

    eventSource.onerror = (error) => {
      console.error('EventSource error:', error);
      eventSource.close();
      eventSourceRef.current = null;
      
      // Refresh status
      checkArenaStatus();
    };
  };

  const handleArenaEvent = (event) => {
    switch (event.type) {
      case 'arena_start':
        setArenaStatus(prev => ({
          ...prev,
          is_running: true,
          player1_name: event.player1,
          player2_name: event.player2,
          total_games: event.total_games
        }));
        toast.success(`Arena started: ${event.player1} vs ${event.player2}`);
        break;
      
      case 'game_start':
        setCurrentPosition(event.fen);
        setMoveLog([]);
        setCommentary(`Game ${event.game_number} started`);
        setEvaluationHistory([]);
        break;
      
      case 'move':
        setCurrentPosition(event.fen);
        setEvaluation(event.evaluation);
        
        // Add to move log
        const moveEntry = {
          move_number: event.move_number,
          move: event.move,
          player: event.player,
          evaluation: event.evaluation
        };
        setMoveLog(prev => [...prev, moveEntry]);
        
        // Update commentary
        if (event.commentary) {
          setCommentary(event.commentary);
        }
        
        // Add to evaluation history
        setEvaluationHistory(prev => [...prev, {
          move: event.move_number,
          value: event.evaluation
        }]);
        
        // Update status
        setArenaStatus(prev => ({
          ...prev,
          current_game: event.game_number,
          current_move: event.move_number
        }));
        break;
      
      case 'game_end':
        toast.success(`Game ${event.game_number} complete: ${event.winner} wins!`);
        setCommentary(`Game over: ${event.result} - ${event.winner}`);
        
        // Update stats
        setArenaStatus(prev => ({
          ...prev,
          stats: event.stats
        }));
        break;
      
      case 'arena_complete':
        toast.success('Arena complete!');
        setCommentary('All games completed');
        setArenaStatus(prev => ({
          ...prev,
          is_running: false,
          stats: event.stats
        }));
        
        // Close event stream
        if (eventSourceRef.current) {
          eventSourceRef.current.close();
          eventSourceRef.current = null;
        }
        break;
      
      case 'arena_error':
        toast.error(`Arena error: ${event.error}`);
        setCommentary(`Error: ${event.error}`);
        break;
      
      default:
        break;
    }
  };

  const renderEvaluationBar = () => {
    // Convert evaluation (-1 to 1) to percentage (0 to 100)
    const percentage = ((evaluation + 1) / 2) * 100;
    
    return (
      <div className="relative w-full h-8 bg-slate-700 rounded-lg overflow-hidden">
        <div 
          className="absolute top-0 left-0 h-full bg-gradient-to-r from-blue-500 to-blue-600 transition-all duration-300"
          style={{ width: `${percentage}%` }}
        />
        <div className="absolute inset-0 flex items-center justify-center text-white font-bold text-sm">
          {evaluation > 0 ? '+' : ''}{evaluation.toFixed(2)}
        </div>
      </div>
    );
  };

  const renderStats = () => {
    const stats = arenaStatus.stats || {};
    const total = stats.games_completed || 0;
    
    return (
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-slate-700/50 p-4 rounded-lg">
          <div className="text-slate-400 text-sm">Games</div>
          <div className="text-2xl font-bold text-white">{total}</div>
        </div>
        <div className="bg-blue-500/20 p-4 rounded-lg">
          <div className="text-blue-400 text-sm">{arenaStatus.player1_name}</div>
          <div className="text-2xl font-bold text-white">{stats.player1_wins || 0}</div>
        </div>
        <div className="bg-purple-500/20 p-4 rounded-lg">
          <div className="text-purple-400 text-sm">{arenaStatus.player2_name}</div>
          <div className="text-2xl font-bold text-white">{stats.player2_wins || 0}</div>
        </div>
        <div className="bg-slate-600/50 p-4 rounded-lg">
          <div className="text-slate-400 text-sm">Draws</div>
          <div className="text-2xl font-bold text-white">{stats.draws || 0}</div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6" data-testid="arena-panel">
      {/* Configuration Card */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Trophy className="text-yellow-500" size={24} />
            Live Arena Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {/* Player 1 */}
            <div>
              <label className="text-slate-300 text-sm mb-2 block">Player 1 Model</label>
              <Select
                value={arenaConfig.players[0] || 'active'}
                onValueChange={(value) => {
                  const newPlayers = [...arenaConfig.players];
                  newPlayers[0] = value === 'active' ? null : value;
                  setArenaConfig({ ...arenaConfig, players: newPlayers });
                }}
                disabled={arenaStatus.is_running}
              >
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Select model" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active Model</SelectItem>
                  {models.map(model => (
                    <SelectItem key={model.name} value={model.name}>
                      {model.name} (ELO: {model.elo})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Player 2 */}
            <div>
              <label className="text-slate-300 text-sm mb-2 block">Player 2 Model</label>
              <Select
                value={arenaConfig.players[1] || 'active'}
                onValueChange={(value) => {
                  const newPlayers = [...arenaConfig.players];
                  newPlayers[1] = value === 'active' ? null : value;
                  setArenaConfig({ ...arenaConfig, players: newPlayers });
                }}
                disabled={arenaStatus.is_running}
              >
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Select model" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active Model</SelectItem>
                  {models.map(model => (
                    <SelectItem key={model.name} value={model.name}>
                      {model.name} (ELO: {model.elo})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Number of Games */}
            <div>
              <label className="text-slate-300 text-sm mb-2 block">Number of Games</label>
              <input
                type="number"
                min="1"
                max="100"
                value={arenaConfig.games}
                onChange={(e) => setArenaConfig({ ...arenaConfig, games: parseInt(e.target.value) })}
                disabled={arenaStatus.is_running}
                className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white"
              />
            </div>

            {/* Move Delay */}
            <div>
              <label className="text-slate-300 text-sm mb-2 block">Move Delay (seconds)</label>
              <input
                type="number"
                min="0.1"
                max="10"
                step="0.1"
                value={arenaConfig.move_delay}
                onChange={(e) => setArenaConfig({ ...arenaConfig, move_delay: parseFloat(e.target.value) })}
                disabled={arenaStatus.is_running}
                className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white"
              />
            </div>
          </div>

          {/* Controls */}
          <div className="flex gap-4">
            <Button
              onClick={startArena}
              disabled={arenaStatus.is_running}
              className="flex-1 bg-green-600 hover:bg-green-700"
              data-testid="start-arena-button"
            >
              <Play size={20} className="mr-2" />
              Start Arena
            </Button>
            <Button
              onClick={stopArena}
              disabled={!arenaStatus.is_running}
              className="flex-1 bg-red-600 hover:bg-red-700"
              data-testid="stop-arena-button"
            >
              <Square size={20} className="mr-2" />
              Stop Arena
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Arena Display */}
      {arenaStatus.is_running && (
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">
              Game {arenaStatus.current_game} of {arenaStatus.total_games} - Move {arenaStatus.current_move}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-6">
              {/* Chessboard */}
              <div>
                <ChessBoard fen={currentPosition} />
                
                {/* Evaluation Bar */}
                <div className="mt-4">
                  <div className="text-slate-400 text-sm mb-2">Position Evaluation</div>
                  {renderEvaluationBar()}
                </div>
              </div>

              {/* Move Log and Commentary */}
              <div className="space-y-4">
                {/* Commentary */}
                <div className="bg-slate-700/50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 text-blue-400 mb-2">
                    <MessageSquare size={20} />
                    <span className="font-semibold">Commentary</span>
                  </div>
                  <p className="text-slate-300">{commentary}</p>
                </div>

                {/* Move Log */}
                <div className="bg-slate-700/50 p-4 rounded-lg">
                  <div className="text-slate-400 mb-2 font-semibold">Move History</div>
                  <div className="max-h-64 overflow-y-auto space-y-1">
                    {moveLog.slice(-10).reverse().map((entry, idx) => (
                      <div key={idx} className="text-sm text-slate-300 flex justify-between">
                        <span>{entry.move_number}. {entry.move}</span>
                        <span className="text-slate-500">{entry.player}</span>
                        <span className={entry.evaluation > 0 ? 'text-green-400' : 'text-red-400'}>
                          {entry.evaluation > 0 ? '+' : ''}{entry.evaluation.toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Statistics */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <TrendingUp className="text-green-500" size={24} />
            Arena Statistics
          </CardTitle>
        </CardHeader>
        <CardContent>
          {renderStats()}
        </CardContent>
      </Card>
    </div>
  );
}
