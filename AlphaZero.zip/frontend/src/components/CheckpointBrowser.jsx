import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Save, RotateCcw, Download, Clock, TrendingDown } from 'lucide-react';

const CheckpointBrowser = ({ jobId, checkpoints = [], onRestore }) => {
  const formatBytes = (bytes) => {
    if (bytes === 0) return '0 MB';
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(2)} MB`;
  };

  const formatTimestamp = (timestamp) => {
    if (!timestamp) return 'N/A';
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  const getRelativeTime = (timestamp) => {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  return (
    <Card className="bg-slate-800/50 border-slate-700" data-testid="checkpoint-browser">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Save size={20} className="text-cyan-400" />
          Checkpoints ({checkpoints.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {checkpoints.length === 0 ? (
          <div className="text-center py-8 text-slate-400">
            <Save size={48} className="mx-auto mb-4 opacity-20" />
            <p>No checkpoints available yet</p>
            <p className="text-sm mt-2">Checkpoints will appear as training progresses</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {checkpoints.map((checkpoint, index) => (
              <div
                key={checkpoint.checkpoint_id}
                className={`p-3 bg-slate-900/50 rounded border ${
                  index === 0 ? 'border-cyan-500/50' : 'border-slate-700'
                } hover:border-slate-600 transition-colors`}
                data-testid={`checkpoint-${checkpoint.checkpoint_id}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Save size={14} className={index === 0 ? 'text-cyan-400' : 'text-slate-400'} />
                    <span className="text-white font-medium text-sm">
                      Epoch {checkpoint.epoch}
                      {index === 0 && (
                        <span className="ml-2 px-2 py-0.5 bg-cyan-500/20 text-cyan-400 text-xs rounded">
                          Latest
                        </span>
                      )}
                    </span>
                  </div>
                  
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onRestore(checkpoint.checkpoint_id)}
                    className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/20"
                    data-testid={`restore-checkpoint-${checkpoint.checkpoint_id}`}
                  >
                    <RotateCcw size={12} className="mr-1" />
                    Restore
                  </Button>
                </div>
                
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="flex items-center gap-1 text-slate-400">
                    <TrendingDown size={12} />
                    <span>Loss: </span>
                    <span className="text-white font-medium">{checkpoint.loss?.toFixed(4) || 'N/A'}</span>
                  </div>
                  
                  <div className="flex items-center gap-1 text-slate-400">
                    <Download size={12} />
                    <span>Size: </span>
                    <span className="text-white font-medium">{checkpoint.size_mb?.toFixed(2) || 0} MB</span>
                  </div>
                  
                  <div className="flex items-center gap-1 text-slate-400 col-span-2">
                    <Clock size={12} />
                    <span>{formatTimestamp(checkpoint.timestamp)}</span>
                    <span className="ml-auto text-slate-500">{getRelativeTime(checkpoint.timestamp)}</span>
                  </div>
                </div>
                
                {checkpoint.storage_backend && (
                  <div className="mt-2 pt-2 border-t border-slate-700">
                    <span className="text-xs text-slate-500">
                      Storage: <span className="text-slate-400">{checkpoint.storage_backend}</span>
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CheckpointBrowser;
