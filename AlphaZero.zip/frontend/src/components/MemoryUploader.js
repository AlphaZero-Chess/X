import React, { useState, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Upload, FileText, AlertCircle, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

function MemoryUploader({ onUploadSuccess }) {
  const [uploading, setUploading] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = Array.from(e.dataTransfer.files).filter(
      file => file.name.endsWith('.pgn')
    );

    if (files.length > 0) {
      setSelectedFiles(files);
      toast.success(`Selected ${files.length} PGN file(s)`);
    } else {
      toast.error('Please select PGN files only');
    }
  }, []);

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files).filter(
      file => file.name.endsWith('.pgn')
    );

    if (files.length > 0) {
      setSelectedFiles(files);
      toast.success(`Selected ${files.length} PGN file(s)`);
    }
  };

  const handleUpload = async () => {
    if (selectedFiles.length === 0) {
      toast.error('Please select PGN files first');
      return;
    }

    setUploading(true);
    try {
      const formData = new FormData();
      selectedFiles.forEach(file => {
        formData.append('files', file);
      });

      const response = await axios.post(`${API}/memory/upload`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      if (response.data.success) {
        toast.success(`Successfully stored ${response.data.games_stored} games!`);
        setSelectedFiles([]);
        if (onUploadSuccess) {
          onUploadSuccess(response.data);
        }
      }
    } catch (error) {
      console.error('Upload error:', error);
      toast.error(`Upload failed: ${error.response?.data?.detail || error.message}`);
    } finally {
      setUploading(false);
    }
  };

  return (
    <Card data-testid="memory-uploader-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-5 w-5" />
          Upload Memory Files
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            dragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          data-testid="drag-drop-zone"
        >
          <Upload className="h-12 w-12 mx-auto mb-4 text-gray-400" />
          <p className="text-lg font-medium mb-2">Drag & Drop PGN Files</p>
          <p className="text-sm text-gray-500 mb-4">or click to browse</p>
          <input
            type="file"
            multiple
            accept=".pgn"
            onChange={handleFileSelect}
            className="hidden"
            id="file-upload"
            data-testid="file-input"
          />
          <label htmlFor="file-upload">
            <Button variant="outline" asChild>
              <span>Browse Files</span>
            </Button>
          </label>
        </div>

        {selectedFiles.length > 0 && (
          <div className="space-y-2" data-testid="selected-files-list">
            <p className="text-sm font-medium">Selected Files ({selectedFiles.length}):</p>
            <div className="space-y-1 max-h-40 overflow-y-auto">
              {selectedFiles.map((file, idx) => (
                <div key={idx} className="flex items-center gap-2 text-sm p-2 bg-gray-50 rounded">
                  <FileText className="h-4 w-4" />
                  <span className="flex-1">{file.name}</span>
                  <span className="text-gray-500">{(file.size / 1024).toFixed(1)} KB</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex gap-2">
          <Button
            onClick={handleUpload}
            disabled={uploading || selectedFiles.length === 0}
            className="flex-1"
            data-testid="upload-button"
          >
            {uploading ? (
              <>
                <AlertCircle className="mr-2 h-4 w-4 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <CheckCircle2 className="mr-2 h-4 w-4" />
                Upload {selectedFiles.length} File(s)
              </>
            )}
          </Button>
          {selectedFiles.length > 0 && (
            <Button
              variant="outline"
              onClick={() => setSelectedFiles([])}
              disabled={uploading}
              data-testid="clear-button"
            >
              Clear
            </Button>
          )}
        </div>

        <div className="text-xs text-gray-500 space-y-1">
          <p>• Accepts PGN files from AlphaZero vs Stockfish, self-play, or online databases</p>
          <p>• Multiple files can be uploaded simultaneously</p>
          <p>• Games will be parsed and stored in AlphaZero's long-term memory</p>
        </div>
      </CardContent>
    </Card>
  );
}

export default MemoryUploader;
