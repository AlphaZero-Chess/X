import React, { useEffect, useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Progress } from './ui/progress';
import { Clock, Zap, Brain } from 'lucide-react';

function MemoryProgress({ trainingStatus }) {
  const [elapsed, setElapsed] = useState(0);
  const [eta, setEta] = useState(0);

  useEffect(() => {
    if (!trainingStatus || !trainingStatus.active) {
      setElapsed(0);
      setEta(0);
      return;
    }

    const startTime = trainingStatus.start_time ? new Date(trainingStatus.start_time).getTime() : Date.now();
    
    const interval = setInterval(() => {
      const now = Date.now();
      const elapsedSec = Math.floor((now - startTime) / 1000);
      setElapsed(elapsedSec);
      
      // Use ETA from backend
      setEta(trainingStatus.eta_seconds || 0);
    }, 1000);

    return () => clearInterval(interval);
  }, [trainingStatus]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  if (!trainingStatus || !trainingStatus.active) {
    return null;
  }

  return (
    <Card data-testid="memory-progress-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5 animate-pulse" />
          AlphaZero is recalling memory...
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="font-medium">{trainingStatus.message}</span>
            <span className="text-gray-500">{trainingStatus.progress}%</span>
          </div>
          <Progress value={trainingStatus.progress} className="h-3" data-testid="progress-bar" />
        </div>

        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="space-y-1">
            <Clock className="h-4 w-4 mx-auto text-blue-500" />
            <p className="text-xs text-gray-500">Elapsed</p>
            <p className="text-sm font-medium" data-testid="elapsed-time">{formatTime(elapsed)}</p>
          </div>
          <div className="space-y-1">
            <Zap className="h-4 w-4 mx-auto text-green-500" />
            <p className="text-xs text-gray-500">ETA</p>
            <p className="text-sm font-medium" data-testid="eta-time">{formatTime(eta)}</p>
          </div>
          <div className="space-y-1">
            <Brain className="h-4 w-4 mx-auto text-purple-500" />
            <p className="text-xs text-gray-500">Step</p>
            <p className="text-sm font-medium" data-testid="step-progress">
              {trainingStatus.step}/{trainingStatus.total_steps}
            </p>
          </div>
        </div>

        <div className="text-xs text-gray-500 italic text-center">
          Processing historical matches and retraining neural weights...
        </div>
      </CardContent>
    </Card>
  );
}

export default MemoryProgress;
