import React, { useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { motion } from 'framer-motion';
import { TrendingUp, Zap } from 'lucide-react';

const AlphaZeroCharts = ({ metrics }) => {
  const { metrics: metricsData = [], summary = {} } = metrics;
  
  // Prepare ELO chart data
  const eloData = useMemo(() => {
    if (!metricsData || metricsData.length === 0) return [];
    
    return metricsData.slice(-50).map((m, idx) => ({
      index: idx + 1,
      elo: m.current_elo || 1500,
      games: m.games_completed || 0
    }));
  }, [metricsData]);
  
  // Prepare performance chart data (games/sec)
  const performanceData = useMemo(() => {
    if (!metricsData || metricsData.length === 0) return [];
    
    return metricsData.slice(-50).map((m, idx) => ({
      index: idx + 1,
      gamesPerSec: m.games_per_sec || 0,
      evalsPerSec: m.evals_per_sec || 0
    }));
  }, [metricsData]);
  
  // Custom tooltip
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-3 shadow-xl">
          <p className="text-slate-400 text-xs mb-1">Checkpoint {label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-white font-mono text-sm">
              {entry.name}: <span style={{ color: entry.color }}>{entry.value.toFixed(2)}</span>
            </p>
          ))}
        </div>
      );
    }
    return null;
  };
  
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* ELO Progression Chart */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm" data-testid="elo-chart-card">
          <CardHeader>
            <CardTitle className="text-xl text-white flex items-center gap-2">
              <TrendingUp className="text-green-400" size={24} />
              ELO Progression
            </CardTitle>
          </CardHeader>
          <CardContent>
            {eloData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={eloData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis 
                    dataKey="index" 
                    stroke="#94a3b8" 
                    tick={{ fill: '#94a3b8' }}
                    label={{ value: 'Checkpoint', position: 'insideBottom', offset: -5, fill: '#94a3b8' }}
                  />
                  <YAxis 
                    stroke="#94a3b8" 
                    tick={{ fill: '#94a3b8' }}
                    label={{ value: 'ELO Rating', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend wrapperStyle={{ color: '#94a3b8' }} />
                  <Line 
                    type="monotone" 
                    dataKey="elo" 
                    stroke="#22d3ee" 
                    strokeWidth={3}
                    dot={{ fill: '#22d3ee', r: 4 }}
                    activeDot={{ r: 6, fill: '#06b6d4' }}
                    name="ELO"
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center">
                <p className="text-slate-400 text-center">
                  No ELO data available yet.<br />
                  <span className="text-sm">Start training to see progression.</span>
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
      
      {/* Performance Chart (Games/Sec) */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm" data-testid="performance-chart-card">
          <CardHeader>
            <CardTitle className="text-xl text-white flex items-center gap-2">
              <Zap className="text-yellow-400" size={24} />
              Training Throughput
            </CardTitle>
          </CardHeader>
          <CardContent>
            {performanceData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis 
                    dataKey="index" 
                    stroke="#94a3b8" 
                    tick={{ fill: '#94a3b8' }}
                    label={{ value: 'Checkpoint', position: 'insideBottom', offset: -5, fill: '#94a3b8' }}
                  />
                  <YAxis 
                    stroke="#94a3b8" 
                    tick={{ fill: '#94a3b8' }}
                    label={{ value: 'Games/Second', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend wrapperStyle={{ color: '#94a3b8' }} />
                  <Bar 
                    dataKey="gamesPerSec" 
                    fill="#facc15" 
                    name="Games/Sec"
                    radius={[8, 8, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center">
                <p className="text-slate-400 text-center">
                  No performance data available yet.<br />
                  <span className="text-sm">Start training to see throughput.</span>
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default AlphaZeroCharts;
