import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Slider } from './ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Activity, 
  Zap, 
  Globe, 
  TrendingUp, 
  AlertTriangle,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Moon,
  Sun
} from 'lucide-react';
import { toast } from 'sonner';
import UtilizationGauge from './UtilizationGauge';
import LatencyHeatmap from './LatencyHeatmap';
import ThroughputChart from './ThroughputChart';
import FaultRateTimeline from './FaultRateTimeline';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api/cloud`;
const WS_URL = BACKEND_URL.replace('http', 'ws') + '/api/cloud/live';

const CloudControlPanel = () => {
  // State
  const [status, setStatus] = useState(null);
  const [metrics, setMetrics] = useState(null);
  const [jobs, setJobs] = useState({ running: [], queued: [] });
  const [loading, setLoading] = useState(true);
  const [connected, setConnected] = useState(false);
  const [darkMode, setDarkMode] = useState(true);
  
  // Scaling state
  const [targetTpus, setTargetTpus] = useState(5000);
  const [scaling, setScaling] = useState(false);
  
  // Fault injection state
  const [selectedRegion, setSelectedRegion] = useState('random');
  const [faultType, setFaultType] = useState('crash');
  const [numNodes, setNumNodes] = useState(10);
  const [injecting, setInjecting] = useState(false);
  
  // WebSocket connection
  const [ws, setWs] = useState(null);
  
  // Initialize WebSocket connection
  useEffect(() => {
    connectWebSocket();
    
    return () => {
      if (ws) {
        ws.close();
      }
    };
  }, []);
  
  const connectWebSocket = useCallback(() => {
    try {
      const websocket = new WebSocket(WS_URL);
      
      websocket.onopen = () => {
        console.log('WebSocket connected');
        setConnected(true);
        toast.success('Connected to Cloud Grid');
      };
      
      websocket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          
          if (data.type === 'initial_status') {
            setStatus(data.data);
            setLoading(false);
          } else if (data.type === 'live_update') {
            setStatus(data.data.status);
            setMetrics(data.data.metrics);
            setJobs(data.data.jobs);
          } else if (data.type === 'scale_update') {
            toast.success(data.data.message);
          } else if (data.type === 'fault_injection') {
            toast.warning(`Fault injected: ${data.data.fault_type} on ${data.data.affected_nodes} nodes`);
          }
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };
      
      websocket.onerror = (error) => {
        console.error('WebSocket error:', error);
        setConnected(false);
      };
      
      websocket.onclose = () => {
        console.log('WebSocket disconnected');
        setConnected(false);
        toast.error('Disconnected from Cloud Grid');
        
        // Reconnect after 5 seconds
        setTimeout(() => {
          console.log('Attempting to reconnect...');
          connectWebSocket();
        }, 5000);
      };
      
      setWs(websocket);
    } catch (error) {
      console.error('Error connecting WebSocket:', error);
      setConnected(false);
    }
  }, []);
  
  // Scale grid
  const handleScale = async () => {
    setScaling(true);
    try {
      const response = await fetch(`${API}/scale`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target_tpus: targetTpus })
      });
      
      const data = await response.json();
      
      if (data.success) {
        toast.success(data.message);
      }
    } catch (error) {
      console.error('Error scaling grid:', error);
      toast.error('Failed to scale grid');
    } finally {
      setScaling(false);
    }
  };
  
  // Inject fault
  const handleInjectFault = async () => {
    setInjecting(true);
    try {
      const response = await fetch(`${API}/inject-fault`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          region: selectedRegion,
          fault_type: faultType,
          num_nodes: numNodes
        })
      });
      
      const data = await response.json();
      
      if (data.success) {
        toast.success(`Fault injected: ${faultType}`);
      }
    } catch (error) {
      console.error('Error injecting fault:', error);
      toast.error('Failed to inject fault');
    } finally {
      setInjecting(false);
    }
  };
  
  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-white text-xl flex items-center gap-2">
          <RefreshCw className="animate-spin" />
          Initializing Cloud Grid...
        </div>
      </div>
    );
  }
  
  return (
    <div className={`space-y-6 ${darkMode ? 'dark' : ''}`} data-testid="cloud-control-panel">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-2">
            <Globe className="text-cyan-400" />
            Cloud Control Panel
          </h1>
          <p className="text-slate-400 mt-1">
            Real-time TPU Grid Monitoring & Management
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          {/* Connection Status */}
          <Badge variant={connected ? 'default' : 'destructive'} className="flex items-center gap-2">
            {connected ? (
              <><CheckCircle2 size={16} /> Connected</>
            ) : (
              <><XCircle size={16} /> Disconnected</>
            )}
          </Badge>
          
          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setDarkMode(!darkMode)}
            className="text-slate-400 hover:text-white"
          >
            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
          </Button>
        </div>
      </div>
      
      {/* Global Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-slate-800/50 border-slate-700" data-testid="total-tpus-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Total TPUs</p>
                <p className="text-3xl font-bold text-white">
                  {status?.total_tpus?.toLocaleString()}
                </p>
              </div>
              <Activity className="text-cyan-400" size={32} />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-slate-800/50 border-slate-700" data-testid="active-tpus-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Active TPUs</p>
                <p className="text-3xl font-bold text-green-400">
                  {status?.active_tpus?.toLocaleString()}
                </p>
              </div>
              <CheckCircle2 className="text-green-400" size={32} />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-slate-800/50 border-slate-700" data-testid="utilization-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Global Utilization</p>
                <p className="text-3xl font-bold text-yellow-400">
                  {(status?.global_utilization * 100).toFixed(1)}%
                </p>
              </div>
              <TrendingUp className="text-yellow-400" size={32} />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-slate-800/50 border-slate-700" data-testid="jobs-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Jobs Running</p>
                <p className="text-3xl font-bold text-purple-400">
                  {status?.jobs_running}
                </p>
              </div>
              <Zap className="text-purple-400" size={32} />
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-slate-800/50">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="metrics">Metrics</TabsTrigger>
          <TabsTrigger value="jobs">Jobs</TabsTrigger>
          <TabsTrigger value="control">Control</TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          {/* Region Health Map */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Globe size={20} />
                Region Health Map
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                {status?.regions && Object.entries(status.regions).map(([region, data]) => (
                  <Card key={region} className="bg-slate-900/50 border-slate-600">
                    <CardHeader>
                      <CardTitle className="text-lg text-white flex items-center justify-between">
                        <span>{region}</span>
                        <Badge 
                          variant={data.utilization > 0.8 ? 'destructive' : data.utilization > 0.5 ? 'default' : 'secondary'}
                        >
                          {(data.utilization * 100).toFixed(0)}%
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-400">Total TPUs:</span>
                          <span className="text-white font-medium">{data.total_tpus}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Active:</span>
                          <span className="text-green-400 font-medium">{data.active_tpus}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Faults:</span>
                          <span className="text-red-400 font-medium">{data.fault_tpus}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Jobs:</span>
                          <span className="text-purple-400 font-medium">{data.jobs_running}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
          
          {/* Quick Metrics */}
          <div className="grid grid-cols-2 gap-4">
            <UtilizationGauge utilization={status?.global_utilization || 0} />
            {metrics && <LatencyHeatmap latencyMatrix={metrics.latency_matrix} />}
          </div>
        </TabsContent>
        
        {/* Metrics Tab */}
        <TabsContent value="metrics" className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {metrics && (
              <>
                <ThroughputChart history={metrics.history?.throughput || []} />
                <FaultRateTimeline history={metrics.history?.fault_rate || []} />
              </>
            )}
          </div>
          
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Current Metrics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-slate-400 text-sm">Throughput</p>
                  <p className="text-2xl font-bold text-white">{metrics?.throughput || 0} jobs/s</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Fault Rate</p>
                  <p className="text-2xl font-bold text-white">{((metrics?.fault_rate || 0) * 100).toFixed(2)}%</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Avg Utilization</p>
                  <p className="text-2xl font-bold text-white">{((metrics?.utilization || 0) * 100).toFixed(1)}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Jobs Tab */}
        <TabsContent value="jobs" className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {/* Running Jobs */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  <span>Running Jobs</span>
                  <Badge>{jobs.total_running || 0}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {jobs.running && jobs.running.length > 0 ? (
                    jobs.running.map((job) => (
                      <Card key={job.job_id} className="bg-slate-900/50 border-slate-600">
                        <CardContent className="pt-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-white font-medium">{job.name}</span>
                            <Badge variant="default">Priority {job.priority}</Badge>
                          </div>
                          <div className="text-sm text-slate-400 space-y-1">
                            <div>Region: {job.region}</div>
                            <div>TPUs: {job.tpus_required}</div>
                            <div>Progress: {(job.progress * 100).toFixed(0)}%</div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <p className="text-slate-400 text-center py-8">No running jobs</p>
                  )}
                </div>
              </CardContent>
            </Card>
            
            {/* Queued Jobs */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  <span>Queued Jobs</span>
                  <Badge>{jobs.total_queued || 0}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {jobs.queued && jobs.queued.length > 0 ? (
                    jobs.queued.map((job) => (
                      <Card key={job.job_id} className="bg-slate-900/50 border-slate-600">
                        <CardContent className="pt-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-white font-medium">{job.name}</span>
                            <Badge variant="secondary">Priority {job.priority}</Badge>
                          </div>
                          <div className="text-sm text-slate-400 space-y-1">
                            <div>Region: {job.region}</div>
                            <div>TPUs Required: {job.tpus_required}</div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <p className="text-slate-400 text-center py-8">No queued jobs</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* Control Tab */}
        <TabsContent value="control" className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {/* Scaling Controls */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <TrendingUp size={20} />
                  Scale TPU Grid
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-slate-400 text-sm block mb-2">
                    Target TPUs: {targetTpus.toLocaleString()}
                  </label>
                  <Slider
                    value={[targetTpus]}
                    onValueChange={(val) => setTargetTpus(val[0])}
                    min={100}
                    max={10000}
                    step={100}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-slate-500 mt-1">
                    <span>100</span>
                    <span>10,000</span>
                  </div>
                </div>
                
                <Button
                  onClick={handleScale}
                  disabled={scaling || targetTpus === status?.total_tpus}
                  className="w-full"
                  data-testid="scale-button"
                >
                  {scaling ? 'Scaling...' : `Scale to ${targetTpus.toLocaleString()} TPUs`}
                </Button>
              </CardContent>
            </Card>
            
            {/* Fault Injection */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <AlertTriangle size={20} />
                  Fault Injection
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-slate-400 text-sm block mb-2">Region</label>
                  <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                    <SelectTrigger className="bg-slate-900 border-slate-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="random">Random</SelectItem>
                      <SelectItem value="us-east">US East</SelectItem>
                      <SelectItem value="us-west">US West</SelectItem>
                      <SelectItem value="eu-west">EU West</SelectItem>
                      <SelectItem value="asia">Asia</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-slate-400 text-sm block mb-2">Fault Type</label>
                  <Select value={faultType} onValueChange={setFaultType}>
                    <SelectTrigger className="bg-slate-900 border-slate-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="crash">Crash</SelectItem>
                      <SelectItem value="latency">Latency Spike</SelectItem>
                      <SelectItem value="recovery">Recovery</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-slate-400 text-sm block mb-2">
                    Affected Nodes: {numNodes}
                  </label>
                  <Slider
                    value={[numNodes]}
                    onValueChange={(val) => setNumNodes(val[0])}
                    min={1}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>
                
                <Button
                  onClick={handleInjectFault}
                  disabled={injecting}
                  variant="destructive"
                  className="w-full"
                  data-testid="inject-fault-button"
                >
                  {injecting ? 'Injecting...' : 'Inject Fault'}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CloudControlPanel;