import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { AlertTriangle } from 'lucide-react';

const FaultRateTimeline = ({ history }) => {
  // Format data for Recharts
  const data = (history || []).map((point, idx) => ({
    time: idx,
    faultRate: (point.value || 0) * 100  // Convert to percentage
  }));
  
  return (
    <Card className="bg-slate-800/50 border-slate-700" data-testid="fault-rate-timeline">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <AlertTriangle size={20} />
          Fault Rate Timeline
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={250}>
          <AreaChart data={data}>
            <defs>
              <linearGradient id="faultGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#ef4444" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#ef4444" stopOpacity={0.1}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis 
              dataKey="time" 
              stroke="#94a3b8"
              tick={{ fill: '#94a3b8', fontSize: 12 }}
            />
            <YAxis 
              stroke="#94a3b8"
              tick={{ fill: '#94a3b8', fontSize: 12 }}
              label={{ value: 'Fault %', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1e293b', 
                border: '1px solid #334155',
                borderRadius: '8px'
              }}
              labelStyle={{ color: '#94a3b8' }}
              itemStyle={{ color: '#ef4444' }}
              formatter={(value) => `${value.toFixed(3)}%`}
            />
            <Area 
              type="monotone" 
              dataKey="faultRate" 
              stroke="#ef4444" 
              strokeWidth={2}
              fill="url(#faultGradient)"
            />
          </AreaChart>
        </ResponsiveContainer>
        
        <div className="mt-4 text-center">
          <div className="text-2xl font-bold text-red-400">
            {data.length > 0 ? data[data.length - 1].faultRate.toFixed(3) : '0.000'}%
          </div>
          <div className="text-slate-400 text-sm">Current Fault Rate</div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FaultRateTimeline;