import React, { useState, useEffect } from 'react';
import { Brain, TrendingUp, Award, Activity, RefreshCw } from 'lucide-react';
import axios from 'axios';

const IQGrowthPanel = () => {
  const [iqData, setIqData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [evaluating, setEvaluating] = useState(false);

  const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || '';

  useEffect(() => {
    fetchIQData();
  }, []);

  const fetchIQData = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/iq/history`);
      setIqData(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching IQ data:', error);
      setLoading(false);
    }
  };

  const startSelfEvaluation = async () => {
    setEvaluating(true);
    try {
      await axios.post(`${BACKEND_URL}/api/evaluate/self`);
      // Refresh data after a delay
      setTimeout(() => {
        fetchIQData();
        setEvaluating(false);
      }, 5000);
    } catch (error) {
      console.error('Error starting self-evaluation:', error);
      setEvaluating(false);
    }
  };

  if (loading) {
    return (
      <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
        <div className="flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
        </div>
      </div>
    );
  }

  const stats = iqData?.statistics || {};
  const progression = iqData?.progression || [];
  const latest = iqData?.history?.[iqData.history.length - 1];

  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Brain className="w-6 h-6 text-purple-400" />
          <h2 className="text-xl font-bold text-white">IQ Growth Tracking</h2>
        </div>
        <button
          onClick={startSelfEvaluation}
          disabled={evaluating}
          className="px-4 py-2 bg-purple-600 text-white rounded font-medium hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
        >
          {evaluating ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              Evaluating...
            </>
          ) : (
            <>
              <Activity className="w-4 h-4" />
              Run Self-Evaluation
            </>
          )}
        </button>
      </div>

      {/* Key Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard
          icon={<Award className="w-5 h-5 text-yellow-400" />}
          label="Current ELO"
          value={stats.current_elo || 1500}
          color="text-yellow-400"
        />
        <StatCard
          icon={<TrendingUp className="w-5 h-5 text-green-400" />}
          label="Total Gain"
          value={`+${stats.total_elo_gain || 0}`}
          color="text-green-400"
        />
        <StatCard
          icon={<Activity className="w-5 h-5 text-blue-400" />}
          label="Avg Gain/Cycle"
          value={`${stats.avg_elo_gain >= 0 ? '+' : ''}${stats.avg_elo_gain || 0}`}
          color="text-blue-400"
        />
        <StatCard
          icon={<Brain className="w-5 h-5 text-purple-400" />}
          label="Comparisons"
          value={stats.total_comparisons || 0}
          color="text-purple-400"
        />
      </div>

      {/* Latest Comparison */}
      {latest && (
        <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
          <h3 className="text-sm font-semibold text-gray-300 mb-3">Latest Comparison</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-sm">Model</span>
              <span className="text-white font-medium">{latest.model_id}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-sm">vs Previous</span>
              <span className="text-gray-400">{latest.previous_model_id}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-sm">ELO Change</span>
              <span className={`font-bold ${
                latest.elo_delta >= 0 ? 'text-green-400' : 'text-red-400'
              }`}>
                {latest.elo_delta >= 0 ? '+' : ''}{latest.elo_delta}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-sm">Win Rate</span>
              <span className="text-white">{(latest.win_rate * 100).toFixed(1)}%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-sm">Games Played</span>
              <span className="text-white">{latest.games_played}</span>
            </div>
          </div>
        </div>
      )}

      {/* ELO Progression Chart */}
      {progression.length > 0 && (
        <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
          <h3 className="text-sm font-semibold text-gray-300 mb-4">ELO Progression</h3>
          <div className="relative h-48">
            <ELOChart data={progression} />
          </div>
        </div>
      )}

      {/* Recent History */}
      {iqData?.history && iqData.history.length > 0 && (
        <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
          <h3 className="text-sm font-semibold text-gray-300 mb-3">Recent History</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {iqData.history.slice(-10).reverse().map((entry, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between py-2 px-3 bg-gray-900/50 rounded border border-gray-700"
              >
                <div className="flex-1">
                  <div className="text-sm text-white font-medium">{entry.model_id}</div>
                  <div className="text-xs text-gray-500">
                    {new Date(entry.timestamp).toLocaleDateString()}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="text-sm text-gray-400">ELO</div>
                    <div className="text-sm font-bold text-white">{entry.current_elo}</div>
                  </div>
                  <div className={`text-sm font-bold px-2 py-1 rounded ${
                    entry.elo_delta >= 0
                      ? 'bg-green-900/30 text-green-400'
                      : 'bg-red-900/30 text-red-400'
                  }`}>
                    {entry.elo_delta >= 0 ? '+' : ''}{entry.elo_delta}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* No Data Message */}
      {(!iqData?.history || iqData.history.length === 0) && (
        <div className="bg-gray-800 rounded-lg p-8 border border-gray-700 text-center">
          <Brain className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400 mb-4">No IQ comparisons recorded yet</p>
          <p className="text-sm text-gray-500 mb-4">
            Run self-evaluation to compare models and track intelligence growth
          </p>
          <button
            onClick={startSelfEvaluation}
            disabled={evaluating}
            className="px-4 py-2 bg-purple-600 text-white rounded font-medium hover:bg-purple-700 transition-colors disabled:opacity-50"
          >
            Start First Evaluation
          </button>
        </div>
      )}
    </div>
  );
};

const StatCard = ({ icon, label, value, color }) => (
  <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
    <div className="flex items-center gap-2 mb-2">
      {icon}
      <span className="text-sm text-gray-400">{label}</span>
    </div>
    <div className={`text-2xl font-bold ${color}`}>{value}</div>
  </div>
);

const ELOChart = ({ data }) => {
  if (!data || data.length === 0) return null;

  const minElo = Math.min(...data.map(d => d.elo)) - 50;
  const maxElo = Math.max(...data.map(d => d.elo)) + 50;
  const range = maxElo - minElo;

  const points = data.map((entry, idx) => {
    const x = (idx / (data.length - 1)) * 100;
    const y = 100 - ((entry.elo - minElo) / range) * 100;
    return { x, y, elo: entry.elo };
  });

  const pathData = points.map((p, i) => 
    `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`
  ).join(' ');

  return (
    <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
      {/* Grid lines */}
      <line x1="0" y1="25" x2="100" y2="25" stroke="#374151" strokeWidth="0.2" />
      <line x1="0" y1="50" x2="100" y2="50" stroke="#374151" strokeWidth="0.2" />
      <line x1="0" y1="75" x2="100" y2="75" stroke="#374151" strokeWidth="0.2" />
      
      {/* Area under curve */}
      <path
        d={`${pathData} L 100 100 L 0 100 Z`}
        fill="url(#gradient)"
        opacity="0.3"
      />
      
      {/* Line */}
      <path
        d={pathData}
        fill="none"
        stroke="#a78bfa"
        strokeWidth="0.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      
      {/* Points */}
      {points.map((p, i) => (
        <circle
          key={i}
          cx={p.x}
          cy={p.y}
          r="1"
          fill="#a78bfa"
          className="hover:r-2 transition-all"
        />
      ))}
      
      {/* Gradient definition */}
      <defs>
        <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#a78bfa" stopOpacity="0.8" />
          <stop offset="100%" stopColor="#a78bfa" stopOpacity="0" />
        </linearGradient>
      </defs>
    </svg>
  );
};

export default IQGrowthPanel;
