import React, { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';

const ChessBoard = ({ fen, legalMoves, onMove, gameOver }) => {
  const [selectedSquare, setSelectedSquare] = useState(null);
  const [highlightedMoves, setHighlightedMoves] = useState([]);
  const [captureSquares, setCaptureSquares] = useState([]);
  const [showPromotionDialog, setShowPromotionDialog] = useState(false);
  const [promotionMove, setPromotionMove] = useState(null);
  const [lastMoveSquares, setLastMoveSquares] = useState([]);

  // Parse FEN to get piece positions
  const parseFEN = (fen) => {
    // Return empty board if FEN is not provided
    if (!fen) {
      console.error('No FEN provided to ChessBoard');
      return Array(8).fill().map(() => Array(8).fill(null));
    }
    
    try {
      const fenParts = fen.split(' ');
      const rows = fenParts[0].split('/');
      const board = [];

      for (let i = 0; i < 8; i++) {
        const row = [];
        let col = 0;
        
        for (const char of rows[i]) {
          if (isNaN(char)) {
            row.push(char);
            col++;
          } else {
            const emptySquares = parseInt(char);
            for (let j = 0; j < emptySquares; j++) {
              row.push(null);
              col++;
            }
          }
        }
        board.push(row);
      }

      return board;
    } catch (error) {
      console.error('Error parsing FEN:', error, 'FEN:', fen);
      // Return empty board on error
      return Array(8).fill().map(() => Array(8).fill(null));
    }
  };

  const board = parseFEN(fen);

  const getPieceSymbol = (piece) => {
    const symbols = {
      'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
      'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'
    };
    return symbols[piece] || '';
  };

  const squareToIndex = (square) => {
    const file = square.charCodeAt(0) - 97; // a=0, b=1, ...
    const rank = 8 - parseInt(square[1]); // 8=0, 7=1, ...
    return { rank, file };
  };

  const indexToSquare = (rank, file) => {
    const files = 'abcdefgh';
    const ranks = '87654321';
    return files[file] + ranks[rank];
  };

  const handleSquareClick = (rank, file) => {
    if (gameOver) return;

    const square = indexToSquare(rank, file);
    const piece = board[rank][file];

    if (selectedSquare) {
      // Try to make a move
      const baseMove = selectedSquare + square;
      
      // Check if this is a pawn promotion
      const selectedPiece = board[squareToIndex(selectedSquare).rank][squareToIndex(selectedSquare).file];
      const isPromotion = checkIfPromotion(selectedPiece, selectedSquare, square);
      
      if (isPromotion) {
        // Check if any promotion move is legal
        const promotionMoves = ['q', 'r', 'b', 'n'].map(p => baseMove + p);
        const hasLegalPromotion = promotionMoves.some(m => legalMoves && legalMoves.includes(m));
        
        if (hasLegalPromotion) {
          // Show promotion dialog
          setPromotionMove(baseMove);
          setShowPromotionDialog(true);
          return;
        }
      }
      
      // Check if it's a legal move (including en passant and other special moves)
      // The backend returns all legal moves in UCI format, including en passant
      const isLegalMove = legalMoves && legalMoves.some(move => {
        // Handle regular moves and en passant (which are in format "e5f6")
        // Also handle castling moves (e1g1, e1c1, etc.)
        const moveBase = move.substring(0, 4);
        return moveBase === baseMove;
      });
      
      if (isLegalMove) {
        onMove(baseMove);
        setLastMoveSquares([selectedSquare, square]);
        setSelectedSquare(null);
        setHighlightedMoves([]);
        setCaptureSquares([]);
      } else {
        // Select new piece or deselect
        if (piece) {
          selectPiece(square);
        } else {
          setSelectedSquare(null);
          setHighlightedMoves([]);
          setCaptureSquares([]);
        }
      }
    } else {
      // Select a piece
      if (piece) {
        selectPiece(square);
      }
    }
  };

  const selectPiece = (square) => {
    setSelectedSquare(square);
    
    if (!legalMoves) {
      setHighlightedMoves([]);
      setCaptureSquares([]);
      return;
    }
    
    // Extract all possible destination squares for this piece
    // This handles regular moves, en passant, castling, etc.
    const possibleMoves = [];
    const captures = [];
    
    legalMoves.forEach(move => {
      if (move.startsWith(square)) {
        const destSquare = move.substring(2, 4);
        possibleMoves.push(destSquare);
        
        // Check if it's a capture (has a piece on destination or is en passant)
        const destIndex = squareToIndex(destSquare);
        const targetPiece = board[destIndex.rank][destIndex.file];
        
        // En passant capture: pawn move to empty square that's not straight ahead
        const fromIndex = squareToIndex(square);
        const movingPiece = board[fromIndex.rank][fromIndex.file];
        const isEnPassant = movingPiece && 
                           movingPiece.toLowerCase() === 'p' && 
                           !targetPiece && 
                           Math.abs(destIndex.file - fromIndex.file) === 1;
        
        if (targetPiece || isEnPassant) {
          captures.push(destSquare);
        }
      }
    });
    
    setHighlightedMoves(possibleMoves);
    setCaptureSquares(captures);
  };

  const checkIfPromotion = (piece, fromSquare, toSquare) => {
    if (!piece || (piece.toLowerCase() !== 'p')) return false;
    
    const toRank = toSquare[1];
    // White pawn to rank 8 or black pawn to rank 1
    if ((piece === 'P' && toRank === '8') || (piece === 'p' && toRank === '1')) {
      return true;
    }
    return false;
  };

  const handlePromotion = (promotionPiece) => {
    if (promotionMove) {
      const fullMove = promotionMove + promotionPiece;
      onMove(fullMove);
    }
    setShowPromotionDialog(false);
    setPromotionMove(null);
    setSelectedSquare(null);
    setHighlightedMoves([]);
    setCaptureSquares([]);
  };

  const cancelPromotion = () => {
    setShowPromotionDialog(false);
    setPromotionMove(null);
    setSelectedSquare(null);
    setHighlightedMoves([]);
    setCaptureSquares([]);
  };

  const isSquareHighlighted = (rank, file) => {
    const square = indexToSquare(rank, file);
    return highlightedMoves.includes(square);
  };

  const isSquareCapture = (rank, file) => {
    const square = indexToSquare(rank, file);
    return captureSquares.includes(square);
  };

  const isSquareSelected = (rank, file) => {
    const square = indexToSquare(rank, file);
    return selectedSquare === square;
  };

  const isLastMoveSquare = (rank, file) => {
    const square = indexToSquare(rank, file);
    return lastMoveSquares.includes(square);
  };

  return (
    <Card className="p-6 bg-gradient-to-br from-slate-900 to-slate-800 shadow-2xl border-slate-700" data-testid="chess-board-container">
      <div className="inline-block rounded-2xl overflow-hidden shadow-xl border-4 border-slate-700">
        {board.map((row, rankIdx) => (
          <div key={rankIdx} className="flex">
            {row.map((piece, fileIdx) => {
              const isLight = (rankIdx + fileIdx) % 2 === 0;
              const isSelected = isSquareSelected(rankIdx, fileIdx);
              const isHighlighted = isSquareHighlighted(rankIdx, fileIdx);
              const isCapture = isSquareCapture(rankIdx, fileIdx);
              const isLastMove = isLastMoveSquare(rankIdx, fileIdx);
              
              return (
                <div
                  key={`${rankIdx}-${fileIdx}`}
                  data-testid={`square-${indexToSquare(rankIdx, fileIdx)}`}
                  onClick={() => handleSquareClick(rankIdx, fileIdx)}
                  className={`
                    w-16 h-16 sm:w-20 sm:h-20 flex items-center justify-center text-4xl sm:text-5xl cursor-pointer
                    transition-all duration-300 ease-out hover:brightness-110 relative
                    ${isLight ? 'bg-slate-700' : 'bg-slate-900'}
                    ${isSelected ? 'ring-4 ring-cyan-400 ring-inset shadow-lg shadow-cyan-400/50' : ''}
                    ${isHighlighted && !isCapture ? 'bg-cyan-400/20' : ''}
                    ${isCapture ? 'bg-rose-500/25' : ''}
                    ${isLastMove ? 'bg-yellow-400/20' : ''}
                  `}
                >
                  {/* Coordinate labels */}
                  {fileIdx === 0 && (
                    <div className="absolute left-1 top-1 text-[10px] font-mono text-slate-500 select-none">
                      {8 - rankIdx}
                    </div>
                  )}
                  {rankIdx === 7 && (
                    <div className="absolute right-1 bottom-1 text-[10px] font-mono text-slate-500 select-none">
                      {'abcdefgh'[fileIdx]}
                    </div>
                  )}
                  
                  {piece && (
                    <span 
                      className={`drop-shadow-lg select-none font-bold transition-transform duration-200 hover:scale-110`}
                      style={{
                        color: piece === piece.toUpperCase() ? '#f8f8f8' : '#1a1a1a',
                        textShadow: piece === piece.toUpperCase() 
                          ? '0 0 4px rgba(0,0,0,0.9), 2px 2px 0 rgba(0,0,0,0.8)' 
                          : '0 0 4px rgba(255,255,255,0.9), 2px 2px 0 rgba(255,255,255,0.8)',
                        filter: isSelected ? 'brightness(1.2)' : 'none'
                      }}
                    >
                      {getPieceSymbol(piece)}
                    </span>
                  )}
                  {isHighlighted && !piece && !isCapture && (
                    <div className="w-4 h-4 rounded-full bg-cyan-400 opacity-70 animate-pulse"></div>
                  )}
                  {isCapture && piece && (
                    <div className="absolute inset-0 border-2 border-rose-400 rounded-sm animate-pulse"></div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>
      <div className="mt-4 text-center text-sm text-slate-400">
        {!fen ? (
          <div>
            <span className="text-red-400 font-medium">⚠️ No board data available</span>
            <div className="text-xs mt-1 text-slate-500">Expected FEN but received: {typeof fen}</div>
          </div>
        ) : gameOver ? (
          <span className="text-cyan-400 font-semibold">Game Over</span>
        ) : (
          <span className="text-slate-400">Click a piece to move</span>
        )}
      </div>

      {/* Promotion Dialog */}
      <Dialog open={showPromotionDialog} onOpenChange={setShowPromotionDialog}>
        <DialogContent className="sm:max-w-md bg-slate-800 border-slate-700" data-testid="promotion-dialog">
          <DialogHeader>
            <DialogTitle className="text-slate-100">Choose Promotion Piece</DialogTitle>
            <DialogDescription className="text-slate-400">
              Select which piece you want to promote your pawn to.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <Button
              onClick={() => handlePromotion('q')}
              className="h-24 text-4xl bg-cyan-600 hover:bg-cyan-700 transition-all duration-200 hover:scale-105"
              data-testid="promote-queen"
            >
              ♕
              <span className="text-sm ml-2">Queen</span>
            </Button>
            <Button
              onClick={() => handlePromotion('r')}
              className="h-24 text-4xl bg-emerald-600 hover:bg-emerald-700 transition-all duration-200 hover:scale-105"
              data-testid="promote-rook"
            >
              ♖
              <span className="text-sm ml-2">Rook</span>
            </Button>
            <Button
              onClick={() => handlePromotion('b')}
              className="h-24 text-4xl bg-purple-600 hover:bg-purple-700 transition-all duration-200 hover:scale-105"
              data-testid="promote-bishop"
            >
              ♗
              <span className="text-sm ml-2">Bishop</span>
            </Button>
            <Button
              onClick={() => handlePromotion('n')}
              className="h-24 text-4xl bg-orange-600 hover:bg-orange-700 transition-all duration-200 hover:scale-105"
              data-testid="promote-knight"
            >
              ♘
              <span className="text-sm ml-2">Knight</span>
            </Button>
          </div>
          <Button
            onClick={cancelPromotion}
            variant="outline"
            className="w-full border-slate-600 text-slate-300 hover:bg-slate-700"
            data-testid="cancel-promotion"
          >
            Cancel
          </Button>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default ChessBoard;