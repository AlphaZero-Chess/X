import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { motion } from 'framer-motion';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart } from 'recharts';
import { TrendingUp, Award, Clock, Database } from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const AdaptiveLearningHistory = () => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    fetchHistory();
    
    // Refresh every 30 seconds
    const interval = setInterval(fetchHistory, 30000);
    return () => clearInterval(interval);
  }, []);

  const fetchHistory = async () => {
    try {
      const response = await axios.get(`${API}/train/history-adaptive?limit=20`);
      if (response.data.success) {
        setHistory(response.data.history || []);
      }
    } catch (error) {
      console.error('Error fetching adaptive history:', error);
    } finally {
      setLoading(false);
    }
  };

  // Prepare chart data
  const chartData = history.map((cycle, index) => ({
    cycle: cycle.cycle,
    timestamp: new Date(cycle.timestamp).toLocaleDateString(),
    elo_delta: cycle.elo_delta,
    win_rate: (cycle.win_rate * 100).toFixed(1),
    loss: cycle.training_loss.toFixed(4),
    games: cycle.games_trained
  }));

  // Calculate statistics
  const totalCycles = history.length;
  const totalEloGain = history.reduce((sum, cycle) => sum + cycle.elo_delta, 0);
  const avgEloGain = totalCycles > 0 ? (totalEloGain / totalCycles).toFixed(1) : 0;
  const bestCycle = history.reduce((best, cycle) => 
    cycle.elo_delta > (best?.elo_delta || 0) ? cycle : best, null);

  if (loading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="p-6">
          <p className="text-slate-400 text-center">Loading adaptive learning history...</p>
        </CardContent>
      </Card>
    );
  }

  if (history.length === 0) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="p-6">
          <p className="text-slate-400 text-center">No adaptive training cycles completed yet</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-4"
    >
      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Total Cycles</p>
                <p className="text-2xl font-bold text-white">{totalCycles}</p>
              </div>
              <Clock className="text-cyan-400" size={32} />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Total ELO Gain</p>
                <p className="text-2xl font-bold text-green-400">{totalEloGain > 0 ? '+' : ''}{totalEloGain}</p>
              </div>
              <TrendingUp className="text-green-400" size={32} />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Avg ELO/Cycle</p>
                <p className="text-2xl font-bold text-purple-400">{avgEloGain > 0 ? '+' : ''}{avgEloGain}</p>
              </div>
              <Database className="text-purple-400" size={32} />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border-yellow-500/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Best Cycle</p>
                <p className="text-2xl font-bold text-yellow-400">
                  {bestCycle ? `+${bestCycle.elo_delta}` : 'N/A'}
                </p>
              </div>
              <Award className="text-yellow-400" size={32} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Collapsible Chart Section */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl text-white">Adaptive Training Timeline</CardTitle>
            <button
              onClick={() => setExpanded(!expanded)}
              className="text-cyan-400 hover:text-cyan-300 text-sm font-semibold"
            >
              {expanded ? 'Hide Charts' : 'Show Charts'}
            </button>
          </div>
        </CardHeader>

        {expanded && (
          <CardContent className="space-y-6">
            {/* ELO Delta Chart */}
            <div>
              <h3 className="text-slate-300 font-semibold mb-3">ELO Delta per Cycle</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis 
                    dataKey="cycle" 
                    stroke="#94a3b8"
                    label={{ value: 'Training Cycle', position: 'insideBottom', offset: -5, fill: '#94a3b8' }}
                  />
                  <YAxis 
                    stroke="#94a3b8"
                    label={{ value: 'ELO Delta', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
                    labelStyle={{ color: '#e2e8f0' }}
                  />
                  <Legend />
                  <Bar dataKey="elo_delta" fill="#06b6d4" name="ELO Delta" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Win Rate & Training Loss Combined Chart */}
            <div>
              <h3 className="text-slate-300 font-semibold mb-3">Win Rate & Training Loss</h3>
              <ResponsiveContainer width="100%" height={250}>
                <ComposedChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis 
                    dataKey="cycle" 
                    stroke="#94a3b8"
                    label={{ value: 'Training Cycle', position: 'insideBottom', offset: -5, fill: '#94a3b8' }}
                  />
                  <YAxis 
                    yAxisId="left"
                    stroke="#94a3b8"
                    label={{ value: 'Win Rate (%)', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
                  />
                  <YAxis 
                    yAxisId="right"
                    orientation="right"
                    stroke="#94a3b8"
                    label={{ value: 'Training Loss', angle: 90, position: 'insideRight', fill: '#94a3b8' }}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
                    labelStyle={{ color: '#e2e8f0' }}
                  />
                  <Legend />
                  <Line 
                    yAxisId="left"
                    type="monotone" 
                    dataKey="win_rate" 
                    stroke="#10b981" 
                    strokeWidth={2}
                    name="Win Rate (%)"
                    dot={{ fill: '#10b981', r: 4 }}
                  />
                  <Line 
                    yAxisId="right"
                    type="monotone" 
                    dataKey="loss" 
                    stroke="#ef4444" 
                    strokeWidth={2}
                    name="Training Loss"
                    dot={{ fill: '#ef4444', r: 4 }}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Recent Cycles Table */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-lg text-white">Recent Training Cycles</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left text-slate-400 py-2 px-3">Cycle</th>
                  <th className="text-left text-slate-400 py-2 px-3">Timestamp</th>
                  <th className="text-left text-slate-400 py-2 px-3">Model</th>
                  <th className="text-left text-slate-400 py-2 px-3">ELO Δ</th>
                  <th className="text-left text-slate-400 py-2 px-3">Win Rate</th>
                  <th className="text-left text-slate-400 py-2 px-3">Games</th>
                  <th className="text-left text-slate-400 py-2 px-3">Backend</th>
                </tr>
              </thead>
              <tbody>
                {history.slice(-10).reverse().map((cycle) => (
                  <tr key={cycle.cycle} className="border-b border-slate-700/50 hover:bg-slate-700/30">
                    <td className="py-2 px-3 text-white font-mono">#{cycle.cycle}</td>
                    <td className="py-2 px-3 text-slate-300">
                      {new Date(cycle.timestamp).toLocaleString()}
                    </td>
                    <td className="py-2 px-3 text-cyan-400 font-mono text-xs">
                      {cycle.model_name?.slice(0, 20)}...
                    </td>
                    <td className={`py-2 px-3 font-bold ${cycle.elo_delta > 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {cycle.elo_delta > 0 ? '+' : ''}{cycle.elo_delta}
                    </td>
                    <td className="py-2 px-3 text-slate-300">
                      {(cycle.win_rate * 100).toFixed(1)}%
                    </td>
                    <td className="py-2 px-3 text-slate-300">
                      {cycle.games_trained}
                    </td>
                    <td className="py-2 px-3">
                      <span className={`px-2 py-1 rounded text-xs ${
                        cycle.backend?.includes('TPU') 
                          ? 'bg-purple-500/20 text-purple-400'
                          : 'bg-blue-500/20 text-blue-400'
                      }`}>
                        {cycle.backend || 'N/A'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default AdaptiveLearningHistory;
