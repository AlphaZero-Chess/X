import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Brain, Upload, Archive, Zap, Database } from 'lucide-react';
import { toast } from 'sonner';
import axios from 'axios';
import MemoryUploader from './MemoryUploader';
import MemoryArchive from './MemoryArchive';
import MemoryReplayViewerEnhanced from './MemoryReplayViewerEnhanced';
import MemoryProgress from './MemoryProgress';
import TrainingSummary from './TrainingSummary';
import OfflineIndicator from './OfflineIndicator';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

function MemoryTab() {
  const [trainingStatus, setTrainingStatus] = useState(null);
  const [selectedMemory, setSelectedMemory] = useState(null);
  const [commentary, setCommentary] = useState(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [trainingSummary, setTrainingSummary] = useState(null);
  const [showSummary, setShowSummary] = useState(false);
  const [trainingConfig, setTrainingConfig] = useState({
    training_source: 'combined',
    num_epochs: 5,
    batch_size: 64,
    learning_rate: 0.001,
    save_as_new_model: false,
    new_model_name: ''
  });

  useEffect(() => {
    checkTrainingStatus();
    const interval = setInterval(checkTrainingStatus, 2000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Check if training just completed
    if (trainingStatus && !trainingStatus.active && trainingStatus.progress === 100) {
      // Fetch training summary
      fetchTrainingSummary();
    }
  }, [trainingStatus]);

  const fetchTrainingSummary = async () => {
    try {
      const response = await axios.get(`${API}/memory/training-history?limit=1`);
      if (response.data.success && response.data.sessions.length > 0) {
        const latestSession = response.data.sessions[0];
        setTrainingSummary(latestSession);
        setShowSummary(true);
      }
    } catch (error) {
      console.error('Error fetching training summary:', error);
    }
  };

  const checkTrainingStatus = async () => {
    try {
      const response = await axios.get(`${API}/training/status`);
      setTrainingStatus(response.data);
    } catch (error) {
      console.error('Error checking training status:', error);
    }
  };

  const handleUploadSuccess = (data) => {
    toast.success(`Uploaded ${data.games_stored} games to AlphaZero memory`);
    setRefreshTrigger(prev => prev + 1);
  };

  const handleReplaySelect = (memory, memoryCommentary) => {
    setSelectedMemory(memory);
    setCommentary(memoryCommentary);
  };

  const handleStartMemoryTraining = async () => {
    try {
      const response = await axios.post(`${API}/train/from-memory`, trainingConfig);
      
      if (response.data.success) {
        toast.success('Memory training started!');
      }
    } catch (error) {
      console.error('Error starting memory training:', error);
      toast.error(`Failed to start training: ${error.response?.data?.detail || error.message}`);
    }
  };

  return (
    <div className="space-y-6" data-testid="memory-tab">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold flex items-center gap-3">
            <Database className="h-8 w-8 text-purple-600" />
            AlphaZero Memory Archive
          </h2>
          <p className="text-gray-500 mt-1">
            Upload, replay, and retrain from historical PGN matches
          </p>
        </div>
      </div>

      {/* Offline Mode Indicator */}
      <OfflineIndicator />

      {/* Training Progress (if active) */}
      {trainingStatus?.active && (
        <MemoryProgress trainingStatus={trainingStatus} />
      )}

      <Tabs defaultValue="upload" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="upload" data-testid="upload-tab">
            <Upload className="mr-2 h-4 w-4" />
            Upload
          </TabsTrigger>
          <TabsTrigger value="archive" data-testid="archive-tab">
            <Archive className="mr-2 h-4 w-4" />
            Archive
          </TabsTrigger>
          <TabsTrigger value="train" data-testid="train-tab">
            <Zap className="mr-2 h-4 w-4" />
            Train from Memory
          </TabsTrigger>
        </TabsList>

        {/* Upload Tab */}
        <TabsContent value="upload" className="space-y-4">
          <MemoryUploader onUploadSuccess={handleUploadSuccess} />
          
          <Card>
            <CardHeader>
              <CardTitle>About AlphaZero Memory System</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-gray-700 space-y-2">
              <p>
                The Memory Archive allows AlphaZero to recall and learn from historical matches,
                expanding its strategic understanding through continuous accumulation of experience.
              </p>
              <p className="font-medium">Supported Sources:</p>
              <ul className="list-disc list-inside space-y-1 ml-2">
                <li>AlphaZero vs Stockfish historical games</li>
                <li>Self-play generated PGN files</li>
                <li>Online chess database imports</li>
                <li>Custom training sets</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Archive Tab */}
        <TabsContent value="archive" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div>
              <MemoryArchive 
                onReplaySelect={handleReplaySelect}
                refreshTrigger={refreshTrigger}
              />
            </div>
            <div>
              <MemoryReplayViewerEnhanced 
                memory={selectedMemory}
                commentary={commentary}
              />
            </div>
          </div>
        </TabsContent>

        {/* Train from Memory Tab */}
        <TabsContent value="train" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Neural Recall Training Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Training Source</label>
                  <Select
                    value={trainingConfig.training_source}
                    onValueChange={(value) => 
                      setTrainingConfig({ ...trainingConfig, training_source: value })
                    }
                  >
                    <SelectTrigger data-testid="training-source-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="combined">Combined (PGN + Self-Play)</SelectItem>
                      <SelectItem value="pgn_only">PGN Only</SelectItem>
                      <SelectItem value="selfplay_only">Self-Play Only</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-500 mt-1">
                    {trainingConfig.training_source === 'combined' && 'Combines uploaded PGN memories with existing self-play data'}
                    {trainingConfig.training_source === 'pgn_only' && 'Train exclusively from uploaded PGN files'}
                    {trainingConfig.training_source === 'selfplay_only' && 'Train only from self-play generated data'}
                  </p>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Epochs</label>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={trainingConfig.num_epochs}
                    onChange={(e) => 
                      setTrainingConfig({ ...trainingConfig, num_epochs: parseInt(e.target.value) })
                    }
                    className="w-full px-3 py-2 border rounded-md"
                    data-testid="epochs-input"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Batch Size</label>
                  <Select
                    value={trainingConfig.batch_size.toString()}
                    onValueChange={(value) => 
                      setTrainingConfig({ ...trainingConfig, batch_size: parseInt(value) })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="32">32</SelectItem>
                      <SelectItem value="64">64</SelectItem>
                      <SelectItem value="128">128</SelectItem>
                      <SelectItem value="256">256</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Learning Rate</label>
                  <Select
                    value={trainingConfig.learning_rate.toString()}
                    onValueChange={(value) => 
                      setTrainingConfig({ ...trainingConfig, learning_rate: parseFloat(value) })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0.0001">0.0001</SelectItem>
                      <SelectItem value="0.001">0.001 (Default)</SelectItem>
                      <SelectItem value="0.01">0.01</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Save as New Model Option */}
              <div className="border-t pt-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-medium">Save as New Model</label>
                    <p className="text-xs text-gray-500">Create a new model version instead of updating the active model</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={trainingConfig.save_as_new_model}
                    onChange={(e) => 
                      setTrainingConfig({ ...trainingConfig, save_as_new_model: e.target.checked })
                    }
                    className="rounded"
                  />
                </div>

                {trainingConfig.save_as_new_model && (
                  <div>
                    <label className="text-sm font-medium mb-2 block">New Model Name</label>
                    <input
                      type="text"
                      value={trainingConfig.new_model_name}
                      onChange={(e) => 
                        setTrainingConfig({ ...trainingConfig, new_model_name: e.target.value })
                      }
                      placeholder="e.g., alphazero_memory_v2"
                      className="w-full px-3 py-2 border rounded-md"
                      data-testid="new-model-name-input"
                    />
                  </div>
                )}
              </div>

              <Button
                onClick={handleStartMemoryTraining}
                disabled={trainingStatus?.active}
                className="w-full"
                data-testid="start-memory-training-button"
              >
                <Zap className="mr-2 h-4 w-4" />
                {trainingStatus?.active ? 'Training In Progress...' : 'Start Memory Training'}
              </Button>

              <div className="text-xs text-gray-500 space-y-1">
                <p>• Training will convert PGN games to neural network training positions</p>
                <p>• ETA will be calculated based on memory size and epochs</p>
                <p>• Progress will be streamed in real-time with move-by-move updates</p>
                <p>• Trained model will be automatically evaluated and promoted if superior</p>
              </div>
            </CardContent>
          </Card>

          {/* Training History */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Memory Training Sessions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500">Training history will appear here</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Training Summary Modal */}
      {showSummary && trainingSummary && (
        <TrainingSummary 
          summary={trainingSummary}
          onClose={() => setShowSummary(false)}
        />
      )}
    </div>
  );
}

export default MemoryTab;
