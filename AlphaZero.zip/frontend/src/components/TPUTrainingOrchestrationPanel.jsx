import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Play,
  Square,
  Cpu,
  Database,
  TrendingUp,
  Award,
  Activity,
  Zap,
  CheckCircle2,
  AlertCircle,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from 'recharts';

const TPUTrainingOrchestrationPanel = () => {
  const [cycleStatus, setCycleStatus] = useState(null);
  const [metrics, setMetrics] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isRunning, setIsRunning] = useState(false);

  // Training configuration
  const [config, setConfig] = useState({
    num_selfplay_games: 100,
    num_tpus_selfplay: 100,
    num_tpus_training: 50,
    num_training_epochs: 3,
    num_eval_games: 20,
    batch_size: 256,
    learning_rate: 0.001,
    continuous: false
  });

  // Poll for status updates
  useEffect(() => {
    fetchMetrics();
    fetchHistory();
    
    const interval = setInterval(() => {
      if (isRunning) {
        fetchCycleStatus();
        fetchMetrics();
      }
    }, 2000); // Poll every 2 seconds

    return () => clearInterval(interval);
  }, [isRunning]);

  const fetchCycleStatus = async () => {
    try {
      const response = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/training/cycle/status`);
      const data = await response.json();
      
      if (data.success && data.is_running) {
        setCycleStatus(data);
        setIsRunning(true);
      } else {
        setIsRunning(false);
        setCycleStatus(null);
      }
    } catch (error) {
      console.error('Error fetching cycle status:', error);
    }
  };

  const fetchMetrics = async () => {
    try {
      const response = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/training/metrics`);
      const data = await response.json();
      
      if (data.success) {
        setMetrics(data);
      }
    } catch (error) {
      console.error('Error fetching metrics:', error);
    }
  };

  const fetchHistory = async () => {
    try {
      const response = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/training/cycle/history`);
      const data = await response.json();
      
      if (data.success) {
        setHistory(data.cycles || []);
      }
    } catch (error) {
      console.error('Error fetching history:', error);
    }
  };

  const startTrainingCycle = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/training/cycle/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });

      const data = await response.json();

      if (data.success) {
        toast.success(`Training cycle ${data.cycle_number} started!`);
        setIsRunning(true);
        fetchCycleStatus();
      } else {
        toast.error('Failed to start training cycle');
      }
    } catch (error) {
      console.error('Error starting training cycle:', error);
      toast.error('Error starting training cycle');
    } finally {
      setLoading(false);
    }
  };

  const stopTrainingCycle = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/training/cycle/stop`, {
        method: 'POST'
      });

      const data = await response.json();

      if (data.success) {
        toast.success('Training cycle stopped');
        setIsRunning(false);
      } else {
        toast.error('Failed to stop training cycle');
      }
    } catch (error) {
      console.error('Error stopping training cycle:', error);
      toast.error('Error stopping training cycle');
    } finally {
      setLoading(false);
    }
  };

  const getPhaseIcon = (phase) => {
    switch (phase) {
      case 'self_play': return <Activity className="text-cyan-400" size={20} />;
      case 'training': return <Zap className="text-yellow-400" size={20} />;
      case 'evaluation': return <TrendingUp className="text-purple-400" size={20} />;
      case 'promotion': return <Award className="text-green-400" size={20} />;
      case 'completed': return <CheckCircle2 className="text-green-500" size={20} />;
      case 'failed': return <AlertCircle className="text-red-500" size={20} />;
      default: return <Activity className="text-gray-400" size={20} />;
    }
  };

  const getPhaseLabel = (phase) => {
    const labels = {
      'idle': 'Idle',
      'self_play': 'Self-Play',
      'training': 'Training',
      'evaluation': 'Evaluation',
      'promotion': 'Promotion',
      'completed': 'Completed',
      'failed': 'Failed'
    };
    return labels[phase] || phase;
  };

  const formatNumber = (num) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num?.toFixed(0) || '0';
  };

  return (
    <div className="space-y-6" data-testid="tpu-training-orchestration-panel">
      {/* Control Panel */}
      <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-cyan-500/30">
        <CardHeader>
          <CardTitle className="text-2xl text-white flex items-center gap-3">
            <Cpu className="text-cyan-400" size={32} />
            TPU Training Orchestration
            {isRunning && (
              <Badge className="bg-green-500/20 text-green-400 border-green-500/50">
                <Loader2 className="animate-spin mr-1" size={14} />
                Active
              </Badge>
            )}
          </CardTitle>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Current Model Info */}
          {metrics && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-slate-800/50 rounded-lg p-4 border border-cyan-500/20">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 text-sm">Current Model</span>
                  <Award className="text-cyan-400" size={20} />
                </div>
                <div className="text-2xl font-bold text-white">
                  v{metrics.aggregate_metrics?.current_model_version || 0}
                </div>
                <div className="text-sm text-slate-400">
                  ELO: {metrics.aggregate_metrics?.current_model_elo?.toFixed(0) || '1500'}
                </div>
              </div>

              <div className="bg-slate-800/50 rounded-lg p-4 border border-green-500/20">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 text-sm">Cycles Completed</span>
                  <CheckCircle2 className="text-green-400" size={20} />
                </div>
                <div className="text-2xl font-bold text-white">
                  {metrics.aggregate_metrics?.total_cycles_completed || 0}
                </div>
                <div className="text-sm text-slate-400">
                  {metrics.aggregate_metrics?.total_models_promoted || 0} promoted
                </div>
              </div>

              <div className="bg-slate-800/50 rounded-lg p-4 border border-purple-500/20">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 text-sm">Positions</span>
                  <Database className="text-purple-400" size={20} />
                </div>
                <div className="text-2xl font-bold text-white">
                  {formatNumber(metrics.replay_buffer?.total_size)}
                </div>
                <div className="text-sm text-slate-400">
                  {formatNumber(metrics.aggregate_metrics?.total_positions_generated)} generated
                </div>
              </div>

              <div className="bg-slate-800/50 rounded-lg p-4 border border-yellow-500/20">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 text-sm">TPU Grid</span>
                  <Cpu className="text-yellow-400" size={20} />
                </div>
                <div className="text-2xl font-bold text-white">
                  {metrics.tpu_grid?.busy_tpus || 0}/{metrics.tpu_grid?.total_tpus || 5000}
                </div>
                <div className="text-sm text-slate-400">
                  {metrics.tpu_grid?.utilization_percent?.toFixed(1)}% utilization
                </div>
              </div>
            </div>
          )}

          {/* Current Cycle Status */}
          <AnimatePresence>
            {cycleStatus && cycleStatus.is_running && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-slate-800/50 rounded-lg p-6 border border-cyan-500/30"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <span className="text-lg font-semibold text-white">
                      Cycle {cycleStatus.cycle?.cycle_number}
                    </span>
                    <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/50 flex items-center gap-1">
                      {getPhaseIcon(cycleStatus.cycle?.phase)}
                      {getPhaseLabel(cycleStatus.cycle?.phase)}
                    </Badge>
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {cycleStatus.overall_progress?.toFixed(0)}%
                  </div>
                </div>

                <Progress value={cycleStatus.overall_progress || 0} className="mb-4 h-3" />

                {/* Phase-specific Progress */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Self-Play</span>
                      <span className="text-white">{cycleStatus.cycle?.selfplay_progress || 0}%</span>
                    </div>
                    <Progress value={cycleStatus.cycle?.selfplay_progress || 0} className="h-2" />
                    <div className="text-xs text-slate-500">
                      {cycleStatus.cycle?.positions_generated?.toLocaleString() || 0} positions
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Training</span>
                      <span className="text-white">{cycleStatus.cycle?.training_progress || 0}%</span>
                    </div>
                    <Progress value={cycleStatus.cycle?.training_progress || 0} className="h-2" />
                    <div className="text-xs text-slate-500">
                      Loss: {cycleStatus.cycle?.training_loss?.toFixed(4) || 'N/A'}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Evaluation</span>
                      <span className="text-white">{cycleStatus.cycle?.evaluation_progress || 0}%</span>
                    </div>
                    <Progress value={cycleStatus.cycle?.evaluation_progress || 0} className="h-2" />
                    <div className="text-xs text-slate-500">
                      Win Rate: {(cycleStatus.cycle?.evaluation_win_rate * 100)?.toFixed(1) || 0}%
                    </div>
                  </div>
                </div>

                {/* TPU Workers Activity */}
                {cycleStatus.tpu_grid && (
                  <div className="mt-4 p-4 bg-slate-900/50 rounded-lg">
                    <div className="text-sm text-slate-400 mb-2">TPU Workers Active</div>
                    <div className="flex items-center gap-4">
                      <div className="flex-1">
                        <div className="flex justify-between text-xs text-slate-500 mb-1">
                          <span>{cycleStatus.tpu_grid.active_workers} workers</span>
                          <span>{cycleStatus.tpu_grid.busy_tpus}/{cycleStatus.tpu_grid.total_tpus} TPUs</span>
                        </div>
                        <Progress 
                          value={(cycleStatus.tpu_grid.busy_tpus / cycleStatus.tpu_grid.total_tpus) * 100} 
                          className="h-2" 
                        />
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Control Buttons */}
          <div className="flex gap-4">
            {!isRunning ? (
              <Button
                onClick={startTrainingCycle}
                disabled={loading}
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-semibold px-6 py-3 rounded-lg shadow-lg hover:shadow-cyan-500/50 transition-all disabled:opacity-50"
                data-testid="start-cycle-button"
              >
                {loading ? (
                  <Loader2 className="mr-2 animate-spin" size={20} />
                ) : (
                  <Play className="mr-2" size={20} />
                )}
                Start Training Cycle
              </Button>
            ) : (
              <Button
                onClick={stopTrainingCycle}
                disabled={loading}
                className="bg-gradient-to-r from-red-500 to-orange-600 hover:from-red-600 hover:to-orange-700 text-white font-semibold px-6 py-3 rounded-lg shadow-lg hover:shadow-red-500/50 transition-all disabled:opacity-50"
                data-testid="stop-cycle-button"
              >
                {loading ? (
                  <Loader2 className="mr-2 animate-spin" size={20} />
                ) : (
                  <Square className="mr-2" size={20} />
                )}
                Stop Training
              </Button>
            )}

            {/* Configuration Preview */}
            <div className="flex-1 bg-slate-800/30 rounded-lg px-4 py-2 text-sm text-slate-400">
              <span className="font-semibold text-white">Config:</span>{' '}
              {config.num_selfplay_games} games, {config.num_tpus_selfplay} TPUs self-play, {config.num_training_epochs} epochs
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Training History Chart */}
      {history.length > 0 && (
        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-xl text-white flex items-center gap-2">
              <TrendingUp className="text-purple-400" size={24} />
              Training Progress History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={history}>
                <defs>
                  <linearGradient id="colorElo" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorWinRate" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="cycle_number" stroke="#94a3b8" label={{ value: 'Cycle', fill: '#94a3b8' }} />
                <YAxis stroke="#94a3b8" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                  labelStyle={{ color: '#fff' }}
                />
                <Legend />
                <Area 
                  type="monotone" 
                  dataKey="elo_delta" 
                  stroke="#06b6d4" 
                  fillOpacity={1} 
                  fill="url(#colorElo)" 
                  name="ELO Delta"
                />
                <Area 
                  type="monotone" 
                  dataKey={(d) => d.evaluation_win_rate * 100} 
                  stroke="#22c55e" 
                  fillOpacity={1} 
                  fill="url(#colorWinRate)" 
                  name="Win Rate %"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Recent Cycles Table */}
      {history.length > 0 && (
        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-xl text-white">Recent Training Cycles</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left text-slate-400 py-3 px-4">Cycle</th>
                    <th className="text-left text-slate-400 py-3 px-4">Model</th>
                    <th className="text-right text-slate-400 py-3 px-4">Positions</th>
                    <th className="text-right text-slate-400 py-3 px-4">Loss</th>
                    <th className="text-right text-slate-400 py-3 px-4">Win Rate</th>
                    <th className="text-right text-slate-400 py-3 px-4">ELO Δ</th>
                    <th className="text-center text-slate-400 py-3 px-4">Promoted</th>
                  </tr>
                </thead>
                <tbody>
                  {history.slice(-10).reverse().map((cycle) => (
                    <tr key={cycle.cycle_id} className="border-b border-slate-800 hover:bg-slate-800/30">
                      <td className="py-3 px-4 text-white">{cycle.cycle_number}</td>
                      <td className="py-3 px-4 text-cyan-400">{cycle.model_name}</td>
                      <td className="py-3 px-4 text-right text-slate-300">
                        {cycle.positions_generated?.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-right text-slate-300">
                        {cycle.training_loss?.toFixed(4)}
                      </td>
                      <td className="py-3 px-4 text-right text-slate-300">
                        {(cycle.evaluation_win_rate * 100)?.toFixed(1)}%
                      </td>
                      <td className={`py-3 px-4 text-right font-semibold ${
                        cycle.elo_delta > 0 ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {cycle.elo_delta > 0 ? '+' : ''}{cycle.elo_delta?.toFixed(0)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {cycle.model_promoted ? (
                          <CheckCircle2 className="text-green-500 inline" size={18} />
                        ) : (
                          <span className="text-slate-600">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default TPUTrainingOrchestrationPanel;
