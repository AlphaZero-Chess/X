import React, { useState, useEffect, useRef } from 'react';
import { X, Minimize2, Maximize2, GripVertical } from 'lucide-react';
import { Button } from './ui/button';
import ChessBoard from './ChessBoard';
import { useGame } from '../contexts/GameContext';

const STORAGE_KEY = 'floating-chessboard-state';
const MIN_WIDTH = 250;
const MAX_WIDTH = 800;
const DEFAULT_WIDTH = 500;
const BOARD_ASPECT_RATIO = 1.15; // Slightly taller to account for header/status

const FloatingChessBoard = ({ isVisible, onClose }) => {
  const { gameState, makeMove } = useGame();
  
  // Position and size state
  const [position, setPosition] = useState({ x: null, y: null });
  const [size, setSize] = useState({ width: DEFAULT_WIDTH, height: DEFAULT_WIDTH * BOARD_ASPECT_RATIO });
  const [isMinimized, setIsMinimized] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [resizeStart, setResizeStart] = useState({ x: 0, y: 0, width: 0, height: 0 });
  
  const containerRef = useRef(null);

  // Load saved state from localStorage
  useEffect(() => {
    const savedState = localStorage.getItem(STORAGE_KEY);
    if (savedState) {
      try {
        const parsed = JSON.parse(savedState);
        if (parsed.position) setPosition(parsed.position);
        if (parsed.size) setSize(parsed.size);
        if (parsed.isMinimized !== undefined) setIsMinimized(parsed.isMinimized);
      } catch (error) {
        console.error('Error loading floating board state:', error);
      }
    }
    
    // Set default position to bottom-right if not saved
    if (!savedState || !JSON.parse(savedState).position) {
      setPosition({
        x: window.innerWidth - DEFAULT_WIDTH - 24,
        y: window.innerHeight - (DEFAULT_WIDTH * BOARD_ASPECT_RATIO) - 24
      });
    }
  }, []);

  // Save state to localStorage
  useEffect(() => {
    if (position.x !== null && position.y !== null) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        position,
        size,
        isMinimized
      }));
    }
  }, [position, size, isMinimized]);

  // Drag handlers
  const handleMouseDown = (e) => {
    if (e.target.closest('.no-drag')) return;
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - position.x,
      y: e.clientY - position.y
    });
  };

  const handleMouseMove = (e) => {
    if (isDragging) {
      const newX = Math.max(0, Math.min(window.innerWidth - size.width, e.clientX - dragOffset.x));
      const newY = Math.max(0, Math.min(window.innerHeight - size.height, e.clientY - dragOffset.y));
      setPosition({ x: newX, y: newY });
    }
    
    if (isResizing) {
      const deltaX = e.clientX - resizeStart.x;
      const newWidth = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, resizeStart.width + deltaX));
      const newHeight = newWidth * BOARD_ASPECT_RATIO;
      setSize({ width: newWidth, height: newHeight });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setIsResizing(false);
  };

  useEffect(() => {
    if (isDragging || isResizing) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, isResizing, dragOffset, resizeStart, position, size]);

  // Resize handler
  const handleResizeStart = (e) => {
    e.stopPropagation();
    setIsResizing(true);
    setResizeStart({
      x: e.clientX,
      y: e.clientY,
      width: size.width,
      height: size.height
    });
  };

  // Toggle minimize
  const toggleMinimize = () => {
    setIsMinimized(!isMinimized);
  };

  if (!isVisible) return null;

  return (
    <div
      ref={containerRef}
      data-testid="floating-chessboard"
      className={`fixed rounded-2xl shadow-2xl backdrop-blur-md border-2 border-slate-700/80 transition-all duration-300 ${
        isDragging ? 'cursor-grabbing' : 'cursor-grab'
      } ${isMinimized ? 'bg-slate-800/98' : 'bg-slate-900/95'}`}
      style={{
        left: position.x !== null ? `${position.x}px` : 'auto',
        top: position.y !== null ? `${position.y}px` : 'auto',
        right: position.x === null ? '24px' : 'auto',
        bottom: position.y === null ? '24px' : 'auto',
        width: isMinimized ? '200px' : `${size.width}px`,
        height: isMinimized ? 'auto' : `${size.height}px`,
        zIndex: 50,
        userSelect: isDragging || isResizing ? 'none' : 'auto',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5), 0 0 30px rgba(6, 182, 212, 0.1)'
      }}
    >
      {/* Header Bar */}
      <div
        className="flex items-center justify-between px-4 py-3 border-b border-slate-700/50 bg-gradient-to-r from-slate-900 to-slate-800 rounded-t-2xl"
        onMouseDown={handleMouseDown}
        data-testid="floating-board-header"
      >
        <div className="flex items-center gap-2">
          <span className="text-2xl select-none">♟️</span>
          <span className="text-sm font-semibold text-slate-200">AlphaZero Board</span>
        </div>
        
        <div className="flex items-center gap-1 no-drag">
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleMinimize}
            className="h-7 w-7 p-0 hover:bg-cyan-600/30 text-slate-400 hover:text-cyan-300 transition-all duration-200"
            data-testid="minimize-floating-board"
            title={isMinimized ? 'Maximize' : 'Minimize'}
          >
            {isMinimized ? <Maximize2 size={16} /> : <Minimize2 size={16} />}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-7 w-7 p-0 hover:bg-red-600/50 text-slate-400 hover:text-red-300 transition-all duration-200"
            data-testid="close-floating-board"
            title="Close"
          >
            <X size={16} />
          </Button>
        </div>
      </div>

      {/* Board Content */}
      {!isMinimized && (
        <div className="p-4 overflow-hidden" data-testid="floating-board-content">
          {gameState ? (
            <div className="flex flex-col items-center">
              <div 
                className="inline-block"
                style={{
                  transform: `scale(${Math.min(1, (size.width - 32) / 520)})`,
                  transformOrigin: 'top center',
                  transition: 'transform 200ms ease-out'
                }}
              >
                <ChessBoard
                  fen={gameState.fen}
                  legalMoves={gameState.legal_moves || []}
                  onMove={makeMove}
                  gameOver={gameState.is_game_over}
                />
              </div>
              
              {/* Compact Status */}
              <div className="mt-3 text-center">
                <div className="text-xs text-slate-400">
                  {gameState.is_game_over ? (
                    <span className="text-cyan-400 font-medium">Game Over: {gameState.result}</span>
                  ) : (
                    <span>Moves: {gameState.history?.length || 0} | Legal: {gameState.legal_moves?.length || 0}</span>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="text-4xl mb-2">♟️</div>
              <p className="text-sm text-slate-400">No active game</p>
              <p className="text-xs text-slate-500 mt-1">Start a game in the Game tab</p>
            </div>
          )}
        </div>
      )}

      {/* Minimized State */}
      {isMinimized && (
        <div className="px-4 py-2 text-center" data-testid="floating-board-minimized">
          <p className="text-xs text-slate-400">
            {gameState ? `Move ${gameState.history?.length || 0}` : 'No game'}
          </p>
        </div>
      )}

      {/* Resize Handle */}
      {!isMinimized && (
        <div
          className="absolute bottom-0 right-0 w-8 h-8 cursor-nwse-resize no-drag group"
          onMouseDown={handleResizeStart}
          data-testid="resize-handle"
        >
          <div className="absolute bottom-1 right-1 text-slate-600 group-hover:text-cyan-400 transition-colors duration-200">
            <GripVertical size={18} className="transform rotate-45" />
          </div>
        </div>
      )}
    </div>
  );
};

export default FloatingChessBoard;