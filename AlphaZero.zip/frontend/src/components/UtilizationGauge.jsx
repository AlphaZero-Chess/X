import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from 'recharts';
import { Activity } from 'lucide-react';

const UtilizationGauge = ({ utilization }) => {
  const utilizationPercent = (utilization * 100).toFixed(1);
  const remaining = 100 - utilization * 100;
  
  const data = [
    { name: 'Utilized', value: utilization * 100 },
    { name: 'Available', value: remaining }
  ];
  
  // Color based on utilization level
  const getColor = () => {
    if (utilization > 0.9) return '#ef4444'; // red
    if (utilization > 0.7) return '#f59e0b'; // orange
    if (utilization > 0.5) return '#eab308'; // yellow
    return '#10b981'; // green
  };
  
  const COLORS = [getColor(), '#1e293b'];
  
  return (
    <Card className="bg-slate-800/50 border-slate-700" data-testid="utilization-gauge">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Activity size={20} />
          TPU Utilization
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={200}>
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              startAngle={180}
              endAngle={0}
              innerRadius={60}
              outerRadius={80}
              paddingAngle={0}
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index]} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        
        <div className="text-center -mt-8">
          <div className="text-4xl font-bold" style={{ color: getColor() }}>
            {utilizationPercent}%
          </div>
          <div className="text-slate-400 text-sm mt-1">Global Utilization</div>
        </div>
      </CardContent>
    </Card>
  );
};

export default UtilizationGauge;