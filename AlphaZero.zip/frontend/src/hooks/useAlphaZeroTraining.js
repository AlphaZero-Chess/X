import { useState, useEffect, useCallback, useRef } from 'react';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

/**
 * Custom hook for AlphaZero training state management
 * Handles polling, status updates, and training lifecycle
 */
export const useAlphaZeroTraining = () => {
  const [status, setStatus] = useState({
    active: false,
    games_completed: 0,
    max_games: 0,
    progress_pct: 0,
    current_elo: 1500,
    games_per_sec: 0,
    elapsed_seconds: 0,
    eta_seconds: 0,
    message: 'No training session active',
    device_mode: 'Unknown',
    models_promoted: 0,
    last_checkpoint: null
  });
  
  const [metrics, setMetrics] = useState({
    success: true,
    metrics: [],
    summary: {}
  });
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const pollIntervalRef = useRef(null);
  const previousEloRef = useRef(1500);
  
  // Fetch current training status
  const fetchStatus = useCallback(async () => {
    try {
      const response = await axios.get(`${API}/train/status-alphazero`);
      const newStatus = response.data;
      
      // Check for ELO milestone
      if (newStatus.current_elo && previousEloRef.current) {
        const eloDelta = newStatus.current_elo - previousEloRef.current;
        if (eloDelta >= 50) {
          toast.success(`🎯 New ELO Milestone: ${Math.round(newStatus.current_elo)}`, {
            description: `+${Math.round(eloDelta)} ELO gained!`
          });
        }
      }
      previousEloRef.current = newStatus.current_elo;
      
      setStatus(newStatus);
      setError(null);
    } catch (err) {
      console.error('Error fetching status:', err);
      setError(err.message);
    }
  }, []);
  
  // Fetch training metrics history
  const fetchMetrics = useCallback(async () => {
    try {
      const response = await axios.get(`${API}/train/metrics-alphazero`);
      setMetrics(response.data);
    } catch (err) {
      console.error('Error fetching metrics:', err);
    }
  }, []);
  
  // Start training
  const startTraining = useCallback(async (config) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await axios.post(`${API}/train/start-alphazero`, config);
      
      if (response.data.success) {
        toast.success('🚀 Training Started!', {
          description: `Target: ${config.max_games.toLocaleString()} games / ${config.max_hours}h`
        });
        
        // Start polling
        startPolling();
        
        // Fetch initial status
        await fetchStatus();
      }
      
      return response.data;
    } catch (err) {
      const errorMsg = err.response?.data?.detail || err.message;
      setError(errorMsg);
      toast.error('Failed to start training', {
        description: errorMsg
      });
      throw err;
    } finally {
      setLoading(false);
    }
  }, [fetchStatus]);
  
  // Stop training
  const stopTraining = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await axios.post(`${API}/train/stop-alphazero`);
      
      if (response.data.success) {
        toast.info('⏸️ Training Stopped', {
          description: 'Saving checkpoint...'
        });
        
        // Stop polling
        stopPolling();
        
        // Fetch final status
        await fetchStatus();
      }
      
      return response.data;
    } catch (err) {
      const errorMsg = err.response?.data?.detail || err.message;
      setError(errorMsg);
      toast.error('Failed to stop training', {
        description: errorMsg
      });
      throw err;
    } finally {
      setLoading(false);
    }
  }, [fetchStatus]);
  
  // Export training logs
  const exportLogs = useCallback(async (format = 'json') => {
    try {
      const response = await axios.get(`${API}/train/metrics-alphazero`);
      const data = response.data;
      
      if (format === 'json') {
        // Download as JSON
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `alphazero_training_${Date.now()}.json`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      } else if (format === 'csv') {
        // Convert to CSV
        const metrics = data.metrics || [];
        if (metrics.length === 0) {
          toast.warning('No metrics to export');
          return;
        }
        
        const headers = Object.keys(metrics[0]);
        const csvRows = [
          headers.join(','),
          ...metrics.map(row => headers.map(h => JSON.stringify(row[h] || '')).join(','))
        ];
        
        const csv = csvRows.join('\n');
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `alphazero_training_${Date.now()}.csv`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
      
      toast.success(`Logs exported as ${format.toUpperCase()}`);
    } catch (err) {
      toast.error('Failed to export logs', {
        description: err.message
      });
    }
  }, []);
  
  // Start polling (every 5 seconds)
  const startPolling = useCallback(() => {
    if (pollIntervalRef.current) return; // Already polling
    
    pollIntervalRef.current = setInterval(() => {
      fetchStatus();
      fetchMetrics();
    }, 5000); // 5 seconds
  }, [fetchStatus, fetchMetrics]);
  
  // Stop polling
  const stopPolling = useCallback(() => {
    if (pollIntervalRef.current) {
      clearInterval(pollIntervalRef.current);
      pollIntervalRef.current = null;
    }
  }, []);
  
  // Initial fetch and setup polling
  useEffect(() => {
    fetchStatus();
    fetchMetrics();
    
    // Check if training is active and start polling
    const checkAndStartPolling = async () => {
      try {
        const response = await axios.get(`${API}/train/status-alphazero`);
        if (response.data.active) {
          startPolling();
        }
      } catch (err) {
        console.error('Error checking status:', err);
      }
    };
    
    checkAndStartPolling();
    
    // Cleanup on unmount
    return () => {
      stopPolling();
    };
  }, [fetchStatus, fetchMetrics, startPolling, stopPolling]);
  
  return {
    status,
    metrics,
    loading,
    error,
    startTraining,
    stopTraining,
    exportLogs,
    refreshStatus: fetchStatus,
    refreshMetrics: fetchMetrics
  };
};
