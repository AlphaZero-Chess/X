import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  LineChart,
  Line,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { toast } from 'sonner';
import { Play, Square, Check, TrendingUp, Zap, Clock, Target } from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

const HyperparamOptimization = () => {
  const [hpoStatus, setHpoStatus] = useState(null);
  const [trialHistory, setTrialHistory] = useState([]);
  const [bestParams, setBestParams] = useState(null);
  const [insights, setInsights] = useState(null);
  const [loading, setLoading] = useState(false);
  const [config, setConfig] = useState({
    max_trials: 25,
    evaluation_games: 10,
    num_workers: 4,
    resume: false
  });

  // Poll status
  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 3000);
    return () => clearInterval(interval);
  }, []);

  // Fetch trial history when status changes
  useEffect(() => {
    if (hpoStatus?.total_trials_completed > 0) {
      fetchTrialHistory();
      fetchBestParams();
      fetchInsights();
    }
  }, [hpoStatus?.total_trials_completed]);

  const fetchStatus = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/train/status-hpo`);
      setHpoStatus(response.data);
    } catch (error) {
      console.error('Error fetching HPO status:', error);
    }
  };

  const fetchTrialHistory = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/train/hpo-history?limit=50`);
      if (response.data.success) {
        setTrialHistory(response.data.trials);
      }
    } catch (error) {
      console.error('Error fetching trial history:', error);
    }
  };

  const fetchBestParams = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/train/best-params`);
      if (response.data.success) {
        setBestParams(response.data);
      }
    } catch (error) {
      console.error('Error fetching best params:', error);
    }
  };

  const fetchInsights = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/train/hpo-insights`);
      if (response.data.success) {
        setInsights(response.data.insights);
      }
    } catch (error) {
      console.error('Error fetching insights:', error);
    }
  };

  const startHPO = async () => {
    setLoading(true);
    try {
      const response = await axios.post(`${BACKEND_URL}/api/train/start-hpo`, config);
      if (response.data.success) {
        toast.success('🚀 Hyperparameter optimization started!');
        fetchStatus();
      }
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to start HPO');
    } finally {
      setLoading(false);
    }
  };

  const stopHPO = async () => {
    setLoading(true);
    try {
      const response = await axios.post(`${BACKEND_URL}/api/train/stop-hpo`);
      if (response.data.success) {
        toast.info('⏸️ HPO stop requested');
        fetchStatus();
      }
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to stop HPO');
    } finally {
      setLoading(false);
    }
  };

  const applyBestParams = async () => {
    setLoading(true);
    try {
      const response = await axios.post(`${BACKEND_URL}/api/train/apply-best-params`);
      if (response.data.success) {
        toast.success('✅ Best parameters applied to configuration!', {
          description: 'Future training will use these optimal settings'
        });
      }
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to apply parameters');
    } finally {
      setLoading(false);
    }
  };

  // Prepare chart data
  const eloTrendData = trialHistory.map(trial => ({
    trial: trial.trial_number,
    elo_gain: trial.metrics.elo_gain,
    objective: trial.metrics.objective_value
  }));

  const lossVsLRData = trialHistory.map(trial => ({
    learning_rate: trial.parameters.learning_rate,
    loss: trial.metrics.loss
  }));

  const timeVsBatchData = trialHistory.map(trial => ({
    batch_size: trial.parameters.batch_size,
    time: trial.metrics.training_time / 60
  }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-gray-800/50 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
                <Zap className="w-8 h-8 text-purple-400" />
                Hyperparameter Optimization
              </h1>
              <p className="text-gray-400">
                Intelligent parameter tuning with Bayesian optimization and meta-learning
              </p>
            </div>
            
            {hpoStatus?.active && (
              <div className="flex items-center gap-3 bg-green-500/20 px-4 py-2 rounded-lg border border-green-500/30">
                <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse" />
                <span className="text-green-400 font-medium">Optimizing...</span>
              </div>
            )}
          </div>
        </div>

        {/* Control Panel */}
        <div className="bg-gray-800/50 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6">
          <h2 className="text-xl font-bold text-white mb-4">Configuration & Control</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Max Trials
              </label>
              <input
                type="number"
                value={config.max_trials}
                onChange={(e) => setConfig({ ...config, max_trials: parseInt(e.target.value) })}
                disabled={hpoStatus?.active}
                min="5"
                max="100"
                className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Evaluation Games
              </label>
              <input
                type="number"
                value={config.evaluation_games}
                onChange={(e) => setConfig({ ...config, evaluation_games: parseInt(e.target.value) })}
                disabled={hpoStatus?.active}
                min="5"
                max="20"
                className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Parallel Workers
              </label>
              <input
                type="number"
                value={config.num_workers}
                onChange={(e) => setConfig({ ...config, num_workers: parseInt(e.target.value) })}
                disabled={hpoStatus?.active}
                min="2"
                max="8"
                className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent disabled:opacity-50"
              />
            </div>

            <div className="flex items-end">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.resume}
                  onChange={(e) => setConfig({ ...config, resume: e.target.checked })}
                  disabled={hpoStatus?.active}
                  className="w-4 h-4 text-purple-500 bg-gray-700 border-gray-600 rounded focus:ring-purple-500"
                />
                <span className="text-sm font-medium text-gray-300">Resume Previous</span>
              </label>
            </div>
          </div>

          <div className="flex gap-3">
            {!hpoStatus?.active ? (
              <button
                onClick={startHPO}
                disabled={loading}
                className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-semibold rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all disabled:opacity-50"
              >
                <Play className="w-5 h-5" />
                Start Optimization
              </button>
            ) : (
              <button
                onClick={stopHPO}
                disabled={loading}
                className="flex items-center gap-2 px-6 py-3 bg-red-500 text-white font-semibold rounded-lg hover:bg-red-600 transition-all disabled:opacity-50"
              >
                <Square className="w-5 h-5" />
                Stop Optimization
              </button>
            )}

            {bestParams?.best_params && (
              <button
                onClick={applyBestParams}
                disabled={loading || hpoStatus?.active}
                className="flex items-center gap-2 px-6 py-3 bg-green-500 text-white font-semibold rounded-lg hover:bg-green-600 transition-all disabled:opacity-50"
              >
                <Check className="w-5 h-5" />
                Apply Best Parameters
              </button>
            )}
          </div>
        </div>

        {/* Progress Stats */}
        {hpoStatus && hpoStatus.total_trials_completed > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-gray-800/50 backdrop-blur-sm border border-blue-500/30 rounded-xl p-6">
              <div className="flex items-center justify-between mb-2">
                <Target className="w-6 h-6 text-blue-400" />
                <span className="text-2xl font-bold text-blue-400">
                  {hpoStatus.current_trial}/{hpoStatus.max_trials}
                </span>
              </div>
              <p className="text-sm text-gray-400">Trials Completed</p>
              <div className="mt-2 w-full bg-gray-700 rounded-full h-2">
                <div
                  className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${hpoStatus.progress_percent}%` }}
                />
              </div>
            </div>

            {hpoStatus.best_trial && (
              <>
                <div className="bg-gray-800/50 backdrop-blur-sm border border-green-500/30 rounded-xl p-6">
                  <div className="flex items-center justify-between mb-2">
                    <TrendingUp className="w-6 h-6 text-green-400" />
                    <span className="text-2xl font-bold text-green-400">
                      {hpoStatus.best_trial.elo_gain > 0 ? '+' : ''}
                      {hpoStatus.best_trial.elo_gain.toFixed(1)}
                    </span>
                  </div>
                  <p className="text-sm text-gray-400">Best ELO Gain</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Trial #{hpoStatus.best_trial.trial_number}
                  </p>
                </div>

                <div className="bg-gray-800/50 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6">
                  <div className="flex items-center justify-between mb-2">
                    <Target className="w-6 h-6 text-purple-400" />
                    <span className="text-2xl font-bold text-purple-400">
                      {(hpoStatus.best_trial.win_rate * 100).toFixed(1)}%
                    </span>
                  </div>
                  <p className="text-sm text-gray-400">Best Win Rate</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Loss: {hpoStatus.best_trial.loss.toFixed(4)}
                  </p>
                </div>

                <div className="bg-gray-800/50 backdrop-blur-sm border border-yellow-500/30 rounded-xl p-6">
                  <div className="flex items-center justify-between mb-2">
                    <Clock className="w-6 h-6 text-yellow-400" />
                    <span className="text-2xl font-bold text-yellow-400">
                      {hpoStatus.best_trial.training_time_min.toFixed(1)}
                    </span>
                  </div>
                  <p className="text-sm text-gray-400">Minutes / Trial</p>
                  {hpoStatus.eta_minutes > 0 && (
                    <p className="text-xs text-gray-500 mt-1">
                      ETA: {hpoStatus.eta_minutes}min
                    </p>
                  )}
                </div>
              </>
            )}
          </div>
        )}

        {/* Best Parameters Display */}
        {bestParams?.best_params && (
          <div className="bg-gray-800/50 backdrop-blur-sm border border-green-500/30 rounded-xl p-6">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Check className="w-6 h-6 text-green-400" />
              Best Configuration Found
            </h2>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {Object.entries(bestParams.best_params).map(([key, value]) => (
                <div key={key} className="bg-gray-700/50 rounded-lg p-4">
                  <p className="text-xs text-gray-400 mb-1 uppercase tracking-wide">
                    {key.replace(/_/g, ' ')}
                  </p>
                  <p className="text-lg font-bold text-white">
                    {typeof value === 'number' ? value.toFixed(4) : value}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Charts */}
        {trialHistory.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* ELO Gain vs Trial */}
            <div className="bg-gray-800/50 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-4">ELO Gain vs Trial Number</h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={eloTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="trial" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1F2937',
                      border: '1px solid #374151',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="elo_gain"
                    stroke="#10B981"
                    strokeWidth={2}
                    dot={{ fill: '#10B981', r: 4 }}
                    name="ELO Gain"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Loss vs Learning Rate */}
            <div className="bg-gray-800/50 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-4">Loss vs Learning Rate</h3>
              <ResponsiveContainer width="100%" height={300}>
                <ScatterChart>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis
                    type="number"
                    dataKey="learning_rate"
                    name="Learning Rate"
                    stroke="#9CA3AF"
                    scale="log"
                    domain={['auto', 'auto']}
                  />
                  <YAxis
                    type="number"
                    dataKey="loss"
                    name="Loss"
                    stroke="#9CA3AF"
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1F2937',
                      border: '1px solid #374151',
                      borderRadius: '8px'
                    }}
                  />
                  <Scatter
                    data={lossVsLRData}
                    fill="#8B5CF6"
                    name="Trials"
                  />
                </ScatterChart>
              </ResponsiveContainer>
            </div>

            {/* Training Time vs Batch Size */}
            <div className="bg-gray-800/50 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-4">Training Time vs Batch Size</h3>
              <ResponsiveContainer width="100%" height={300}>
                <ScatterChart>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis
                    type="number"
                    dataKey="batch_size"
                    name="Batch Size"
                    stroke="#9CA3AF"
                  />
                  <YAxis
                    type="number"
                    dataKey="time"
                    name="Time (min)"
                    stroke="#9CA3AF"
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1F2937',
                      border: '1px solid #374151',
                      borderRadius: '8px'
                    }}
                  />
                  <Scatter
                    data={timeVsBatchData}
                    fill="#F59E0B"
                    name="Trials"
                  />
                </ScatterChart>
              </ResponsiveContainer>
            </div>

            {/* Meta-Learning Correlations */}
            {insights?.correlations && Object.keys(insights.correlations).length > 0 && (
              <div className="bg-gray-800/50 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6">
                <h3 className="text-lg font-bold text-white mb-4">
                  Parameter-Performance Correlations
                </h3>
                <div className="space-y-3">
                  {Object.entries(insights.correlations).map(([param, corrs]) => (
                    <div key={param} className="bg-gray-700/50 rounded-lg p-3">
                      <p className="text-sm font-medium text-gray-300 mb-2">
                        {param.replace(/_/g, ' ').toUpperCase()}
                      </p>
                      <div className="grid grid-cols-3 gap-2 text-xs">
                        <div>
                          <span className="text-gray-400">ELO: </span>
                          <span
                            className={
                              corrs.elo_gain > 0 ? 'text-green-400' : 'text-red-400'
                            }
                          >
                            {corrs.elo_gain?.toFixed(3) || '0.000'}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-400">Loss: </span>
                          <span
                            className={
                              corrs.loss < 0 ? 'text-green-400' : 'text-red-400'
                            }
                          >
                            {corrs.loss?.toFixed(3) || '0.000'}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-400">Time: </span>
                          <span
                            className={
                              corrs.training_time < 0 ? 'text-green-400' : 'text-red-400'
                            }
                          >
                            {corrs.training_time?.toFixed(3) || '0.000'}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Trial History Table */}
        {trialHistory.length > 0 && (
          <div className="bg-gray-800/50 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6">
            <h2 className="text-xl font-bold text-white mb-4">Trial History</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="text-left py-3 px-4 text-gray-300 font-medium">Trial #</th>
                    <th className="text-left py-3 px-4 text-gray-300 font-medium">ELO Gain</th>
                    <th className="text-left py-3 px-4 text-gray-300 font-medium">Win Rate</th>
                    <th className="text-left py-3 px-4 text-gray-300 font-medium">Loss</th>
                    <th className="text-left py-3 px-4 text-gray-300 font-medium">LR</th>
                    <th className="text-left py-3 px-4 text-gray-300 font-medium">MCTS</th>
                    <th className="text-left py-3 px-4 text-gray-300 font-medium">Batch</th>
                    <th className="text-left py-3 px-4 text-gray-300 font-medium">Time (min)</th>
                  </tr>
                </thead>
                <tbody>
                  {trialHistory.slice().reverse().map((trial) => (
                    <tr
                      key={trial.trial_number}
                      className="border-b border-gray-700/50 hover:bg-gray-700/30 transition-colors"
                    >
                      <td className="py-3 px-4 text-white font-medium">
                        #{trial.trial_number}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={
                            trial.metrics.elo_gain > 0
                              ? 'text-green-400 font-medium'
                              : 'text-red-400 font-medium'
                          }
                        >
                          {trial.metrics.elo_gain > 0 ? '+' : ''}
                          {trial.metrics.elo_gain.toFixed(1)}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-gray-300">
                        {(trial.metrics.win_rate * 100).toFixed(1)}%
                      </td>
                      <td className="py-3 px-4 text-gray-300">
                        {trial.metrics.loss.toFixed(4)}
                      </td>
                      <td className="py-3 px-4 text-gray-300">
                        {trial.parameters.learning_rate.toExponential(2)}
                      </td>
                      <td className="py-3 px-4 text-gray-300">
                        {trial.parameters.mcts_simulations}
                      </td>
                      <td className="py-3 px-4 text-gray-300">
                        {trial.parameters.batch_size}
                      </td>
                      <td className="py-3 px-4 text-gray-300">
                        {(trial.metrics.training_time / 60).toFixed(1)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default HyperparamOptimization;
