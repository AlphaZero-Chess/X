import React from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, CheckCircle2 } from 'lucide-react';
import AlphaZeroControlPanel from '../components/AlphaZeroControlPanel';
import AlphaZeroTrainingStatus from '../components/AlphaZeroTrainingStatus';
import AlphaZeroCharts from '../components/AlphaZeroCharts';
import { useAlphaZeroTraining } from '../hooks/useAlphaZeroTraining';

const AlphaZeroDashboard = () => {
  const {
    status,
    metrics,
    loading,
    error,
    startTraining,
    stopTraining,
    exportLogs
  } = useAlphaZeroTraining();
  
  return (
    <div className="space-y-6" data-testid="alphazero-dashboard">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center"
      >
        <h1 className="text-4xl font-bold text-white mb-2">
          AlphaZero TPU Control Panel
        </h1>
        <p className="text-slate-400 text-lg">
          Massive-Scale Self-Play Training • 44M Games • 9 Hours
        </p>
      </motion.div>
      
      {/* Error Alert */}
      {error && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-red-500/10 border border-red-500/50 rounded-lg p-4 flex items-center gap-3"
        >
          <AlertCircle className="text-red-400" size={24} />
          <div>
            <p className="text-red-400 font-semibold">Connection Error</p>
            <p className="text-slate-300 text-sm">{error}</p>
          </div>
        </motion.div>
      )}
      
      {/* Backend Connection Status */}
      {!error && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-green-500/10 border border-green-500/50 rounded-lg p-3 flex items-center justify-center gap-2"
        >
          <CheckCircle2 className="text-green-400" size={20} />
          <p className="text-green-400 font-semibold">Backend Connected</p>
        </motion.div>
      )}
      
      {/* Control Panel */}
      <AlphaZeroControlPanel
        status={status}
        loading={loading}
        onStartTraining={startTraining}
        onStopTraining={stopTraining}
        onExportLogs={exportLogs}
      />
      
      {/* Training Status */}
      <AlphaZeroTrainingStatus status={status} />
      
      {/* Charts */}
      <AlphaZeroCharts metrics={metrics} />
      
      {/* Footer Info */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="text-center text-slate-500 text-sm py-4"
      >
        <p>
          Status updates every 5 seconds • Checkpoint saved every 30 minutes
        </p>
      </motion.div>
    </div>
  );
};

export default AlphaZeroDashboard;
