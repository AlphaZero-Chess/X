import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { toast } from 'sonner';
import { 
  Play, 
  Square, 
  RefreshCw, 
  TrendingUp, 
  Layers, 
  Zap, 
  Award,
  GitBranch,
  Activity,
  BarChart3
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const NeuralArchitectureSearch = () => {
  // State management
  const [nasStatus, setNasStatus] = useState({
    active: false,
    current_generation: 0,
    max_generations: 0,
    progress_percent: 0,
    best_elo: null,
    best_genome_id: null
  });
  
  const [config, setConfig] = useState({
    population_size: 12,
    max_generations: 10,
    mutation_rate: 0.25,
    evaluation_games: 10,
    auto_trigger: false,
    resume: false
  });
  
  const [history, setHistory] = useState([]);
  const [bestArchitecture, setBestArchitecture] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch NAS status
  const fetchStatus = useCallback(async () => {
    try {
      const response = await fetch(`${API}/train/status-nas`);
      const data = await response.json();
      
      if (data.success) {
        setNasStatus(data);
      }
    } catch (error) {
      console.error('Error fetching NAS status:', error);
    }
  }, []);

  // Fetch NAS history
  const fetchHistory = useCallback(async () => {
    try {
      const response = await fetch(`${API}/train/nas-history?limit=20`);
      const data = await response.json();
      
      if (data.success) {
        setHistory(data.history);
      }
    } catch (error) {
      console.error('Error fetching NAS history:', error);
    }
  }, []);

  // Fetch best architecture
  const fetchBestArchitecture = useCallback(async () => {
    try {
      const response = await fetch(`${API}/train/best-architecture`);
      const data = await response.json();
      
      if (data.success && data.best_architecture) {
        setBestArchitecture(data.best_architecture);
      }
    } catch (error) {
      console.error('Error fetching best architecture:', error);
    }
  }, []);

  // Poll for updates when NAS is active
  useEffect(() => {
    fetchStatus();
    fetchHistory();
    fetchBestArchitecture();

    const interval = setInterval(() => {
      fetchStatus();
      if (nasStatus.active) {
        fetchHistory();
      }
    }, 3000); // Poll every 3 seconds

    return () => clearInterval(interval);
  }, [fetchStatus, fetchHistory, fetchBestArchitecture, nasStatus.active]);

  // Start NAS
  const handleStartNAS = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`${API}/train/start-nas`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      
      const data = await response.json();
      
      if (data.success) {
        toast.success('🧬 Neural Architecture Search started!');
        fetchStatus();
      } else {
        toast.error('Failed to start NAS');
      }
    } catch (error) {
      console.error('Error starting NAS:', error);
      toast.error('Error starting NAS');
    } finally {
      setIsLoading(false);
    }
  };

  // Stop NAS
  const handleStopNAS = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`${API}/train/stop-nas`, {
        method: 'POST'
      });
      
      const data = await response.json();
      
      if (data.success) {
        toast.success('NAS stopped');
        fetchStatus();
      } else {
        toast.error('Failed to stop NAS');
      }
    } catch (error) {
      console.error('Error stopping NAS:', error);
      toast.error('Error stopping NAS');
    } finally {
      setIsLoading(false);
    }
  };

  // Promote architecture
  const handlePromoteArchitecture = async () => {
    if (!nasStatus.best_genome_id) {
      toast.error('No architecture to promote');
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(`${API}/train/promote-nas-architecture?genome_id=${nasStatus.best_genome_id}`, {
        method: 'POST'
      });
      
      const data = await response.json();
      
      if (data.success) {
        toast.success(`✅ Architecture promoted! ELO: ${data.elo}`);
      } else {
        toast.error('Failed to promote architecture');
      }
    } catch (error) {
      console.error('Error promoting architecture:', error);
      toast.error('Error promoting architecture');
    } finally {
      setIsLoading(false);
    }
  };

  // Prepare chart data
  const eloProgressData = history.map(gen => ({
    generation: gen.generation,
    bestELO: gen.best_genome?.performance?.elo || 0,
    avgELO: gen.avg_elo || 0
  }));

  const fitnessData = history.map(gen => ({
    generation: gen.generation,
    avgFitness: gen.avg_fitness || 0,
    bestFitness: gen.best_genome?.performance?.fitness_score || 0
  }));

  const architectureComplexityData = history.map(gen => {
    const arch = gen.best_genome?.architecture || {};
    return {
      generation: gen.generation,
      channels: arch.num_channels || 0,
      blocks: arch.num_res_blocks || 0,
      elo: gen.best_genome?.performance?.elo || 0
    };
  });

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <GitBranch className="w-8 h-8 text-blue-500" />
            Neural Architecture Search
          </h1>
          <p className="text-gray-600 mt-1">
            Evolutionary optimization of neural network architectures
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            onClick={fetchStatus}
            variant="outline"
            size="sm"
            disabled={isLoading}
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Status Banner */}
      {nasStatus.active && (
        <Card className="border-blue-500 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Activity className="w-5 h-5 text-blue-600 animate-pulse" />
                <div>
                  <p className="font-semibold text-blue-900">
                    NAS in Progress - Generation {nasStatus.current_generation} / {nasStatus.max_generations}
                  </p>
                  <p className="text-sm text-blue-700">
                    Progress: {nasStatus.progress_percent}%
                  </p>
                </div>
              </div>
              <div className="w-48 bg-blue-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all"
                  style={{ width: `${nasStatus.progress_percent}%` }}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Control Panel */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5" />
              NAS Controls
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Configuration */}
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-gray-700">Population Size</label>
                <input
                  type="number"
                  value={config.population_size}
                  onChange={(e) => setConfig({...config, population_size: parseInt(e.target.value)})}
                  min="8"
                  max="16"
                  disabled={nasStatus.active}
                  className="w-full mt-1 px-3 py-2 border rounded-md"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">Max Generations</label>
                <input
                  type="number"
                  value={config.max_generations}
                  onChange={(e) => setConfig({...config, max_generations: parseInt(e.target.value)})}
                  min="5"
                  max="20"
                  disabled={nasStatus.active}
                  className="w-full mt-1 px-3 py-2 border rounded-md"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">Mutation Rate</label>
                <input
                  type="number"
                  value={config.mutation_rate}
                  onChange={(e) => setConfig({...config, mutation_rate: parseFloat(e.target.value)})}
                  min="0.1"
                  max="0.5"
                  step="0.05"
                  disabled={nasStatus.active}
                  className="w-full mt-1 px-3 py-2 border rounded-md"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">Evaluation Games</label>
                <input
                  type="number"
                  value={config.evaluation_games}
                  onChange={(e) => setConfig({...config, evaluation_games: parseInt(e.target.value)})}
                  min="5"
                  max="20"
                  disabled={nasStatus.active}
                  className="w-full mt-1 px-3 py-2 border rounded-md"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="auto-trigger"
                  checked={config.auto_trigger}
                  onChange={(e) => setConfig({...config, auto_trigger: e.target.checked})}
                  disabled={nasStatus.active}
                  className="rounded"
                />
                <label htmlFor="auto-trigger" className="text-sm text-gray-700">
                  Auto-trigger after HPO completion
                </label>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="resume"
                  checked={config.resume}
                  onChange={(e) => setConfig({...config, resume: e.target.checked})}
                  disabled={nasStatus.active}
                  className="rounded"
                />
                <label htmlFor="resume" className="text-sm text-gray-700">
                  Resume from previous session
                </label>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 pt-4 border-t">
              {!nasStatus.active ? (
                <Button
                  onClick={handleStartNAS}
                  disabled={isLoading}
                  className="flex-1"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Start NAS
                </Button>
              ) : (
                <Button
                  onClick={handleStopNAS}
                  disabled={isLoading}
                  variant="destructive"
                  className="flex-1"
                >
                  <Square className="w-4 h-4 mr-2" />
                  Stop NAS
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Best Architecture */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5 text-yellow-500" />
              Best Architecture
            </CardTitle>
          </CardHeader>
          <CardContent>
            {bestArchitecture ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <p className="text-xs text-gray-600">ELO Rating</p>
                    <p className="text-2xl font-bold text-blue-600">
                      {bestArchitecture.performance?.elo?.toFixed(0) || 'N/A'}
                    </p>
                  </div>
                  
                  <div className="bg-green-50 p-3 rounded-lg">
                    <p className="text-xs text-gray-600">Win Rate</p>
                    <p className="text-2xl font-bold text-green-600">
                      {bestArchitecture.performance?.win_rate 
                        ? (bestArchitecture.performance.win_rate * 100).toFixed(1) + '%'
                        : 'N/A'}
                    </p>
                  </div>

                  <div className="bg-purple-50 p-3 rounded-lg">
                    <p className="text-xs text-gray-600">Channels</p>
                    <p className="text-2xl font-bold text-purple-600">
                      {bestArchitecture.architecture?.num_channels || 'N/A'}
                    </p>
                  </div>

                  <div className="bg-orange-50 p-3 rounded-lg">
                    <p className="text-xs text-gray-600">Res Blocks</p>
                    <p className="text-2xl font-bold text-orange-600">
                      {bestArchitecture.architecture?.num_res_blocks || 'N/A'}
                    </p>
                  </div>
                </div>

                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-600 mb-2">Architecture Details</p>
                  <div className="space-y-1 text-sm">
                    <p><span className="font-medium">Activation:</span> {bestArchitecture.architecture?.activation || 'N/A'}</p>
                    <p><span className="font-medium">FC Layers:</span> {bestArchitecture.architecture?.value_fc_layers?.join(', ') || 'N/A'}</p>
                    <p><span className="font-medium">Generation:</span> {bestArchitecture.generation || 'N/A'}</p>
                    <p className="text-xs text-gray-500 truncate"><span className="font-medium">Genome ID:</span> {bestArchitecture.genome_id || 'N/A'}</p>
                  </div>
                </div>

                <Button
                  onClick={handlePromoteArchitecture}
                  disabled={isLoading || !nasStatus.best_genome_id}
                  className="w-full"
                >
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Promote to Active Model
                </Button>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Layers className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>No architecture discovered yet</p>
                <p className="text-sm">Start NAS to begin evolution</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ELO Progress Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              ELO Evolution
            </CardTitle>
          </CardHeader>
          <CardContent>
            {eloProgressData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={eloProgressData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="generation" label={{ value: 'Generation', position: 'insideBottom', offset: -5 }} />
                  <YAxis label={{ value: 'ELO', angle: -90, position: 'insideLeft' }} />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="bestELO" stroke="#3b82f6" strokeWidth={2} name="Best ELO" />
                  <Line type="monotone" dataKey="avgELO" stroke="#94a3b8" strokeWidth={1} strokeDasharray="5 5" name="Avg ELO" />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-gray-400">
                No data yet
              </div>
            )}
          </CardContent>
        </Card>

        {/* Fitness Progress Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5" />
              Fitness Score Evolution
            </CardTitle>
          </CardHeader>
          <CardContent>
            {fitnessData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={fitnessData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="generation" label={{ value: 'Generation', position: 'insideBottom', offset: -5 }} />
                  <YAxis label={{ value: 'Fitness', angle: -90, position: 'insideLeft' }} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="bestFitness" fill="#10b981" name="Best Fitness" />
                  <Bar dataKey="avgFitness" fill="#94a3b8" name="Avg Fitness" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-gray-400">
                No data yet
              </div>
            )}
          </CardContent>
        </Card>

        {/* Architecture Complexity vs Performance */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Layers className="w-5 h-5" />
              Architecture Complexity vs Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            {architectureComplexityData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <ScatterChart>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    type="number" 
                    dataKey="channels" 
                    name="Channels"
                    label={{ value: 'Channels', position: 'insideBottom', offset: -5 }}
                  />
                  <YAxis 
                    type="number" 
                    dataKey="elo" 
                    name="ELO"
                    label={{ value: 'ELO', angle: -90, position: 'insideLeft' }}
                  />
                  <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                  <Legend />
                  <Scatter 
                    name="Architectures" 
                    data={architectureComplexityData} 
                    fill="#8b5cf6"
                  />
                </ScatterChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-gray-400">
                No data yet
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Evolution History Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GitBranch className="w-5 h-5" />
            Evolution History
          </CardTitle>
        </CardHeader>
        <CardContent>
          {history.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left">Gen</th>
                    <th className="px-4 py-2 text-left">Best ELO</th>
                    <th className="px-4 py-2 text-left">Avg ELO</th>
                    <th className="px-4 py-2 text-left">Channels</th>
                    <th className="px-4 py-2 text-left">Blocks</th>
                    <th className="px-4 py-2 text-left">Activation</th>
                    <th className="px-4 py-2 text-left">Fitness</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {history.slice().reverse().map((gen, idx) => {
                    const arch = gen.best_genome?.architecture || {};
                    const perf = gen.best_genome?.performance || {};
                    
                    return (
                      <tr key={idx} className="hover:bg-gray-50">
                        <td className="px-4 py-2 font-medium">{gen.generation}</td>
                        <td className="px-4 py-2">
                          <span className="font-semibold text-blue-600">
                            {perf.elo?.toFixed(0) || 'N/A'}
                          </span>
                        </td>
                        <td className="px-4 py-2 text-gray-600">{gen.avg_elo?.toFixed(0) || 'N/A'}</td>
                        <td className="px-4 py-2">{arch.num_channels || 'N/A'}</td>
                        <td className="px-4 py-2">{arch.num_res_blocks || 'N/A'}</td>
                        <td className="px-4 py-2">
                          <span className="px-2 py-1 bg-purple-100 text-purple-700 rounded text-xs">
                            {arch.activation || 'N/A'}
                          </span>
                        </td>
                        <td className="px-4 py-2">{perf.fitness_score?.toFixed(2) || 'N/A'}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <GitBranch className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>No evolution history yet</p>
              <p className="text-sm">History will appear after first generation</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default NeuralArchitectureSearch;
