import React, { createContext, useContext, useState } from 'react';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const GameContext = createContext();

export const useGame = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within GameProvider');
  }
  return context;
};

export const GameProvider = ({ children }) => {
  const [gameId, setGameId] = useState(null);
  const [gameState, setGameState] = useState(null);
  const [aiThinking, setAiThinking] = useState(false);
  const [numSimulations, setNumSimulations] = useState(200);
  const [aiColor, setAiColor] = useState('black');
  const [loading, setLoading] = useState(false);
  const [llmExplanation, setLlmExplanation] = useState(null);
  const [llmLoading, setLlmLoading] = useState(false);
  const [coachingMode, setCoachingMode] = useState(false);

  const startNewGame = async () => {
    try {
      setLoading(true);
      const response = await axios.post(`${API}/game/new`, { ai_color: aiColor });
      
      setGameId(response.data.game_id);
      setGameState({
        fen: response.data.fen,
        legal_moves: response.data.legal_moves,
        is_game_over: response.data.is_game_over,
        result: response.data.result,
        history: response.data.history
      });
      
      toast.success('New game started!');
    } catch (error) {
      console.error('Error starting game:', error);
      toast.error('Failed to start game');
    } finally {
      setLoading(false);
    }
  };

  const makeMove = async (move) => {
    if (!gameId || aiThinking) return;

    try {
      const response = await axios.post(`${API}/game/move`, {
        game_id: gameId,
        move: move
      });

      setGameState({
        fen: response.data.fen,
        legal_moves: response.data.legal_moves,
        is_game_over: response.data.is_game_over,
        result: response.data.result,
        history: response.data.history
      });

      // If game is not over and it's AI's turn, get AI move
      if (!response.data.is_game_over) {
        await getAIMove();
      } else {
        toast.info(`Game Over: ${response.data.result}`);
        // Log completed game for adaptive learning
        await logGameCompletion(response.data.result, response.data.history);
      }
    } catch (error) {
      console.error('Error making move:', error);
      toast.error(error.response?.data?.detail || 'Invalid move');
    }
  };

  const getLLMExplanation = async (fen, lastMove) => {
    try {
      setLlmLoading(true);
      const response = await axios.post(`${API}/llm/explain`, {
        fen: fen,
        last_move: lastMove,
        context: "Explain this chess position and the last move played."
      });
      
      setLlmExplanation({
        text: response.data.explanation,
        move: lastMove,
        offline: response.data.offline || false
      });
    } catch (error) {
      console.error('Error getting LLM explanation:', error);
      setLlmExplanation({
        text: "Position analysis unavailable. The AI is learning from your games.",
        move: lastMove,
        offline: true
      });
    } finally {
      setLlmLoading(false);
    }
  };

  const getAIMove = async () => {
    if (!gameId) return;

    try {
      setAiThinking(true);
      const response = await axios.post(`${API}/game/ai-move`, {
        game_id: gameId,
        num_simulations: numSimulations
      });

      setGameState({
        fen: response.data.fen,
        legal_moves: response.data.legal_moves,
        is_game_over: response.data.is_game_over,
        result: response.data.result,
        history: response.data.history
      });

      toast.success(`AI played: ${response.data.move} (${response.data.computation_time.toFixed(2)}s)`);

      // Get LLM explanation for the AI's move
      await getLLMExplanation(response.data.fen, response.data.move);

      if (response.data.is_game_over) {
        toast.info(`Game Over: ${response.data.result}`);
        // Log completed game for adaptive learning
        await logGameCompletion(response.data.result, response.data.history);
      }
    } catch (error) {
      console.error('Error getting AI move:', error);
      toast.error('AI failed to make a move');
    } finally {
      setAiThinking(false);
    }
  };

  const logGameCompletion = async (result, history) => {
    try {
      await axios.post(`${API}/game/complete`, {
        game_id: gameId,
        result: result,
        moves: history,
        ai_color: aiColor
      });
      console.log('Game completion logged for adaptive learning');
    } catch (error) {
      console.error('Error logging game completion:', error);
      // Don't show error toast to user, this is a background operation
    }
  };

  const value = {
    gameId,
    gameState,
    aiThinking,
    numSimulations,
    setNumSimulations,
    aiColor,
    setAiColor,
    loading,
    llmExplanation,
    llmLoading,
    coachingMode,
    setCoachingMode,
    startNewGame,
    makeMove,
    getAIMove,
    getLLMExplanation
  };

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
};
